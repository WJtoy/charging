package com.gdcdgj.charging.api.constant;

/**
 * @author JianMei Chen
 * @date 2020/05/11/11:01
 */
public class Constant {

    /**
     * 默认字符集
     */
    public static final String DEFAULT_CHARSET = "UTF-8";
}
