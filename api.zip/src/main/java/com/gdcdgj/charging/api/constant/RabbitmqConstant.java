package com.gdcdgj.charging.api.constant;

/**
 * rabbitmq常量
 *
 * @author Changliang Tao
 * @date 2020/4/18 11:56
 * @since JDK 1.8
 */
public class RabbitmqConstant {
    /**
     * 充电桩
     */
    // 签到队列
    public static final String SIGN_IN_PILE_QUEUE = "sign_in_pile_queue";
    // i签到交换机
    public static final String SIGN_IN_PILE_EXCHANGE = "sign_in_pile_exchange";
    // 签到路由键
    public static final String SIGN_IN_PILE_ROUTING_KEY = "signIn";

    // 启动队列
    public static final String START_PILE_QUEUE = "start_pile_queue";
    // 启动交换机
    public static final String START_PILE_EXCHANGE = "start_pile_exchange";
    // 启动路由键
    public static final String START_PILE_ROUTING_KEY = "start";

    // 停止队列
    public static final String STOP_PILE_QUEUE="stop_pile_queue";
    // 停止交换机
    public static final String STOP_PILE_EXCHANGE="stop_pile_exchange";
    // 停止路由键
    public static final String STOP_PILE_ROUTING_KEY="stop";

    // 设置服务类型
    public static final String SERVICE_TYPE_QUEUE = "service_type_queue";
    public static final String SERVICE_TYPE_EXCHANGE = "service_type_exchange";
    public static final String SERVICE_TYPE_ROUTING_KEY = "serviceType";

    // 死信队列
    public static final String DEAD_QUEUE_NAME = "dead_queue";
    // 死信交换机
    public static final String DEAD_EXCHANGE_NAME = "dead_topic_exchange";
    // 死信路由键
    public static final String DEAD_ROUTING_KEY = "#";
    // 消息过期时间为1分钟
    public static final Integer MESSAGE_TTL = 60 * 1000;

    //启动修改状态队列
    public static final String START_MODIFY_STATUS_QUEUE="start_modify_status_queue";
    //启动修改状态交换机
    public static final String START_MODIFY_STATUS_EXCHANGE="strat_modify_status_exchange";
    //启动修改状态路由键
    public static final String START_MODIFY_STATUS_ROUTING_KEY="start_modify_status";
    
    //宜步状态信息包队列
    public static final String MOUDLEINFO_STATUS_QUEUE="moudleInfo_status_queue";
    //宜步状态信息包交换机
    public static final String MOUDLEINFO_STATUS_EXCHANGE="moudleInfo_status_exchange";
    //宜步状态信息包路由键
    public static final String MOUDLEINFO_STATUS_ROUTING_KEY="moudleInfo_status";
    
    //充电桩启动结果队列
    public static final String STARTED_STATUS_QUEUE="started_status_queue";
    //充电桩启动结果交换机
    public static final String STARTED_STATUS_EXCHANGE="started_status_exchange";
    //充电桩启动结果路由键
    public static final String STARTED_STATUS_ROUTING_KEY="started_status";
    
    //科旺状态信息上报队列
    public static final String STATEINFO_STATUS_QUEUE="stateInfo_status_queue";
    //科旺状态信息上报交换机
    public static final String STATEINFO_STATUS_EXCHANGE="stateInfo_status_exchange";
    //科旺状态信息上报路由键
    public static final String STATEINFO_STATUS_ROUTING_KEY="stateInfo_status";
    
    //充电结束记录上报包队列
    public static final String CHARGEINFO_STATUS_QUEUE="chargeInfo_status_queue";
    //充电结束记录上报包交换机
    public static final String CHARGEINFO_STATUS_EXCHANGE="chargeInfo_status_exchange";
    //充电结束记录上报包路由键
    public static final String CHARGEINFO_STATUS_ROUTING_KEY="chargeInfo_status";
}
