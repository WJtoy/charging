package com.gdcdgj.charging.api.constant;

/**
 * @author Changliang Tao
 * @date 2020/4/17 15:37
 * @since JDK 1.8
 */
public class RedisConstant {
    //会员登陆Token
    public static final String MEMBER_LOGIN_TOKEN = "member_login_token_";
    public static int MEMBER_LOGIN_TOKEN_EXPIRE = 60 * 60 * 24;//有效期为1天
    // token_prefix
    public static final String TOKEN_PREFIX="token:";
    //员工登陆Token
    public static final String EMPLOYEE_LOGIN_TOKEN = "employee_login_token_";
    public static int EMPLOYEE_LOGIN_TOKEN_EXPIRE = 60 * 60 * 24;//有效期为1天
    // ib充电桩签到消息
    public static final String IB_SIGN_IN = "ib_signIn";
    public static final int CHARGING_PILE_VO_EXPIRE = 60 * 60 * 24;
}
