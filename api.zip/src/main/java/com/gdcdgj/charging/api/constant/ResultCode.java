package com.gdcdgj.charging.api.constant;

/**
 * @author Changliang Tao
 * @date 2020/4/17 15:33
 * @since JDK 1.8
 */
public class ResultCode {
    /**
     * 请求参数必填字段为空状态
     */
    public static final String TOKEN_CODE = "04";
    /**
     * 请求参数必填字段为空中文字符
     */
    public static final String TOKEN_MSG = "token error";
    /**
     * 统一失败状态
     */
    public static final String FAIL_CODE = "99";
    /**
     * 统一失败状态中文字符
     */
    public static final String FAIL_MSG = "网络繁忙，请稍后重试";

    /**************会员******************** */
    public static final String MEMBER_NOT_EXISTS_CODE = "1000";
    public static final String MEMBER_NOT_EXISTS_MSG = "会员不存在";
    /**
     * 根据手机号码进行登陆操作时，输入的手机号码有误
     */
    public static final String MEMBER_LOGIN_PHONE_CODE = "100301";
    public static final String MEMBER_LOGIN_PHONE_MSG = "您输入手机号码有误，请重新输入";

    public static final String MEMBER_PHONE_EXISTS_CODE = "100201";
    public static final String MEMBER_PHONE_EXISTS_MSG = "您输入的手机号码已存在，请重新输入";
    public static final String MEMBER_PHONE_FORMAT_ERROR_CODE = "100202";
    public static final String MEMBER_PHONE_FORMAT_ERROR_MSG = "您输入的手机号码格式有误，请重新输入";
    /**
     * 扫码充电时
     */
    // 二维码错误
    public static final String QR_CODE_ERROR_CODE = "100003";
    public static final String QR_CODE_ERROR_MSG = "二维码有误，请选择其他充电枪";
    // 充电枪桩不为空闲时
    public static final String CONNECTOR_STATUS_NOT_FREE_CODE = "100004";
    public static final String CONNECTOR_STATUS_NOT_FREE_MSG = "充电枪不是待机状态";
    // 充电枪与车 未连接时
    public static final String CONNECTOR_DISCONNECTED_CODE = "100005";
    public static final String CONNECTOR_DISCONNECTED_MSG = "请检查充电枪是否已插好";
    // 充电桩离线
    public static final String CHARGING_PILE_OFFLINE_CODE = "100006";
    public static final String CHARGING_PILE_OFFLINE_MSG = "充电桩已离线";
    // 会员状态为停用
    public static final String MEMBER_STATUS_STOP_USE_CODE = "100007";
    public static final String MEMBER_STATUS_STOP_USE_MSG = "会员已停用";
    // 会员状态为临时冻结
    public static final String MEMBER_STATUS_TEMPORARY_FREEZE_CODE = "100008";
    public static final String MEMBER_STATUS_TEMPORARY_FREEZE_MSG = "会员已临时冻结";
    // 会员状态为临时冻结
    public static final String MEMBER_STATUS_PERMANENT_FREEZE_CODE = "100009";
    public static final String MEMBER_STATUS_PERMANENT_MSG = "会员已永久冻结";
    // 会员存在正在充电、结束充电、未付费的订单
    public static final String MEMBER_IN_PROCESS_CODE = "100010";
    public static final String MEMBER_IN_PROCESS_MSG = "会员存在正在充电、结束充电、未付费的订单";
    // 会员钱包余额不足
    public static final String MEMBER_WALLET_SHORTAGE_CODE = "100011";
    public static final String MEMBER_WALLET_SHORTAGE_MSG = "会员钱包余额不足";
    // 启动充电成功
    public static final String SUCCESS_START_CHARGING_CODE = "100012";
    public static final String SUCCESS_START_CHARGING_MSG = "启动充电成功";

    public static final String PARAM_REQUIRED_CODE = "03";
    public static final String PARAM_REQUIRED_MSG = "请求参数必填字段为空";

    public static final String SUCCESS_CODE = "00";
    public static final String SUCCESS_MSG = "操作成功";

}
