package com.gdcdgj.charging.api.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 充电桩
 * </p>
 *
 * @author tcl
 * @since 2020-04-30
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="AssetsChargingpile对象", description="充电桩")
public class AssetsChargingpile implements Serializable {

    private static final long serialVersionUID=1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "电桩编号")
    private String code;

    @ApiModelProperty(value = "是否启用")
    private Boolean isEnabled;

    @ApiModelProperty(value = "是否在线")
    private Boolean isOnline;

    @ApiModelProperty(value = "设备型号")
    private String equipmentModel;

    @ApiModelProperty(value = "设备出厂编号")
    private String equipmentCode;

    @ApiModelProperty(value = "生产日期")
    private Date productionDate;

    @ApiModelProperty(value = "设备类型")
    private Integer equipmentType;

    @ApiModelProperty(value = "充电枪数量")
    private Integer connectorNumber;

    @ApiModelProperty(value = "批次")
    private String batch;

    @ApiModelProperty(value = "同批次数量")
    private Integer batchTotal;

    @ApiModelProperty(value = "额定电压上限")
    private Integer ratedVoltageUpper;

    @ApiModelProperty(value = "额定电压下限")
    private Integer ratedVoltageBottom;

    @ApiModelProperty(value = "额定电流")
    private Integer ratedCurrent;

    @ApiModelProperty(value = "额定功率")
    private Integer ratedPower;

    @ApiModelProperty(value = "总订单量")
    private Integer totalChargingorderNums;

    @ApiModelProperty(value = "总充电时长")
    private Integer totalChargingTime;

    @ApiModelProperty(value = "总充电电量")
    private Double totalChargingQuantity;

    @ApiModelProperty(value = "总营收")
    private Double totalPrice;

    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    @ApiModelProperty(value = "更新时间")
    private Date updateTime;

    @ApiModelProperty(value = "所属区域")
    private Integer cityId;

    @ApiModelProperty(value = "所属运营商")
    private Integer companyId;

    @ApiModelProperty(value = "创建人")
    private Integer createById;

    @ApiModelProperty(value = "区域负责人")
    private Integer managerId;

    @ApiModelProperty(value = "设备供应商")
    private Integer providerId;

    @ApiModelProperty(value = "站点")
    private Integer stationId;

    @ApiModelProperty(value = "更新人")
    private Integer updateById;

    @ApiModelProperty(value = "软件版本号")
    private Integer versionId;


}
