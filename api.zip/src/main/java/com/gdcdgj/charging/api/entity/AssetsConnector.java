package com.gdcdgj.charging.api.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 充电枪
 * </p>
 *
 * @author tcl
 * @since 2020-04-30
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="AssetsConnector对象", description="充电枪")
public class AssetsConnector implements Serializable {

    private static final long serialVersionUID=1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "枪口号(充电桩底层接口号)")
    private Integer serialNo;

    @ApiModelProperty(value = "枪编号")
    private String code;

    @ApiModelProperty(value = "枪名称")
    private String name;

    @ApiModelProperty(value = "状态")
    private Integer status;

    @ApiModelProperty(value = "停车位号码")
    private String parkNum;

    @ApiModelProperty(value = "接口类型")
    private Integer portType;

    @ApiModelProperty(value = "锁定原因")
    private String lockCode;

    @ApiModelProperty(value = "连接状态")
    private Integer connectStatus;

    @ApiModelProperty(value = "所属区域")
    private Integer cityId;

    @ApiModelProperty(value = "所属运营商")
    private Integer companyId;

    @ApiModelProperty(value = "区域负责人")
    private Integer managerId;

    @ApiModelProperty(value = "充电桩")
    private Integer pileId;

    @ApiModelProperty(value = "站点")
    private Integer stationId;

    @ApiModelProperty(value = "最近故障编码")
    private String faultCode;

    @ApiModelProperty(value = "最近故障时间")
    private Date faultTime;

    @ApiModelProperty(value = "最近锁定时间")
    private Date lockTime;

    public void setCode(String code,Integer serialNo) {
    	this.code = code+ (serialNo >= 10 ? serialNo: "0"+serialNo);
    }
}
