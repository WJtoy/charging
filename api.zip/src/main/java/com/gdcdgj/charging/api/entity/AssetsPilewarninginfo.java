package com.gdcdgj.charging.api.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 电桩告警记录信息
 * </p>
 *
 * @author tcl
 * @since 2020-04-30
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="AssetsPilewarninginfo对象", description="电桩告警记录信息")
public class AssetsPilewarninginfo implements Serializable {

    private static final long serialVersionUID=1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "告警编码")
    private Integer code;

    @ApiModelProperty(value = "产生时间")
    private Date produceTime;

    @ApiModelProperty(value = "级别")
    private Integer level;

    @ApiModelProperty(value = "责任类型")
    private Integer dutyType;

    @ApiModelProperty(value = "故障类型")
    private Integer hitchType;

    @ApiModelProperty(value = "告警内容")
    private String content;

    @ApiModelProperty(value = "是否恢复")
    private Boolean isRecovered;

    @ApiModelProperty(value = "恢复时间")
    private Date recoverTime;

    @ApiModelProperty(value = "所属运营商")
    private Integer companyId;

    @ApiModelProperty(value = "充电枪")
    private Integer connectorId;

    @ApiModelProperty(value = "充电桩")
    private Integer pileId;

    @ApiModelProperty(value = "站点")
    private Integer stationId;


}
