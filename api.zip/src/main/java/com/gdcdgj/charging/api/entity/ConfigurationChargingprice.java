package com.gdcdgj.charging.api.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * 价格模板
 * </p>
 *
 * @author tcl
 * @since 2020-05-08
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="ConfigurationChargingprice对象", description="价格模板")
public class ConfigurationChargingprice implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "模板名")
    private String name;

    @ApiModelProperty(value = "模板描述")
    private String description;

    @ApiModelProperty(value = "级别")
    private Integer level;

    @ApiModelProperty(value = "是否启用")
    private Boolean isEnabled;

    @ApiModelProperty(value = "是否统一全部费用")
    private Boolean isFlatFee;

    @ApiModelProperty(value = "是否统一服务费")
    private Boolean isServiceFlatFee;

    @ApiModelProperty(value = "电费（统一模式）")
    private BigDecimal chargingPrice;

    @ApiModelProperty(value = "服务费（统一模式）")
    private BigDecimal servicePrice;

    @ApiModelProperty(value = "峰时电费")
    private BigDecimal peaksChargingPrice;

    @ApiModelProperty(value = "峰时服务费")
    private BigDecimal peaksServicePrice;

    @ApiModelProperty(value = "平时电费")
    private BigDecimal normalChargingPrice;

    @ApiModelProperty(value = "平时服务费")
    private BigDecimal normalServicePrice;

    @ApiModelProperty(value = "谷时电费")
    private BigDecimal valleysChargingPrice;

    @ApiModelProperty(value = "谷时服务费")
    private BigDecimal valleysServicePrice;

    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    @ApiModelProperty(value = "更新时间")
    private Date updateTime;

    @ApiModelProperty(value = "创建人")
    private Integer createById;

    @ApiModelProperty(value = "更新人")
    private Integer updateById;

    @ApiModelProperty(value = "已绑定站点数量")
    private Integer bindCount;


}
