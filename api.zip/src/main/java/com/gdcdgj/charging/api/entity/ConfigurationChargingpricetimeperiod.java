package com.gdcdgj.charging.api.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 价格模板时间段
 * </p>
 *
 * @author tcl
 * @since 2020-04-30
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="ConfigurationChargingpricetimeperiod对象", description="价格模板时间段")
public class ConfigurationChargingpricetimeperiod implements Serializable {

    private static final long serialVersionUID=1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "所属峰平谷")
    private String pnvType;

    @ApiModelProperty(value = "开始时间点")
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private Date start;

    @ApiModelProperty(value = "结束时间点")
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private Date end;

    @ApiModelProperty(value = "价格模板")
    private Integer priceId;


}
