package com.gdcdgj.charging.api.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * <p>
 * 充电桩告警消息配置
 * </p>
 *
 * @author tcl
 * @since 2020-04-30
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="ConfigurationEquipmentcode对象", description="充电桩告警消息配置")
public class ConfigurationEquipmentcode implements Serializable {

    private static final long serialVersionUID=1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "级别")
    private Integer customizeLevel;

    @ApiModelProperty(value = "责任类型")
    private Integer customizeDuty;

    @ApiModelProperty(value = "故障类型")
    private Integer customizeHitch;

    @ApiModelProperty(value = "厂商消息分类")
    private Integer category;

    @ApiModelProperty(value = "传输回来的是否是字节码形式")
    private Boolean isByteCode;

    @ApiModelProperty(value = "错误码")
    private Integer code;

    @ApiModelProperty(value = "字节码字节顺序")
    private Integer byteNo;

    @ApiModelProperty(value = "字节码字节内偏移量")
    private Integer bytePosition;

    @ApiModelProperty(value = "含义")
    private String name;

    @ApiModelProperty(value = "描述")
    private String description;

    @ApiModelProperty(value = "供应商")
    private Integer providerId;


}
