package com.gdcdgj.charging.api.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 会员账户充值记录
 * </p>
 *
 * @author tcl
 * @since 2020-05-28
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="CustomerChargingorder对象", description="会员账户充值记录")
public class CustomerChargingorder implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "订单号")
    private String orderNo;

    @ApiModelProperty(value = "扫码时间")
    private Date scanTime;

    @ApiModelProperty(value = "订单生成时间")
    private Date orderTime;

    @ApiModelProperty(value = "充电开始时间")
    private Date startTime;

    @ApiModelProperty(value = "峰时充电时长")
    private Integer peaksChargingTime;

    @ApiModelProperty(value = "峰时充电电量")
    private Double peaksChargingQuantity;

    @ApiModelProperty(value = "峰时电费")
    private Double peaksChargingPrice;

    @ApiModelProperty(value = "峰时服务费")
    private Double peaksServicePrice;

    @ApiModelProperty(value = "平时充电时长")
    private Integer normalChargingTime;

    @ApiModelProperty(value = "平时充电电量")
    private Double normalChargingQuantity;

    @ApiModelProperty(value = "平时电费")
    private Double normalChargingPrice;

    @ApiModelProperty(value = "平时服务费")
    private Double normalServicePrice;

    @ApiModelProperty(value = "谷时充电时长")
    private Integer valleysChargingTime;

    @ApiModelProperty(value = "谷时充电电量")
    private Double valleysChargingQuantity;

    @ApiModelProperty(value = "谷时电费")
    private Double valleysChargingPrice;

    @ApiModelProperty(value = "谷时服务费")
    private Double valleysServicePrice;

    @ApiModelProperty(value = "总充电时长")
    private Integer totalChargingTime;

    @ApiModelProperty(value = "总充电电量")
    private Double totalChargingQuantity;

    @ApiModelProperty(value = "总电费")
    private Double totalChargingPrice;

    @ApiModelProperty(value = "总服务费")
    private Double totalServicePrice;

    @ApiModelProperty(value = "总费用")
    private Double totalPrice;

    @ApiModelProperty(value = "起始SOC电量")
    private Double socStart;

    @ApiModelProperty(value = "结束SOC电量")
    private Double socEnd;

    @ApiModelProperty(value = "起始电表度数kwh")
    private Double electricStart;

    @ApiModelProperty(value = "起始电表度数kwh")
    private Double electricEnd;

    @ApiModelProperty(value = "充电结束时间")
    private Date stopTime;

    @ApiModelProperty(value = "订单结束方式")
    private Integer stopMethod;

    @ApiModelProperty(value = "账单生成时间")
    private Date billTime;

    @ApiModelProperty(value = "支付时间")
    private Date payTime;

    @ApiModelProperty(value = "钱包余额支付金额")
    private Double walletPayAmount;

    @ApiModelProperty(value = "实际余额支付金额")
    private Double realPayAmount;

    @ApiModelProperty(value = "充电枪编号")
    private String connectorCode;

    @ApiModelProperty(value = "会员手机号")
    private String memberPhone;

    @ApiModelProperty(value = "区划代码")
    private String cityCode;

    @ApiModelProperty(value = "区划")
    private Integer cityId;

    @ApiModelProperty(value = "运营商")
    private Integer companyId;

    @ApiModelProperty(value = "充电枪")
    private Integer connectorId;

    @ApiModelProperty(value = "会员")
    private Integer memberId;

    @ApiModelProperty(value = "充电桩")
    private Integer pileId;

    @ApiModelProperty(value = "设备商")
    private Integer pileProviderId;

    @ApiModelProperty(value = "站点")
    private Integer stationId;

    @ApiModelProperty(value = "电流")
    private Double current;

    @ApiModelProperty(value = "剩余充电时间")
    private Integer leftTime;

    @ApiModelProperty(value = "需求电流")
    private Double requireCurrent;

    @ApiModelProperty(value = "需求电压")
    private Double requireVoltage;

    @ApiModelProperty(value = "电压")
    private Double voltage;

    @ApiModelProperty(value = "订单充电状态")
    private Integer chargingStatus;

    @ApiModelProperty(value = "订单支付状态")
    private Integer paymentStatus;

    @ApiModelProperty(value = "异常订单告警编码")
    private Integer warningCode;

    @ApiModelProperty(value = "车辆VIN码")
    private String vinCode;

    @ApiModelProperty(value = "计价标准，由当前及未来一段时间（24小时）内生效的多个模板综合出本订单应该参照的计费时段和单价。JSON格式存储。参考信息：段内开始/结束时间、电费单价、服务费单价")
    private String priceUnit;

    @ApiModelProperty(value = "计价运营过程标准，JSON格式存储。参考信息：段内开始/结束时间、用电量、电费、服务费")
    private String priceCalculation;

    public Integer getLeftTime() {
        if(leftTime==null)
            leftTime=0;
        return leftTime;
    }

    public void setLeftTime(Integer leftTime) {
        this.leftTime = leftTime;
    }

    public Double getVoltage(){
        if (voltage==null)
            voltage=0.0;
        return voltage;
    }

    public void setVoltage(Double voltage){
        this.voltage=voltage;
    }

    public Double getCurrent(){
        if (current==null)
            current=0.0;
        return current;
    }

    public void setCurrent(Double current){
        this.current=current;
    }

    public Integer getTotalChargingTime() {
        if (totalChargingTime==null)
            totalChargingTime=0;
        return totalChargingTime;
    }

    public void setTotalChargingTime(Integer totalChargingTime) {
        this.totalChargingTime = totalChargingTime;
    }

    public Double getTotalChargingQuantity() {
        if (totalChargingQuantity==null)
            totalChargingQuantity=0.0;
        return totalChargingQuantity;
    }

    public void setTotalChargingQuantity(Double totalChargingQuantity) {
        this.totalChargingQuantity = totalChargingQuantity;
    }

    public Double getTotalChargingPrice() {
        if (totalChargingPrice==null)
            totalChargingPrice=0.0;
        return totalChargingPrice;
    }

    public void setTotalChargingPrice(Double totalChargingPrice) {
        this.totalChargingPrice = totalChargingPrice;
    }

    public Double getTotalServicePrice() {
        if (totalServicePrice==null)
            totalServicePrice=0.0;
        return totalServicePrice;
    }

    public void setTotalServicePrice(Double totalServicePrice) {
        this.totalServicePrice = totalServicePrice;
    }

    public Double getTotalPrice() {
        if (totalPrice==null)
            totalPrice=0.0;
        return totalPrice;
    }

    public Double getSocStart() {
        if (socStart==null)
            socStart=0.0;
        return socStart;
    }

    public void setSocStart(Double socStart) {
        this.socStart = socStart;
    }

    public Double getSocEnd() {
        if (socEnd==null)
            socEnd=0.0;
        return socEnd;
    }

    public void setSocEnd(Double socEnd) {
        this.socEnd = socEnd;
    }

    public Date getStopTime() {
        if(stopTime==null)
            stopTime=new Date();
        return stopTime;
    }

    public void setStopTime(Date stopTime) {
        this.stopTime = stopTime;
    }


    public Integer getPeaksChargingTime() {
        if (peaksChargingPrice == null){
            peaksChargingPrice = 0.0;
        }
        return peaksChargingTime;
    }

    public void setPeaksChargingTime(Integer peaksChargingTime) {
        this.peaksChargingTime = peaksChargingTime;
    }

    public Double getPeaksChargingQuantity() {
        if (peaksChargingQuantity == null){
            peaksChargingQuantity = 0.0;
        }
        return peaksChargingQuantity;
    }

    public void setPeaksChargingQuantity(Double peaksChargingQuantity) {
        this.peaksChargingQuantity = peaksChargingQuantity;
    }

    public Double getPeaksChargingPrice() {
        if (peaksChargingPrice == null){
            peaksChargingPrice = 0.0;
        }
        return peaksChargingPrice;
    }

    public void setPeaksChargingPrice(Double peaksChargingPrice) {
        this.peaksChargingPrice = peaksChargingPrice;
    }

    public Double getPeaksServicePrice() {
        if (peaksServicePrice == null){
            peaksServicePrice = 0.0;
        }
        return peaksServicePrice;
    }

    public void setPeaksServicePrice(Double peaksServicePrice) {
        this.peaksServicePrice = peaksServicePrice;
    }

    public Integer getNormalChargingTime() {
        if (normalChargingPrice == null){
            normalChargingTime = 0;
        }
        return normalChargingTime;
    }

    public void setNormalChargingTime(Integer normalChargingTime) {
        this.normalChargingTime = normalChargingTime;
    }

    public Double getNormalChargingQuantity() {
        if (normalChargingQuantity == null){
            normalChargingQuantity = 0.0;
        }
        return normalChargingQuantity;
    }

    public void setNormalChargingQuantity(Double normalChargingQuantity) {
        this.normalChargingQuantity = normalChargingQuantity;
    }

    public Double getNormalChargingPrice() {
        if (normalChargingPrice == null){
            normalChargingPrice = 0.0;
        }
        return normalChargingPrice;
    }

    public void setNormalChargingPrice(Double normalChargingPrice) {
        this.normalChargingPrice = normalChargingPrice;
    }

    public Double getNormalServicePrice() {
        if (normalServicePrice== null){
            normalServicePrice= 0.0;
        }
        return normalServicePrice;
    }

    public void setNormalServicePrice(Double normalServicePrice) {
        this.normalServicePrice = normalServicePrice;
    }

    public Integer getValleysChargingTime() {
        if (valleysChargingTime == null){
            valleysChargingTime = 0;
        }
        return valleysChargingTime;
    }

    public void setValleysChargingTime(Integer valleysChargingTime) {
        this.valleysChargingTime = valleysChargingTime;
    }

    public Double getValleysChargingQuantity() {
        if (valleysChargingQuantity == null){
            valleysChargingQuantity = 0.0;
        }
        return valleysChargingQuantity;
    }

    public void setValleysChargingQuantity(Double valleysChargingQuantity) {
        this.valleysChargingQuantity = valleysChargingQuantity;
    }

    public Double getValleysChargingPrice() {
        if (valleysChargingPrice == null ){
            valleysChargingPrice = 0.0;
        }
        return valleysChargingPrice;
    }

    public void setValleysChargingPrice(Double valleysChargingPrice) {
        this.valleysChargingPrice = valleysChargingPrice;
    }

    public Double getValleysServicePrice() {
        if (valleysServicePrice == null){
            valleysServicePrice =0.0;
        }
        return valleysServicePrice;
    }

    public void setValleysServicePrice(Double valleysServicePrice) {
        this.valleysServicePrice = valleysServicePrice;
    }

}
