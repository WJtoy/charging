package com.gdcdgj.charging.api.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 充电订单过程轨迹跟踪
 * </p>
 *
 * @author tcl
 * @since 2020-05-28
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="CustomerChargingordertracks对象", description="充电订单过程轨迹跟踪")
public class CustomerChargingordertracks implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "当前时间")
    private Date addTime;

    @ApiModelProperty(value = "总充电时长")
    private Integer totalChargingTime;

    @ApiModelProperty(value = "总电费")
    private Double totalChargingPrice;

    @ApiModelProperty(value = "总服务费")
    private Double totalServicePrice;

    @ApiModelProperty(value = "总费用")
    private Double totalPrice;

    @ApiModelProperty(value = "电压")
    private Double voltage;

    @ApiModelProperty(value = "电流")
    private Double current;

    @ApiModelProperty(value = "需求电压")
    private Double requireVoltage;

    @ApiModelProperty(value = "需求电流")
    private Double requireCurrent;

    @ApiModelProperty(value = "预计剩余时间")
    private Integer leftTime;

    @ApiModelProperty(value = "充电订单")
    private Integer orderId;

    @ApiModelProperty(value = "总充电电量")
    private Double totalChargingQuantity;

    @ApiModelProperty(value = "交流A相电流")
    private Double acACurrent;

    @ApiModelProperty(value = "交流A相电压")
    private Double acAVoltage;

    @ApiModelProperty(value = "交流B相电流")
    private Double acBCurrent;

    @ApiModelProperty(value = "交流B相电压")
    private Double acBVoltage;

    @ApiModelProperty(value = "交流C相电流")
    private Double acCCurrent;

    @ApiModelProperty(value = "交流C相电压")
    private Double acCVoltage;

    @ApiModelProperty(value = "当前电表读数（kwh)")
    private Double electric;

    @ApiModelProperty(value = "当前功率")
    private Double power;

    @ApiModelProperty(value = "当前BMS的SOC电量")
    private Double soc;

    @ApiModelProperty(value = "出风口温度")
    private Double temperatureAiroutlet;

    @ApiModelProperty(value = "充电枪温度")
    private Double temperatureConnector;

    @ApiModelProperty(value = "环境温度")
    private Double temperatureEnvironment;


}
