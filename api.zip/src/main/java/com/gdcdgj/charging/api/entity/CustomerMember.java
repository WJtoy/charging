package com.gdcdgj.charging.api.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 会员
 * </p>
 *
 * @author tcl
 * @since 2020-04-30
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="CustomerMember对象", description="会员")
public class CustomerMember implements Serializable {

    private static final long serialVersionUID=1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "会员状态")
    private Integer status;

    @ApiModelProperty(value = "手机号")
    private String phone;

    @ApiModelProperty(value = "姓名")
    private String name;

    @ApiModelProperty(value = "密码")
    private String password;

    @ApiModelProperty(value = "性别")
    private Integer sex;

    @ApiModelProperty(value = "身份证")
    private String idcard;

    @ApiModelProperty(value = "微信昵称")
    private String wxNick;

    @ApiModelProperty(value = "用户token")
    private String token;

    @ApiModelProperty(value = "用户类型")
    private Integer source;

    @ApiModelProperty(value = "注册时间")
    private Date registerTime;

    @ApiModelProperty(value = "注册地（区划代码）")
    private String registerAddress;

    @ApiModelProperty(value = "最近登录时间")
    private Date lastLoginTime;

    @ApiModelProperty(value = "信用额（可透支额度）")
    private Double credit;

    @ApiModelProperty(value = "钱包金额")
    private Double wallet;

    @ApiModelProperty(value = "最近充电时间")
    private Date lastChargingTime;

    @ApiModelProperty(value = "最近充电金额")
    private Double lastChargingFee;

    @ApiModelProperty(value = "最近充电电量")
    private Double lastChargingPower;

    @ApiModelProperty(value = "累计充电次数")
    private Integer totalChargingNum;

    @ApiModelProperty(value = "累计充电时间")
    private Date totalChargingTime;

    @ApiModelProperty(value = "累计充电金额")
    private Double totalChargingFee;

    @ApiModelProperty(value = "累计充电电量")
    private Double totalChargingPower;

    @ApiModelProperty(value = "累计充值次数")
    private Integer totalRechargeNum;

    @ApiModelProperty(value = "累计充值金额")
    private Double totalRechargeFee;

    @ApiModelProperty(value = "累计退还次数")
    private Integer totalRefundNum;

    @ApiModelProperty(value = "累计退还金额")
    private Double totalRefundFee;

    @ApiModelProperty(value = "停用时间")
    private Date disableTime;

    @ApiModelProperty(value = "停用原因")
    private String disableReason;

    @ApiModelProperty(value = "冻结时间")
    private Date freezeTime;

    @ApiModelProperty(value = "冻结原因")
    private String freezeReason;

    @ApiModelProperty(value = "备注")
    private String memo;

    @ApiModelProperty(value = "合作渠道")
    private Integer cooperationId;

    @ApiModelProperty(value = "停用操作人")
    private Integer disableOperatorId;

    @ApiModelProperty(value = "冻结操作人")
    private Integer freezeOperatorId;

    @ApiModelProperty(value = "推荐人")
    private Integer inviterId;


}
