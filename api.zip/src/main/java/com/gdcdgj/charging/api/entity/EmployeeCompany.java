package com.gdcdgj.charging.api.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * <p>
 * 运营商
 * </p>
 *
 * @author tcl
 * @since 2020-04-30
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="EmployeeCompany对象", description="运营商")
public class EmployeeCompany implements Serializable {

    private static final long serialVersionUID=1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "运营商类型")
    private Integer ctype;

    @ApiModelProperty(value = "公司名")
    private String name;

    @ApiModelProperty(value = "简称")
    private String shortName;

    @ApiModelProperty(value = "组织机构代码")
    private String organizationCode;

    @ApiModelProperty(value = "联系人")
    private String contact;

    @ApiModelProperty(value = "联系电话1")
    private String contactPhone1;

    @ApiModelProperty(value = "联系电话2")
    private String contactPhone2;

    @ApiModelProperty(value = "备注信息")
    private String memo;

    @ApiModelProperty(value = "是否启用")
    private Boolean isEnabled;


}
