package com.gdcdgj.charging.api.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 用户
 * </p>
 *
 * @author tcl
 * @since 2020-04-30
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="EmployeeUser对象", description="用户")
public class EmployeeUser implements Serializable {

    private static final long serialVersionUID=1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "密码")
    private String password;

    @ApiModelProperty(value = "上次登录")
    private Date lastLogin;

    @ApiModelProperty(value = "超级用户状态")
    private Boolean isSuperuser;

    @ApiModelProperty(value = "用户类型")
    private String utype;

    @ApiModelProperty(value = "工号")
    private Integer pid;

    @ApiModelProperty(value = "姓名")
    private String username;

    @ApiModelProperty(value = "手机号")
    private String phone;

    @ApiModelProperty(value = "状态")
    private Integer status;

    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    @ApiModelProperty(value = "api用户的token")
    private String token;

    @ApiModelProperty(value = "token到期时间")
    private Date expireTime;

    @ApiModelProperty(value = "company")
    private Integer companyId;

    @ApiModelProperty(value = "create by")
    private Integer createById;

    @ApiModelProperty(value = "department")
    private Integer departmentId;


}
