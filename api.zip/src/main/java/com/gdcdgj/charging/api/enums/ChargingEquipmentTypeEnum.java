package com.gdcdgj.charging.api.enums;

/**
 * @author JianMei Chen
 * @date 2020/04/23/11:08
 * 充电桩设备类型
 *
 * CHARGINGPILE_TYPE_CHOICES = ((0,'未知'),(1,'直流'),(2,'交流'),(3,'交直流一体'),)
 */
public enum  ChargingEquipmentTypeEnum {

    UNKNOWN(0),
    DIRECT(1),
    COMMUNICATION(2),
    BLEND(3);

    private int value;

    private ChargingEquipmentTypeEnum(int value) {
        this.value=value;
    }

    public int getValue() {
        return this.value;
    }

    public static ChargingEquipmentTypeEnum valueOf(int value) throws RuntimeException {
        ChargingEquipmentTypeEnum tempEnum = null;
        for (ChargingEquipmentTypeEnum en : ChargingEquipmentTypeEnum.values()) {
            if (en.getValue() == value) {
                tempEnum = en;
                break;
            }
        }
        if (tempEnum == null) {
            throw new RuntimeException("Enum value not exist");
        }
        return tempEnum;
    }

}
