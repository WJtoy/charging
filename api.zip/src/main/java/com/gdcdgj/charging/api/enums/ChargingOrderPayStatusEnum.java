package com.gdcdgj.charging.api.enums;

/**
 *
 * 订单支付状态 1 未支付 2 已支付
 * @author Changliang Tao
 * @date 2020/4/21 15:02
 * @since JDK 1.8
 */
public enum ChargingOrderPayStatusEnum {
    NO_PAY(1),
    PAID(2);
    private int value;

    private ChargingOrderPayStatusEnum(int value) {
        this.value = value;
    }

    public int getValue() {
        return this.value;
    }

    public static ChargingOrderPayStatusEnum valueOf(int value) throws RuntimeException {
        ChargingOrderPayStatusEnum tempEnum = null;
        for (ChargingOrderPayStatusEnum en : ChargingOrderPayStatusEnum.values()) {
            if (en.getValue() == value) {
                tempEnum = en;
                break;
            }
        }
        if (tempEnum == null) {
            throw new RuntimeException("Enum value not exist");
        }
        return tempEnum;
    }
}
