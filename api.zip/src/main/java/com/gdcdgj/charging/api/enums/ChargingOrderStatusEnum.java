package com.gdcdgj.charging.api.enums;

/**
 * ((1,'准备充电'),(2,'充电中'),(3,'结束中'),(4,'充电结束'),(5,'启动失败'),(6,'系统故障')
 * @author Changliang Tao
 * @date 2020/4/21 15:02
 * @since JDK 1.8
 */
public enum ChargingOrderStatusEnum {
    PREPARE_CHARGING(1),//准备充电
    CHARGING(2),//充电中
    ENDING(3),//结束中
    END_CHARGING(4),//充电结束
    START_FAIL(5),//启动失败
    SYSTEM_FAULT(6);//系统故障
    private int value;

    private ChargingOrderStatusEnum(int value) {
        this.value = value;
    }

    public int getValue() {
        return this.value;
    }

    public static ChargingOrderStatusEnum valueOf(int value) throws RuntimeException {
        ChargingOrderStatusEnum tempEnum = null;
        for (ChargingOrderStatusEnum en : ChargingOrderStatusEnum.values()) {
            if (en.getValue() == value) {
                tempEnum = en;
                break;
            }
        }
        if (tempEnum == null) {
            throw new RuntimeException("Enum value not exist");
        }
        return tempEnum;
    }
}
