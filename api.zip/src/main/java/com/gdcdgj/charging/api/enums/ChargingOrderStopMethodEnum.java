package com.gdcdgj.charging.api.enums;

/**
 * CHARGINGORDER_STOP_METHOD_CHOICES = ((0,'客户端结束'),(1,'充满结束'),(2,'急停结束'),(3,'系统异常结束'),(4,'其他'))
 *
 * @author Changliang Tao
 * @date 2020/4/21 15:12
 * @since JDK 1.8
 */
public enum ChargingOrderStopMethodEnum {
    CLIENT(0),
    FULL_CHARGING(1),
    EMERGENCY_STOP(2),
    SYSTEM_ERROR(3),
    OTHERS(4);
    private int value;

    private ChargingOrderStopMethodEnum(int value) {
        this.value = value;
    }

    public int getValue() {
        return this.value;
    }

    public static ChargingOrderStopMethodEnum valueOf(int value) throws RuntimeException {
        ChargingOrderStopMethodEnum tempEnum = null;
        for (ChargingOrderStopMethodEnum en : ChargingOrderStopMethodEnum.values()) {
            if (en.getValue() == value) {
                tempEnum = en;
                break;
            }
        }
        if (tempEnum == null) {
            throw new RuntimeException("Enum value not exist");
        }
        return tempEnum;
    }
}
