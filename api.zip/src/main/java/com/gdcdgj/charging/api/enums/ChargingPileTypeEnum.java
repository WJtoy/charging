package com.gdcdgj.charging.api.enums;

/**
 * CHARGINGPILE_TYPE_CHOICES = ((0,'未知'),(1,'直流'),(2,'交流'),(3,'交直流一体'),)
 *
 * @author Changliang Tao
 * @date 2020/4/21 16:49
 * @since JDK 1.8
 */
public enum ChargingPileTypeEnum {
    UNKNOWN(0),
    DC(1),
    AC(2),
    DC_AC(3);
    private int value;

    private ChargingPileTypeEnum(int value) {
        this.value = value;
    }

    public int getValue() {
        return this.value;
    }

    public static ChargingPileTypeEnum valueOf(int value) throws RuntimeException {
        ChargingPileTypeEnum tempEnum = null;
        for (ChargingPileTypeEnum en : ChargingPileTypeEnum.values()) {
            if (en.getValue() == value) {
                tempEnum = en;
                break;
            }
        }
        if (tempEnum == null) {
            throw new RuntimeException("Enum value not exist");
        }
        return tempEnum;
    }
}
