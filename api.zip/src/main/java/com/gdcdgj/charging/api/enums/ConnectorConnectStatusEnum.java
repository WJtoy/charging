package com.gdcdgj.charging.api.enums;

/**
 * 充电枪与车的连接状态
 *
 * @author Changliang Tao
 * @date 2020/4/22 11:03
 * @since JDK 1.8
 */
public enum ConnectorConnectStatusEnum {
    // 未连接
    DISCONNECTED(0),
    // 非0都是已连接
    CONNECTED(1);
    private int value;

    private ConnectorConnectStatusEnum(int value) {
        this.value = value;
    }

    public int getValue() {
        return this.value;
    }

    public static ConnectorConnectStatusEnum valueOf(int value) throws RuntimeException {
        ConnectorConnectStatusEnum tempEnum = null;
        for (ConnectorConnectStatusEnum en : ConnectorConnectStatusEnum.values()) {
            if (en.getValue() == value) {
                tempEnum = en;
                break;
            }
        }
        if (tempEnum == null) {
            throw new RuntimeException("Enum value not exist");
        }
        return tempEnum;
    }
}
