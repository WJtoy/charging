package com.gdcdgj.charging.api.enums;

/**
 * CONNECTOR_INTERFACE_CHOICES = ((0,'未知'),(1,'市电家用插座'),(2,'交流接口插座'),(3,'交流接口插头'),(4,'直流接口插头'),)
 *
 * @author Changliang Tao
 * @date 2020/4/21 16:54
 * @since JDK 1.8
 */
public enum ConnectorInterfaceEnum {
    UNKNOWN(0),
    CITY_POWER_HOUSEHOLD_SOCKET(1),
    AC_SOCKET(2),
    AC_PLUG(3),
    DC_PLUG(4);

    private int value;

    private ConnectorInterfaceEnum(int value) {
        this.value = value;
    }

    public int getValue() {
        return this.value;
    }

    public static ConnectorInterfaceEnum valueOf(int value) throws RuntimeException {
        ConnectorInterfaceEnum tempEnum = null;
        for (ConnectorInterfaceEnum en : ConnectorInterfaceEnum.values()) {
            if (en.getValue() == value) {
                tempEnum = en;
                break;
            }
        }
        if (tempEnum == null) {
            throw new RuntimeException("Enum value not exist");
        }
        return tempEnum;
    }
}
