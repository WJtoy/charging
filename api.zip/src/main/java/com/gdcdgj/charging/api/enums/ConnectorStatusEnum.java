package com.gdcdgj.charging.api.enums;

/**
 * CONNECTOR_STATUS_CHOICES = (
 * (0,'空闲'),(1,'准备充电'),(2,'充电中'),(3,'充电结束'),(4,'启动失败'),(5,'预约失败'),(6,'系统故障'),(7,'锁定'),
 * (10,'未初始'),(11,'停用'),(13,'其他待补充。。。'),)
 * STATUS_CHOICES = ((0,'空闲'),(1,'充电中'),(2,'充电结束'),(3,'系统故障'))
 *
 * @author Changliang Tao
 * @date 2020/4/21 16:59
 * @since JDK 1.8
 */
public enum ConnectorStatusEnum {
    FREE(0),
    CONNECTOR_CHARGING(1),
    END_CHARGING(2),
    SYSTEM_FAULT(3);
    private int value;

    private ConnectorStatusEnum(int value) {
        this.value = value;
    }

    public int getValue() {
        return this.value;
    }

    public static ConnectorStatusEnum valueOf(int value) throws RuntimeException {
        ConnectorStatusEnum tempEnum = null;
        for (ConnectorStatusEnum en : ConnectorStatusEnum.values()) {
            if (en.getValue() == value) {
                tempEnum = en;
                break;
            }
        }
        if (tempEnum == null) {
            throw new RuntimeException("Enum value not exist");
        }
        return tempEnum;
    }
}
