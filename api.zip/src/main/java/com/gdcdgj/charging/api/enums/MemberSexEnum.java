package com.gdcdgj.charging.api.enums;

/**
 * MEMBER_SEX_CHOICES = ((0,'未知'),(1,'男'),(2,'女'))
 *
 * @author Changliang Tao
 * @date 2020/4/21 11:11
 * @since JDK 1.8
 */
public enum MemberSexEnum {
    UNKNOWN(0),
    MALE(1),
    FEMALE(2);

    private int value;

    private MemberSexEnum(int value) {
        this.value = value;
    }

    public int getValue() {
        return this.value;
    }

    public static MemberSexEnum valueOf(int value) throws RuntimeException {
        MemberSexEnum tempEnum = null;
        for (MemberSexEnum en : MemberSexEnum.values()) {
            if (en.getValue() == value) {
                tempEnum = en;
                break;
            }
        }
        if (tempEnum == null) {
            throw new RuntimeException("Enum value not exist");
        }
        return tempEnum;
    }
}
