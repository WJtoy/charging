package com.gdcdgj.charging.api.enums;

/**
 * MEMBER_SOURCE_CHOICES = ((0,'未知'),(1,'小程序'),(2,'APP'),(3,'渠道'),(4,'网站'),)
 *
 * @author Changliang Tao
 * @date 2020/4/21 10:33
 * @since JDK 1.8
 */
public enum MemberSourceEnum {
    UNKNOWN(0),
    MINI_APP(1),
    APP(2),
    CHANNEL(3),
    WEBSITE(4);
    private int value;

    private MemberSourceEnum(int value) {
        this.value = value;
    }

    public int getValue() {
        return this.value;
    }

    public static MemberSourceEnum valueOf(int value) throws RuntimeException {
        MemberSourceEnum tempEnum = null;
        for (MemberSourceEnum en : MemberSourceEnum.values()) {
            if (en.getValue() == value) {
                tempEnum = en;
                break;
            }
        }
        if (tempEnum == null) {
            throw new RuntimeException("Enum value not exist");
        }
        return tempEnum;
    }
}
