package com.gdcdgj.charging.api.enums;

/**
 * MEMBER_STATUS_CHOICES = ((0,'未知'),(1,'正常'),(2,'停用'),(3,'临时冻结'),(4,'永久冻结'),(5,'其他'),)
 *
 * @author Changliang Tao
 * @date 2020/4/21 10:41
 * @since JDK 1.8
 */
public enum MemberStatusEnum {
    UNKNOWN(0),
    NORMAL(1),
    STOP_USE(2),
    TEMPORARY_FREEZE(3),
    PERMANENT_FREEZE(4),
    OTHERS(5);
    private int value;

    private MemberStatusEnum(int value) {
        this.value = value;
    }

    public int getValue() {
        return this.value;
    }

    public static MemberStatusEnum valueOf(int value) throws RuntimeException {
        MemberStatusEnum tempEnum = null;
        for (MemberStatusEnum en : MemberStatusEnum.values()) {
            if (en.getValue() == value) {
                tempEnum = en;
                break;
            }
        }
        if (tempEnum == null) {
            throw new RuntimeException("Enum value not exist");
        }
        return tempEnum;
    }
}
