package com.gdcdgj.charging.api.enums;


import lombok.extern.slf4j.Slf4j;

import java.util.Arrays;

/**
 * 每个平台桩的报文协议起始域
 *
 * @author Changliang Tao
 * @date 2020/4/13 16:55
 * @since JDK 1.8
 */
@Slf4j
public enum MsgProviderEnum {
    // ib供应商  2
    IB_PROVIDER(2),
    // kw供应商 1
    KW_PROVIDER(1);

	 private int value;

	 private MsgProviderEnum(int value) {
	     this.value = value;
	 }

	 public int getValue() {
	     return this.value;
	 }
}
