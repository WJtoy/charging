package com.gdcdgj.charging.api.enums;

/**
 * @author JianMei Chen
 * @date 2020/04/23/16:25
 * PARK_FEE_TYPE_CHOICES = ((0,'免费'),(1,'限时免费'),(2,'凭券免费'))
 */
public enum  ParkFreeTypeEnum {
    FREE(0),
    LIMITED(1),
    VOUCHER_FREE(2);
    private int value;

    private ParkFreeTypeEnum(int value) {
        this.value = value;
    }

    public int getValue() {
        return this.value;
    }

    public static ParkFreeTypeEnum valueOf(int value) throws RuntimeException {
        ParkFreeTypeEnum tempEnum = null;
        for (ParkFreeTypeEnum en : ParkFreeTypeEnum.values()) {
            if (en.getValue() == value) {
                tempEnum = en;
                break;
            }
        }
        if (tempEnum == null) {
            throw new RuntimeException("Enum value not exist");
        }
        return tempEnum;
    }
    
}
