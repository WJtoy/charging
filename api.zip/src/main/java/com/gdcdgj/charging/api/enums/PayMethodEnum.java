package com.gdcdgj.charging.api.enums;

/**
 * @author JianMei Chen
 * @date 2020/04/28/15:20
 * RECHARGE_METHOD_CHOICES = ((0,'未知'),(1,'微信'),(2,'支付宝'),)
 */
public enum PayMethodEnum {

    UNKNOWN(0),//未知
    WX(1),//微信
    ALIPAY(2);//支付宝
    private int value;

    private PayMethodEnum(int value) {
        this.value = value;
    }

    public int getValue() {
        return this.value;
    }

    public static PayMethodEnum valueOf(int value) throws RuntimeException {
        PayMethodEnum tempEnum = null;
        for (PayMethodEnum en : PayMethodEnum.values()) {
            if (en.getValue() == value) {
                tempEnum = en;
                break;
            }
        }
        if (tempEnum == null) {
            throw new RuntimeException("Enum value not exist");
        }
        return tempEnum;
    }
}
