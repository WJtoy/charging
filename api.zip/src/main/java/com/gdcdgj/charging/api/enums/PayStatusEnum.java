package com.gdcdgj.charging.api.enums;

/**
 * @author JianMei Chen
 * @date 2020/05/11/11:48
 */
public enum PayStatusEnum {
    UNKNOWN(0),//未知
    SUCCESS(1),//成功
    FAIL(2),//失败
    REVOKE(3);//撤销
    private int value;

    private PayStatusEnum(int value) {
        this.value = value;
    }

    public int getValue() {
        return this.value;
    }

    public static PayStatusEnum valueOf(int value) throws RuntimeException {
        PayStatusEnum tempEnum = null;
        for (PayStatusEnum en : PayStatusEnum.values()) {
            if (en.getValue() == value) {
                tempEnum = en;
                break;
            }
        }
        if (tempEnum == null) {
            throw new RuntimeException("Enum value not exist");
        }
        return tempEnum;
    }
}
