package com.gdcdgj.charging.api.enums;

/**
 * @author JianMei Chen
 * @date 2020/04/23/17:52
 *  默认为1，不默认为0
 *  默认表示没有活动，不默认表示活动
 */
public enum PriceIsDefaultEunm {
    DEFAULT(1),
    NO(0);
    private int value;

    private PriceIsDefaultEunm(int value) {
        this.value = value;
    }

    public int getValue() {
        return this.value;
    }

    public static PriceIsDefaultEunm valueOf(int value) throws RuntimeException {
        PriceIsDefaultEunm tempEnum = null;
        for (PriceIsDefaultEunm en : PriceIsDefaultEunm.values()) {
            if (en.getValue() == value) {
                tempEnum = en;
                break;
            }
        }
        if (tempEnum == null) {
            throw new RuntimeException("Enum value not exist");
        }
        return tempEnum;
    }
}
