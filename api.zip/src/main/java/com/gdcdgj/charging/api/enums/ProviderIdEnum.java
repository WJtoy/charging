package com.gdcdgj.charging.api.enums;

/**
 * 充电桩提供厂商的id
 *
 * @author Changliang Tao
 * @date 2020/4/26 17:17
 * @since JDK 1.8
 */
public enum ProviderIdEnum {
    IB(1),
    KW(2);

    private int value;

    private ProviderIdEnum(int value) {
        this.value = value;
    }

    public int getValue() {
        return this.value;
    }

    public static ProviderIdEnum valueOf(int value) throws RuntimeException {
        ProviderIdEnum tempEnum = null;
        for (ProviderIdEnum en : ProviderIdEnum.values()) {
            if (en.getValue() == value) {
                tempEnum = en;
                break;
            }
        }
        if (tempEnum == null) {
            throw new RuntimeException("Enum value not exist");
        }
        return tempEnum;
    }

}
