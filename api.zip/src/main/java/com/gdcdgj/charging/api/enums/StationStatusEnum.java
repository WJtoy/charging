package com.gdcdgj.charging.api.enums;

/**
 * @author JianMei Chen
 * @date 2020/06/01/9:21
 */
public enum StationStatusEnum {

    UNKNOWN(0),//未初始化
    NORMAL(1),//正常运营
    CLOSE(2),//关闭营业（不显示/扫码可充电）
    STOP(3);//停止营业（不显示/不能扫描充电
    private int value;

    private StationStatusEnum(int value) {
        this.value=value;
    }

    public int getValue() {
        return this.value;
    }

    public static StationStatusEnum valueOf(int value) throws RuntimeException {
        StationStatusEnum tempEnum = null;
        for (StationStatusEnum en : StationStatusEnum.values()) {
            if (en.getValue() == value) {
                tempEnum = en;
                break;
            }
        }
        if (tempEnum == null) {
            throw new RuntimeException("Enum value not exist");
        }
        return tempEnum;
    }

}
