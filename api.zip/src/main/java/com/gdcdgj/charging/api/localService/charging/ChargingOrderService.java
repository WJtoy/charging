package com.gdcdgj.charging.api.localService.charging;

import com.gdcdgj.charging.api.vo.CommonVo;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.StateInfo;

/**
 * 充电订单业务
 * 桩、充电枪、轨迹订单、订单状态
 */
public interface ChargingOrderService {

    CommonVo chargingOrder(StateInfo stateInfo);
    void startChargingOrder(DataBaseVo vo);


}
