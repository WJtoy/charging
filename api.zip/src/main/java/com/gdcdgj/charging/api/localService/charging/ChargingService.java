package com.gdcdgj.charging.api.localService.charging;

import com.gdcdgj.charging.api.vo.CommonVo;

/**
 * 扫码启动充电服务
 *
 * @author Changliang Tao
 * @date 2020/4/23 9:17
 * @since JDK 1.8
 */
public interface ChargingService {
    /**
     * 二维码即是枪编码，利用token从redis查询会员信息
     *
     * @param qrCode
     * @param token
     * @param scanTime 扫描时间
     * @return common vo
     * @throws
     * @author Changliang Tao
     * @date 2020/4/21 14:31
     */
    CommonVo start(String token, String qrCode,String scanTime,Integer is_simulate) throws Exception;

    /**
     *  结束充电
     * @Author JianMei Chen
     * @Date  2020/5/9
     **/
    CommonVo stop(String token,String qrCode,Integer is_simulate);

}
