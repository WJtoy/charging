package com.gdcdgj.charging.api.localService.charging;


import com.gdcdgj.charging.api.vo.srv2gw.ModuleChargingInfo;

/**
 *
 */
public interface ModelChargingOrderService {

    void moduleChargingOrder(ModuleChargingInfo moduleChargingInfo);
}
