package com.gdcdgj.charging.api.localService.charging;

import com.gdcdgj.charging.api.vo.CommonVo;

/**
 * 与充电相关
 *
 * @author Changliang Tao
 * @date 2020/4/19 14:24
 * @since JDK 1.8
 */
public interface OldChargingService {

    /**
    * @Description:  根据行政区域编码(cityCode)来查询充电站点详细情况
    * @param: cityCode
    * @return:
    * @Author: JianMei Chen
    * @Date: 2020/4/23
    */
    CommonVo getStationList(String cityCode);

    /**
    * @Description:  根据用户编号分页查询用户充电消费订单详细情况
    * @param: memberId
    * @param page
    * @param size
    * @return:
    * @Author: JianMei Chen
    * @Date: 2020/4/23
    */
    CommonVo queryChargingOrderList(Integer memberId, Integer page,Integer size);

    /**
    * @Description:  根据站点编号来获取快充枪数量，慢充枪数量，当前时间段的价格模板
    * @param: stationId
    * @return:
    * @Author: JianMei Chen
    * @Date: 2020/4/23
    */
    CommonVo queryAllByStationId(Integer stationId);

    /**
    * @Description:  根据站点编号来查询该站点所有价格模板
    * @param: stationId
    * @return:
    * @Author: JianMei Chen
    * @Date: 2020/4/23
    */
    CommonVo queryChargingPriceByStationId(Integer stationId);

    /**
     * 根据充电订单号查询充电订单
     * @param orderNo
     * @return
     */
    CommonVo getChargingByOrderNo(String orderNo);

    /**
     * 充电订单支付
     * @param orderNo
     * @param payType
     * @return
     */
    CommonVo payChargingOrder(String orderNo, Integer payType,Integer memberId);

    /**
    * @Description: 充电结束
    * @param:
    * @return:
    * @Author: JianMei Chen
    * @Date: 2020/4/27
    */
    CommonVo requestEndCharging(String orderNo);
}
