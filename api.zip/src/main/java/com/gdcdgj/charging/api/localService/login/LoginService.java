package com.gdcdgj.charging.api.localService.login;

import com.gdcdgj.charging.api.entity.CustomerMember;
import com.gdcdgj.charging.api.vo.CommonVo;

import java.util.Map;

/**
 * 提供登录服务
 *
 * @author Changliang Tao
 * @date 2020/3/27 16:46
 * @since JDK 1.8
 */
public interface LoginService {
    /**
     * 登录方法
     * @return
     * @throws
     * @author Changliang Tao
     * @date 2020/3/27 16:50
     */

    CommonVo login(Map<String,String> map);


    CommonVo register(Map<String,String> map);

}
