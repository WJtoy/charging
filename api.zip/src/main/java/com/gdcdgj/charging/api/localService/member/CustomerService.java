package com.gdcdgj.charging.api.localService.member;

import com.gdcdgj.charging.api.vo.CommonVo;

import java.util.Map;

/**
 * @author JianMei Chen
 * @date 2020/05/08/8:42
 */
public interface CustomerService {


    /**
     * 会员相关信息
     *
     * @return
     * @Author JianMei Chen
     * @Date 2020/5/14
     **/
    CommonVo profile(String token);


    /**
     * 会员支付充值后通知回调
     *
     * @return
     * @Author JianMei Chen
     * @Date 2020/5/14
     **/
    String rechargeNotify(Map<String, String> map);


    /**
     * 会员收藏站点列表
     *
     * @return
     * @Author JianMei Chen
     * @Date 2020/5/20
     **/
    CommonVo collectionStation(String token,Integer page,Integer pageSize);


    /**
     *  会员收藏站点以及取消收藏站点
     * @Author JianMei Chen
     * @Date  2020/5/20
     * @return
     **/
    CommonVo collection(Integer station_id,Integer type,String token);


    /**
     *  会员充值/退款记录，1表示充值，2表示退款
     * @Author JianMei Chen
     * @Date  2020/5/21
     * @return
     **/
    CommonVo moneyRecord(Integer type,String token,Integer page,Integer pageSize);


    /**
     *  绑定车辆
     * @Author JianMei Chen
     * @Date  2020/5/22
     * @return
     **/
    CommonVo addCarNumber(String token,String carNumber,Boolean is_default);


    /**
     *  设置默认车牌号/删除
     * @Author JianMei Chen
     * @Date  2020/5/22
     * @return
     **/
    CommonVo alertCarnumberInfo(Integer id,Integer type,String token);


    /**
     *  编辑车牌号信息
     * @Author JianMei Chen
     * @Date  2020/5/22
     * @return
     **/
    CommonVo editCarNumber(Integer id,String carNumber,Boolean is_default);


    /**
     *  会员车辆列表
     * @Author JianMei Chen
     * @Date  2020/5/22
     * @return
     *
     **/
    CommonVo carNumberList(String token);


    /**
     *  会员支付
     * @Author JianMei Chen
     * @Date  2020/5/27
     * @return
     **/
    CommonVo pay(String orderNo);
}
