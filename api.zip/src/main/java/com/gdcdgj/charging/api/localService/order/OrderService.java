package com.gdcdgj.charging.api.localService.order;

import com.gdcdgj.charging.api.vo.CommonVo;

/**
 * @author JianMei Chen
 * @date 2020/05/09/11:59
 */
public interface OrderService {


    /**
     * 查询订单实时状态
     * @Author JianMei Chen
     * @Date  2020/5/9
     * @return
     **/
    CommonVo order(String orderNo);


    /**
     * 订单列表
     * @Author JianMei Chen
     * @Date  2020/5/12
     * @return
     **/
    CommonVo orderList(Integer charging_status,Integer payment_status,String token);


    /**
     * 订单评价标签
     * @Author JianMei Chen
     * @Date  2020/5/22
     * @return
     **/
    CommonVo orderTags();

    /***
     *
     */
    CommonVo settleOrder(String token , String orderNo);

}
