package com.gdcdgj.charging.api.localService.pay;

import com.gdcdgj.charging.api.vo.CommonVo;

import java.util.Map;

/**
 * @author JianMei Chen
 * @date 2020/04/28/14:55
 */
public interface PayService {


    /**
     * 会员充值
     * @Author JianMei Chen
     * @Date  2020/5/11
     * @return
     **/
    CommonVo preloadCharge(Map<String,String> map);

    /**
     * 会员预充值通莞回调
     * @Author JianMei Chen
     * @Date  2020/5/11
     * @return
     **/
    CommonVo tgChargeResult(Map<String,String> map);


    /**
     * 去通莞金服主动查询订单
     * @Author JianMei Chen
     * @Date  2020/5/11
     * @return
     **/
    CommonVo orderQuery(Map<String,String> map);


    /**
     * 充电微信支付回调
     * @Author JianMei Chen
     * @Date  2020/5/11
     * @return
     **/
    CommonVo payChargingOrderCallBack(Map<String,String> map);
}
