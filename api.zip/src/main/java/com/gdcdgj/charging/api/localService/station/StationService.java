package com.gdcdgj.charging.api.localService.station;

import com.gdcdgj.charging.api.vo.CommonVo;

/**
 * @author JianMei Chen
 * @date 2020/05/06/13:54
 */
public interface StationService {


    /**
     *  站点列表
     * @Author JianMei Chen
     * @Date  2020/4/29
     * @return
     **/
    CommonVo findStationList(Integer page, Integer pagesize, Integer tags, Double latitude, Double longitude, Double distance, String search);


    /**
     * 站点标签显示
     * @Author JianMei Chen
     * @Date  2020/5/6
     * @return
     **/
    CommonVo findStationTags();


    /**
     *  站点详情
     * @Author JianMei Chen
     * @Date  2020/5/7
     * @return
     **/
    CommonVo stationDesc(Integer stationId);


    /**
     * 根据枪编码获取站点编号
     * @Author JianMei Chen
     * @Date  2020/5/14
     * @return
     **/
    CommonVo queryStationByCode(String code);


    /**
     *  查询站点评价标签
     * @Author JianMei Chen
     * @Date  2020/5/22
     * @return
     **/
    CommonVo evaluateTags();
}
