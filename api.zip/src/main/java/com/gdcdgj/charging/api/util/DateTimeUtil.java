package com.gdcdgj.charging.api.util;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 日期时间工具类
 */
@Slf4j
public class DateTimeUtil {
    /**
     * 字符串转时间
     * @param datTime
     * @return
     * @throws
     * @author Changliang Tao
     * @date 2020/4/23 11:50
     */
    public static Date getFormatDateTime(String datTime) {
        if (null != datTime && !StringUtils.isBlank(datTime)) {
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            try {
                return df.parse(datTime);
            } catch (ParseException var3) {
                log.error(var3.getMessage(), var3);
                return null;
            }
        } else {
            return null;
        }
    }

    /***
     * 将日期转化为字符串
     * @param date yyyy-MM-dd HH:mm:ss
     * @return
     */
    public static String getFormatDateTimeString(Date date) {
        if (null != date && !StringUtils.isBlank(date.toString())) {
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            try {
                return df.format(date);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
                return null;
            }
        } else {
            return null;
        }
    }

}
