package com.gdcdgj.charging.api.util;

import com.alibaba.fastjson.JSONObject;
import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.*;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.*;

public class HttpClientUtil {


	// 默认字符集
	private static String encoding = "utf-8";

    private static final Logger logger = LoggerFactory.getLogger(HttpClientUtil.class);


	/**
	 * 向指定URL发送POST方法的请求
	 *
	 * @param url
	 *            发送请求的URL
	 * @param param
	 *            请求参数，请求参数应该是name1=value1&name2=value2的形式。
	 * @return URL所代表远程资源的响应
	 */
	public static String sendPost(String url, String param) {
		OutputStreamWriter out = null;
		BufferedReader in = null;
		String result = ""; //$NON-NLS-1$
		try {
			URL realUrl = new URL(url);//new URL(URLEncoder.encode(url,"utf-8"));//
			// 打开和URL之间的连接
			URLConnection conn = realUrl.openConnection();
			// 设置通用的请求属性
			conn.setRequestProperty("accept", "*/*"); //$NON-NLS-1$ //$NON-NLS-2$
			conn.setRequestProperty("connection", "Keep-Alive"); //$NON-NLS-1$ //$NON-NLS-2$
			conn.setRequestProperty("user-agent", //$NON-NLS-1$
					"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)"); //$NON-NLS-1$
			// 发送POST请求必须设置如下两行
			conn.setDoOutput(true);
			conn.setDoInput(true);
			// 获取URLConnection对象对应的输出流
			out = new OutputStreamWriter(conn.getOutputStream(), "UTF-8"); //$NON-NLS-1$
			// 发送请求参数
			out.write(param);
			// flush输出流的缓冲
			out.flush();
			// 定义BufferedReader输入流来读取URL的响应
//			 InputStream in = conn.getInputStream();
			in = new BufferedReader(new InputStreamReader(
					conn.getInputStream(), "utf-8")); //$NON-NLS-1$
			String line;
			while ((line = in.readLine()) != null) {
				result +=  line; //$NON-NLS-1$
			}
		} catch (Exception e) {
			System.out.println("发送POST请求出现异常！" + e); //$NON-NLS-1$
			e.printStackTrace();
		}
		// 使用finally块来关闭输出流、输入流
		finally {
			try {
				if (out != null) {
					out.close();
				}
				if (in != null) {
					in.close();
				}
			} catch (IOException ex) {
                logger.error("http请求异常:"+ex.getMessage());
			}
		}
		return result;
	}



	public static String sendPost(String url, Map<String, String> headers, Map<String,Object> data, String encoding) {
//		CloseableHttpClient client = HttpClients.createDefault();
		CloseableHttpClient client = null;
//		HttpPost httpPost = new HttpPost();
		HttpPost httpPost = null;
		try {
            // 创建Client
            client = HttpClients.createDefault();
            // 创建HttpPost对象
            httpPost = new HttpPost();
			// 设置请求地址
			httpPost.setURI(new URI(url));
			// 设置请求头
			if (headers != null) {
				Header[] allHeader = new BasicHeader[headers.size()];
				int i = 0;
				for (Map.Entry<String, String> entry : headers.entrySet()) {
					allHeader[i] = new BasicHeader(entry.getKey(), entry.getValue());
					i++;
				}
				httpPost.setHeaders(allHeader);
			}
			// 表单方式
			List<BasicNameValuePair> pairList = new ArrayList<BasicNameValuePair>();
			for (Map.Entry<String,Object> item:data.entrySet()) {
				pairList.add(new BasicNameValuePair(item.getKey(), item.getValue()==null?"":item.getValue().toString()));
			}
			httpPost.setEntity(new UrlEncodedFormEntity(pairList, "utf-8"));
			// 发送请求,返回响应对象
			CloseableHttpResponse response = client.execute(httpPost);
			return parseData(response);

		} catch (Exception e) {
            logger.error("http请求异常:"+e.getMessage());
		} finally {
			httpPost.releaseConnection();
            try {
                client.close();
            } catch (IOException e) {
                logger.error("http请求异常:"+e.getMessage());
            }
        }
		return null;
	}


	public static String sendPost(String url, Map<String, String> headers, Map<String, Object> params) {
		return sendPost(url, headers, params, encoding);
	}
	public static String sendPostJson(String url, Map<String, String> headers, Map<String,Object> data, String encoding) {
//		CloseableHttpClient client = HttpClients.createDefault();
		CloseableHttpClient client = null;
//		HttpPost httpPost = new HttpPost();
		HttpPost httpPost = null;
		try {
			// 创建Client
			client = HttpClients.createDefault();
			// 创建HttpPost对象
			httpPost = new HttpPost();
			// 设置请求地址
			httpPost.setURI(new URI(url));
			// 设置请求头
			if (headers != null) {
				Header[] allHeader = new BasicHeader[headers.size()];
				int i = 0;
				for (Map.Entry<String, String> entry : headers.entrySet()) {
					allHeader[i] = new BasicHeader(entry.getKey(), entry.getValue());
					i++;
				}
				httpPost.setHeaders(allHeader);
			}
			// json方式
			String jsonString = JSONObject.toJSONString(data);
			StringEntity postEntity = new StringEntity(jsonString, "UTF-8");
			httpPost.setEntity(postEntity);
			// 发送请求,返回响应对象
			CloseableHttpResponse response = client.execute(httpPost);
			return parseData(response);

		} catch (Exception e) {
			logger.error("http请求异常:"+e.getMessage());
		} finally {
			httpPost.releaseConnection();
			try {
				client.close();
			} catch (IOException e) {
				logger.error("http请求异常:"+e.getMessage());
			}
		}
		return null;
	}

	/**
	 * 解析response
	 *
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public static String parseData(CloseableHttpResponse response) throws Exception {
		// 获取响应状态
		int status = response.getStatusLine().getStatusCode();
		if (status == HttpStatus.SC_OK) {
			// 获取响应数据
			return EntityUtils.toString(response.getEntity(), encoding);
		} else {
			//log.error("响应失败，状态码：" + status);
		}
		return null;
	}


    public static DefaultHttpClient getHttpsClient()
    {
        try {
            SSLContext ctx = SSLContext.getInstance("TLS");
            X509TrustManager tm = new X509TrustManager() {

                @Override
                public void checkClientTrusted(
                        java.security.cert.X509Certificate[] chain,
                        String authType)
                        throws java.security.cert.CertificateException {
                }

                @Override
                public void checkServerTrusted(
                        java.security.cert.X509Certificate[] chain,
                        String authType)
                        throws java.security.cert.CertificateException {
                }

                @Override
                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                    return null;
                }

            };
            try (DefaultHttpClient client = new DefaultHttpClient()) {
				ctx.init(null, new TrustManager[]{tm}, null);
				SSLSocketFactory ssf = new SSLSocketFactory(ctx);

				ClientConnectionManager ccm = client.getConnectionManager();
				SchemeRegistry sr = ccm.getSchemeRegistry();
				//设置要使用的端口，默认是443
				sr.register(new Scheme("https", 443, ssf));
				return client;
			}
        } catch (Exception ex) {
//            logger.error("", ex);
        	ex.printStackTrace();
            return null;
        }
    }

	/**
	 * 带token的get请求
	 * @param url
	 * @param params
	 * @return
	 */
	public static String sendGet(String url,  Map<String, String> headers,Map<String, Object> params) {
		// 创建client
//		CloseableHttpClient client = HttpClients.createDefault();
		CloseableHttpClient client = null;
		// 创建HttpGet
//		HttpGet httpGet = new HttpGet();
		HttpGet httpGet = null;
		try {
            client = HttpClients.createDefault();
            httpGet = new HttpGet();
			// 创建uri
			URIBuilder builder = new URIBuilder(url);
			//封装请求头
			if (headers != null) {
				Header[] allHeader = new BasicHeader[headers.size()];
				int i = 0;
				for (Map.Entry<String, String> entry : headers.entrySet()) {
					allHeader[i] = new BasicHeader(entry.getKey(), entry.getValue());
					i++;
				}
				httpGet.setHeaders(allHeader);
			}

			// 封装参数
			if (params != null) {
				for (String key : params.keySet()) {
					builder.addParameter(key, params.get(key).toString());
				}
			}
			URI uri = builder.build();
			// 设置请求地址
			httpGet.setURI(uri);
			// 发送请求，返回响应对象
			CloseableHttpResponse response = client.execute(httpGet);
			return parseData(response);
		} catch (Exception e) {
            logger.error("http请求异常:"+e.getMessage());
		} finally {
			httpGet.releaseConnection();
            try {
                client.close();
            } catch (IOException e) {
                logger.error("http请求异常:"+e.getMessage());
            }
        }
		return null;
	}


	public static String get(String url , String params){
    	DefaultHttpClient httpClient = null;
    	try {
            httpClient =getHttpsClient();
            HttpGet request = new HttpGet();
            request.setURI(new URI(url+URLEncoder.encode(params,"utf-8")));
            HttpResponse response = httpClient.execute(request);
            InputStream is = response.getEntity().getContent();

            ByteArrayOutputStream result =  new ByteArrayOutputStream();
            int   i=-1;
            while((i=is.read())!=-1){
            	result.write(i);
            }
           return result.toString();
		} catch (Exception e) {
            logger.error("http请求异常:"+e.getMessage());
		}finally{
			 httpClient.getConnectionManager().shutdown();
		}
    	return null ;
	}

	public static void main(String[] args) {
		System.out.println("-->"+new Date());
		String token = "";
		Map<String,String> header = new HashMap<>();
		String timestamp = System.currentTimeMillis()+"";
		Map<String,Object> param = new HashMap<>();
		String sign = "app_id=69yNRzNSd76Xlt0U&app_security=69yNRzNSd76Xlt0UrbojDZyJpg2sq35s&timestamp="+timestamp;
		sign = MD5Util.toMD5(sign);
		param.put("app_id","69yNRzNSd76Xlt0U");
		param.put("timestamp",timestamp);
		param.put("sign",sign);
		String response = sendPost("https://b.shumaidata.com/api/authorize",header,param);
		System.out.println(response);
		Map<String,Object> map = JSONObject.parseObject(response);
		if (map!=null && "0".equals(map.get("code"))){
			Map<String,String> result = (Map<String, String>) map.get("result");
			token = result.get("token");
		}

		Map<String,String> headers = new HashMap<>();
		headers.put("token",token);
		String url2 ="https://b.shumaidata.com/api/v2/driver_total_score_query/verify";
		Map<String,Object> param2 = new HashMap<>();

		param2.put("app_id","69yNRzNSd76Xlt0U");
		param2.put("licenseNo","441900199206192419");
		param2.put("fileNo","441903157028");

		String response2 =HttpClientUtil.sendGet(url2,headers,param2);
		System.out.println(response2);
		System.out.println("-->2"+new Date());
	}
}
