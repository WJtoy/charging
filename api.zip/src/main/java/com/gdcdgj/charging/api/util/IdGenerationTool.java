package com.gdcdgj.charging.api.util;

import java.util.Random;

/**
 * @author Changliang Tao
 * @date 2020/4/20 16:06
 * @since JDK 1.8
 */
public class IdGenerationTool {
    /**
     * 根据长度生成随机字符串
     *
     * @param
     * @return
     * @throws
     * @author Changliang Tao
     * @date 2020/4/20 16:07
     */

    public static String getRandomStringByLength(int length) {
        String base = "abcdefghijklmnopqrstuvwxyz0123456789";
        Random random = new Random();
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < length; i++) {
            int number = random.nextInt(base.length());
            sb.append(base.charAt(number));
        }
        return sb.toString();
    }
}
