package com.gdcdgj.charging.api.util;

import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Properties;

@Slf4j
public class PropertyUtil {

	private static final String BUNDLE_NAME = "/conf.properties";

	private static  Properties prop=new Properties();

	static{
		try {
			InputStream is=PropertyUtil.class.getResourceAsStream(BUNDLE_NAME);
			prop.load(new InputStreamReader(is, "utf-8"));
			is.close();
		} catch (IOException e) {
			log.error(e.getMessage(),e);
		}
	}

	public static String getString(String key) {
		try {
			return prop.getProperty(key);
		} catch (Exception e) {
			return '!' + key + '!';
		}
	}

    public static int getInt(String s) {
		return Integer.valueOf(getString(s));
    }

    public static int getInt(String s,int df) {
		if (!prop.containsKey(s)){
			return df;
		}
		return Integer.valueOf(getString(s));
    }
}
