package com.gdcdgj.charging.api.util;

import com.gdcdgj.charging.api.vo.order.OrderListInfoVo;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * @author JianMei Chen
 * @date 2020/05/28/15:14
 */
public class TimeUtils {

    public static void listSort(List<OrderListInfoVo> list){
        Collections.sort(list, new Comparator<OrderListInfoVo>() {
            DateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            @Override
            public int compare(OrderListInfoVo o1, OrderListInfoVo o2) {
                try {
                    return f.parse(o2.getStart_time()).compareTo(f.parse(o1.getStart_time()));
                } catch (ParseException e) {
                    throw new IllegalArgumentException(e);
                }
            }
        });
    }
}
