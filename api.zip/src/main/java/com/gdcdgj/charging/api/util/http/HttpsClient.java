package com.gdcdgj.charging.api.util.http;

import com.alibaba.fastjson.JSONObject;

import javax.net.ssl.*;
import java.io.*;
import java.net.URL;
import java.security.*;
import java.security.cert.CertificateException;


/**
 * HTTPS工具类
 *
 * @auther ouxx
 * @create 2018/6/28 14:01
 */
public class HttpsClient implements Serializable {
    private static final int OK = 200;
    private static final int ConnectionTimeout = 20000;
    private static final int ReadTimeout = 120000;

    public HttpsClient() {
    }

    public static Response post(String url, JSONObject json) throws Exception {
        String jsonString = json == null ? null : json.toString();
        return httpsRequest(url, "POST", jsonString, false, (String)null, (String)null, (String)null);
    }

    public static Response get(String url) throws Exception {
        return httpsRequest(url, "GET", (String)null, false, (String)null, (String)null, (String)null);
    }

    public static Response postXml(String url, String xml) throws Exception {
        return httpsRequest(url, "POST", xml, false, (String)null, (String)null, (String)null);
    }


    public static Response postXml(String url, String xml, String partnerId, String certPath, String certSecret) throws Exception {
        return httpsRequest(url, "POST", xml, true, partnerId, certPath, certSecret);
    }

    private static Response httpsRequest(String url, String method, String postData, boolean needCert, String partnerId, String certPath, String certSecret) throws Exception {
        Response res = null;

        try {
            HttpsURLConnection https = getHttpsURLConnection(url);
            if (https != null) {
                setHttpsHeader(https, method, needCert, partnerId, certPath, certSecret);
                if (method.equals("POST") && null != postData) {
                    byte[] bytes = postData.getBytes("UTF-8");
                    https.setRequestProperty("Content-Length", Integer.toString(bytes.length));
                    https.connect();
                    OutputStream output = https.getOutputStream();
                    output.write(bytes);
                    output.flush();
                    output.close();
                } else {
                    https.connect();
                }

                res = new Response(https);
                if (res.getStatus() == 200) {
                    return res;
                }
            }

            return res;
        } catch (NoSuchAlgorithmException var12) {
            throw new Exception(var12.getMessage(), var12);
        } catch (KeyManagementException var13) {
            throw new Exception(var13.getMessage(), var13);
        } catch (NoSuchProviderException var14) {
            throw new Exception(var14.getMessage(), var14);
        } catch (IOException var15) {
            throw new Exception(var15.getMessage(), var15);
        } catch (KeyStoreException var16) {
            throw new Exception(var16.getMessage(), var16);
        } catch (CertificateException var17) {
            throw new Exception(var17.getMessage(), var17);
        } catch (UnrecoverableKeyException var18) {
            throw new Exception(var18.getMessage(), var18);
        }
    }

    private static HttpsURLConnection getHttpsURLConnection(String url) throws IOException {
        URL urlGet = new URL(url);
        HttpsURLConnection httpsUrlConnection = (HttpsURLConnection)urlGet.openConnection();
        return httpsUrlConnection;
    }

    private static void setHttpsHeader(HttpsURLConnection httpsUrlConnection, String method, boolean needCert, String partnerId, String certPath, String certSecret) throws NoSuchAlgorithmException, KeyManagementException, NoSuchProviderException, IOException, KeyStoreException, CertificateException, UnrecoverableKeyException {
        if (!needCert) {
            TrustManager[] tm = new TrustManager[]{new MyX509TrustManager()};
            SSLContext sslContext = SSLContext.getInstance("SSL", "SunJSSE");
            sslContext.init((KeyManager[])null, tm, new SecureRandom());
            SSLSocketFactory ssf = sslContext.getSocketFactory();
            httpsUrlConnection.setSSLSocketFactory(ssf);
        } else {
            KeyStore keyStore = KeyStore.getInstance("PKCS12");
            FileInputStream instream = new FileInputStream(new File(certPath));

            try {
                keyStore.load(instream, partnerId.toCharArray());
            } finally {
                instream.close();
            }

            KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
            kmf.init(keyStore, certSecret.toCharArray());
            SSLContext sslContext = SSLContext.getInstance("TLSv1");
            sslContext.init(kmf.getKeyManagers(), (TrustManager[])null, (SecureRandom)null);
            SSLSocketFactory ssf = sslContext.getSocketFactory();
            httpsUrlConnection.setSSLSocketFactory(ssf);
        }

        httpsUrlConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        httpsUrlConnection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.146 Safari/537.36");
        httpsUrlConnection.setDoOutput(true);
        httpsUrlConnection.setDoInput(true);
        httpsUrlConnection.setRequestMethod(method);
        if (ConnectionTimeout > 0) {
            httpsUrlConnection.setConnectTimeout(ConnectionTimeout);
        } else {
            httpsUrlConnection.setConnectTimeout(10000);
        }

        if (ReadTimeout > 0) {
            httpsUrlConnection.setReadTimeout(ReadTimeout);
        } else {
            httpsUrlConnection.setReadTimeout(10000);
        }

        httpsUrlConnection.setRequestProperty("Charsert", "UTF-8");
    }

    public static String uploadHttps(String url, File file) throws Exception {
        HttpsURLConnection https = null;
        new StringBuffer();

        StringBuffer bufferRes;
        try {
            String BOUNDARY = "----WebKitFormBoundaryiDGnV9zdZA1eM1yL";
            https = getHttpsURLConnection(url);
            setHttpsHeader(https, "POST", false, (String)null, (String)null, (String)null);
            https.setUseCaches(false);
            https.setRequestProperty("connection", "Keep-Alive");
            https.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + BOUNDARY);
            DataOutputStream out = null;

            try {
                out = new DataOutputStream(https.getOutputStream());
                byte[] end_data = ("\r\n--" + BOUNDARY + "--\r\n").getBytes();
                StringBuilder sb = new StringBuilder();
                sb.append("--");
                sb.append(BOUNDARY);
                sb.append("\r\n");
                sb.append("Content-Disposition: form-data;name=\"media\";filename=\"").append(file.getName()).append("\"\r\n");
                sb.append("Content-Type:application/octet-stream\r\n\r\n");
                byte[] data = sb.toString().getBytes();
                out.write(data);
                try(DataInputStream dataInputStream = new DataInputStream(new FileInputStream(file))) {
                    byte[] bufferOut = new byte[1024];

                    int bytes;
                    while ((bytes = dataInputStream.read(bufferOut)) != -1) {
                        out.write(bufferOut, 0, bytes);
                    }

                    out.write("\r\n".getBytes());
                }
                out.write(end_data);
                out.flush();
            } finally {
                if (out != null) {
                    out.close();
                }

            }

            InputStream ins = null;

            try {
                ins = https.getInputStream();
                BufferedReader read = new BufferedReader(new InputStreamReader(ins, "UTF-8"));
                bufferRes = new StringBuffer();

                String valueString;
                while((valueString = read.readLine()) != null) {
                    bufferRes.append(valueString);
                }
            } finally {
                if (ins != null) {
                    ins.close();
                }

            }
        } catch (IOException var48) {
            throw new Exception(var48.getMessage(), var48);
        } catch (NoSuchAlgorithmException var49) {
            throw new Exception(var49.getMessage(), var49);
        } catch (KeyManagementException var50) {
            throw new Exception(var50.getMessage(), var50);
        } catch (NoSuchProviderException var51) {
            throw new Exception(var51.getMessage(), var51);
        } catch (KeyStoreException var52) {
            throw new Exception(var52.getMessage(), var52);
        } catch (CertificateException var53) {
            throw new Exception(var53.getMessage(), var53);
        } catch (UnrecoverableKeyException var54) {
            throw new Exception(var54.getMessage(), var54);
        } finally {
            if (https != null) {
                https.disconnect();
            }

        }

        return bufferRes.toString();
    }

}
