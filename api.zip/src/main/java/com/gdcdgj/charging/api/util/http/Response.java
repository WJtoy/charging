package com.gdcdgj.charging.api.util.http;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import javax.net.ssl.HttpsURLConnection;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;


/**
 * HTTP响应
 *
 * @auther ouxx
 * @create 2018/6/28 14:13
 */
public class Response {
    private HttpsURLConnection https;
    private HttpURLConnection http;
    private int status;
    private InputStream is;
    private String responseAsString = null;
    private boolean streamConsumed = false;

    public Response() {
    }

    public Response(HttpsURLConnection https) throws IOException {
        this.https = https;
        this.status = https.getResponseCode();
        if (null == (this.is = https.getErrorStream())) {
            this.is = https.getInputStream();
        }

    }

    public Response(HttpURLConnection http) throws IOException {
        this.http = http;
        this.status = http.getResponseCode();
        if (null == (this.is = http.getErrorStream())) {
            this.is = http.getInputStream();
        }

    }

    public InputStream asStream() {
        if (this.streamConsumed) {
            throw new IllegalStateException("Stream has already been consumed.");
        } else {
            return this.is;
        }
    }

    public String asString() throws Exception {
        if (null == this.responseAsString) {
            try {
                InputStream stream = this.asStream();
                if (null == stream) {
                    return null;
                }

                BufferedReader br = new BufferedReader(new InputStreamReader(stream, "UTF-8"));
                StringBuilder buf = new StringBuilder();

                String line;
                while(null != (line = br.readLine())) {
                    buf.append(line).append("\n");
                }

                this.responseAsString = buf.toString();
                stream.close();
                if (this.https != null) {
                    this.https.disconnect();
                }

                if (this.http != null) {
                    this.http.disconnect();
                }

                this.streamConsumed = true;
            } catch (NullPointerException var5) {
                throw new Exception(var5.getMessage(), var5);
            } catch (IOException var6) {
                throw new Exception(var6.getMessage(), var6);
            }
        }

        return this.responseAsString;
    }

    public JSONObject asJSONObject() throws Exception {
        return JSONObject.parseObject(this.asString());
    }

    public JSONArray asJSONArray() throws Exception {
        return JSONArray.parseArray(this.asString());
    }

    public int getStatus() {
        return this.status;
    }
}
