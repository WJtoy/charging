package com.gdcdgj.charging.api.util.pay.wx;

import java.util.HashMap;
import java.util.Map;

/**
 * 微信的错误码与错误信息
 *
 * @auther ouxx
 * @create 2018/6/20 14:15
 */
public class WXCodeMsg {

    private static final Map<Long, String> returnCodeMap = new HashMap<Long, String>();


    public static String getCause(final int statusCode) {
        return returnCodeMap.containsKey(statusCode) ? statusCode + ":" + returnCodeMap.get(statusCode) : statusCode + ":操作异常";
    }

    static {
        returnCodeMap.put(-1L, "系统繁忙，此时请开发者稍候再试");

        returnCodeMap.put(0L, "请求成功");

        returnCodeMap.put(40001L, "获取access_token时AppSecret错误，或者access_token无效。请开发者认真比对AppSecret的正确性，或查看是否正在为恰当的公众号调用接口");

        returnCodeMap.put(40002L, "不合法的凭证类型");

        returnCodeMap.put(40003L, "不合法的OpenID，请开发者确认OpenID（该用户）是否已关注公众号，或是否是其他公众号的OpenID");

        returnCodeMap.put(40004L, "不合法的媒体文件类型");

        returnCodeMap.put(40005L, "不合法的文件类型");

        returnCodeMap.put(40006L, "不合法的文件大小");

        returnCodeMap.put(40007L, "不合法的媒体文件id");

        returnCodeMap.put(40008L, "不合法的消息类型");

        returnCodeMap.put(40009L, "不合法的图片文件大小");

        returnCodeMap.put(40010L, "不合法的语音文件大小");

        returnCodeMap.put(40011L, "不合法的视频文件大小");

        returnCodeMap.put(40012L, "不合法的缩略图文件大小");

        returnCodeMap.put(40013L, "不合法的AppID，请开发者检查AppID的正确性，避免异常字符，注意大小写");

        returnCodeMap.put(40014L, "不合法的access_token，请开发者认真比对access_token的有效性（如是否过期），或查看是否正在为恰当的公众号调用接口");

        returnCodeMap.put(40015L, "不合法的菜单类型");

        returnCodeMap.put(40016L, "不合法的按钮个数");

        returnCodeMap.put(40017L, "不合法的按钮个数");

        returnCodeMap.put(40018L, "不合法的按钮名字长度");

        returnCodeMap.put(40019L, "不合法的按钮KEY长度");

        returnCodeMap.put(40020L, "不合法的按钮URL长度");

        returnCodeMap.put(40021L, "不合法的菜单版本号");

        returnCodeMap.put(40022L, "不合法的子菜单级数");

        returnCodeMap.put(40023L, "不合法的子菜单按钮个数");

        returnCodeMap.put(40024L, "不合法的子菜单按钮类型");

        returnCodeMap.put(40025L, "不合法的子菜单按钮名字长度");

        returnCodeMap.put(40026L, "不合法的子菜单按钮KEY长度");

        returnCodeMap.put(40027L, "不合法的子菜单按钮URL长度");

        returnCodeMap.put(40028L, "不合法的自定义菜单使用用户");

        returnCodeMap.put(40029L, "不合法的oauth_code");

        returnCodeMap.put(40030L, "不合法的refresh_token");

        returnCodeMap.put(40031L, "不合法的openid列表");

        returnCodeMap.put(40032L, "不合法的openid列表长度");

        returnCodeMap.put(40033L, "不合法的请求字符，不能包含\\uxxxx格式的字符");

        returnCodeMap.put(40035L, "不合法的参数");

        returnCodeMap.put(40038L, "不合法的请求格式");

        returnCodeMap.put(40039L, "不合法的URL长度");

        returnCodeMap.put(40050L, "不合法的分组id");

        returnCodeMap.put(40051L, "分组名字不合法");

        returnCodeMap.put(40117L, "分组名字不合法");

        returnCodeMap.put(40118L, "media_id大小不合法");

        returnCodeMap.put(40119L, "button类型错误");

        returnCodeMap.put(40120L, "button类型错误");

        returnCodeMap.put(40121L, "不合法的media_id类型");

        returnCodeMap.put(40132L, "微信号不合法");

        returnCodeMap.put(40137L, "不支持的图片格式");

        returnCodeMap.put(41001L, "缺少access_token参数");

        returnCodeMap.put(41002L, "缺少appid参数");

        returnCodeMap.put(41003L, "缺少refresh_token参数");

        returnCodeMap.put(41004L, "缺少secret参数");

        returnCodeMap.put(41005L, "缺少多媒体文件数据");

        returnCodeMap.put(41006L, "缺少media_id参数");

        returnCodeMap.put(41007L, "缺少子菜单数据");

        returnCodeMap.put(41008L, "缺少oauth code");

        returnCodeMap.put(41009L, "缺少openid");

        returnCodeMap.put(42001L, "access_token超时，请检查access_token的有效期，请参考基础支持-获取access_token中，对access_token的详细机制说明");

        returnCodeMap.put(42002L, "refresh_token超时");

        returnCodeMap.put(42003L, "oauth_code超时");

        returnCodeMap.put(42007L, "用户修改微信密码，accesstoken和refreshtoken失效，需要重新授权");

        returnCodeMap.put(43001L, "需要GET请求");

        returnCodeMap.put(43002L, "需要POST请求");

        returnCodeMap.put(43003L, "需要HTTPS请求");

        returnCodeMap.put(43004L, "需要接收者关注");

        returnCodeMap.put(43005L, "需要好友关系");

        returnCodeMap.put(44001L, "多媒体文件为空");

        returnCodeMap.put(44002L, "POST的数据包为空");

        returnCodeMap.put(44003L, "图文消息内容为空");

        returnCodeMap.put(44004L, "文本消息内容为空");

        returnCodeMap.put(45001L, "多媒体文件大小超过限制");

        returnCodeMap.put(45002L, "消息内容超过限制");

        returnCodeMap.put(45003L, "标题字段超过限制");

        returnCodeMap.put(45004L, "描述字段超过限制");

        returnCodeMap.put(45005L, "链接字段超过限制");

        returnCodeMap.put(45006L, "图片链接字段超过限制");

        returnCodeMap.put(45007L, "语音播放时间超过限制");

        returnCodeMap.put(45008L, "图文消息超过限制");

        returnCodeMap.put(45009L, "接口调用超过限制");

        returnCodeMap.put(45010L, "创建菜单个数超过限制");

        returnCodeMap.put(45015L, "回复时间超过限制");

        returnCodeMap.put(45016L, "系统分组，不允许修改");

        returnCodeMap.put(45017L, "分组名字过长");

        returnCodeMap.put(45018L, "分组数量超过上限");

        returnCodeMap.put(45047L, "客服接口下行条数超过上限");

        returnCodeMap.put(46001L, "不存在媒体数据");

        returnCodeMap.put(46002L, "不存在的菜单版本");

        returnCodeMap.put(46003L, "不存在的菜单数据");

        returnCodeMap.put(46004L, "不存在的用户");

        returnCodeMap.put(47001L, "解析JSON/XML内容错误");

        returnCodeMap.put(48001L, "api功能未授权，请确认公众号已获得该接口，可以在公众平台官网-开发者中心页中查看接口权限");

        returnCodeMap.put(48004L, "api接口被封禁，请登录mp.weixin.qq.com查看详情");

        returnCodeMap.put(48005L, "api禁止删除被自动回复和自定义菜单引用的素材");

        returnCodeMap.put(48006L, "api禁止清零调用次数，因为清零次数达到上限");

        returnCodeMap.put(50001L, "用户未授权该api");

        returnCodeMap.put(50002L, "用户受限，可能是违规后接口被封禁");

        returnCodeMap.put(61451L, "参数错误(invalid parameter)");

        returnCodeMap.put(61452L, "无效客服账号(invalid kf_account)");

        returnCodeMap.put(61453L, "客服帐号已存在(kf_account exsited)");

        returnCodeMap.put(61454L, "客服帐号名长度超过限制(仅允许10个英文字符，不包括@及@后的公众号的微信号)(invalid kf_acount length)");

        returnCodeMap.put(61455L, "客服帐号名包含非法字符(仅允许英文+数字)(illegal character in kf_account)");

        returnCodeMap.put(61456L, "客服帐号个数超过限制(10个客服账号)(kf_account count exceeded)");

        returnCodeMap.put(61457L, "无效头像文件类型(invalid file type)");

        returnCodeMap.put(61450L, "系统错误(system error)");

        returnCodeMap.put(61500L, "日期格式错误");

        returnCodeMap.put(65301L, "不存在此menuid对应的个性化菜单");

        returnCodeMap.put(65302L, "没有相应的用户");

        returnCodeMap.put(65303L, "没有默认菜单，不能创建个性化菜单");

        returnCodeMap.put(65304L, "MatchRule信息为空");

        returnCodeMap.put(65305L, "个性化菜单数量受限");

        returnCodeMap.put(65306L, "不支持个性化菜单的帐号");

        returnCodeMap.put(65307L, "个性化菜单信息为空");

        returnCodeMap.put(65308L, "包含没有响应类型的button");

        returnCodeMap.put(65309L, "个性化菜单开关处于关闭状态");

        returnCodeMap.put(65310L, "填写了省份或城市信息，国家信息不能为空");

        returnCodeMap.put(65311L, "填写了城市信息，省份信息不能为空");

        returnCodeMap.put(65312L, "不合法的国家信息");

        returnCodeMap.put(65313L, "不合法的省份信息");

        returnCodeMap.put(65314L, "不合法的城市信息");

        returnCodeMap.put(65316L, "该公众号的菜单设置了过多的域名外跳（最多跳转到3个域名的链接）");

        returnCodeMap.put(65317L, "不合法的URL");

        returnCodeMap.put(9001001L, "POST数据参数不合法");

        returnCodeMap.put(9001002L, "远端服务不可用");

        returnCodeMap.put(9001003L, "Ticket不合法");

        returnCodeMap.put(9001004L, "获取摇周边用户信息失败");

        returnCodeMap.put(9001005L, "获取商户信息失败");

        returnCodeMap.put(9001006L, "获取OpenID失败");

        returnCodeMap.put(9001007L, "上传文件缺失");

        returnCodeMap.put(9001008L, "上传素材的文件类型不合法");

        returnCodeMap.put(9001009L, "上传素材的文件尺寸不合法");

        returnCodeMap.put(9001010L, "上传失败");

        returnCodeMap.put(9001020L, "帐号不合法");

        returnCodeMap.put(9001021L, "已有设备激活率低于50%，不能新增设备");

        returnCodeMap.put(9001022L, "设备申请数不合法，必须为大于0的数字");

        returnCodeMap.put(9001023L, "已存在审核中的设备ID申请");

        returnCodeMap.put(9001024L, "一次查询设备ID数量不能超过50");

        returnCodeMap.put(9001025L, "设备ID不合法");

        returnCodeMap.put(9001026L, "页面ID不合法");

        returnCodeMap.put(9001027L, "页面参数不合法");

        returnCodeMap.put(9001028L, "一次删除页面ID数量不能超过10");

        returnCodeMap.put(9001029L, "页面已应用在设备中，请先解除应用关系再删除");

        returnCodeMap.put(9001030L, "一次查询页面ID数量不能超过50");

        returnCodeMap.put(9001031L, "时间区间不合法");

        returnCodeMap.put(9001032L, "保存设备与页面的绑定关系参数错误");

        returnCodeMap.put(9001033L, "门店ID不合法");

        returnCodeMap.put(9001034L, "设备备注信息过长");

        returnCodeMap.put(9001035L, "设备申请参数不合法");

        returnCodeMap.put(9001036L, "查询起始值begin不合法");
    }
}
