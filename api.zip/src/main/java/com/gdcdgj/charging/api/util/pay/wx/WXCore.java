package com.gdcdgj.charging.api.util.pay.wx;

import com.alibaba.fastjson.JSONObject;
import com.gdcdgj.charging.api.constant.Constant;
import com.gdcdgj.charging.api.constant.ResultCode;
import com.gdcdgj.charging.api.util.IdGenerationTool;
import com.gdcdgj.charging.api.util.http.HttpsClient;
import com.gdcdgj.charging.api.util.http.Response;
import com.gdcdgj.charging.api.vo.CommonVo;
import com.gdcdgj.charging.api.vo.wx.OAuthJsToken;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.codehaus.jackson.map.ObjectMapper;

import java.io.UnsupportedEncodingException;
import java.util.*;

@Slf4j
public class WXCore {


	private String genNonceStr() {
		Random random = new Random();
		return MD5.getMessageDigest(String.valueOf(random.nextInt(10000)).getBytes());
	}

	private String genProductArgs() {
		StringBuffer xml = new StringBuffer();

		try {
			String	nonceStr = genNonceStr();
			xml.append("</xml>");
            List<NameValuePair> packageParams = new LinkedList<NameValuePair>();
			packageParams.add(new BasicNameValuePair("appid", WXConfig.APP_ID));
			packageParams.add(new BasicNameValuePair("body", "123"));
			packageParams.add(new BasicNameValuePair("mch_id", WXConfig.MCH_ID));
			packageParams.add(new BasicNameValuePair("nonce_str", nonceStr));
			packageParams.add(new BasicNameValuePair("notify_url", "http://121.40.35.3/test"));
			packageParams.add(new BasicNameValuePair("out_trade_no","123164974631313610"));
			packageParams.add(new BasicNameValuePair("spbill_create_ip","127.0.0.1"));
			packageParams.add(new BasicNameValuePair("total_fee", "1"));
			packageParams.add(new BasicNameValuePair("trade_type", "APP"));

			String sign = genPackageSign(packageParams);
			packageParams.add(new BasicNameValuePair("sign", sign));

		   String xmlstring =toXml(packageParams);
			return xmlstring;
		} catch (Exception e) {
			log.error(e.getMessage(),e);
			return null;
		}
	}

	private String toXml(List<NameValuePair> params) {
		StringBuilder sb = new StringBuilder();
		sb.append("<xml>");
		for (int i = 0; i < params.size(); i++) {
			sb.append("<"+params.get(i).getName()+">");
			sb.append(params.get(i).getValue());
			sb.append("</"+params.get(i).getName()+">");
		}
		sb.append("</xml>");
		return sb.toString();
	}

	private String genPackageSign(List<NameValuePair> params) {
		StringBuilder sb = new StringBuilder();

		for (int i = 0; i < params.size(); i++) {
			sb.append(params.get(i).getName());
			sb.append('=');
			sb.append(params.get(i).getValue());
			sb.append('&');
		}
		sb.append("key=");
		sb.append(WXConfig.API_KEY);
		String packageSign = MD5.getMessageDigest(sb.toString().getBytes()).toUpperCase();
		return packageSign;
	}

	private Map<String,String>  doInBackground() {
		String url = String.format("https://api.mch.weixin.qq.com/pay/unifiedorder");
		String entity = genProductArgs();
		System.out.println("entity=" + entity);
		byte[] buf = Util.httpPost(url, entity);

		String content  = "";
		try {
			content = new String(buf, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			log.error(e.getMessage(),e);
		}
		System.out.println("content=" + content);

		return null;
	}


	public static void main(String[] args) {
		WXCore c = new WXCore();
		c.wxPay(null,"http://localtest.ibgoing.com","123asdasd1asdaa2asda312","1","192.168.0.14","充值","aa");
	}

	public static Map<String, Object> code2Session(final String code) throws Exception {
		if (StringUtils.isBlank(code)) {
			throw new Exception("code is null.");
		}

		Map<String, Object> ret = new HashMap<String, Object>();

		//调用获取access_token接口
		String param = "?grant_type=authorization_code" + "&appid=" + WXConfig.MINI_APP_ID
				+ "&secret=" + WXConfig.MINI_APP_SECRET + "&js_code=" + code;
		Response resp = HttpsClient.get("https://api.weixin.qq.com/sns/jscode2session" + param);
		JSONObject jsonObj = resp.asJSONObject();
		//根据请求结果判定，是否验证成功
		if (jsonObj != null) {
			Object errcode = jsonObj.get("errcode");
			if (errcode != null) {
				//返回异常信息
				ret.put("errcode", errcode);
				ret.put("errmsg", WXCodeMsg.getCause(Integer.parseInt(errcode.toString())));
				return ret;
			}

			ObjectMapper mapper = new ObjectMapper();
			OAuthJsToken oauthJsToken = mapper.readValue(jsonObj.toJSONString(),OAuthJsToken.class);

			ret.put("openid", oauthJsToken.getOpenid());
		}
		return ret;
	}

	/**
	 * @Description: 发起微信支付
	 * @param openid
	 * @param notifyUrl 回调URL，支付成功后,在notifyUrl对应的接口中处理业务数据及流程
	 * @param money 支付金额，单位：分，这边需要转成字符串类型，否则后面的签名会失败
	 * @param ip
	 */
	public CommonVo wxPay(final String openid, final String notifyUrl,
						  final String orderNo, final String money, String ip, String body, String attach){
		CommonVo ret = new CommonVo();
		//返回给移动端需要的参数
		Map<String, Object> response = new HashMap<String, Object>();
		try{
			//生成的随机字符串
			String nonce_str = IdGenerationTool.getRandomStringByLength(32);


			String xml =null;
			if(attach==null)
				attach="";
			if(openid ==null){
				xml = wxAppPay(body,nonce_str,notifyUrl,orderNo,ip,money,attach);
			}else{
				xml=wxMiniPay(body,nonce_str,notifyUrl,openid,orderNo,ip,money,attach);
			}

			System.out.println("调试模式_统一下单接口 请求XML数据：" + xml);

			//调用统一下单接口，并接受返回的结果
			String result = HttpsClient.postXml(WXConfig.PAY_URL, xml).asString();// PayUtil.httpRequest(WXConfig.PAY_URL, "POST", xml);

			System.out.println("调试模式_统一下单接口 返回XML数据：" + result);

			// 将解析结果存储在HashMap中
			Map map = PayUtil.doXMLParse(result);

			String return_code = (String) map.get("return_code");//返回状态码
			if("SUCCESS".equalsIgnoreCase(return_code)){
				// 业务结果
				String paySign = null;
				String prepay_id = map.get("prepay_id").toString();//返回的预付单信息
				response.put("nonceStr", nonce_str);
				Long timeStamp = System.currentTimeMillis() / 1000;
				response.put("timeStamp", timeStamp + "");//这边要将返回的时间戳转化成字符串，不然小程序端调用wx.requestPayment方法会报签名错误
				if(openid ==null){
					response.put("package", "Sign=WXPay");
					response.put("partnerid",WXConfig.MCH_ID);
					response.put("prepay_id",prepay_id);
					response.put(WXConfig.RETURN_KEY_APPID, WXConfig.APP_ID);
					String stringSignTemp = "appid=" + WXConfig.APP_ID + "&noncestr=" + nonce_str + "&package=Sign=WXPay"
							+"&partnerid="+WXConfig.MCH_ID+"&prepayid="+prepay_id + "&timestamp=" + timeStamp;
					paySign = PayUtil.sign(stringSignTemp, WXConfig.API_KEY, Constant.DEFAULT_CHARSET).toUpperCase();
				}else{
					response.put("package", "prepay_id=" + prepay_id);
					String stringSignTemp = "appId=" + WXConfig.MINI_APP_ID + "&nonceStr=" + nonce_str + "&package=prepay_id=" + prepay_id+ "&signType=" + WXConfig.SIGNTYPE + "&timeStamp=" + timeStamp;
					//再次签名，这个签名用于小程序端调用wx.requesetPayment方法
					paySign = PayUtil.sign(stringSignTemp, WXConfig.MINI_APP_SECRET, Constant.DEFAULT_CHARSET).toUpperCase();
					response.put(WXConfig.RETURN_KEY_APPID, WXConfig.MINI_APP_ID);
				}
//				log.info("=======================第二次签名：" + paySign + "=====================");

				response.put("sign", paySign);
				response.put("signType","MD5");
				System.out.println(response.toString());
			}



			ret.setstatus(ResultCode.SUCCESS_CODE);
			ret.setMsg(ResultCode.SUCCESS_MSG);
			ret.setdata(response);
		}catch(Exception e){
			log.error(e.getMessage(),e);
			ret.setstatus(ResultCode.FAIL_CODE);
			ret.setMsg(ResultCode.FAIL_MSG);
			ret.setdata(response);
		}
		return ret;
	}


	private  String  wxMiniPay(String body,String nonce_str,String notifyUrl,String openid,String orderNo,String ip,String money,String attach){
		Map<String, String> packageParams = new HashMap<>();
		packageParams.put(WXConfig.RETURN_KEY_APPID, WXConfig.MINI_APP_ID);
		packageParams.put("body", body);
		packageParams.put(WXConfig.RETURN_KEY_MCH_ID, WXConfig.MINI_APP_MCH_ID);
		packageParams.put(WXConfig.RETURN_KEY_NONCE_STR, nonce_str);
		packageParams.put(WXConfig.RETURN_KEY_NOTIFY_URL, notifyUrl);
		packageParams.put(WXConfig.RETURN_KEY_OPENID, openid);
		packageParams.put(WXConfig.RETURN_KEY_OUT_TRADE_NO, orderNo);//商户订单号
		packageParams.put(WXConfig.RETURN_KEY_SPBILL_CREATE_IP, ip);//APP和网页支付提交用户端ip，Native支付填调用微信支付API的机器IP
		packageParams.put(WXConfig.RETURN_KEY_TOTAL_FEE, money);//支付金额，这边需要转成字符串类型，否则后面的签名会失败
		packageParams.put(WXConfig.RETURN_KEY_TRADE_TYPE, WXConfig.TRADETYPE);
		packageParams.put(WXConfig.RETURN_KEY_ATTACH, attach);

		// 除去数组中的空值和签名参数
		packageParams = PayUtil.paraFilter(packageParams);
		String prestr = PayUtil.createLinkString(packageParams); // 把数组所有元素，按照“参数=参数值”的模式用“&”字符拼接成字符串

		//MD5运算生成签名，这里是第一次签名，用于调用统一下单接口
		String mysign = PayUtil.sign(prestr, WXConfig.MINI_APP_API_KEY, Constant.DEFAULT_CHARSET).toUpperCase();
//			log.info("=======================第一次签名：" + mysign + "=====================");

		//拼接统一下单接口使用的xml数据，要将上一步生成的签名一起拼接进去
		String xml = "<xml>" + "<appid>" + WXConfig.MINI_APP_ID + "</appid>"
				+ "<body><![CDATA[" + body + "]]></body>"
				+ "<mch_id>" + WXConfig.MINI_APP_MCH_ID + "</mch_id>"
				+ "<nonce_str>" + nonce_str + "</nonce_str>"
				+ "<notify_url>" + notifyUrl + "</notify_url>"
				+ "<out_trade_no>" + orderNo + "</out_trade_no>"
				+ "<spbill_create_ip>" + ip + "</spbill_create_ip>"
				+ "<total_fee>" + money + "</total_fee>"
				+ "<openid>" + openid + "</openid>"
				+ "<trade_type>" + WXConfig.TRADETYPE + "</trade_type>"
				+ "<attach>" + attach + "</attach>"
				+ "<sign>" + mysign + "</sign>"
				+ "</xml>";
		return  xml;
	}

	private String wxAppPay(String body,String nonce_str,String notifyUrl,String orderNo,String ip,String money,String attach){
		Map<String, String> packageParams = new HashMap<>();
		packageParams.put(WXConfig.RETURN_KEY_APPID, WXConfig.APP_ID);
		packageParams.put("body", body);
		packageParams.put(WXConfig.RETURN_KEY_MCH_ID, WXConfig.MCH_ID);
		packageParams.put(WXConfig.RETURN_KEY_NONCE_STR, nonce_str);
		packageParams.put(WXConfig.RETURN_KEY_NOTIFY_URL, notifyUrl);
		packageParams.put(WXConfig.RETURN_KEY_OUT_TRADE_NO, orderNo);//商户订单号
		packageParams.put(WXConfig.RETURN_KEY_SPBILL_CREATE_IP, ip);//APP和网页支付提交用户端ip，Native支付填调用微信支付API的机器IP
		packageParams.put(WXConfig.RETURN_KEY_TOTAL_FEE, money);//支付金额，这边需要转成字符串类型，否则后面的签名会失败
		packageParams.put(WXConfig.RETURN_KEY_TRADE_TYPE, WXConfig.APP_TRADETYPE);
		packageParams.put(WXConfig.RETURN_KEY_ATTACH, attach);

		// 除去数组中的空值和签名参数
		packageParams = PayUtil.paraFilter(packageParams);
		String prestr = PayUtil.createLinkString(packageParams); // 把数组所有元素，按照“参数=参数值”的模式用“&”字符拼接成字符串

		//MD5运算生成签名，这里是第一次签名，用于调用统一下单接口
		String mysign = PayUtil.sign(prestr, WXConfig.API_KEY, Constant.DEFAULT_CHARSET).toUpperCase();
//			log.info("=======================第一次签名：" + mysign + "=====================");

		//拼接统一下单接口使用的xml数据，要将上一步生成的签名一起拼接进去
		String xml = "<xml>" + "<appid>" + WXConfig.APP_ID + "</appid>"
				+ "<body><![CDATA[" + body + "]]></body>"
				+ "<mch_id>" + WXConfig.MCH_ID + "</mch_id>"
				+ "<nonce_str>" + nonce_str + "</nonce_str>"
				+ "<notify_url>" + notifyUrl + "</notify_url>"
				+ "<out_trade_no>" + orderNo + "</out_trade_no>"
				+ "<spbill_create_ip>" + ip + "</spbill_create_ip>"
				+ "<total_fee>" + money + "</total_fee>"
				+ "<trade_type>" + WXConfig.APP_TRADETYPE + "</trade_type>"
				+ "<attach>" + attach + "</attach>"
				+ "<sign>" + mysign + "</sign>"
				+ "</xml>";
		return  xml;
	}


}
