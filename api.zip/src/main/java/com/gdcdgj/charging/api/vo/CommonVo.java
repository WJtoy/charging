package com.gdcdgj.charging.api.vo;


import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

@ApiModel(value="CommonVo对象", description="数据传输")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CommonVo implements Serializable{

	private static final long serialVersionUID = 1L;
	@ApiModelProperty(value = "响应码")
	private String status;
	@ApiModelProperty(value = "响应信息")
	private String msg;
	@ApiModelProperty(value = "响应结果")
	private Object data;
	public CommonVo(){}

    private static final String SUCCESS_status = "00";
    private static final String ERROR_status = "99";
    public  static final String SUCCESS_MSG = "操作成功";
    public  static final String ERROR_MSG = "操作失败";

    public CommonVo(Object data) {
        this.status = SUCCESS_status;
        this.msg = SUCCESS_MSG;
        this.data = data;
    }

    public CommonVo(String msg, Object data) {
        this.status = ERROR_status;
        this.msg = msg;
        this.data = data;
    }

	public String getstatus() {
		return status;
	}

	public void setstatus(String status) {
		this.status = status;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public Object getdata() {
		return data;
	}

	public void setdata(Object data) {
		this.data = data;
	}

	public CommonVo(String status, String msg, Object data) {
		this.status = status;
		this.msg = msg;
		this.data = data;
	}

	/**
	 * @param data
	 * @return
	 */
	public static String jsonStringOk(Object data) {
		Map returnMap = new HashMap();
		returnMap.put("message", "OK");
		returnMap.put("status", 200);
		returnMap.put("data",data);
		JSONObject json = new JSONObject(returnMap);
		return json.toString();
	}
	public static String jsonStringOk() {
		Map returnMap = new HashMap();
		returnMap.put("message", "OK");
		returnMap.put("status", 200);
		JSONObject json = new JSONObject(returnMap);
		return json.toString();
	}

	/**
	 * @param data
	 * @return
	 */
	public static String jsonStringError(Object data) {
		Map returnMap = new HashMap();
		returnMap.put("message", "Error");
		returnMap.put("status", 500);
		returnMap.put("data",data);
		JSONObject json = new JSONObject(returnMap);
		return json.toString();
	}

	/**
	 * @param message
	 * @param data
	 * @param status
	 * @return
	 */
	public static String jsonString(String message, Object data, String status) {
		Map returnMap = new HashMap();
		returnMap.put("message", message);
		returnMap.put("data", data);
		returnMap.put("status", status);
		JSONObject json = new JSONObject(returnMap);
		return json.toString();
	}




}
