package com.gdcdgj.charging.api.vo;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.io.Serializable;

/**
 * 将返回的空字段过滤掉
 * 定义的都继承他
 * @author liubiao
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class JsonIncludeVo implements Serializable {
}
