package com.gdcdgj.charging.api.vo.charging;

import com.gdcdgj.charging.api.entity.CustomerChargingorder;
import com.gdcdgj.charging.api.entity.CustomerChargingordertracks;
import com.gdcdgj.charging.api.vo.JsonIncludeVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author JianMei Chen
 * @date 2020/04/22/9:15
 * 充电订单信息
 */
@Data
@ApiModel(value="ChargingOrderInfoVo对象", description="订单详情信息对象，比实体类多了三个字段")
public class ChargingOrderInfoVo extends JsonIncludeVo implements Serializable {

    @ApiModelProperty("充电消费订单对象")
    private CustomerChargingorder order;

    @ApiModelProperty("充电轨迹记录对象")
    private CustomerChargingordertracks chargingOrderTrack;

    @ApiModelProperty("会员状态")
    private Integer memberStatus;

    @ApiModelProperty("车牌号")
    private String carNumber;

    @ApiModelProperty("设备类型")
    private Integer equipmentType;

    @ApiModelProperty("设备编码")
    private String code;

    @ApiModelProperty("站点编号")
    private Integer stationId;

    @ApiModelProperty("站点地址")
    private String address;

    @ApiModelProperty("站点名字")
    private String stationName;

    @ApiModelProperty("站点纬度")
    private Double latitude;

    @ApiModelProperty("站点经度")
    private Double longitude;

    @ApiModelProperty("充电枪接口类型")
    private Integer portType;
}
