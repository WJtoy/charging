package com.gdcdgj.charging.api.vo.charging;

import com.gdcdgj.charging.api.vo.JsonIncludeVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author JianMei Chen
 * @date 2020/04/23/15:35
 *
 */
@Data
@ApiModel("通过站点编号查询快充，慢充相关信息，站点信息等封装类")
public class ChargingStationAllInfoVo extends JsonIncludeVo implements Serializable {

    @ApiModelProperty("站点编号")
    private Integer id;

    @ApiModelProperty("站点名称")
    private String name;

    @ApiModelProperty("快充空闲抢的数量")
    private Integer free_fast_cntr_count;

    @ApiModelProperty("快充枪的总数量")
    private Integer fast_cntr_count;

    @ApiModelProperty("空闲慢充枪的数量")
    private Integer free_slow_cntr_count;

    @ApiModelProperty("慢充枪的总数量")
    private Integer slow_cntr_count;

    @ApiModelProperty("停车费类型")
    private String park_fee_type;

    @ApiModelProperty("停车费政策描述")
    private String park_fee_desc;

    @ApiModelProperty("目前价格（电费+服务费）")
    private Double price;

    @ApiModelProperty("原价格（电费+服务费）")
    private Double original_price;

    @ApiModelProperty("纬度")
    private Double latitude;

    @ApiModelProperty("经度")
    private Double longitude;

    @ApiModelProperty("会员所在地点和站点的几何距离")
    private Double distance;

    //===================================

    @ApiModelProperty("营业时间")
    private String businessHours;

    @ApiModelProperty("站点地址")
    private String address;

    @ApiModelProperty("站点图片url")
    private String imgUrl;


    @ApiModelProperty("当前计费时段")
    private String timeRange;

}
