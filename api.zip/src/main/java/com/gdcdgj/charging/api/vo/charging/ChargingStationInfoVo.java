package com.gdcdgj.charging.api.vo.charging;

import com.gdcdgj.charging.api.entity.AssetsStations;
import com.gdcdgj.charging.api.vo.JsonIncludeVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author JianMei Chen
 * @date 2020/04/22/12:02
 * 充电站点信息
 *   比实体类多了totalFastPileNum,totalSlowPileNum,freeFastPileNum,freeSlowPileNum四个字段
 */
@Data
@ApiModel(value = "ChargingStationInfoVo对象",description = "充电站点信息对象")
public class ChargingStationInfoVo extends JsonIncludeVo implements Serializable {

    @ApiModelProperty("站点信息对象")
    private AssetsStations stations;

    @ApiModelProperty("‘直流接口枪头‘类型的枪数")
    private Integer totalFastPileNum;

    @ApiModelProperty("'交流接口插头'类型的枪数")
    private Integer totalSlowPileNum;

    @ApiModelProperty("'直流接口枪头'类型的正常枪数")
    private Integer freeFastPileNum;

    @ApiModelProperty("'交流接口插头'类型的正常枪数")
    private Integer freeSlowPileNum;

}
