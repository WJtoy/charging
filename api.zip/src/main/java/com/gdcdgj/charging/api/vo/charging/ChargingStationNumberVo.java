package com.gdcdgj.charging.api.vo.charging;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author JianMei Chen
 * @date 2020/04/23/14:40
 * 快充，慢充空闲枪数以及全部数量
 */
@Data
@ApiModel("快充，慢充空闲枪数以及全部数量vo对象")
public class ChargingStationNumberVo {

    @ApiModelProperty("空闲快充枪的数量")
    private Integer freeFastNum;

    @ApiModelProperty("空闲慢充枪的数量")
    private Integer freeSlowNum;

    @ApiModelProperty("快充枪的总数量")
    private Integer totalFastNum;

    @ApiModelProperty("慢充枪的总数量")
    private Integer totalSlowNum;



}
