package com.gdcdgj.charging.api.vo.charging;

import com.gdcdgj.charging.api.vo.JsonIncludeVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author JianMei Chen
 * @date 2020/05/16/16:27
 */
@ApiModel("计价标准vo")
@Data
public class PricingStandardVo extends JsonIncludeVo implements Serializable {

    @ApiModelProperty("开始时间")
    private String startTime;

    @ApiModelProperty("结束时间")
    private String endTime;

    @ApiModelProperty("服务费")
    private double servicePrice;

    @ApiModelProperty("电费")
    private double chargingPrice;

    @ApiModelProperty("所属峰平谷")
    private Integer pnvType;
}
