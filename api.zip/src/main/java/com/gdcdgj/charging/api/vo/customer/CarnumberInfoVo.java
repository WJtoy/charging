package com.gdcdgj.charging.api.vo.customer;

import com.gdcdgj.charging.api.vo.JsonIncludeVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author JianMei Chen
 * @date 2020/05/29/15:44
 */
@ApiModel("会员车辆集合vo对象")
@Data
public class CarnumberInfoVo extends JsonIncludeVo implements Serializable {

    @ApiModelProperty("车辆编号")
    private Integer id;

    @ApiModelProperty("车牌号")
    private String carnumber;

    @ApiModelProperty("是否为默认车牌号")
    private Boolean is_defalult;
}
