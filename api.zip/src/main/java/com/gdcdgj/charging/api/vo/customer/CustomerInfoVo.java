package com.gdcdgj.charging.api.vo.customer;

import com.gdcdgj.charging.api.vo.JsonIncludeVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author JianMei Chen
 * @date 2020/05/08/9:01
 */
@Data
@ApiModel("会员相关信息vo")
public class CustomerInfoVo extends JsonIncludeVo implements Serializable {

    @ApiModelProperty("电话号码")
    private String phone;

    @ApiModelProperty("车牌号")
    private String car_number;

    @ApiModelProperty("余额")
    private Double wallet;

    @ApiModelProperty("信用额")
    private Double credit;

    @ApiModelProperty("优惠券数量")
    private Integer coupon_count;
}
