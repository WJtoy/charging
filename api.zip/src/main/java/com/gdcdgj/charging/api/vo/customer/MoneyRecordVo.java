package com.gdcdgj.charging.api.vo.customer;

import com.gdcdgj.charging.api.vo.JsonIncludeVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author JianMei Chen
 * @date 2020/05/21/15:06
 */
@Data
@ApiModel("充值/退款记录vo对象")
public class MoneyRecordVo extends JsonIncludeVo implements Serializable {

    @ApiModelProperty("充值/退款金额")
    private Double money;

    @ApiModelProperty("充值/退款时间")
    private String time;

    @ApiModelProperty("充值/退款方式")
    private Integer pay_method;

    @ApiModelProperty("流水号")
    private String trade_no;

    @ApiModelProperty("充值/退款结果")
    private Integer status;

    @ApiModelProperty("备注")
    private String remark;
}
