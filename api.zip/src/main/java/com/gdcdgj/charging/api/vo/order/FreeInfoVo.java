package com.gdcdgj.charging.api.vo.order;

import com.gdcdgj.charging.api.vo.JsonIncludeVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author JianMei Chen
 * @date 2020/05/19/9:14
 */
@ApiModel("总费用计算vo对象")
@Data
public class FreeInfoVo extends JsonIncludeVo implements Serializable {

    @ApiModelProperty(value = "开始时间")
    private String startTime;

    @ApiModelProperty(value = "结束时间")
    private String endTime;

    @ApiModelProperty(value = "服务价格")
    private Double servicePrice;

    @ApiModelProperty(value = "充电费用")
    private Double chargingPrice;

    @ApiModelProperty("电量")
    private Double quantity;
}
