package com.gdcdgj.charging.api.vo.order;

import com.gdcdgj.charging.api.vo.JsonIncludeVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author JianMei Chen
 * @date 2020/05/09/11:36
 */
@ApiModel("订单信息vo对象")
@Data
public class OrderInfoVo extends JsonIncludeVo implements Serializable {

    @ApiModelProperty("预计剩余分钟数")
    private Integer left_time;

    @ApiModelProperty("电压")
    private Double voltage;

    @ApiModelProperty("电流")
    private Double current;

    @ApiModelProperty("充电总时长")
    private Integer total_charging_time;

    @ApiModelProperty("充电总电量")
    private Double total_charging_quantity;

    @ApiModelProperty("总电费")
    private Double total_charging_price;

    @ApiModelProperty("总服务费")
    private Double total_service_price;

    @ApiModelProperty("总费用")
    private Double total_price;

    @ApiModelProperty("起始SOC电量%")
    private Double soc_start;

    @ApiModelProperty("结束SOC电量%")
    private Double soc_end;

    @ApiModelProperty("充电开始时间")
    private String start_time;

    @ApiModelProperty("充电结束时间")
    private String end_time;

    @ApiModelProperty("订单编号")
    private String order_no;

    @ApiModelProperty("枪编号")
    private String connector_code;

    @ApiModelProperty("订单状态")
    private Integer payment_status;

    @ApiModelProperty("充电状态")
    private Integer charging_status;
}
