package com.gdcdgj.charging.api.vo.order;

import com.gdcdgj.charging.api.vo.JsonIncludeVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author JianMei Chen
 * @date 2020/05/12/16:07
 */
@ApiModel("订单列表vo对象")
@Data
public class OrderListInfoVo extends JsonIncludeVo implements Serializable {

    @ApiModelProperty("订单编号")
    private String order_no;

    @ApiModelProperty("站点名称")
    private String station_name;

    @ApiModelProperty("充电状态")
    private Integer charging_status;

    @ApiModelProperty("支付状态")
    private Integer payment_status;

    @ApiModelProperty("充电开始时间")
    private String start_time;

    @ApiModelProperty("充电总时长")
    private Integer total_charging_time;

    @ApiModelProperty("总费用")
    private Double total_price;
}
