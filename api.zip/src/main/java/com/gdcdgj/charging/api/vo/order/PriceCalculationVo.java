package com.gdcdgj.charging.api.vo.order;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class PriceCalculationVo {

    @ApiModelProperty(value = "开始时间")
    private String startTime;

    @ApiModelProperty(value = "结束时间")
    private String endTime;

    @ApiModelProperty(value = "服务价格")
    private Double servicePrice;

    @ApiModelProperty(value = "充电费用")
    private Double chargingPrice;

    @ApiModelProperty(value = "充电量")
    private Double charging;

}
