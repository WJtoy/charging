package com.gdcdgj.charging.api.vo.order;

import com.gdcdgj.charging.api.vo.JsonIncludeVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author JianMei Chen
 * @date 2020/05/19/10:50
 */
@ApiModel("电量vo")
@Data
public class QuantityInfoVo extends JsonIncludeVo implements Serializable {

    @ApiModelProperty("电量")
    private Double quantity;

    @ApiModelProperty("相减时间戳")
    private String diffTime;
}
