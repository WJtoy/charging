/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.api.vo.srv2gw;

import java.util.Calendar;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 账户信息查询（0xcb）
 *
 * @author ouxx
 * @since 2016-11-14 下午3:33:19
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class AccountInfo extends DataBaseVo {

	//查询标识
	private int queryCode;
	//响应码
	private int respCode;
	//账户余额
	private int accountBalance;
	//服务费率
	private int serveRate;
	//充电密码验证
	private Byte chargeSignal;
	//验证VIN标志
	private Byte VINSignal;
	//车辆VIN
	private String carVIN;
	//服务费
	private int fee;
	//充电卡号
	private String chargeNo;
	//充电订单号
	private String chargeOrderNo;
	//设置服务费类型
	private Byte feeType;
	//充电卡黑白名单标志
	private Byte blacklistSignal;
	//用户充电卡密码
	private String chargeCheck;
	
	/**************宜步***************/
	//卡号CardNum
	private String cardNum;
	//证件类型CertType
	private Byte certType;
	//证件号码CertNum
	private String certNum;
	//受理渠道ApprovalChannel
	private Integer approvalChannel;//受理渠道
	//出单机构流水号OperSeq
	private String operSeq;//出单机构流水号
	//出单机构代码OperCode
	private String operCode;//出单机构代码
	//受理操作员编号ApprovalOperNum
	private String approvalOperNum;//受理操作员编号
	//交易日期时间TradeDate
	private Calendar tradeDate;//交易日期时间
	//支付密码PayPassword
	private String payPassword;//支付密码
	//服务收费标识ServiceFeeId
	private byte serviceFeeId;//服务收费标识
	//服务收费金额ServiceFee
	private double serviceFee;//服务收费金额
	//报文认证代码AuthCode
	private String authCode;//报文认证码
	
	private String customName;//客户姓名
	private String respDesc;//响应码描述
	private String customNum;//客户号
	private double chargeAllBalance;//电费主账户余额
	private double chargeBalance;//电费主账户可用余额
	private double serviceAllBalance;//服务费账户余额
	private double serviceBalance;//电费主账户余额
	private String tradeSeq;//中心交易流水号
	private Integer permitKwh;//本次允许充电电量
	private Integer permitTime;//本次允许充电时间
}
