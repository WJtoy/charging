/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.api.vo.srv2gw;

import java.util.Calendar;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 告警信息（）
 *
 * @author ouxx
 * @since 2016-11-14 下午3:33:19
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class AlarmInfo extends DataBaseVo {

	//告警信息
	private String alarmInfo;
	//告警点
	private Integer alarmStation;
	//告警开始时间
	private Calendar alarmStartTime;
	//告警结束时间
	private Calendar alarmStopTime;
	//是否影响充电
	private Integer isAffectCharge;
	//确认标识
	private Integer successSignal;
}
