/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.api.vo.srv2gw;

import java.util.Calendar;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 金额补发(0x9c)
 *
 * @author ouxx
 * @since 2016-11-14 下午3:33:19
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class BalanceReissue extends DataBaseVo {

	//用户卡号
	private String userNo;
	//充电金额
	private Integer money;
	//更新结果
	private Integer successSignal;
}
