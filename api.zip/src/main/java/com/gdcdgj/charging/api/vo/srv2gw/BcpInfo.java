/*
 *
 */
package com.gdcdgj.charging.api.vo.srv2gw;

/**
 * 充电桩在充电准备阶段上报BCP 0x03
 * @author ouxx
 * @since 2017-4-28 下午4:56:42
 *
 */
public class BcpInfo extends DataBaseVo {
	private Double batteryCellVolLimit;//单体动力电池最高允许充电电压	2
	private Double currLimit;//最高允许充电电流	2
	private Double totalKwh;//动力蓄电池标称总能量	2
	private Double totalVol;//最高允许充电总电压	2
	private Integer tempretureLimit;//最高允许温度	1
	private Double soc;//整车动力蓄电池荷电状态	2
	private Double currentVol;//动力蓄电池当前电池电压	2

	public Double getBatteryCellVolLimit() {
		return batteryCellVolLimit;
	}
	public void setBatteryCellVolLimit(Double batteryCellVolLimit) {
		this.batteryCellVolLimit = batteryCellVolLimit;
	}
	public Double getCurrLimit() {
		return currLimit;
	}
	public void setCurrLimit(Double currLimit) {
		this.currLimit = currLimit;
	}
	public Double getTotalKwh() {
		return totalKwh;
	}
	public void setTotalKwh(Double totalKwh) {
		this.totalKwh = totalKwh;
	}
	public Double getTotalVol() {
		return totalVol;
	}
	public void setTotalVol(Double totalVol) {
		this.totalVol = totalVol;
	}
	public Integer getTempretureLimit() {
		return tempretureLimit;
	}
	public void setTempretureLimit(Integer tempretureLimit) {
		this.tempretureLimit = tempretureLimit;
	}
	public Double getSoc() {
		return soc;
	}
	public void setSoc(Double soc) {
		this.soc = soc;
	}
	public Double getCurrentVol() {
		return currentVol;
	}
	public void setCurrentVol(Double currentVol) {
		this.currentVol = currentVol;
	}


}
