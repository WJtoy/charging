package com.gdcdgj.charging.api.vo.srv2gw;

import java.util.Calendar;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class BrmInfo extends DataBaseVo{
	private String protocolVersion;//BMS协议版本
	private Byte batteryType;//电池类型
	private Double batteryAh;//动力电池额定容量
	private Double batteryTotalVol;//动力电池额定总电压
	private String batteryManufact;//电池生产厂商名称
	private String batteryPackSn;//	电池组序号
	private Calendar batteryPackDateOfProd;//	电池组生产日期: 年、月、日
	private Integer batteryPackChargTimes;//	电池组充电次数
	private Integer batteryPackPropId;//	电池组产权标识 0，租赁；1、车自有
	private String carVin;//车辆vin
	private String bmsSoftVersion;
}
