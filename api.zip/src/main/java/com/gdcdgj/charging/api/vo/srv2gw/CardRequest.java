package com.gdcdgj.charging.api.vo.srv2gw;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Map;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 刷卡请求
 * @author ydc
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class CardRequest extends DataBaseVo{
	
	//卡类型
	private Integer cardType;
	//卡内余额
	private Double balance;
	//卡状态
	private Integer cardStatus;
	//充电流水号
	private Integer serialNo;
	//停止验证码
	private Integer stopVolidate;
	//用户卡号
	private String userNo;
	//用户输入密码
	private String password;
	//卡唯一ID
	private String cardNo;
	//操作类型
	private Integer operationType;
}
