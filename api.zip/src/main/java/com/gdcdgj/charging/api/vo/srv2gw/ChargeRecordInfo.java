/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.api.vo.srv2gw;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Map;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 充电桩上报充电记录信息
 * ☆为科旺独有
 * @author ouxx
 * @since 2016-11-14 下午3:33:19
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class ChargeRecordInfo extends DataBaseVo {
	
	/****************充电桩上报充电信息*******************/
	//充电枪位置类型
	private int locationType;
	//充电卡号 卡号  ASCII 编码，长度不足，空格补位
	private String chargeNo;
	//开始充电时间
	private Calendar startChargeTime;
	//结束充电时间
	private Calendar stopChargeTime;
	//充电时间长度
	private int chargeTimeLen;
	//开始SOC
	private int startSOC;
	//结束SOC
	private int stopSOC;
	//充电结束原因==是否正常结束
	private int chargeStopCause;
	//本次充电电量
	private Double currentChargeCount;
	//充电前电表读数
	private Double beforeAmmeterNum;
	//充电后电表读数
	private Double afterAmmeterNum;
	//充电策略 0-充满为止 1-按时间 2-按余额 3-按电量
	private int chargePolicy;
	//充电策略参数 时间 min 金额 元 电量 kwh
	private int chargePolicyParam;
	//车辆VIN
	private String carVIN;
	//车牌号8字节 
	private String carLpn;
	//充电流水号
	private String serialNum;
	//本次累计充电能  Kwh
	private double kwh;
	
	/************** ☆ 表示科旺独有****************/
	//☆启动方式
	private int startType;
	//☆充电服务费
	private Double chargeFee;
	//☆本次充电金额
	private int chargeMoney;
	//☆内部索引号
	private int indexNum;
	//☆充电前卡余额
	private int brforeChargeMoney;
	//☆48时段充电map
	private Map<Byte,Double> chargeCount;
	//充电预约序号
	private String bookSeq;

	/***********科旺服务器应答上报充电信息(0xc9)***************/
	//充电优惠、折扣、实扣有效标识
	private int fieldSignal = 0;
	//充电优惠前金额
	private BigDecimal beforeDiscountMoney;
	//充电折扣金额
	private BigDecimal DiscountMoney;
	//用户剩余金额
	private BigDecimal balance;
	/***********宜步中心系统应答充电记录上报(0x63)**************/
	private String customerNum;//客户号
	//本次充电结算时间和电量 格式：充电时间;电量;结束SOC
	//①充电时间 单位:分钟 ②电量 单位：度 ③电量 单位：%
	private String timeAndQuantityAndSoc;
	private String operSeq;//出单机构流水号
	private Calendar tradeDate;//交易日期时间
	
	private double chargingFee;//本次充电结算电费
	private double serviceFee;//本次充电服务费
	private double totalFee;//本次累计消费总金额
	//故障码
	private Integer falutCode;
}
