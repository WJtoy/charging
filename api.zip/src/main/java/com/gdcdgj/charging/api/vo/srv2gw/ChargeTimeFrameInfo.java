/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.api.vo.srv2gw;

import java.util.Calendar;
import java.util.Map;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 充电桩应答服务器查询最近一次充电各时段信息(0x71 0x72)
 *
 * @author ouxx
 * @since 2016-11-14 下午3:33:19
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class ChargeTimeFrameInfo extends DataBaseVo {

	//标志
	private Byte signal;
	//工作状态
	private Byte workState;
	//开始充电时间
	private Calendar startChargeTime;
	//各时段充电电量
	private Map<Byte,Double> timeFrame;
}
