package com.gdcdgj.charging.api.vo.srv2gw;

/**
 * 通讯模式
 * @author ouxx
 * @since 2016-11-10 下午6:15:02
 *
 */
public class CommunicationMode extends DataBaseVo {

	//通讯模式   0x01:应答 0x02:上报
	private Byte mode;
	//定时上报间隔，上报模式，定时上报的间隔单位：秒； 缺省：15秒
	private Byte reportInterval;

	public Byte getMode() {
		return mode;
	}
	public void setMode(Byte mode) {
		this.mode = mode;
	}
	public Byte getReportInterval() {
		return reportInterval;
	}
	public void setReportInterval(Byte reportInterval) {
		this.reportInterval = reportInterval;
	}
}
