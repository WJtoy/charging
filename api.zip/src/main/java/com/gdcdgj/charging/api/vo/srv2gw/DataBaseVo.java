package com.gdcdgj.charging.api.vo.srv2gw;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
@Data
@EqualsAndHashCode
@Accessors(chain = true)
public class DataBaseVo implements Serializable {

	protected String pileCode; //充电桩编码
	protected int providerId;//供应商
	
	protected int memberId;// 用户id
	protected int cmdSeq;//指令序号
	
	protected int equipmentType;//设备类型
	protected int encryptType;//加密方式
	protected int equipmentId;//设备id 保留0x00 0x01

	protected int connectorNo;//枪编码

	
	public String getCode(String pileCode,Integer connectorNo) {
		if(getProviderId() == 2) return pileCode+"_"+connectorNo;
	    return pileCode+ (connectorNo >= 10 ? connectorNo: "0"+connectorNo);
	}
}
