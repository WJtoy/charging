/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.api.vo.srv2gw;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import lombok.experimental.Accessors;

import java.util.Map;

/**
 * 远端心跳包上报(0x58)
 * 服务器系统心跳包应答(0x48)
 * @author ouxx
 * @since 2016-11-14 下午3:33:19
 *
 */
@Data
@Accessors(chain = true)
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class HeartBeat extends DataBaseVo {

	//心跳应答
	private Integer response;
	//心跳序号
	private int heartBeatSeq;
	//连接状态
	private Map<Integer, Integer> connectorState;
}
