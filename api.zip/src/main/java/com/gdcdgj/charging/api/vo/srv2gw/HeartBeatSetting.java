package com.gdcdgj.charging.api.vo.srv2gw;

import java.util.Calendar;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 心跳包信息设置
 * <p>充电桩为确保与服务器远端连接的正常，定期发送该指令向服务器传递连接心跳包信息，
 * 中心服务器接收该信息后给出应答。中心服务器可以对充电桩发送心跳包的间隔周期和超时检测次数进行修改。
 * @author ouxx
 * @since 2016-11-11 下午2:27:27
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class HeartBeatSetting extends DataBaseVo{

	private byte period;//心跳上报周期
	private byte timeOutCnt;//心跳包检测超时次数
}
