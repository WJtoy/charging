package com.gdcdgj.charging.api.vo.srv2gw;

import java.util.Calendar;
import java.util.Map;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 历史记录查询（0x91,0x01）
 *
 * @author ouxx
 * @since 2016-11-14 下午3:33:19
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class HistoryChargeRecord extends DataBaseVo {
	
	/*****************科旺历史充电记录查询应答*****************/
	//查询记录起始索引 0表示最近一次
	private int queryCode;
	//充电枪位置类型
	private Byte locationType;
	//充电卡号
	private String chargeNo;
	//开始充电时间
	private Calendar startChargeTime;
	//结束充电时间
	private Calendar stopChargeTime;
	//充电时间长度
	private int chargeTimeLen;
	//开始SOC
	private Byte startSOC;
	//结束SOC
	private Byte stopSOC;
	//充电结束原因
	private int chargeStopCause;
	//本次充电电量、电能
	private Double currentChargeCount;
	//充电前电表读数
	private Double beforeAmmeterNum;
	//充电后电表读数
	private Double afterAmmeterNum;
	//本次充电金额
	private Double chargeMoney;
	//内部索引号
	private int indexNum;
	//充电前卡余额
	private Double brforeChargeMoney;
	//充电策略-充电模式
	private Byte chargePolicy;
	//充电策略参数
	private int chargePolicyParam;
	//车辆VIN
	private String carVIN;
	//48时段充电map
	private Map<Byte,Double> chargeCount;
	//启动方式 -充电方式
	private Integer startType;
	//充电流水号
	private String serialNum;
	/****************宜步充电历史记录查询应答******************/
	//记录数
	private int recordCount;
	//记录序号Map<recordSerial,recordSerial>
	private Map<Integer,Integer> recordSerialMap;
	//充电位置类型map
	private Map<Integer,Integer> locationTypeMap;
	//充电桩编码Map
	private Map<Integer,String> pileCodeMap;
	//卡号map
	private Map<Integer,String> chargeNoMap;
	//中心交易流水号map
	private Map<Integer,String> serialNumMap;
	//充电预约序号map
	private Map<Integer,String> orderIndexNumMap;
	//车辆VINmap
	private Map<Integer,String> carVINMap;
	//车牌号map
	private Map<Integer,String> carLPNMap;
	//开始充电SOCmap
	private Map<Integer,Integer> startSOCMap;
	//结束充电SOCmap
	private Map<Integer,Integer> endSOCMap;
	//本次充电电量map
	private Map<Integer,Double> chargeQualityMap;
	//本次充电电能map
	private Map<Integer,Double> chargePowerMap;
	//充电时间长度map
	private Map<Integer,Integer> chargeTimeLenMap;
	//充电策略map
	private Map<Integer,Integer> chargePolicyMap;
	//充电结束原因map
	private Map<Integer,Integer> stopCauseMap;
	//开始充电日期时间map
	private Map<Integer,Calendar> startChargeTimeMap;
	//结束充电日期时间map
	private Map<Integer,Calendar> stopChargeTimeMap;
	//交易日期时间map
	private Map<Integer,Calendar> treadTimeMap;
	//开始电表读数map
	private Map<Integer,Double> beforeAmmeterNumMap;
	//结束电表读数map
	private Map<Integer,Double> afterAmmeterNumMap;
	/***************宜步历史查询记录下发*****************/
	//记录起始位置
	private int startlocation;
	//采集记录条数
	private int requireRecordCount;
	/***************科华历史查询记录下发*****************/
	//充电卡类型
	private Integer cardType;
	//充电最高电压
	private Double maxVoltage;
	//充电最大电流
	private Double maxCurrent;
	//充电开始电能
	private Double startChargeQuality;
	//充电结束电能
	private Double stopChargeQuality;
	//是否付费
	private Integer isPayment;
	//单体最高电压
	private Double sigalVoltage;
	//单体最高电流
	private Double sigalCurrent;
	//单体最高温度
	private Double sigalTemperature;
	//本地存储流水号
	private Integer localSerialNo;
	//服务费
	private Double servePrice;
	//总费用
	private Double totalPrice;
	//计费版本
	private String voluationVersion;
	//尖时电量
	private Double sharpQuality;
	//峰时电量
	private Double peakQuality;
	//平时电量
	private Double normalQuality;
	//谷时电量
	private Double valleyQuality;
	//尖时电费
	private Double sharpChargingPrice;
	//峰时电费
	private Double peakChargingPrice;
	//平时电费
	private Double normalChargingPrice;
	//谷时电费
	private Double valleyChargingPrice;
	//尖时服务费
	private Double sharpServicePrice;
	//峰时服务费
	private Double peakServicePrice;
	//平时服务费
	private Double normalServicePrice;
	//谷时服务费
	private Double valleyServicePrice;
	//确认标识
	private Integer successSignal;
	
}
