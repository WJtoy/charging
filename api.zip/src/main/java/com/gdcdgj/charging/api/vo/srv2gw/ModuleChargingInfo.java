/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.api.vo.srv2gw;

import java.util.Calendar;
import java.util.Map;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 充电信息
 * 当前充电模块充电信息查询应答/上报(0x33)
 * @author ouxx
 * @since 2016-11-11 下午10:03:21
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class ModuleChargingInfo extends DataBaseVo{
	
	/**************充电桩模块信息上报******************/
	//充电机故障编码  4字节	每位表示一个故障
	private long faultCode;

	private byte connectorCnt;//充电枪数量
	//充电枪位置N充电类型  1=直流；2=交流  Map<充电枪位置, 类型>
	private Map<Byte, Byte> typeMap;

	//位置N状态 0：充电位待机 1：充电中 2：充电结束 3：充电位故障
	private Map<Byte, Byte> stateMap;

	//位置N本次累计充电kwh  Map<充电枪位置, kwh>10
	private Map<Byte, Double> kwhTotalMap;

	//位置N本次累计充电Ah  Map<充电枪位置, Ah>
	private Map<Byte, Integer> ahMap;

	//位置N本次累计充电时间  Map<充电枪位置, 时间>
	private Map<Byte, Double> timeMap;

	//充电枪位置N起始充电SOC   Map<充电枪位置, soc>
	private Map<Byte, Byte> socBeginMap;

	//充电枪位置N当前SOC   Map<充电枪位置, soc>
	private Map<Byte, Byte> socNowMap;

	//位置N电表度数kwh  Map<充电枪位置, kwh>
	private Map<Byte, Double> kwhMap;

	//位置N电压V  Map<充电枪位置, V>
	private Map<Byte, Double> voltageMap;

	//位置N电流A  Map<充电枪位置, A>
	private Map<Byte, Double> currentMap;

	//预估充满时间(分钟)  Map<充电枪位置, 分钟>
	private Map<Byte, Double> remainTimeMap;

	//充电枪位置N连接状态   Map<充电枪位置, 连接状态>  0未连接，1已连接
	private Map<Byte, Byte> connectedStateMap;

	/*************科旺模块信息上报独有**************/
	//上报方式
	private Byte reportType;
	//模块类型
	private Byte moudleType;
	//模块AC版本
	private Map<Byte, Integer> ACVersionMap;
	//模块AC版本
	private Map<Byte, Integer> DCVersionMap;
	//充电桩告警信息
	private Map<Byte,Integer> alarmMap;

}
