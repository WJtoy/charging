package com.gdcdgj.charging.api.vo.srv2gw;

import java.util.Calendar;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 操作记录
 *
 * @author ouxx
 * @since 2016-11-14 下午3:33:19
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class OperationRecord extends DataBaseVo {

	//操作记录内容
	private Integer operationContext;
	//操作时间
	private Calendar operationTime;
	//操作记录值
	private Integer operationValue;
	//确认标识
	private Integer successSignal;
	
}
