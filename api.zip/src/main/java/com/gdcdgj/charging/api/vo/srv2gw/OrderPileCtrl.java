/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.api.vo.srv2gw;

import java.util.Calendar;
import java.util.Map;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 预约充电设备控制
 * @author ouxx
 * @since 2016-11-11 上午9:28:59
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class OrderPileCtrl extends DataBaseVo{

	//用户账号
	private String userNo;
	//充电流水号
	private Integer serialNo;
	//预约操作
	private Integer orderOperation;
	//预约充电时间
	private Calendar orderChargeTime;
	//预约车牌号
	private String carLPN;
	//预约车VIN
	private String carVIN;
	
	//成功标识
	private Integer successSignal;
}
