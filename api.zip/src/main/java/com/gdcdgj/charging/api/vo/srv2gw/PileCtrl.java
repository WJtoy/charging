/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.api.vo.srv2gw;

import java.util.Calendar;
import java.util.Map;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 充电设备控制
 * @author ouxx
 * @since 2016-11-11 上午9:28:59
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class PileCtrl extends DataBaseVo{

	//参数类型
	private Byte paramType;
	//充电模块个数
	private Byte connectorCount;
	//充电模块位置编号   Map<充电模块位置, 编号>
	private Map<Byte, Byte> connectorNoMap;
	//充电模块 控制参数值  Map<充电模块位置, 控制参数值>
	private Map<Byte, Integer> valueMap;


	/*******新增*********/
	//响应结果-确认标识
	private Integer ResultCode;
	//命令起始标志
	private Integer OriginAddr;
	//参数字节数
	private Integer valueLength;
	//充电流水号
	private String serialNo;
	//余额
	private Double balance;
	//停充验证
	private Integer chargeStopCheck;
	//充电策略
	private Integer chargePolicy;
	//充电策略参数 时间金额单位
	private Integer chargePolicyParam;
	//预约/启动时间
	private Calendar timerStartTime;
	//超时时间
	private Calendar timeoutTime;
	//用户卡号
	private String userNo;
	//车辆Vin识别码
	private String vinCar;
	
	/************科华**************/
	//操作类型
	private Integer operationType;
	//辅源电压
	private Integer voltage;
	//停止验证码-手机号后四位
	private Integer stopVolidate;
}
