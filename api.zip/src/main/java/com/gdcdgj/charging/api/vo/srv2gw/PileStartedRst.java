/*
 *
 */
package com.gdcdgj.charging.api.vo.srv2gw;

import java.util.Calendar;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 桩启动结果。充电桩启动成功后，向平台上报的0x06命令，平台应答0x16
 * @author ouxx
 * @since 2017-3-1 下午7:52:26
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class PileStartedRst extends DataBaseVo {

	//中心系统下发合法用户认证信息0x64
	private String customName;//客户姓名
	private String parkName;//网点名
	//操作类型
	private Integer operationType;
	//用户账号
	private String userNo;
	//充电流水号
	private Integer SerialNo;
	//确认标识 设置结果1成功2失败   、科旺 发送此报文原因0成功 其他失败
	private Integer result;
}
