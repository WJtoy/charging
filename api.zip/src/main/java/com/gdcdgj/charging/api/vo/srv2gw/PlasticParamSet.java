/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.api.vo.srv2gw;

import java.util.Calendar;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 *整形参数设置（）
 *
 * @author ouxx
 * @since 2016-11-14 下午3:33:19
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class PlasticParamSet extends DataBaseVo {

	//类型
	private Byte paramType;
	//查询、起始地址
	private int originAddr;
	//参数个数
	private Byte paramCount;
	//执行结果
	private Byte resultCode;
	//参数字节数
	private int valLength = 4;
	//整形参数值
	private int value;
}
