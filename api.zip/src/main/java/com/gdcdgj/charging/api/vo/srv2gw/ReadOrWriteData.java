/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.api.vo.srv2gw;

import java.util.Map;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 读取终端数据（0x03 83）
 *
 * @author ydc
 * @since 2020/06/3
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class ReadOrWriteData extends DataBaseVo {
	
	//数据单元个数
	private Integer dataCount;
	
	//成功标识 0-失败 1-成功
	private Integer successSignal; 
	
	//数据单元标识
	private Map<Integer,Integer> dataSignalMap;
	//数据单元长度
	private Map<Integer,Integer> dataLengthMap;
	//数据单元值
	private Map<Integer,Object> dataValueMap;
	//数据单元成功标识
	private Map<Integer,Integer> datasuccessSignalMap;
	
}
