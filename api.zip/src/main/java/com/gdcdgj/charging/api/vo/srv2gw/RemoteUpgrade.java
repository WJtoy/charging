/*
 *
 */
package com.gdcdgj.charging.api.vo.srv2gw;

import java.util.Calendar;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 10.2.19	中心系统下发充电桩远程升级命令(0x29)
 * 10.2.20	充电桩远程升级应答(0x39)
 * @author ouxx
 * @since 2017-3-21 下午3:00:24
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class RemoteUpgrade extends DataBaseVo {

	//中心系统下发充电桩远程升级命令(0x29)
	//IP地址
	private String ip;
	//ftp登陆账号
	private String ftpAccount;
	//ftp登陆密码
	private String ftpPassword;
	//文件路径
	private String path;
	//软件版本(如：1.2.2.0)
	private String version;

	//充电桩远程升级应答(0x39)
	//升级结果 0：升级成功  1：升级失败
	private byte result;

}
