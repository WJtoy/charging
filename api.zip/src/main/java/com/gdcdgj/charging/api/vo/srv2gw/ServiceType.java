/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.api.vo.srv2gw;

import java.util.Calendar;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 服务类型
 * <p>
 * 充电桩上报服务类型申请命令(0x71)
 * <p>
 * 中心系统应答服务类型(0x61)
 * @author ouxx
 * @since 2016-11-9 下午8:06:32
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class ServiceType extends DataBaseVo{

	//充电桩上报服务类型申请命令(0x71)
	private String cardNum;//卡号
	private byte type;//交易类型
	private Calendar tradeDate;//交易日期时间

	//中心系统应答服务类型(0x61)
	private String tradeSeq;//中心交易流水号
	private String operSeq;//出单机构流水号

	private Integer ctrlVal;//控制参数 若按时间：分钟； 若按电量：0.01度


}
