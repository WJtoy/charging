/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.api.vo.srv2gw;

import java.util.Calendar;
import java.util.Map;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 24时段电费计价
 *
 * @author ouxx
 * @since 2016-11-14 下午3:33:19
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class SetVoluationPolicy extends DataBaseVo {
	//开始小时map 十二段开始小时存储
	private Map<Byte, Byte> beginHourMap;
	//开始分钟map 十二段开始分钟存储
	private Map<Byte, Byte> beginMinMap;
	//结束小时map 十二段结束小时存储
	private Map<Byte, Byte> endHourMap;
  	//结束分钟map 十二段结束分钟存储
	private Map<Byte, Byte> endMinMap;
  	//费率map 十二段费率存储
	private Map<Byte, Integer> ratesMap;
	//命令执行结果
	private int resultCode;
}
