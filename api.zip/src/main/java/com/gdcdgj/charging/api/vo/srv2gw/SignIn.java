/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.api.vo.srv2gw;

import java.util.Calendar;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 充电桩签到上报报文
 *
 * <p>充电桩根据实际情况实时上传签到报文到运营管理平台。
 * <p>以下情况需要上报该报文：
 * <p>1) 充电桩上电以后，完成初始化，进入正常工作状态，自动向中心监控上报签到信息；
 * <p>2) 充电桩检测到网络中断以后，又恢复连接，自动向中心监控上报签到信息；
 * <p>3) 从充电桩管理状态切换到服务状态；
 * <p>4) 充电桩按照周期签到参数设置要求，自动定时向中心监控上报签到信息
 * @author ouxx
 * @since 2016-11-11 下午1:40:16
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class SignIn extends DataBaseVo{

	//设备资产编码
	private String assetCode;
	//系统软件版本
	private Double version;
	//版本号的字符串，只作存储
	private String versionStr;
	//启动次数
	private long bootTimes;
	//存储空间容量  按照M 为单位（可选）
	private long capacity;
	//软件持续运行时间
	private long continuousRunPeriod;
	//最近一次启动时间
	private Calendar lastBootTime;
	//最近一次签到时间
	private Calendar lastSignInTime;
	/*************新增************/
	//加密标志
	private Byte signal;
	//签到间隔时间
	private long intervalTime;
	//充电枪个数
	private int connectCount;
	//充电记录数量
	private int chargeCount;
	//当前系统时间
	private Calendar currentTime;
	//签到密码
	private Byte signInCheck;
	//公共模数
	private String moudleCount;
	//启停用标志
	private Byte startStopSingal;
	//RSA
	private int RSA;
}
