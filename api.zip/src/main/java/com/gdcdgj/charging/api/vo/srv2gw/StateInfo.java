/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.api.vo.srv2gw;

import java.util.Calendar;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 状态信息
 *
 * @author ouxx
 * @since 2016-11-14 下午3:33:19
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class StateInfo extends DataBaseVo {
	
	/*************科旺状态信息包上报(0x68)**************/
	//充电枪数量
	private Byte connectorCount;
	//充电枪类型
	private Byte connectorType;
	//工作状态
	private Byte workState;
	//当前SOC%
	private Byte currentSOC;
	//当前最高警告编码
	private int alarmCode;
	//车连接状态 0&1 = 0 未连接  2 = 已连接
	private Byte carConnectState;
	//本次充电累计费用   整形
	private int chargeCost;
	//直流充电电压
	private Double DCChargePressure;
	//直流充电电流
	private Double DCChargeElectric;
	//BMS需求电压
	private int BMSPressure;
	//BMS需求电流
	private int BMSElectric;
	//BMS充电模式
	private Byte BMSChargeType;
	//交流A相充电电压
	private int ACChargePressure;
	//交流B相充电电压
	private int ACChargePressure1;
	//交流C相充电电压
	private int ACChargePressure2;
	//交流A相充电电流
	private int ACChargeElectric;
	//交流B相充电电流
	private int ACChargeElectric1;
	//交流C相充电电流
	private int ACChargeElectric2;
	//剩余充电时间，min
	private int residueChargeTime;
	//充电时长
	private Integer chargeTime;
	//本次累计充电电量
	private Double chargePowerCount;
	//当前电表读数
	private Double currentQuliety;
	//充电启动方式
	private Byte startType;
	//充电预约卡号
	private String chargeNo;
	//预约开始充电时间
	private Calendar beginChargeTime;
	//充电功率
	private Double chargePower;
	
	/***********宜步充电桩总体状态应答上报(0x31)***********/
	//输入电源状态 1- 正常  2- 异常
	private byte inputPowerStatus;
	//平均温度
	private byte meanTemp;
	//外部温度
	private byte outsideTemp;
	//输出有功功率
	private int outputActivePower;
	//输出无功功率
	private int outputReactivePower;
	//充电系统总体状态 bit0=0：正常；bit0=1：故障     bit1=0：门关闭；bit1=1：门开
	//bit2=0：桩位空闲；bit2=1：桩位占用   bit7~bit4=0000 独立工作  bit7~bit4=0001 并机工作
	private byte overallStatus;
	//充电系统故障状态
	private int faultStatus;
	//AC/DC模块控制故障状态
	private int acDcFaultStatus;
	//风扇总状态  2=运行/1=停止/3 故障
	private byte fanStatus;
	//空调总状态  2=运行/1=停止/3 故障
	private byte airCondStatus;
	//加热器总状态  2=运行/1=停止/3 故障
	private byte heaterStatus;
	//烟雾报警总状态  1=异常/2=正常/3 故障
	private byte smokeAlarmStatus;
	//震动传感器报警总状态  1=异常/2=正常/3 故障
	private byte vibratAlarmStatus;
	//地锁数量
	private byte lockCnt;
	
}
