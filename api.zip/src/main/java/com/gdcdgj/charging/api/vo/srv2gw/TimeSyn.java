package com.gdcdgj.charging.api.vo.srv2gw;

import java.util.Calendar;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 宜步时间同步
 * @author ydc
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class TimeSyn extends DataBaseVo{
	
		//标准时钟:
		//2016-10-17-20-09-03
		private Calendar clock;
		//结果
		private Integer successSignal;
}
