package com.gdcdgj.charging.api.vo.srv2gw;

import java.util.Calendar;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 宜步充电前下发用户合法认证
 * @author ydc
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class ValidAuthen extends DataBaseVo {
		//中心系统下发合法用户认证信息0x64
		private String customName;//客户姓名
		private String parkName;//网点名

		//充电桩应答中心合法用户认证通过信息命令0x74
		private Integer result;//设置结果
}
