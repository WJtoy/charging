/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.api.vo.srv2gw;

import java.util.Calendar;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 计费规则
 *
 * @author ydc
 * @since 2020
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class VoluationPolicy extends DataBaseVo {

	//计费规则版本号
	private String policyVersion;
	//计费规则段数
	private Integer partCount;
	//时段1起始时间
	private Calendar partStartTime1;
	//时段1标识  (尖时段 峰时段 平时段 谷时段)
	private Integer partSignal1;
	//时段2起始时间
	private Calendar partStartTime2;
	//时段2标识
	private Integer partSignal2;
	//时段3起始时间
	private Calendar partStartTime3;
	//时段3标识
	private Integer partSignal3;
	//时段4起始时间
	private Calendar partStartTime4;
	//时段4标识
	private Integer partSignal4;
	//尖时电费
	private Double sharpPrice;
	//尖时服务费
	private Double sharpServicePrice;
	//峰时电费
	private Double peakPrice;
	//峰时服务费
	private Double peakServicePrice;
	//平时电费
	private Double normalPrice;
	//平时服务费
	private Double normalServicePrice;
	//谷时电费
	private Double valleyPrice;
	//谷时服务费
	private Double valleyServicePrice;
}
