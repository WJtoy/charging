package com.gdcdgj.charging.api.vo.srv2gw;

import java.util.Calendar;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 工作参数
 * @author ydc
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class WorkParam extends DataBaseVo{
	
	/////////////充电桩工作参数(0x46)
	//充电桩类型
	private byte type;
	//可服务电池类型
	private byte batteryType;
	//充电枪个数
	private byte connectorCnt;
	//中心服务器地址
	private String srvIp;
	//中心服务器端口
	private int srvPort;
	
	///////////充电桩工作参数应答(0x56)
	//设置结果
	private int settingRst;
}
