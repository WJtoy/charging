package com.gdcdgj.charging.api.vo.station;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.gdcdgj.charging.api.vo.JsonIncludeVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author JianMei Chen
 * @date 2020/05/07/9:04
 */
@Data
@ApiModel("充电枪信息vo")
public class ConnectorInfoVo extends JsonIncludeVo implements Serializable {


    @ApiModelProperty("充电枪编号（辅助使用，不输出）")
    @JsonIgnore
    private Integer id;

    @ApiModelProperty("枪口编码")
    private String code;

    @ApiModelProperty("枪状态")
    private Integer status;

    @ApiModelProperty("额定功率")
    private Integer rated_power;

    @ApiModelProperty("当前插口车辆的电量%")
    private Double soc;
}
