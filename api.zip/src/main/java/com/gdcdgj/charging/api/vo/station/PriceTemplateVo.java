package com.gdcdgj.charging.api.vo.station;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.gdcdgj.charging.api.vo.JsonIncludeVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author JianMei Chen
 * @date 2020/04/24/14:28
 *  该站点的所有价格模板显示
 */
@Data
@ApiModel(value = "该站点的所有价格模板显示",description = "时间段，电费，服务费")
public class PriceTemplateVo extends JsonIncludeVo implements Serializable {

    @ApiModelProperty("时间段")
    private String period;

    @ApiModelProperty("电费")
    private Double charging_price;

    @ApiModelProperty("服务费")
    private Double service_price;

    @ApiModelProperty("所属峰平谷")
    @JsonIgnore
    private Integer pnv_type;

}
