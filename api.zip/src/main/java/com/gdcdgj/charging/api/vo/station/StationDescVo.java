package com.gdcdgj.charging.api.vo.station;

import com.gdcdgj.charging.api.vo.JsonIncludeVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author JianMei Chen
 * @date 2020/05/07/8:53
 */
@Data
@ApiModel(value = "StationDescVo对象",description = "站点详情vo")
public class StationDescVo extends JsonIncludeVo implements Serializable {

    @ApiModelProperty("站点名称")
    private String name;

    @ApiModelProperty("营业时间")
    private String weekday;

    @ApiModelProperty("营业开始时间")
    private String start_time;

    @ApiModelProperty("营业结束时间")
    private String end_time;

    @ApiModelProperty("站点地址")
    private String address;

    @ApiModelProperty("站点地址附加说明")
    private String ext_address;

    @ApiModelProperty("站点纬度")
    private Double latitude;

    @ApiModelProperty("站点经度")
    private Double longitude;

    @ApiModelProperty("站点相关图片的url列表")
    private List<String> images;

    @ApiModelProperty("站点相关标签集")
    private String tags;

    @ApiModelProperty("全部快充桩状态描述")
    private List<ConnectorInfoVo> fast_cntrs;

    @ApiModelProperty("全部慢充桩状态描述")
    private List<ConnectorInfoVo> slow_cntrs;

    @ApiModelProperty("价格模板")
    private List<PriceTemplateVo> price_period;

    @ApiModelProperty("停车费类型")
    private Integer park_fee_type;

    @ApiModelProperty("停车费政策描述")
    private String park_fee_desc;

    @ApiModelProperty("合作商家名称")
    private String company;

    @ApiModelProperty("联系电话")
    private String phone;
}
