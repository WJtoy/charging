package com.gdcdgj.charging.api.vo.station;

import com.gdcdgj.charging.api.vo.JsonIncludeVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author JianMei Chen
 * @date 2020/05/06/14:43
 */
@ApiModel("站点标签vo对象")
@Data
public class StationTagsVo extends JsonIncludeVo implements Serializable {

    @ApiModelProperty("标签编号")
    private Integer id;

    @ApiModelProperty("标签名称")
    private String name;
}
