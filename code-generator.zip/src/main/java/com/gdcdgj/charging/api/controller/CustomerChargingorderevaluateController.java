package com.gdcdgj.charging.api.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;

/**
 * <p>
 * 订单评价表 前端控制器
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Controller
@RequestMapping("/customerChargingorderevaluate")
public class CustomerChargingorderevaluateController {

}

