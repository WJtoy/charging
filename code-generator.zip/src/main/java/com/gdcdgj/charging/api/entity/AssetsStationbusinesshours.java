package com.gdcdgj.charging.api.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 站点营业时间
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="AssetsStationbusinesshours对象", description="站点营业时间")
public class AssetsStationbusinesshours implements Serializable {

    private static final long serialVersionUID=1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "星期内的日期")
    private String weekday;

    @ApiModelProperty(value = "营业开始时间")
    private Date startTime;

    @ApiModelProperty(value = "营业结束时间")
    private Date endTime;

    @ApiModelProperty(value = "站点")
    private Integer stationId;


}
