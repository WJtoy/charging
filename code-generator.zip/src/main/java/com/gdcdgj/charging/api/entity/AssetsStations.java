package com.gdcdgj.charging.api.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 充电站
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="AssetsStations对象", description="充电站")
public class AssetsStations implements Serializable {

    private static final long serialVersionUID=1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "站点名称")
    private String name;

    @ApiModelProperty(value = "站点编号")
    private String code;

    @ApiModelProperty(value = "地址")
    private String address;

    @ApiModelProperty(value = "地址附加描述")
    private String extAddress;

    @ApiModelProperty(value = "纬度")
    private Double latitude;

    @ApiModelProperty(value = "经度")
    private Double longitude;

    @ApiModelProperty(value = "服务电话")
    private String servicePhone;

    @ApiModelProperty(value = "区域代码")
    private String cityCode;

    @ApiModelProperty(value = "物业合作方式")
    private Integer cooperationType;

    @ApiModelProperty(value = "物业公司名称")
    private String propertyManagementCompany;

    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    @ApiModelProperty(value = "是否启用")
    private Boolean isEnabled;

    @ApiModelProperty(value = "停用时间")
    private Date disableTime;

    @ApiModelProperty(value = "是否删除")
    private Boolean isDeleted;

    @ApiModelProperty(value = "删除原因")
    private String deleteReason;

    @ApiModelProperty(value = "删除时间")
    private Date deleteTime;

    @ApiModelProperty(value = "停车位数量")
    private Integer parkNums;

    @ApiModelProperty(value = "充电桩数量")
    private Integer pileNums;

    @ApiModelProperty(value = "充电枪数量")
    private Integer connectorNums;

    @ApiModelProperty(value = "站点属性（二进制按位取标识）")
    private Integer propertyLabel;

    @ApiModelProperty(value = "停车费类型")
    private Integer parkFeeType;

    @ApiModelProperty(value = "停车费政策描述")
    private String parkFeeDesc;

    @ApiModelProperty(value = "备注说明")
    private String memo;

    @ApiModelProperty(value = "所属区域")
    private Integer cityId;

    @ApiModelProperty(value = "所属运营商")
    private Integer companyId;

    @ApiModelProperty(value = "创建人")
    private Integer createrId;

    @ApiModelProperty(value = "删除人")
    private Integer deleterId;

    @ApiModelProperty(value = "负责人")
    private Integer managerId;


}
