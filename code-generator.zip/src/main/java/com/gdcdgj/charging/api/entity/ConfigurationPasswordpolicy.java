package com.gdcdgj.charging.api.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 密码设置策略
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="ConfigurationPasswordpolicy对象", description="密码设置策略")
public class ConfigurationPasswordpolicy implements Serializable {

    private static final long serialVersionUID=1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "密码最短长度")
    private Integer lengthMin;

    @ApiModelProperty(value = "密码最大长度")
    private Integer lengthMax;

    @ApiModelProperty(value = "要求首字母大写")
    private Boolean isCapitalize;

    @ApiModelProperty(value = "需包含字母")
    private Boolean containsAlpha;

    @ApiModelProperty(value = "需包含数字")
    private Boolean containsNumber;

    @ApiModelProperty(value = "需包含符号")
    private Boolean containsSymbol;

    @ApiModelProperty(value = "提示信息")
    private String tip;


}
