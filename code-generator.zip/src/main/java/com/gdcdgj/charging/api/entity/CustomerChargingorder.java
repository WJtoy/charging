package com.gdcdgj.charging.api.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 会员账户充值记录
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="CustomerChargingorder对象", description="会员账户充值记录")
public class CustomerChargingorder implements Serializable {

    private static final long serialVersionUID=1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "订单号")
    private String orderNo;

    @ApiModelProperty(value = "订单状态")
    private Integer status;

    @ApiModelProperty(value = "扫码时间")
    private Date scanTime;

    @ApiModelProperty(value = "订单生成时间")
    private Date orderTime;

    @ApiModelProperty(value = "充电开始时间")
    private Date startTime;

    @ApiModelProperty(value = "峰时充电时长")
    private Integer peaksChargingTime;

    @ApiModelProperty(value = "峰时充电电量")
    private Double peaksChargingQuantity;

    @ApiModelProperty(value = "峰时电费")
    private Double peaksChargingPrice;

    @ApiModelProperty(value = "峰时服务费")
    private Double peaksServicePrice;

    @ApiModelProperty(value = "平时充电时长")
    private Integer normalChargingTime;

    @ApiModelProperty(value = "平时充电电量")
    private Double normalChargingQuantity;

    @ApiModelProperty(value = "平时电费")
    private Double normalChargingPrice;

    @ApiModelProperty(value = "平时服务费")
    private Double normalServicePrice;

    @ApiModelProperty(value = "谷时充电时长")
    private Integer valleysChargingTime;

    @ApiModelProperty(value = "谷时充电电量")
    private Double valleysChargingQuantity;

    @ApiModelProperty(value = "谷时电费")
    private Double valleysChargingPrice;

    @ApiModelProperty(value = "谷时服务费")
    private Double valleysServicePrice;

    @ApiModelProperty(value = "总充电时长")
    private Integer totalChargingTime;

    @ApiModelProperty(value = "总充电电量")
    private Double totalChargingQuantity;

    @ApiModelProperty(value = "总电费")
    private Double totalChargingPrice;

    @ApiModelProperty(value = "总服务费")
    private Double totalServicePrice;

    @ApiModelProperty(value = "总费用")
    private Double totalPrice;

    @ApiModelProperty(value = "起始SOC电量")
    private Double socStart;

    @ApiModelProperty(value = "结束SOC电量")
    private Double socEnd;

    @ApiModelProperty(value = "起始电表度数kwh")
    private Double electricStart;

    @ApiModelProperty(value = "起始电表度数kwh")
    private Double electricEnd;

    @ApiModelProperty(value = "充电结束时间")
    private Date stopTime;

    @ApiModelProperty(value = "订单结束方式")
    private Integer stopMethod;

    @ApiModelProperty(value = "账单生成时间")
    private Date billTime;

    @ApiModelProperty(value = "支付时间")
    private Date payTime;

    @ApiModelProperty(value = "是否支付成功")
    private Boolean isPaySuccess;

    @ApiModelProperty(value = "钱包余额支付金额")
    private Double walletPayAmount;

    @ApiModelProperty(value = "实际余额支付金额")
    private Double realPayAmount;

    @ApiModelProperty(value = "充电枪编号")
    private String connectorCode;

    @ApiModelProperty(value = "会员手机号")
    private String memberPhone;

    @ApiModelProperty(value = "区划代码")
    private String cityCode;

    @ApiModelProperty(value = "区划")
    private Integer cityId;

    @ApiModelProperty(value = "运营商")
    private Integer companyId;

    @ApiModelProperty(value = "充电枪")
    private Integer connectorId;

    @ApiModelProperty(value = "会员")
    private Integer memberId;

    @ApiModelProperty(value = "充电桩")
    private Integer pileId;

    @ApiModelProperty(value = "设备商")
    private Integer pileProviderId;

    @ApiModelProperty(value = "站点")
    private Integer stationId;

    @ApiModelProperty(value = "电流")
    private Integer current;

    @ApiModelProperty(value = "剩余充电时间")
    private Integer leftTime;

    @ApiModelProperty(value = "需求电流")
    private Integer requireCurrent;

    @ApiModelProperty(value = "需求电压")
    private Integer requireVoltage;

    @ApiModelProperty(value = "电压")
    private Integer voltage;


}
