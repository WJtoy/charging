package com.gdcdgj.charging.api.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 充电订单过程轨迹跟踪
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="CustomerChargingordertracks对象", description="充电订单过程轨迹跟踪")
public class CustomerChargingordertracks implements Serializable {

    private static final long serialVersionUID=1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "当前时间")
    private Date addTime;

    @ApiModelProperty(value = "峰时充电时长")
    private Integer peaksChargingTime;

    @ApiModelProperty(value = "峰时电费")
    private Double peaksChargingPrice;

    @ApiModelProperty(value = "峰时服务费")
    private Double peaksServicePrice;

    @ApiModelProperty(value = "平时充电时长")
    private Integer normalChargingTime;

    @ApiModelProperty(value = "平时电费")
    private Double normalChargingPrice;

    @ApiModelProperty(value = "平时服务费")
    private Double normalServicePrice;

    @ApiModelProperty(value = "谷时充电时长")
    private Integer valleysChargingTime;

    @ApiModelProperty(value = "谷时电费")
    private Double valleysChargingPrice;

    @ApiModelProperty(value = "谷时服务费")
    private Double valleysServicePrice;

    @ApiModelProperty(value = "总充电时长")
    private Integer totalChargingTime;

    @ApiModelProperty(value = "总电费")
    private Double totalChargingPrice;

    @ApiModelProperty(value = "总服务费")
    private Double totalServicePrice;

    @ApiModelProperty(value = "总费用")
    private Double totalPrice;

    @ApiModelProperty(value = "起始SOC电量")
    private Double socStart;

    @ApiModelProperty(value = "结束SOC电量")
    private Double socEnd;

    @ApiModelProperty(value = "起始电表度数kwh")
    private Double electricStart;

    @ApiModelProperty(value = "起始电表度数kwh")
    private Double electricEnd;

    @ApiModelProperty(value = "电压")
    private Integer voltage;

    @ApiModelProperty(value = "电流")
    private Integer current;

    @ApiModelProperty(value = "需求电压")
    private Integer requireVoltage;

    @ApiModelProperty(value = "需求电流")
    private Integer requireCurrent;

    @ApiModelProperty(value = "预计剩余时间")
    private Integer leftTime;

    @ApiModelProperty(value = "充电订单")
    private Integer orderId;

    @ApiModelProperty(value = "平时充电电量")
    private Double normalChargingQuantity;

    @ApiModelProperty(value = "峰时充电电量")
    private Double peaksChargingQuantity;

    @ApiModelProperty(value = "总充电电量")
    private Double totalChargingQuantity;

    @ApiModelProperty(value = "谷时充电电量")
    private Double valleysChargingQuantity;


}
