package com.gdcdgj.charging.api.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 站点评价表
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="CustomerStationevaluate对象", description="站点评价表")
public class CustomerStationevaluate implements Serializable {

    private static final long serialVersionUID=1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "当前时间")
    private Date addTime;

    @ApiModelProperty(value = "评价分类标签")
    private Integer category;

    @ApiModelProperty(value = "评价内容")
    private String content;

    @ApiModelProperty(value = "客服是否已跟进处理该问题")
    private Boolean isResolved;

    @ApiModelProperty(value = "解决人")
    private String resolvedBy;

    @ApiModelProperty(value = "处理方案（客服自填）")
    private String solution;

    @ApiModelProperty(value = "会员ID")
    private Integer memberId;

    @ApiModelProperty(value = "站点ID")
    private Integer stationId;


}
