package com.gdcdgj.charging.api.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 半小时信息汇总
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="ReportHourssummary对象", description="半小时信息汇总")
public class ReportHourssummary implements Serializable {

    private static final long serialVersionUID=1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "日期")
    private Date date;

    @ApiModelProperty(value = "半小时段（0~47）")
    private Integer hours;

    @ApiModelProperty(value = "订单量")
    private Integer orderNums;

    @ApiModelProperty(value = "充电量")
    private Double chargingQuantity;

    @ApiModelProperty(value = "账单量")
    private Integer billNums;

    @ApiModelProperty(value = "账单金额（营收金额）")
    private Double billAmount;

    @ApiModelProperty(value = "订单故障量（以账单为基准）")
    private Integer faultOrderNums;

    @ApiModelProperty(value = "活跃客户数量")
    private Integer activeCustomerNums;

    @ApiModelProperty(value = "站点")
    private Integer stationId;


}
