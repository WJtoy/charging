package com.gdcdgj.charging.api.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 区划和站点信息汇总
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="ReportRegionsummary对象", description="区划和站点信息汇总")
public class ReportRegionsummary implements Serializable {

    private static final long serialVersionUID=1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "日期类型")
    private String dtype;

    @ApiModelProperty(value = "起始日期")
    private Date date;

    @ApiModelProperty(value = "订单量")
    private Integer orderNums;

    @ApiModelProperty(value = "订单故障量")
    private Integer faultOrderNums;

    @ApiModelProperty(value = "故障率")
    private Double failtureRate;

    @ApiModelProperty(value = "充电量")
    private Double chargingQuantity;

    @ApiModelProperty(value = "账单量")
    private Integer billNums;

    @ApiModelProperty(value = "账单金额（营收金额）")
    private Double billAmount;

    @ApiModelProperty(value = "注册客户数量")
    private Integer newCustomerNums;

    @ApiModelProperty(value = "活跃客户数量")
    private Integer activeCustomerNums;

    @ApiModelProperty(value = "客户留存率")
    private Double retentionRate;

    @ApiModelProperty(value = "区划")
    private Integer cityId;

    @ApiModelProperty(value = "运营商")
    private Integer companyId;

    @ApiModelProperty(value = "站点")
    private Integer stationId;

    @ApiModelProperty(value = "区划级别")
    private Integer cityLevel;

    @ApiModelProperty(value = "运营商类型")
    private Integer companyType;

    @ApiModelProperty(value = "总可用充电时长")
    private Integer chargingDurationAvailable;

    @ApiModelProperty(value = "实际充电时长")
    private Integer chargingDurationUsage;

    @ApiModelProperty(value = "区划编码")
    private String cityCode;

    @ApiModelProperty(value = "区划名称")
    private String cityName;

    @ApiModelProperty(value = "使用率")
    private Double durationRate;


}
