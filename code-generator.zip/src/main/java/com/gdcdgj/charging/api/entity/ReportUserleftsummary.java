package com.gdcdgj.charging.api.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 会员留存统计
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="ReportUserleftsummary对象", description="会员留存统计")
public class ReportUserleftsummary implements Serializable {

    private static final long serialVersionUID=1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "基准日期")
    private Date baseDate;

    @ApiModelProperty(value = "会员渠道来源")
    private String source;

    @ApiModelProperty(value = "基准用户数量")
    private Integer baseUser;

    @ApiModelProperty(value = "1日留存量")
    private Integer left1;

    @ApiModelProperty(value = "2日留存量")
    private Integer left2;

    @ApiModelProperty(value = "3日留存量")
    private Integer left3;

    @ApiModelProperty(value = "4日留存量")
    private Integer left4;

    @ApiModelProperty(value = "5日留存量")
    private Integer left5;

    @ApiModelProperty(value = "6日留存量")
    private Integer left6;

    @ApiModelProperty(value = "7日留存量")
    private Integer left7;

    @ApiModelProperty(value = "15日留存量")
    private Integer left15;

    @ApiModelProperty(value = "30日留存量")
    private Integer left30;

    @ApiModelProperty(value = "60日留存量")
    private Integer left60;

    @ApiModelProperty(value = "90日留存量")
    private Integer left90;

    @ApiModelProperty(value = "180日留存量")
    private Integer left180;

    @ApiModelProperty(value = "360日留存量")
    private Integer left360;


}
