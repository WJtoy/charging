package com.gdcdgj.charging.api.mapper;

import com.gdcdgj.charging.api.entity.AssetsChargingpile;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 充电桩 Mapper 接口
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
public interface AssetsChargingpileMapper extends BaseMapper<AssetsChargingpile> {

}
