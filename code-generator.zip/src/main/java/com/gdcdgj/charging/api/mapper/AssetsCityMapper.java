package com.gdcdgj.charging.api.mapper;

import com.gdcdgj.charging.api.entity.AssetsCity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 行政区划 Mapper 接口
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
public interface AssetsCityMapper extends BaseMapper<AssetsCity> {

}
