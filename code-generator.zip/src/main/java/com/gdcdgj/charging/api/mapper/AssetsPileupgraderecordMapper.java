package com.gdcdgj.charging.api.mapper;

import com.gdcdgj.charging.api.entity.AssetsPileupgraderecord;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 电桩升级记录 Mapper 接口
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
public interface AssetsPileupgraderecordMapper extends BaseMapper<AssetsPileupgraderecord> {

}
