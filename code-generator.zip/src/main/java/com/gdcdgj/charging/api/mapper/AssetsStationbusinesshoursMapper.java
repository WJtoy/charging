package com.gdcdgj.charging.api.mapper;

import com.gdcdgj.charging.api.entity.AssetsStationbusinesshours;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 站点营业时间 Mapper 接口
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
public interface AssetsStationbusinesshoursMapper extends BaseMapper<AssetsStationbusinesshours> {

}
