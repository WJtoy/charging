package com.gdcdgj.charging.api.mapper;

import com.gdcdgj.charging.api.entity.AssetsStationchargingprice;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 站点使用价格关系 Mapper 接口
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
public interface AssetsStationchargingpriceMapper extends BaseMapper<AssetsStationchargingprice> {

}
