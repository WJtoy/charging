package com.gdcdgj.charging.api.mapper;

import com.gdcdgj.charging.api.entity.ConfigurationChargingpricetimeperiod;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 价格模板时间段 Mapper 接口
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
public interface ConfigurationChargingpricetimeperiodMapper extends BaseMapper<ConfigurationChargingpricetimeperiod> {

}
