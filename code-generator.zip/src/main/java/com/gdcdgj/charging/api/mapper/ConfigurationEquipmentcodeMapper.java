package com.gdcdgj.charging.api.mapper;

import com.gdcdgj.charging.api.entity.ConfigurationEquipmentcode;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 充电桩告警消息配置 Mapper 接口
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
public interface ConfigurationEquipmentcodeMapper extends BaseMapper<ConfigurationEquipmentcode> {

}
