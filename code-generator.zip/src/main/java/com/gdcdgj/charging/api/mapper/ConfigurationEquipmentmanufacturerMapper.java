package com.gdcdgj.charging.api.mapper;

import com.gdcdgj.charging.api.entity.ConfigurationEquipmentmanufacturer;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 设备商 Mapper 接口
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
public interface ConfigurationEquipmentmanufacturerMapper extends BaseMapper<ConfigurationEquipmentmanufacturer> {

}
