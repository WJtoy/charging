package com.gdcdgj.charging.api.mapper;

import com.gdcdgj.charging.api.entity.ConfigurationLoginpolicy;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 登陆策略 Mapper 接口
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
public interface ConfigurationLoginpolicyMapper extends BaseMapper<ConfigurationLoginpolicy> {

}
