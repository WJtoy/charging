package com.gdcdgj.charging.api.mapper;

import com.gdcdgj.charging.api.entity.CustomerChargingorderevaluate;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 订单评价表 Mapper 接口
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
public interface CustomerChargingorderevaluateMapper extends BaseMapper<CustomerChargingorderevaluate> {

}
