package com.gdcdgj.charging.api.mapper;

import com.gdcdgj.charging.api.entity.CustomerChargingorderpayment;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 会员充电订单支付记录 Mapper 接口
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
public interface CustomerChargingorderpaymentMapper extends BaseMapper<CustomerChargingorderpayment> {

}
