package com.gdcdgj.charging.api.mapper;

import com.gdcdgj.charging.api.entity.CustomerChargingordertracks;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 充电订单过程轨迹跟踪 Mapper 接口
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
public interface CustomerChargingordertracksMapper extends BaseMapper<CustomerChargingordertracks> {

}
