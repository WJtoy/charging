package com.gdcdgj.charging.api.mapper;

import com.gdcdgj.charging.api.entity.CustomerMember;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 会员 Mapper 接口
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
public interface CustomerMemberMapper extends BaseMapper<CustomerMember> {

}
