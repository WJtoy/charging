package com.gdcdgj.charging.api.mapper;

import com.gdcdgj.charging.api.entity.EmployeeCooperation;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 合作渠道商 Mapper 接口
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
public interface EmployeeCooperationMapper extends BaseMapper<EmployeeCooperation> {

}
