package com.gdcdgj.charging.api.mapper;

import com.gdcdgj.charging.api.entity.EmployeePermissions;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 权限 Mapper 接口
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
public interface EmployeePermissionsMapper extends BaseMapper<EmployeePermissions> {

}
