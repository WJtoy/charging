package com.gdcdgj.charging.api.mapper;

import com.gdcdgj.charging.api.entity.ReportHourssummary;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 半小时信息汇总 Mapper 接口
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
public interface ReportHourssummaryMapper extends BaseMapper<ReportHourssummary> {

}
