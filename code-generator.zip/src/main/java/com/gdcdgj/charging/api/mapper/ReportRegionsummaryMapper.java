package com.gdcdgj.charging.api.mapper;

import com.gdcdgj.charging.api.entity.ReportRegionsummary;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 区划和站点信息汇总 Mapper 接口
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
public interface ReportRegionsummaryMapper extends BaseMapper<ReportRegionsummary> {

}
