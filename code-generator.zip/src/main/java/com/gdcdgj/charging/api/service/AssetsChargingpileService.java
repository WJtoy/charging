package com.gdcdgj.charging.api.service;

import com.gdcdgj.charging.api.entity.AssetsChargingpile;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 充电桩 服务类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
public interface AssetsChargingpileService extends IService<AssetsChargingpile> {

}
