package com.gdcdgj.charging.api.service;

import com.gdcdgj.charging.api.entity.AssetsPilewarninginfo;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 电桩告警记录信息 服务类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
public interface AssetsPilewarninginfoService extends IService<AssetsPilewarninginfo> {

}
