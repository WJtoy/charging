package com.gdcdgj.charging.api.service;

import com.gdcdgj.charging.api.entity.AssetsStationchargingprice;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 站点使用价格关系 服务类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
public interface AssetsStationchargingpriceService extends IService<AssetsStationchargingprice> {

}
