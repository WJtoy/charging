package com.gdcdgj.charging.api.service;

import com.gdcdgj.charging.api.entity.AssetsStationimages;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 充电站图片 服务类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
public interface AssetsStationimagesService extends IService<AssetsStationimages> {

}
