package com.gdcdgj.charging.api.service;

import com.gdcdgj.charging.api.entity.CaptchaCaptchastore;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * captcha store 服务类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
public interface CaptchaCaptchastoreService extends IService<CaptchaCaptchastore> {

}
