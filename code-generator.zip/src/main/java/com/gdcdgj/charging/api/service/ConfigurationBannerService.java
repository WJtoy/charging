package com.gdcdgj.charging.api.service;

import com.gdcdgj.charging.api.entity.ConfigurationBanner;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * banner 服务类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
public interface ConfigurationBannerService extends IService<ConfigurationBanner> {

}
