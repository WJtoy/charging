package com.gdcdgj.charging.api.service;

import com.gdcdgj.charging.api.entity.ConfigurationChargingpricetimeperiod;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 价格模板时间段 服务类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
public interface ConfigurationChargingpricetimeperiodService extends IService<ConfigurationChargingpricetimeperiod> {

}
