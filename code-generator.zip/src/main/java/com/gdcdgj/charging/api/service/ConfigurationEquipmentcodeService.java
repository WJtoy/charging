package com.gdcdgj.charging.api.service;

import com.gdcdgj.charging.api.entity.ConfigurationEquipmentcode;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 充电桩告警消息配置 服务类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
public interface ConfigurationEquipmentcodeService extends IService<ConfigurationEquipmentcode> {

}
