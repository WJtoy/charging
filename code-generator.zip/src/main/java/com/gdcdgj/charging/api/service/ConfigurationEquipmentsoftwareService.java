package com.gdcdgj.charging.api.service;

import com.gdcdgj.charging.api.entity.ConfigurationEquipmentsoftware;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 软件版本库 服务类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
public interface ConfigurationEquipmentsoftwareService extends IService<ConfigurationEquipmentsoftware> {

}
