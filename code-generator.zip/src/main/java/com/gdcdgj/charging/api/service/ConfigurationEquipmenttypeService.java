package com.gdcdgj.charging.api.service;

import com.gdcdgj.charging.api.entity.ConfigurationEquipmenttype;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 设备型号 服务类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
public interface ConfigurationEquipmenttypeService extends IService<ConfigurationEquipmenttype> {

}
