package com.gdcdgj.charging.api.service;

import com.gdcdgj.charging.api.entity.CustomerChargingorder;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 会员账户充值记录 服务类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
public interface CustomerChargingorderService extends IService<CustomerChargingorder> {

}
