package com.gdcdgj.charging.api.service;

import com.gdcdgj.charging.api.entity.CustomerChargingorderevaluate;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 订单评价表 服务类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
public interface CustomerChargingorderevaluateService extends IService<CustomerChargingorderevaluate> {

}
