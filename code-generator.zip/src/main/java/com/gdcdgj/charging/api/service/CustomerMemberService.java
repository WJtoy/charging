package com.gdcdgj.charging.api.service;

import com.gdcdgj.charging.api.entity.CustomerMember;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 会员 服务类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
public interface CustomerMemberService extends IService<CustomerMember> {

}
