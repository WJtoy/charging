package com.gdcdgj.charging.api.service;

import com.gdcdgj.charging.api.entity.CustomerParkingcoupon;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 充电订单发放停车卷记录表 服务类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
public interface CustomerParkingcouponService extends IService<CustomerParkingcoupon> {

}
