package com.gdcdgj.charging.api.service;

import com.gdcdgj.charging.api.entity.CustomerStationevaluate;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 站点评价表 服务类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
public interface CustomerStationevaluateService extends IService<CustomerStationevaluate> {

}
