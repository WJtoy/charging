package com.gdcdgj.charging.api.service;

import com.gdcdgj.charging.api.entity.EmployeeCompany;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 运营商 服务类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
public interface EmployeeCompanyService extends IService<EmployeeCompany> {

}
