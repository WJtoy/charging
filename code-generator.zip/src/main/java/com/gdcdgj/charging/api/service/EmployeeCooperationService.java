package com.gdcdgj.charging.api.service;

import com.gdcdgj.charging.api.entity.EmployeeCooperation;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 合作渠道商 服务类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
public interface EmployeeCooperationService extends IService<EmployeeCooperation> {

}
