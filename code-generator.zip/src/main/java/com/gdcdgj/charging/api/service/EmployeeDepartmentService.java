package com.gdcdgj.charging.api.service;

import com.gdcdgj.charging.api.entity.EmployeeDepartment;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 部门 服务类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
public interface EmployeeDepartmentService extends IService<EmployeeDepartment> {

}
