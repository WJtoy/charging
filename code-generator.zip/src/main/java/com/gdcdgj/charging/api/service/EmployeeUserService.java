package com.gdcdgj.charging.api.service;

import com.gdcdgj.charging.api.entity.EmployeeUser;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 用户 服务类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
public interface EmployeeUserService extends IService<EmployeeUser> {

}
