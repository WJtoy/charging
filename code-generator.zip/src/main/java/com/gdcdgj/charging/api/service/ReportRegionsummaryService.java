package com.gdcdgj.charging.api.service;

import com.gdcdgj.charging.api.entity.ReportRegionsummary;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 区划和站点信息汇总 服务类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
public interface ReportRegionsummaryService extends IService<ReportRegionsummary> {

}
