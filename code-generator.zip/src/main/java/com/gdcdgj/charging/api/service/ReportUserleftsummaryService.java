package com.gdcdgj.charging.api.service;

import com.gdcdgj.charging.api.entity.ReportUserleftsummary;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 会员留存统计 服务类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
public interface ReportUserleftsummaryService extends IService<ReportUserleftsummary> {

}
