package com.gdcdgj.charging.api.serviceImpl;

import com.gdcdgj.charging.api.entity.AssetsCity;
import com.gdcdgj.charging.api.mapper.AssetsCityMapper;
import com.gdcdgj.charging.api.service.AssetsCityService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 行政区划 服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Service
public class AssetsCityServiceImpl extends ServiceImpl<AssetsCityMapper, AssetsCity> implements AssetsCityService {

}
