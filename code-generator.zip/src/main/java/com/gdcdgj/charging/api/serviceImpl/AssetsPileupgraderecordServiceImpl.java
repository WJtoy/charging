package com.gdcdgj.charging.api.serviceImpl;

import com.gdcdgj.charging.api.entity.AssetsPileupgraderecord;
import com.gdcdgj.charging.api.mapper.AssetsPileupgraderecordMapper;
import com.gdcdgj.charging.api.service.AssetsPileupgraderecordService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 电桩升级记录 服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Service
public class AssetsPileupgraderecordServiceImpl extends ServiceImpl<AssetsPileupgraderecordMapper, AssetsPileupgraderecord> implements AssetsPileupgraderecordService {

}
