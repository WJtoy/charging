package com.gdcdgj.charging.api.serviceImpl;

import com.gdcdgj.charging.api.entity.AssetsPilewarninginfo;
import com.gdcdgj.charging.api.mapper.AssetsPilewarninginfoMapper;
import com.gdcdgj.charging.api.service.AssetsPilewarninginfoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 电桩告警记录信息 服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Service
public class AssetsPilewarninginfoServiceImpl extends ServiceImpl<AssetsPilewarninginfoMapper, AssetsPilewarninginfo> implements AssetsPilewarninginfoService {

}
