package com.gdcdgj.charging.api.serviceImpl;

import com.gdcdgj.charging.api.entity.AssetsStationbusinesshours;
import com.gdcdgj.charging.api.mapper.AssetsStationbusinesshoursMapper;
import com.gdcdgj.charging.api.service.AssetsStationbusinesshoursService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 站点营业时间 服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Service
public class AssetsStationbusinesshoursServiceImpl extends ServiceImpl<AssetsStationbusinesshoursMapper, AssetsStationbusinesshours> implements AssetsStationbusinesshoursService {

}
