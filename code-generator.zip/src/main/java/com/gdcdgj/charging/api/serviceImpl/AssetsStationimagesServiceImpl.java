package com.gdcdgj.charging.api.serviceImpl;

import com.gdcdgj.charging.api.entity.AssetsStationimages;
import com.gdcdgj.charging.api.mapper.AssetsStationimagesMapper;
import com.gdcdgj.charging.api.service.AssetsStationimagesService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 充电站图片 服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Service
public class AssetsStationimagesServiceImpl extends ServiceImpl<AssetsStationimagesMapper, AssetsStationimages> implements AssetsStationimagesService {

}
