package com.gdcdgj.charging.api.serviceImpl;

import com.gdcdgj.charging.api.entity.AssetsStationsTags;
import com.gdcdgj.charging.api.mapper.AssetsStationsTagsMapper;
import com.gdcdgj.charging.api.service.AssetsStationsTagsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Service
public class AssetsStationsTagsServiceImpl extends ServiceImpl<AssetsStationsTagsMapper, AssetsStationsTags> implements AssetsStationsTagsService {

}
