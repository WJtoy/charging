package com.gdcdgj.charging.api.serviceImpl;

import com.gdcdgj.charging.api.entity.AuthPermission;
import com.gdcdgj.charging.api.mapper.AuthPermissionMapper;
import com.gdcdgj.charging.api.service.AuthPermissionService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Service
public class AuthPermissionServiceImpl extends ServiceImpl<AuthPermissionMapper, AuthPermission> implements AuthPermissionService {

}
