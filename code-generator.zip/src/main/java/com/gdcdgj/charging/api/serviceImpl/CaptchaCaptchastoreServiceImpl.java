package com.gdcdgj.charging.api.serviceImpl;

import com.gdcdgj.charging.api.entity.CaptchaCaptchastore;
import com.gdcdgj.charging.api.mapper.CaptchaCaptchastoreMapper;
import com.gdcdgj.charging.api.service.CaptchaCaptchastoreService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * captcha store 服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Service
public class CaptchaCaptchastoreServiceImpl extends ServiceImpl<CaptchaCaptchastoreMapper, CaptchaCaptchastore> implements CaptchaCaptchastoreService {

}
