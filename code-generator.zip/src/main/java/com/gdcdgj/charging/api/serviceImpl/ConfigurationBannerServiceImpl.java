package com.gdcdgj.charging.api.serviceImpl;

import com.gdcdgj.charging.api.entity.ConfigurationBanner;
import com.gdcdgj.charging.api.mapper.ConfigurationBannerMapper;
import com.gdcdgj.charging.api.service.ConfigurationBannerService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * banner 服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Service
public class ConfigurationBannerServiceImpl extends ServiceImpl<ConfigurationBannerMapper, ConfigurationBanner> implements ConfigurationBannerService {

}
