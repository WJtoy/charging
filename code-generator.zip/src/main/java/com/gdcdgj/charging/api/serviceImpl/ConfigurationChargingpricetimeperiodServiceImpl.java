package com.gdcdgj.charging.api.serviceImpl;

import com.gdcdgj.charging.api.entity.ConfigurationChargingpricetimeperiod;
import com.gdcdgj.charging.api.mapper.ConfigurationChargingpricetimeperiodMapper;
import com.gdcdgj.charging.api.service.ConfigurationChargingpricetimeperiodService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 价格模板时间段 服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Service
public class ConfigurationChargingpricetimeperiodServiceImpl extends ServiceImpl<ConfigurationChargingpricetimeperiodMapper, ConfigurationChargingpricetimeperiod> implements ConfigurationChargingpricetimeperiodService {

}
