package com.gdcdgj.charging.api.serviceImpl;

import com.gdcdgj.charging.api.entity.ConfigurationCoupon;
import com.gdcdgj.charging.api.mapper.ConfigurationCouponMapper;
import com.gdcdgj.charging.api.service.ConfigurationCouponService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 优惠券模板 服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Service
public class ConfigurationCouponServiceImpl extends ServiceImpl<ConfigurationCouponMapper, ConfigurationCoupon> implements ConfigurationCouponService {

}
