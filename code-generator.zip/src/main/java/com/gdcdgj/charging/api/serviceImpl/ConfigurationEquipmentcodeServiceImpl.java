package com.gdcdgj.charging.api.serviceImpl;

import com.gdcdgj.charging.api.entity.ConfigurationEquipmentcode;
import com.gdcdgj.charging.api.mapper.ConfigurationEquipmentcodeMapper;
import com.gdcdgj.charging.api.service.ConfigurationEquipmentcodeService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 充电桩告警消息配置 服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Service
public class ConfigurationEquipmentcodeServiceImpl extends ServiceImpl<ConfigurationEquipmentcodeMapper, ConfigurationEquipmentcode> implements ConfigurationEquipmentcodeService {

}
