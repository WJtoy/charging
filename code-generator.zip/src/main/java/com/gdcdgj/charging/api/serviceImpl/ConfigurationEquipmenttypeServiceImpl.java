package com.gdcdgj.charging.api.serviceImpl;

import com.gdcdgj.charging.api.entity.ConfigurationEquipmenttype;
import com.gdcdgj.charging.api.mapper.ConfigurationEquipmenttypeMapper;
import com.gdcdgj.charging.api.service.ConfigurationEquipmenttypeService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 设备型号 服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Service
public class ConfigurationEquipmenttypeServiceImpl extends ServiceImpl<ConfigurationEquipmenttypeMapper, ConfigurationEquipmenttype> implements ConfigurationEquipmenttypeService {

}
