package com.gdcdgj.charging.api.serviceImpl;

import com.gdcdgj.charging.api.entity.ConfigurationLoginpolicy;
import com.gdcdgj.charging.api.mapper.ConfigurationLoginpolicyMapper;
import com.gdcdgj.charging.api.service.ConfigurationLoginpolicyService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 登陆策略 服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Service
public class ConfigurationLoginpolicyServiceImpl extends ServiceImpl<ConfigurationLoginpolicyMapper, ConfigurationLoginpolicy> implements ConfigurationLoginpolicyService {

}
