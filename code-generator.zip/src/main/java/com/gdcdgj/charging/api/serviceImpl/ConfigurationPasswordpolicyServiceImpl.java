package com.gdcdgj.charging.api.serviceImpl;

import com.gdcdgj.charging.api.entity.ConfigurationPasswordpolicy;
import com.gdcdgj.charging.api.mapper.ConfigurationPasswordpolicyMapper;
import com.gdcdgj.charging.api.service.ConfigurationPasswordpolicyService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 密码设置策略 服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Service
public class ConfigurationPasswordpolicyServiceImpl extends ServiceImpl<ConfigurationPasswordpolicyMapper, ConfigurationPasswordpolicy> implements ConfigurationPasswordpolicyService {

}
