package com.gdcdgj.charging.api.serviceImpl;

import com.gdcdgj.charging.api.entity.ConfigurationTags;
import com.gdcdgj.charging.api.mapper.ConfigurationTagsMapper;
import com.gdcdgj.charging.api.service.ConfigurationTagsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 价格时间段 服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Service
public class ConfigurationTagsServiceImpl extends ServiceImpl<ConfigurationTagsMapper, ConfigurationTags> implements ConfigurationTagsService {

}
