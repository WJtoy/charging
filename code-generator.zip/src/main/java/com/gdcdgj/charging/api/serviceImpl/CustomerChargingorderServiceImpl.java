package com.gdcdgj.charging.api.serviceImpl;

import com.gdcdgj.charging.api.entity.CustomerChargingorder;
import com.gdcdgj.charging.api.mapper.CustomerChargingorderMapper;
import com.gdcdgj.charging.api.service.CustomerChargingorderService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 会员账户充值记录 服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Service
public class CustomerChargingorderServiceImpl extends ServiceImpl<CustomerChargingorderMapper, CustomerChargingorder> implements CustomerChargingorderService {

}
