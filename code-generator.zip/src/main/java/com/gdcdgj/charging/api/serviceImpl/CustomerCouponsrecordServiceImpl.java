package com.gdcdgj.charging.api.serviceImpl;

import com.gdcdgj.charging.api.entity.CustomerCouponsrecord;
import com.gdcdgj.charging.api.mapper.CustomerCouponsrecordMapper;
import com.gdcdgj.charging.api.service.CustomerCouponsrecordService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 会员优惠券 服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Service
public class CustomerCouponsrecordServiceImpl extends ServiceImpl<CustomerCouponsrecordMapper, CustomerCouponsrecord> implements CustomerCouponsrecordService {

}
