package com.gdcdgj.charging.api.serviceImpl;

import com.gdcdgj.charging.api.entity.CustomerMemberFavourateStations;
import com.gdcdgj.charging.api.mapper.CustomerMemberFavourateStationsMapper;
import com.gdcdgj.charging.api.service.CustomerMemberFavourateStationsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Service
public class CustomerMemberFavourateStationsServiceImpl extends ServiceImpl<CustomerMemberFavourateStationsMapper, CustomerMemberFavourateStations> implements CustomerMemberFavourateStationsService {

}
