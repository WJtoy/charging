package com.gdcdgj.charging.api.serviceImpl;

import com.gdcdgj.charging.api.entity.CustomerMember;
import com.gdcdgj.charging.api.mapper.CustomerMemberMapper;
import com.gdcdgj.charging.api.service.CustomerMemberService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 会员 服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Service
public class CustomerMemberServiceImpl extends ServiceImpl<CustomerMemberMapper, CustomerMember> implements CustomerMemberService {

}
