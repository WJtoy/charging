package com.gdcdgj.charging.api.serviceImpl;

import com.gdcdgj.charging.api.entity.CustomerParkingcoupon;
import com.gdcdgj.charging.api.mapper.CustomerParkingcouponMapper;
import com.gdcdgj.charging.api.service.CustomerParkingcouponService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 充电订单发放停车卷记录表 服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Service
public class CustomerParkingcouponServiceImpl extends ServiceImpl<CustomerParkingcouponMapper, CustomerParkingcoupon> implements CustomerParkingcouponService {

}
