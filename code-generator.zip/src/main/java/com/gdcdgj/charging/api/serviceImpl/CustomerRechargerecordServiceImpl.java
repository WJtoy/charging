package com.gdcdgj.charging.api.serviceImpl;

import com.gdcdgj.charging.api.entity.CustomerRechargerecord;
import com.gdcdgj.charging.api.mapper.CustomerRechargerecordMapper;
import com.gdcdgj.charging.api.service.CustomerRechargerecordService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 会员账户充值记录 服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Service
public class CustomerRechargerecordServiceImpl extends ServiceImpl<CustomerRechargerecordMapper, CustomerRechargerecord> implements CustomerRechargerecordService {

}
