package com.gdcdgj.charging.api.serviceImpl;

import com.gdcdgj.charging.api.entity.CustomerStationevaluate;
import com.gdcdgj.charging.api.mapper.CustomerStationevaluateMapper;
import com.gdcdgj.charging.api.service.CustomerStationevaluateService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 站点评价表 服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Service
public class CustomerStationevaluateServiceImpl extends ServiceImpl<CustomerStationevaluateMapper, CustomerStationevaluate> implements CustomerStationevaluateService {

}
