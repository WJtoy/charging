package com.gdcdgj.charging.api.serviceImpl;

import com.gdcdgj.charging.api.entity.DjangoContentType;
import com.gdcdgj.charging.api.mapper.DjangoContentTypeMapper;
import com.gdcdgj.charging.api.service.DjangoContentTypeService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Service
public class DjangoContentTypeServiceImpl extends ServiceImpl<DjangoContentTypeMapper, DjangoContentType> implements DjangoContentTypeService {

}
