package com.gdcdgj.charging.api.serviceImpl;

import com.gdcdgj.charging.api.entity.DjangoMigrations;
import com.gdcdgj.charging.api.mapper.DjangoMigrationsMapper;
import com.gdcdgj.charging.api.service.DjangoMigrationsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Service
public class DjangoMigrationsServiceImpl extends ServiceImpl<DjangoMigrationsMapper, DjangoMigrations> implements DjangoMigrationsService {

}
