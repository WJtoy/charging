package com.gdcdgj.charging.api.serviceImpl;

import com.gdcdgj.charging.api.entity.EmployeeCompany;
import com.gdcdgj.charging.api.mapper.EmployeeCompanyMapper;
import com.gdcdgj.charging.api.service.EmployeeCompanyService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 运营商 服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Service
public class EmployeeCompanyServiceImpl extends ServiceImpl<EmployeeCompanyMapper, EmployeeCompany> implements EmployeeCompanyService {

}
