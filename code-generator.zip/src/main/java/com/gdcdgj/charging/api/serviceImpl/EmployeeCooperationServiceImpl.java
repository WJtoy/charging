package com.gdcdgj.charging.api.serviceImpl;

import com.gdcdgj.charging.api.entity.EmployeeCooperation;
import com.gdcdgj.charging.api.mapper.EmployeeCooperationMapper;
import com.gdcdgj.charging.api.service.EmployeeCooperationService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 合作渠道商 服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Service
public class EmployeeCooperationServiceImpl extends ServiceImpl<EmployeeCooperationMapper, EmployeeCooperation> implements EmployeeCooperationService {

}
