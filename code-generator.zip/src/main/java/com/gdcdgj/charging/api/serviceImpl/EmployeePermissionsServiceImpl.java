package com.gdcdgj.charging.api.serviceImpl;

import com.gdcdgj.charging.api.entity.EmployeePermissions;
import com.gdcdgj.charging.api.mapper.EmployeePermissionsMapper;
import com.gdcdgj.charging.api.service.EmployeePermissionsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 权限 服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Service
public class EmployeePermissionsServiceImpl extends ServiceImpl<EmployeePermissionsMapper, EmployeePermissions> implements EmployeePermissionsService {

}
