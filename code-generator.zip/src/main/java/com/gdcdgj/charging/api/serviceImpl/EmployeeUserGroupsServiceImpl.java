package com.gdcdgj.charging.api.serviceImpl;

import com.gdcdgj.charging.api.entity.EmployeeUserGroups;
import com.gdcdgj.charging.api.mapper.EmployeeUserGroupsMapper;
import com.gdcdgj.charging.api.service.EmployeeUserGroupsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Service
public class EmployeeUserGroupsServiceImpl extends ServiceImpl<EmployeeUserGroupsMapper, EmployeeUserGroups> implements EmployeeUserGroupsService {

}
