package com.gdcdgj.charging.api.serviceImpl;

import com.gdcdgj.charging.api.entity.ReportRegionsummary;
import com.gdcdgj.charging.api.mapper.ReportRegionsummaryMapper;
import com.gdcdgj.charging.api.service.ReportRegionsummaryService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 区划和站点信息汇总 服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Service
public class ReportRegionsummaryServiceImpl extends ServiceImpl<ReportRegionsummaryMapper, ReportRegionsummary> implements ReportRegionsummaryService {

}
