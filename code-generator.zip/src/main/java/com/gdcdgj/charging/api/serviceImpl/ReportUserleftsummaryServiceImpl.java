package com.gdcdgj.charging.api.serviceImpl;

import com.gdcdgj.charging.api.entity.ReportUserleftsummary;
import com.gdcdgj.charging.api.mapper.ReportUserleftsummaryMapper;
import com.gdcdgj.charging.api.service.ReportUserleftsummaryService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 会员留存统计 服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-05-07
 */
@Service
public class ReportUserleftsummaryServiceImpl extends ServiceImpl<ReportUserleftsummaryMapper, ReportUserleftsummary> implements ReportUserleftsummaryService {

}
