package com.gdcdgj.charging.gateway;

import com.gdcdgj.charging.api.config.RedisConfig;
import com.gdcdgj.charging.gateway.server.NettyServer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;

/**
 * @author Changliang Tao
 * @date 2020/4/17 10:10
 * @since JDK 1.8
 */
@SpringBootApplication
@Import(RedisConfig.class)
public class GatewayApplication implements CommandLineRunner {
    @Autowired
    NettyServer nettyServer;

    public static void main(String[] args) {
        SpringApplication.run(GatewayApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        nettyServer.start();
    }
}
