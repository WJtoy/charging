package com.gdcdgj.charging.gateway.config;

import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


/**
 * 消息队列的统一配置
 * @author Changliang Tao
 * @date 2020/4/19 10:37
 * @since JDK 1.8
 */
@Configuration
public class AmqpConfig {
    @Bean
    public MessageConverter jsonConverter() {
        return new Jackson2JsonMessageConverter();
    }
}