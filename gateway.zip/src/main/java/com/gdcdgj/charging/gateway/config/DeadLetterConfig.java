package com.gdcdgj.charging.gateway.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import static com.gdcdgj.charging.api.constant.RabbitmqConstant.*;

/**
 * @author Changliang Tao
 * @date 2020/4/18 14:16
 * @since JDK 1.8
 */
@Configuration
public class DeadLetterConfig  {
    /**
     * 死信队列
     *
     * @param
     * @return
     * @throws
     * @author Changliang Tao
     * @date 2020/4/18 14:16
     */
    @Bean
    public Queue deadQueue() {
        Queue queue = new Queue(DEAD_QUEUE_NAME);
        return queue;
    }

    /**
     * 死信交换机
     *
     * @param
     * @return
     * @throws
     * @author Changliang Tao
     * @date 2020/4/18 14:23
     */

    @Bean
    public TopicExchange deadExchange() {
        return new TopicExchange(DEAD_EXCHANGE_NAME);
    }

    /**
     * 死信路由键的绑定
     *
     * @param
     * @return
     * @throws
     * @author Changliang Tao
     * @date 2020/4/18 14:26
     */

    @Bean
    public Binding deadQueueAndExchangeBinding() {
        return BindingBuilder.bind(deadQueue())
                .to(deadExchange())
                .with(DEAD_ROUTING_KEY);
    }
}
