package com.gdcdgj.charging.gateway.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * Netty服务器配置信息
 */
@Component
@ConfigurationProperties(prefix = "netty")
@Data
public class NettyServerConfig {

    // 端口
    private int port;
    // 最大线程数
    private int maxThreads;
    // 最大数据包长度
    private int maxFrameLength;
    // 心跳超时
    private int heartBeatTimeOut;
    // 丢失读取数据（心跳超时）的次数
    private int lossConnectCount;
    // 充电桩ip地址过滤
    private String filterIp;
}
