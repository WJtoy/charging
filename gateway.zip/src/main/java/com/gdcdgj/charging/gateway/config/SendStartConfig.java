package com.gdcdgj.charging.gateway.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;

import static com.gdcdgj.charging.api.constant.RabbitmqConstant.*;

/**
 * 发送指令启动充电桩
 *
 * @author Changliang Tao
 * @date 2020/4/23 16:56
 * @since JDK 1.8
 */
@Configuration
public class SendStartConfig {

    /**
     * 服务器发送指令启动充电桩队列
     *
     * @return
     * @throws
     * @author Changliang Tao
     * @date 2020/4/18 14:11
     */

    @Bean
    public Queue sendStartQueue() {
        Map<String, Object> map = new HashMap<>();
        map.put("x-dead-letter-exchange", DEAD_EXCHANGE_NAME);
        map.put("x-message-ttl", MESSAGE_TTL);
        // queue: 队列名称
        // durable： 是否持久化, 队列的声明默认是存放到内存中的，如果rabbitmq重启会丢失，
        // 如果想重启之后还存在就要使队列持久化，保存到Erlang自带的Mnesia数据库中，当rabbitmq重启之后会读取该数据库
        // exclusive：是否排外的,如果不是排外的，可以使用两个消费者都访问同一个队列
        // autoDelete：是否自动删除，当最后一个消费者断开连接之后队列是否自动被删除
        return new Queue(START_PILE_QUEUE, true, false, false, map);
    }
    /**
     * 服务器发送指令启动充电桩交换机
     *
     * @param
     * @return
     * @throws
     * @author Changliang Tao
     * @date 2020/4/18 14:12
     */

    @Bean
    public TopicExchange sendStartTopicExchange() {
        return new TopicExchange(START_PILE_EXCHANGE);
    }

    /**
     * 充电桩签到路由键
     *
     * @param
     * @return
     * @throws
     * @author Changliang Tao
     * @date 2020/4/18 14:22
     */

    @Bean
    public Binding sendStartQueueAndTopicExchangeBinding() {
        return BindingBuilder.bind(sendStartQueue())
                .to(sendStartTopicExchange())
                .with(START_PILE_ROUTING_KEY);
    }


}
