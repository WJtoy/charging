package com.gdcdgj.charging.gateway.enums;


/**
 * 每个平台桩的报文协议起始域
 *
 * @author Changliang Tao
 * @date 2020/4/13 16:55
 * @since JDK 1.8
 */
public enum MsgProviderEnum {
	
	 // kw供应商 1
     KW_PROVIDER(1),
	 // ib供应商  2
     IB_PROVIDER(2),
     // kh供应商 3
     KH_PROVIDER(3);

	 private int value;

	 private MsgProviderEnum(int value) {
	     this.value = value;
	 }

	 public int getValue() {
	     return this.value;
	 }
}
