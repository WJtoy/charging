package com.gdcdgj.charging.gateway.enums;


import lombok.extern.slf4j.Slf4j;

import java.util.Arrays;

/**
 * 每个平台桩的报文协议起始域
 *
 * @author Changliang Tao
 * @date 2020/4/13 16:55
 * @since JDK 1.8
 */
@Slf4j
public enum MsgStartFieldEnum {
    // ib起始域：固定为 先0x59、 后0x43
    IB(new byte[]{89, 67}),
    // kw起始域：固定为 先0xaa、 后0xf5
    KW(new byte[]{-86, -11}),
	// kh起始域：固定为 先0x4b、 后0x48
	KH(new byte[] {75, 72});
	
    private byte[] filed;

    MsgStartFieldEnum(byte[] bytes) {
        this.filed = bytes;
    }
    public byte[] getValue() {
        return this.filed;
    }
    public static MsgStartFieldEnum valueOf(byte[] filed) {
        MsgStartFieldEnum tempEnum = null;
        MsgStartFieldEnum[] var2 = values();
        int var3 = var2.length;

        for(int var4 = 0; var4 < var3; ++var4) {
            MsgStartFieldEnum en = var2[var4];
            if (Arrays.equals(en.getValue(),filed)) {
                tempEnum = en;
                break;
            }
        }

        if (tempEnum == null) {
            log.error("Enum value not exist : " + filed);
        }
        return tempEnum;
    }
    public static void main(String[] args) {
		System.err.println(0x4b);
		System.err.println(0x48);
	}
}
