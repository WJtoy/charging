package com.gdcdgj.charging.gateway.listener;


import static com.gdcdgj.charging.api.constant.RabbitmqConstant.START_PILE_QUEUE;
import com.gdcdgj.charging.api.vo.srv2gw.PileCtrl;
import com.gdcdgj.charging.api.vo.srv2gw.ServiceType;
import com.gdcdgj.charging.gateway.enums.MsgProviderEnum;
import com.gdcdgj.charging.gateway.platform.ib.execute.send.SendPileCtrlWithoutOrdCmd;
import com.gdcdgj.charging.gateway.platform.ib.execute.send.SendSrvTypeResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendPileCtrlStartRstRespCmd;
import com.gdcdgj.charging.gateway.server.handler.ChannelSender;
import com.gdcdgj.charging.gateway.server.handler.H2TServer;

import io.netty.channel.Channel;
import lombok.extern.slf4j.Slf4j;

import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * 监听到后台发来的启动充电信息
 *
 * @author ydc
 * @date 2020/4/19 14:10
 * @since JDK 1.8
 */
@Slf4j
@Component
public class PileStartListener {

	@RabbitListener(queues = START_PILE_QUEUE)
	public void handlerMessage(PileCtrl ctrlVo)  throws UnsupportedEncodingException {
        //启动 充电
    	Channel channel = H2TServer.pileChannelMap.get(ctrlVo.getPileCode());
    	if(ctrlVo.getProviderId() == MsgProviderEnum.KW_PROVIDER.getValue()) {
       	   //科旺桩启动充电命令下发
       	   SendPileCtrlStartRstRespCmd start = new SendPileCtrlStartRstRespCmd();
	       byte[] datas = start.sendCmdExecute(ctrlVo);
	       ChannelSender.send(channel, datas);
	       log.info("启动科旺桩命令下发完成 {}",ctrlVo.getParamType() == 2 ? ",电桩正在启动中..." : ",请在约定时间内充电");
        }else if(ctrlVo.getProviderId() == MsgProviderEnum.IB_PROVIDER.getValue()){
        	//宜步桩启动充电命令下发
        	//启动前对获取应答中心充电服务类型
        	log.info("中心充电服务类型下发");
            SendSrvTypeResponseCmd cmd = new SendSrvTypeResponseCmd();
            ServiceType serviceType = new ServiceType();
            serviceType.setCardNum("");
            serviceType.setConnectorNo(ctrlVo.getConnectorNo());
            Calendar cal = Calendar.getInstance();
            serviceType.setTradeDate(cal);
            //交易类型 默认使用0x20自然充满   0x01换电服务 0x10充电服务 0x30按时间 0x40安电量 暂不考虑这些
            serviceType.setType((byte) 32);
            byte[] data = cmd.sendCmdExecute(serviceType);
            ChannelSender.send(channel, data);
            log.info("启动宜步桩命令下发  :{}",ctrlVo);
            SendPileCtrlWithoutOrdCmd send = new SendPileCtrlWithoutOrdCmd();
            byte[] datas = send.sendCmdExecute(ctrlVo);
            ChannelSender.send(channel, datas);
            log.info("启动宜步桩命令下发完成 {}",ctrlVo.getParamType() == 2 ? ",电桩正在启动中..." : ",请在约定时间内充电");
        }
    }
}