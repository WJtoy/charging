package com.gdcdgj.charging.gateway.listener;


import com.gdcdgj.charging.api.constant.RabbitmqConstant;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.PileCtrl;
import com.gdcdgj.charging.gateway.enums.MsgProviderEnum;
import com.gdcdgj.charging.gateway.platform.ib.execute.send.SendPileCtrlWithoutOrdCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendPileCtrlStopRstRespCmd;
import com.gdcdgj.charging.gateway.server.handler.ChannelSender;
import com.gdcdgj.charging.gateway.server.handler.H2TServer;

import io.netty.channel.Channel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.UnsupportedEncodingException;

/**
 * 监听到后台发来的停止充电信息
 *
 * @author ydc
 * @date 2020/4/19 14:10
 * @since JDK 1.8
 */
@Slf4j
@Component
public class PileStopListener {

    @RabbitListener(queues = RabbitmqConstant.STOP_PILE_QUEUE)
    public void handlerMessage(PileCtrl ctrlVo) throws UnsupportedEncodingException {
    	 //停止充电
         Channel channel = H2TServer.pileChannelMap.get(ctrlVo.getPileCode());
         if (ctrlVo.getProviderId() == MsgProviderEnum.IB_PROVIDER.getValue()) {
             //宜步停止充电命令下发
        	 SendPileCtrlWithoutOrdCmd send = new SendPileCtrlWithoutOrdCmd();
             log.info("停止宜步桩==》{}", ctrlVo);
             byte[] datas = send.sendCmdExecute(ctrlVo);
             ChannelSender.send(channel, datas);
        	 log.info("停止宜步桩命令下发完成");
         }else if(ctrlVo.getProviderId() == MsgProviderEnum.KW_PROVIDER.getValue()){
        	 //科旺停止充电命令下发
        	 SendPileCtrlStopRstRespCmd start = new SendPileCtrlStopRstRespCmd();
        	 log.info("停止科旺桩命令下发==》{}", ctrlVo);
        	 byte[] datas = start.sendCmdExecute(ctrlVo);
        	 ChannelSender.send(channel, datas);
        	 log.info("停止科旺桩命令下发完成");
    	 }
    }
}