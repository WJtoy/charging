package com.gdcdgj.charging.gateway.listener;


import com.gdcdgj.charging.api.constant.RabbitmqConstant;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.StrParamSet;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendStrParamSetRespCmd;
import com.gdcdgj.charging.gateway.server.handler.ChannelSender;
import com.gdcdgj.charging.gateway.server.handler.H2TServer;

import io.netty.channel.Channel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.UnsupportedEncodingException;

/**
 * 监听到后台发来设置信息 下发字符型参数命令
 *
 * @author ydc
 * @date 2020/4/19 14:10
 * @since JDK 1.8
 */
@Slf4j
@Component
public class StrParamSetListener {

//    @RabbitListener(queues = RabbitmqConstant.DEAD_QUEUE_NAME)
//    public void handlerMessage(StrParamSet message) throws UnsupportedEncodingException {
//        	 StrParamSet ctrlVo = (StrParamSet) message;
//             Channel channel = H2TServer.pileChannelMap.get(ctrlVo.getPileCode());
//             if (ctrlVo.getProviderId() == 1) {
//                 //宜步报文
//            	 //SendSrvTypeResponseCmd send = new SendSrvTypeResponseCmd();
//                 log.info("启动宜步桩==》{}", ctrlVo);
//                 //byte[] datas = send.sendExecute(ctrlVo.getConnectorNo(), 0, 0, ctrlVo, channel);
//             }else{
//            	 //科旺报文
//         		 SendStrParamSetRespCmd sendStrParamSetRespCmd = new SendStrParamSetRespCmd();
//            	 log.info("字符型参数命令下发==》{}", ctrlVo);
//         		 byte[] datas = sendStrParamSetRespCmd.sendCmdExecute(ctrlVo);
//            	 ChannelSender.send(channel, datas);
//            	 log.info("字符型参数命令下发完成");
//        	 }
//    }
}