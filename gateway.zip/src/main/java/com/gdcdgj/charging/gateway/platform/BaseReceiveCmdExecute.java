package com.gdcdgj.charging.gateway.platform;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;

/**
 * 接收到报文进行处理
 *
 * @author Changliang Tao
 * @date 2020/4/26 17:14
 * @since JDK 1.8
 */
public interface BaseReceiveCmdExecute {
	
    /**
     * 接收报文数据的抽象执行方法
     *
     * @param fullData
     * @return
     * @throws Exception
     * @author ouxx
     * @date 2016-11-14 下午5:09:35
     */
    DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception;
    
}
