package com.gdcdgj.charging.gateway.platform;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;

/**
 * 抽象协议命令（服务端发送给充电桩的）
 *
 * @author Changliang Tao
 * @date 2020/4/26 17:20
 * @since JDK 1.8
 */
public  interface BaseSendCmdExecute {
	
    /**
     * 对象拼接成报文
     *
     * @param dataVo
     * @return byte[]
     * @throws
     * @author Changliang Tao
     * @date 2020/4/26 17:38
     */

     byte[] sendCmdExecute(DataBaseVo dataVo);
}
