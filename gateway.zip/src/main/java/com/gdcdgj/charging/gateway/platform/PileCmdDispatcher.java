package com.gdcdgj.charging.gateway.platform;

import io.netty.channel.ChannelHandlerContext;

/**
 * 充电桩报文分发器
 *
 * @author Changliang Tao
 * @date 2020/4/26 16:49
 * @since JDK 1.8
 */
public interface PileCmdDispatcher {
    /**
     * 子类继承实现该方法
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author Changliang Tao
     * @date 2020/4/26 16:52
     */

     void dispatcher(ChannelHandlerContext ctx, byte[] fullData) throws Exception;
}
