package com.gdcdgj.charging.gateway.platform;

import io.netty.channel.ChannelHandlerContext;

/**
 * 报文处理器
 *
 * @author Changliang Tao
 * @date 2020/4/26 16:56
 * @since JDK 1.8
 */
public interface PileCmdHandler {

    /**
     * 报文心跳处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/26 16:57
     */

    void heartbeatCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception;

    /**
     * 报文签到处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:36
     */

    void signInCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception;

    /**
     * 充电桩上报状态
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:38
     */

    void moduleInfoCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception;

    /**
     * 充电桩上报启动结果
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */

    void startResultCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception;
    /**
     * 充电桩上报启动结果
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */

    void startCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception;
    /**
     * 充电桩上报启动结果
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */

    void stopCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception;
    
    /**
     * 充电桩上报启动结果
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */

    void stateInfoCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception;
    
    /**
     * 充电桩字符型参数设置处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
    
    void strParamSetCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception;
   
    /**
     * 充电桩整形参数设置处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
    
    void plasticParamSetCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception;
    
	/**
     * 充电桩24时电费计价策略设置处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
    
	public void voluationPolicyCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception;
	
	/**
     * 充电桩告警信息上报处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
    
	public void alarmInfoCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception; 
	
	/**
     * 充电桩账户信息上报处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
    
	public void accountInfoCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception; 
	
	/**
     * 充电桩应答服务器查询最近一次充电各时段信息
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
    
	public void chargeTimeFrameInfoCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception; 
	
	/**
     * 充电桩上报充电记录信息
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
    
	public void chargeRecordInfoCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception; 
	
	/**
     * 充电桩上报充历史充电记录信息
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
    
	public void HistoryChargeRecordInfoCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception;
	
	/**
     * 充电桩时间同步
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
    
	public void timeSyncCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception; 

	/**
	 * 工作参数处理
	 * 
	 * @param ctx
	 * @param fullData
	 * @throws Exception
	 * @author ydc
     * @date 2020/4/30 14:40
	 */
	
	public void workParamCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception; 

	/**
	 * 充电桩向中心系统下发合法用户认证
	 * 
	 * @param ctx
	 * @param fullData
	 * @throws Exception
	 * @author ydc
     * @date 2020/4/30 14:40
	 */
	
	public void validAuthenCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception; 
	
	/**
	 * 远程系统升级
	 * 
	 * @param ctx
	 * @param fullData
	 * @throws Exception
	 * @author ydc
     * @date 2020/4/30 14:40
	 */
	
	public void remoteUpgradeCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception;
	
	/**
	 * 中心下发服务类型
	 * 
	 * @param ctx
	 * @param fullData
	 * @throws Exception
	 * @author ydc
     * @date 2020/4/30 14:40
	 */
	
	public void serviceTypeCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception;
	
	/**
	 * BMS辨识报文 BRM
	 * 
	 * @param ctx
	 * @param fullData
	 * @throws Exception
	 * @author ydc
     * @date 2020/4/30 14:40
	 */
	
	public void BRMCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception;
	
	/**
	 * 通讯模式设置应答
	 * 
	 * @param ctx
	 * @param fullData
	 * @throws Exception
	 * @author ydc
     * @date 2020/4/30 14:40
	 */
	
	public void ReportTypeCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception;
	
	/**
	 * 桩上报BCP报文
	 * 
	 * @param ctx
	 * @param fullData
	 * @throws Exception
	 * @author ydc
     * @date 2020/4/30 14:40
	 */
	
	public void BCPCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception;
}
