package com.gdcdgj.charging.gateway.platform.ib.dispatcher;

import com.gdcdgj.charging.gateway.platform.PileCmdDispatcher;
import com.gdcdgj.charging.gateway.platform.ib.handler.IbPileCmdHandler;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbCmdEnum;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbProtocolUtil;
import io.netty.channel.ChannelHandlerContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * 宜步桩上报命令分发
 *
 * @author Changliang Tao
 * @date 2020/4/13 17:35
 * @since JDK 1.8
 */
@Slf4j
@Component
public class IbPileCmdDispatcher implements PileCmdDispatcher {

	// 宜步命令处理器
    @Autowired
    IbPileCmdHandler ibPileCmdHandler;
    /**
     * 宜步根据命令枚举分发不同命令处理
     *
     * @param
     * @return
     * @throws
     * @author Changliang Tao
     * @date 2020/4/13 17:42
     */
    @Override
    public void dispatcher(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
    	// 报文验证
        if (!IbProtocolUtil.verifyRecData(fullData)) {
            log.error("报文验证错误");
            return;
        }
        
        // 获取命令代码枚举
        final IbCmdEnum cmdEnum = IbProtocolUtil.getCmdCodeEnum(fullData);
        log.info("ib_cmdEnum => {}", cmdEnum);
        switch (cmdEnum) {
            case HEART_BEAT_REPORT:
                // 心跳处理
                ibPileCmdHandler.heartbeatCmdHandle(ctx,fullData);
                break;
            case SEND_SIGN_IN_RESP:
                // 签到处理
                ibPileCmdHandler.signInCmdHandle(ctx,fullData);
                break;
            case MODULE_INFO_QUERY_RESP:
                // 当前充电模块充电信息查询应答/上报 T - H
                ibPileCmdHandler.moduleInfoCmdHandle(ctx, fullData);
                break;
            case PILE_ALL_STATUS_RESP:
            	//总状态信息包上报
            	ibPileCmdHandler.stateInfoCmdHandle(ctx, fullData);
            	break;
            case PILE_STARTED_REPORT:
                // 充电桩启动成功后，向平台上报的命令
                ibPileCmdHandler.startResultCmdHandle(ctx, fullData);
                break;
            case PILE_CTRL_WITHOUT_ORD_RESP:
                // 中心监控系统下发指令设置充电桩工作模式
                ibPileCmdHandler.startCmdHandle(ctx, fullData);
                break;
            case TIME_SYN_RESP:
            	//同步
            	ibPileCmdHandler.timeSyncCmdHandle(ctx, fullData);
            	break;
            case WORK_PARAM_RESP:
            	//充电桩工作参数设置
            	ibPileCmdHandler.workParamCmdHandle(ctx,fullData);
            	break;
            case AUTHEN_RESP:
            	//充电桩认证合法用户信息
            	ibPileCmdHandler.validAuthenCmdHandle(ctx, fullData);
            	break;
            case REMOTE_UPGRADE_RESP:
            	//远程系统升级
            	ibPileCmdHandler.remoteUpgradeCmdHandle(ctx, fullData);
            	break;
            case CHARGING_RECORD_REPORT:
            	//充电桩上报充电记录命令
            	ibPileCmdHandler.chargeRecordInfoCmdHandle(ctx, fullData);
            	break;
            case BRM_REC:
            	//充电桩上报BMS与车辆辨识报文
            	ibPileCmdHandler.BRMCmdHandle(ctx, fullData);
            	break;
            case COMMUN_MODE_RESP:
            	//通讯模式设置应答
            	ibPileCmdHandler.ReportTypeCmdHandle(ctx, fullData);
            	break;
            case BCP_REC:
            	//桩上报BCP报文
            	ibPileCmdHandler.BCPCmdHandle(ctx, fullData);
            	break;
            default:
                log.info("其他命令");
                break;
        }
    }
}