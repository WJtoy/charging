/*
 *
 */
package com.gdcdgj.charging.gateway.platform.ib.execute.receive;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;

/**
 * 10.2.36	充电桩上报CEM报文(0x0B)
 * @author ouxx
 * @since 2017-5-3 下午4:13:00
 *
 */
public class CemInfo extends DataBaseVo {

	private static final long serialVersionUID = 1L;

	//充电机错误报文信息1	1
	private Byte errBmsBrmTmOut;//BIT1~BIT0,接收BMS发送BRM报文超时01；

	//充电机错误报文信息2	1
	private Byte errBcpTmOut;//BIT1~BIT0,接收电池BCP报文超时01；
	private Byte errBmsBroTmOut;//BIT3~BIT2,接收BMS发送BRO报文超时01；

	//充电机错误报文信息3	1
	private Byte errBcsTmOut;//BIT1~BIT0,接收电池BCS报文超时01；
	private Byte errBclTmOut;//BIT3~BIT2,接收电池BCL报文超时01；
	private Byte errBstTmOut;//BIT5~BIT4,接收电池BST报文超时01；

	//充电机错误报文信息4	1
	private Byte errBsdTmOut;//BIT1~BIT0,接收电池BSD报文超时01；
	private Byte others;//BIT3~BIT2,其他

	public Byte getErrBmsBrmTmOut() {
		return errBmsBrmTmOut;
	}
	public void setErrBmsBrmTmOut(Byte errBmsBrmTmOut) {
		this.errBmsBrmTmOut = errBmsBrmTmOut;
	}
	public Byte getErrBcpTmOut() {
		return errBcpTmOut;
	}
	public void setErrBcpTmOut(Byte errBcpTmOut) {
		this.errBcpTmOut = errBcpTmOut;
	}
	public Byte getErrBmsBroTmOut() {
		return errBmsBroTmOut;
	}
	public void setErrBmsBroTmOut(Byte errBmsBroTmOut) {
		this.errBmsBroTmOut = errBmsBroTmOut;
	}
	public Byte getErrBcsTmOut() {
		return errBcsTmOut;
	}
	public void setErrBcsTmOut(Byte errBcsTmOut) {
		this.errBcsTmOut = errBcsTmOut;
	}
	public Byte getErrBclTmOut() {
		return errBclTmOut;
	}
	public void setErrBclTmOut(Byte errBclTmOut) {
		this.errBclTmOut = errBclTmOut;
	}
	public Byte getErrBstTmOut() {
		return errBstTmOut;
	}
	public void setErrBstTmOut(Byte errBstTmOut) {
		this.errBstTmOut = errBstTmOut;
	}
	public Byte getErrBsdTmOut() {
		return errBsdTmOut;
	}
	public void setErrBsdTmOut(Byte errBsdTmOut) {
		this.errBsdTmOut = errBsdTmOut;
	}
	public Byte getOthers() {
		return others;
	}
	public void setOthers(Byte others) {
		this.others = others;
	}


}
