/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.ib.execute.receive;

import com.gdcdgj.charging.api.vo.srv2gw.AccountInfo;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbProtocolUtil;
import com.gdcdgj.charging.gateway.platform.ib.protocol.indexAndLen.T2H_AccountQueryReportIndexAndLen;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;

/**
 * 10.3.1	充电桩上报账户查询命令(0x70)
 * @author ouxx
 * @since 2016-11-14 下午4:30:04
 *
 */
public class RecAccountQueryReportCmd implements BaseReceiveCmdExecute {

	/**
	 * 10.3.1	充电桩上报账户查询命令(0x70)
	 * @param fullData
	 * @param accountQuery
	 * @return
	 * @throws Exception
	 * @author ouxx
	 * @date 2016-11-14 下午4:32:55
	 */
	public static AccountInfo recAccountQueryReport(byte[] fullData,AccountInfo accountQuery) throws Exception{
		
		byte[] dataAfterCmdSeq = IbProtocolUtil.getDataAfterConnectorNoInDataField(fullData);

		//卡号
		accountQuery.setCardNum((String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
				T2H_AccountQueryReportIndexAndLen.CARDNUM.getIndex(), T2H_AccountQueryReportIndexAndLen.CARDNUM.getLen(), DataAnalyseWayEnum.StrASCII));

		//客户证件类型
		accountQuery.setCertType((Byte) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
				T2H_AccountQueryReportIndexAndLen.CERT_TYPE.getIndex(), T2H_AccountQueryReportIndexAndLen.CERT_TYPE.getLen(), DataAnalyseWayEnum.Byte));

		//客户证件号码
		accountQuery.setCertNum((String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
				T2H_AccountQueryReportIndexAndLen.CERT_NUM.getIndex(), T2H_AccountQueryReportIndexAndLen.CERT_NUM.getLen(), DataAnalyseWayEnum.StrASCII));

		//受理渠道
		accountQuery.setApprovalChannel((Integer) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
				T2H_AccountQueryReportIndexAndLen.APPROVAL_CHANNEL.getIndex(), T2H_AccountQueryReportIndexAndLen.APPROVAL_CHANNEL.getLen(), DataAnalyseWayEnum.CharReverse));

		//出单机构流水号
		accountQuery.setOperSeq((String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
				T2H_AccountQueryReportIndexAndLen.OPER_SEQ.getIndex(), T2H_AccountQueryReportIndexAndLen.OPER_SEQ.getLen(), DataAnalyseWayEnum.StrASCII));

		//出单机构代码
		accountQuery.setOperCode((String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
				T2H_AccountQueryReportIndexAndLen.OPER_CODE.getIndex(), T2H_AccountQueryReportIndexAndLen.OPER_CODE.getLen(), DataAnalyseWayEnum.StrASCII));

		//受理操作员编号
		accountQuery.setApprovalOperNum((String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
				T2H_AccountQueryReportIndexAndLen.APPROVAL_OPER_NUM.getIndex(), T2H_AccountQueryReportIndexAndLen.APPROVAL_OPER_NUM.getLen(), DataAnalyseWayEnum.StrASCII));

		//交易日期时间
		accountQuery.setTradeDate(ProtocolDataGenerator.getCalendar(T2H_AccountQueryReportIndexAndLen.TRADE_DATE.getIndex(), dataAfterCmdSeq));

		//支付密码
		accountQuery.setPayPassword((String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
				T2H_AccountQueryReportIndexAndLen.PAY_PASSWORD.getIndex(), T2H_AccountQueryReportIndexAndLen.PAY_PASSWORD.getLen(), DataAnalyseWayEnum.StrASCII));

		//服务收费标识
		accountQuery.setServiceFeeId((Byte) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
				T2H_AccountQueryReportIndexAndLen.SERVICE_FEE_ID.getIndex(), T2H_AccountQueryReportIndexAndLen.SERVICE_FEE_ID.getLen(), DataAnalyseWayEnum.Byte));

		//服务收费金额
		accountQuery.setServiceFee((Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
				T2H_AccountQueryReportIndexAndLen.SERVICE_FEE.getIndex(), T2H_AccountQueryReportIndexAndLen.SERVICE_FEE.getLen(), DataAnalyseWayEnum.DoubleReverse));

		//报文认证码
		accountQuery.setAuthCode((String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
				T2H_AccountQueryReportIndexAndLen.AUTH_CODE.getIndex(), T2H_AccountQueryReportIndexAndLen.AUTH_CODE.getLen(), DataAnalyseWayEnum.StrASCII));

		return accountQuery;
	}


	@Override
	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
		AccountInfo accountQuery = new AccountInfo();
		IbProtocolUtil.setMemberIdAndCmdSeqAndConnectorNo(accountQuery, fullData);
		return recAccountQueryReport(fullData,accountQuery);
	}
}
