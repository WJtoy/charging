/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.ib.execute.receive;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbProtocolUtil;
import com.mysql.cj.conf.PropertyDefinitions.AuthMech;

/**
 * 充电桩应答中心合法用户认证通过信息(0x7A)
 * @author ouxx
 * @since 2016-11-14 下午4:44:00
 *
 */
public class RecAuthenCmd implements BaseReceiveCmdExecute {

	@Override
	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
//		AuthMech authen = new AuthMech();
//		ProtocolDataGenerator.beforeHandler(authen, fullData);
//		return recAuthen(fullData,authen);
		return null;
	}

	/**
	 * 充电桩应答中心合法用户认证通过信息(0x7A)
	 * @param fullData
	 * @param authen
	 * @return
	 * @throws Exception
	 * @author ouxx
	 * @date 2016-11-14 下午4:46:59
	 */
	public static AuthMech recAuthen(byte[] fullData,AuthMech authen) throws Exception{
		
		byte[] dataAfterCmdSeq = IbProtocolUtil.getDataAfterConnectorNoInDataField(fullData);
//		//卡号
//		authen.setCardNum((String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
//				T2H_AuthenIndexAndLen.CARDNUM.getIndex(), T2H_AuthenIndexAndLen.CARDNUM.getLen(), DataAnalyseWayEnum.StrASCII));
//
//		//客户证件类型
//		authen.setCertType((Byte) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
//				T2H_AuthenIndexAndLen.CERT_TYPE.getIndex(), T2H_AuthenIndexAndLen.CERT_TYPE.getLen(), DataAnalyseWayEnum.Byte));
//
//		//客户证件号码
//		authen.setCertNum((String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
//				T2H_AuthenIndexAndLen.CERT_NUM.getIndex(), T2H_AuthenIndexAndLen.CERT_NUM.getLen(), DataAnalyseWayEnum.StrASCII));
//
//		//受理渠道
//		authen.setApprovalChannel((Integer) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
//				T2H_AuthenIndexAndLen.APPROVAL_CHANNEL.getIndex(), T2H_AuthenIndexAndLen.APPROVAL_CHANNEL.getLen(), DataAnalyseWayEnum.CharReverse));
//
//		//出单机构流水号
//		authen.setOperSeq((String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
//				T2H_AuthenIndexAndLen.OPER_SEQ.getIndex(), T2H_AuthenIndexAndLen.OPER_SEQ.getLen(), DataAnalyseWayEnum.StrASCII));
//
//		//出单机构代码
//		authen.setOperCode((String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
//				T2H_AuthenIndexAndLen.OPER_CODE.getIndex(), T2H_AuthenIndexAndLen.OPER_CODE.getLen(), DataAnalyseWayEnum.StrASCII));
//
//		//受理操作员编号
//		authen.setApprovalOperNum((String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
//				T2H_AuthenIndexAndLen.APPROVAL_OPER_NUM.getIndex(), T2H_AuthenIndexAndLen.APPROVAL_OPER_NUM.getLen(), DataAnalyseWayEnum.StrASCII));
//
//		//交易日期时间
//		authen.setTradeDate(ProtocolDataGenerator.getCalendar(T2H_AuthenIndexAndLen.TRADE_DATE.getIndex(), dataAfterCmdSeq));
//
//		//充电枪编号
//		authen.setConnectorNum((Byte) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
//				T2H_AuthenIndexAndLen.CONNECTOR_NUM.getIndex(), T2H_AuthenIndexAndLen.CONNECTOR_NUM.getLen(), DataAnalyseWayEnum.Byte));
//
//		//处理状态
//		authen.setState((Byte) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
//				T2H_AuthenIndexAndLen.STATE.getIndex(), T2H_AuthenIndexAndLen.STATE.getLen(), DataAnalyseWayEnum.Byte));
//
//		//报文认证码
//		authen.setAuthCode((String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
//				T2H_AuthenIndexAndLen.AUTH_CODE.getIndex(), T2H_AuthenIndexAndLen.AUTH_CODE.getLen(), DataAnalyseWayEnum.StrASCII));

		return authen;
	}
}
