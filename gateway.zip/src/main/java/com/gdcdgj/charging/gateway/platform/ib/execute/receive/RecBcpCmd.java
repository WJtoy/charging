/*
 *
 */
package com.gdcdgj.charging.gateway.platform.ib.execute.receive;

import com.gdcdgj.charging.api.vo.srv2gw.BcpInfo;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbCmdEnum;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbProtocolUtil;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.platform.ib.protocol.indexAndLen.T2H_BcpRecIndexAndLen;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;
import com.gdcdgj.charging.gateway.util.Offset;
import com.gdcdgj.charging.gateway.util.ZoomFactor;

/**
 * 充电桩在充电准备阶段上报BCP 0x03
 * @author ouxx
 * @since 2017-5-1 下午4:06:56
 *
 */
public class RecBcpCmd implements BaseReceiveCmdExecute {

	/* (non-Javadoc)
	 * @see com.gdcdgj.service.provider.piles.echarging.cmd.BaseRecCmd#recExecute(byte[])
	 */
	@Override
	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
		BcpInfo bcpInfo = new BcpInfo();
		IbProtocolUtil.setMemberIdAndCmdSeqAndConnectorNo(bcpInfo, fullData);
		return  recBcp(fullData, bcpInfo);
	}


	private BcpInfo recBcp(byte[] fullData, BcpInfo bcpInfo) throws Exception {
		byte[] dataAfterCmdSeq = IbProtocolUtil.getDataAfterConnectorNoInDataField(fullData);

//		BATTERY_CELL_VOL_LIMIT(0, 2),//单体动力电池最高允许充电电压	2
		{
			final DataAnalyzer analyzerVolLimit = new DataAnalyzer();
			analyzerVolLimit.setAnalyseWay(DataAnalyseWayEnum.UInt16);
			analyzerVolLimit.setZoomFactor(ZoomFactor.BCP_BATTERY_CELL_VOL_LIMIT);
			Double batteryCellVolLimit = (Double)ProtocolDataGenerator.getOneData2(dataAfterCmdSeq,
					T2H_BcpRecIndexAndLen.BATTERY_CELL_VOL_LIMIT.getIndex(),
					T2H_BcpRecIndexAndLen.BATTERY_CELL_VOL_LIMIT.getLen(),
					analyzerVolLimit);
			bcpInfo.setBatteryCellVolLimit(batteryCellVolLimit);
		}
//		CURR_LIMIT(2, 2),//最高允许充电电流	2
		{
			final DataAnalyzer analyzerCurrLimit = new DataAnalyzer();
			analyzerCurrLimit.setAnalyseWay(DataAnalyseWayEnum.UInt16);
			analyzerCurrLimit.setZoomFactor(ZoomFactor.Current);
			analyzerCurrLimit.setOffset(Offset.BCP_CURR_LIMIT);
			Double currLimit = (Double)ProtocolDataGenerator.getOneData2(dataAfterCmdSeq,
					T2H_BcpRecIndexAndLen.CURR_LIMIT.getIndex(),
					T2H_BcpRecIndexAndLen.CURR_LIMIT.getLen(),
					analyzerCurrLimit);
			bcpInfo.setCurrLimit(currLimit);
		}
//		TOTAL_KWH(4, 2),//动力蓄电池标称总能量	2
		{
			final DataAnalyzer analyzerTotalKwh = new DataAnalyzer();
			analyzerTotalKwh.setAnalyseWay(DataAnalyseWayEnum.UInt16);
			analyzerTotalKwh.setZoomFactor(ZoomFactor.BCP_TOTAL_KWH);
			Double totalKwh = (Double)ProtocolDataGenerator.getOneData2(dataAfterCmdSeq,
					T2H_BcpRecIndexAndLen.TOTAL_KWH.getIndex(),
					T2H_BcpRecIndexAndLen.TOTAL_KWH.getLen(),
					analyzerTotalKwh);
			bcpInfo.setTotalKwh(totalKwh);
		}
//		TOTAL_VOL(6, 2),//最高允许充电总电压	2
		{
			final DataAnalyzer analyzerTotalVol = new DataAnalyzer();
			analyzerTotalVol.setAnalyseWay(DataAnalyseWayEnum.UInt16);
			analyzerTotalVol.setZoomFactor(ZoomFactor.Voltage);
			Double totalVol = (Double)ProtocolDataGenerator.getOneData2(dataAfterCmdSeq,
					T2H_BcpRecIndexAndLen.TOTAL_VOL.getIndex(),
					T2H_BcpRecIndexAndLen.TOTAL_VOL.getLen(),
					analyzerTotalVol);
			bcpInfo.setTotalVol(totalVol);
		}
//		TEMPRETURE_LIMIT(8, 1),//最高允许温度	1
		{
			Integer tempretureLimit = (int) (dataAfterCmdSeq[T2H_BcpRecIndexAndLen.TEMPRETURE_LIMIT.getIndex()] & 0xFF);
			bcpInfo.setTempretureLimit(tempretureLimit + Offset.Temperature.getValue());
		}
//		SOC(9, 2),//整车动力蓄电池荷电状态	2
		{
			final DataAnalyzer analyzerSoc = new DataAnalyzer();
			analyzerSoc.setAnalyseWay(DataAnalyseWayEnum.UInt16);
			analyzerSoc.setZoomFactor(ZoomFactor.BCP_SOC);
			Double soc = (Double)ProtocolDataGenerator.getOneData2(dataAfterCmdSeq,
					T2H_BcpRecIndexAndLen.SOC.getIndex(),
					T2H_BcpRecIndexAndLen.SOC.getLen(),
					analyzerSoc);
			bcpInfo.setSoc(soc);
		}
//		CURRENT_VOL(11, 2);//动力蓄电池当前电池电压	2
		{
			final DataAnalyzer analyzerCurrVol = new DataAnalyzer();
			analyzerCurrVol.setAnalyseWay(DataAnalyseWayEnum.UInt16);
			analyzerCurrVol.setZoomFactor(ZoomFactor.Voltage);
			Double currVol = (Double)ProtocolDataGenerator.getOneData2(dataAfterCmdSeq,
					T2H_BcpRecIndexAndLen.CURRENT_VOL.getIndex(),
					T2H_BcpRecIndexAndLen.CURRENT_VOL.getLen(),
					analyzerCurrVol);
			bcpInfo.setCurrentVol(currVol);
		}

		return bcpInfo;
	}

}
