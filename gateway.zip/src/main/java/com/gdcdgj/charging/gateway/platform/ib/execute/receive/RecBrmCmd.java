/*
 *
 */
package com.gdcdgj.charging.gateway.platform.ib.execute.receive;

import java.util.Calendar;

import org.apache.commons.lang3.time.FastDateFormat;

import com.gdcdgj.charging.api.vo.srv2gw.BrmInfo;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbProtocolUtil;
import com.gdcdgj.charging.gateway.platform.ib.protocol.indexAndLen.T2H_BrmRecIndexAndLen;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;

/**
 * 充电桩在充电准备阶段上报BMS与车辆辨识报文BRM 0x02
 *
 * @author ouxx
 * @since 2017-4-27 下午5:56:22
 *
 */
public class RecBrmCmd implements BaseReceiveCmdExecute {

	private static final FastDateFormat format = FastDateFormat.getInstance("yyyyMMdd");

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * com.gdcdgj.service.provider.piles.echarging.cmd.BaseRecCmd#recExecute(byte
	 * [])
	 */
	@Override
	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
		BrmInfo brmInfo = new BrmInfo();
		IbProtocolUtil.setMemberIdAndCmdSeqAndConnectorNo(brmInfo, fullData);
		brmInfo = recBrm(fullData, brmInfo);
		return brmInfo;
	}

	/**
	 * 取年、月、日.
	 * 年:偏移量为1985,数据范围[1985,2235]
	 * @param index
	 * @param dataAfterCmdSeq
	 * @return
	 * @author ouxx
	 * @date 2017-4-27 下午5:43:07
	 */
	public static Calendar getCalendarBrmBatteryProdDateYMD(final int index, final byte[] dataAfterCmdSeq){
		//年:偏移量为1985,数据范围[1985,2235]
		final int indexYear = index;
		final int lenYear = 1;
		int year = dataAfterCmdSeq[indexYear] + 1985;
		//月  1个字节
		final int indexMonth = indexYear + lenYear;
		final int lenMonth = 1;
		int month = dataAfterCmdSeq[indexMonth];
		//日  1个字节
		final int indexDay = indexMonth + lenMonth;
		int day = dataAfterCmdSeq[indexDay];

		Calendar cal = Calendar.getInstance();
		cal.set(year, month - 1, day, 0, 0, 0);
		return cal;
	}

	private static BrmInfo recBrm(byte[] fullData, BrmInfo brmInfo) throws Exception {
		// PROTOCOL_VERSION(0, 3),//BMS协议版本 3
		// BATTERY_TYPE(3, 1),//电池类型 1
		// BATTERY_AH(4, 2),//动力电池额定容量 2
		// BATTERY_TOTAL_VOL(6, 2),//动力电池额定总电压 2
		// BATTERY_MANUFACT(8, 4),//电池生产厂商名称 4
		// BATTERY_PACK_SN(12, 4),//电池组序号 4
		// BATTERY_PACK_DATE_OF_PROD(16, 3),//电池组生产日期 3
		// BATTERY_PACK_CHARG_TIMES(19, 3),//电池组充电次数 3
		// BATTERY_PACK_PROP_ID(22, 1),//电池组产权标识 1
		// RESERVATION(23, 1),//预留 1
		// CAR_VIN(24, 17),//车辆识别码VIN 17
		// BMS_VERSION(41, 8);//BMS软件版本号 8

		byte[] dataAfterCmdSeq = IbProtocolUtil.getDataAfterConnectorNoInDataField(fullData);
		// BMS协议版本:如V1.2,[0] = 2,[1] = 1,[2] = 0
		{
			//存版本号字符串
			Integer protocolVersionPart1 = ((Double)ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
					1, T2H_BrmRecIndexAndLen.PROTOCOL_VERSION.getLen() - 1,
					DataAnalyseWayEnum.UInt16)).intValue();
			brmInfo.setProtocolVersion(protocolVersionPart1
					+ "." + dataAfterCmdSeq[T2H_BrmRecIndexAndLen.PROTOCOL_VERSION.getIndex()]);
		}
		// 电池类型
		{
			Byte type = dataAfterCmdSeq[T2H_BrmRecIndexAndLen.BATTERY_TYPE.getIndex()];
			brmInfo.setBatteryType(type);
		}
		// 动力电池额定容量
		{
			Double batteryAh = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
					T2H_BrmRecIndexAndLen.BATTERY_AH.getIndex(), T2H_BrmRecIndexAndLen.BATTERY_AH.getLen(), DataAnalyseWayEnum.Int16);
			brmInfo.setBatteryAh(batteryAh);
		}
		// 动力电池额定总电压 2
		{
			Double batteryVol = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
					T2H_BrmRecIndexAndLen.BATTERY_TOTAL_VOL.getIndex(),
					T2H_BrmRecIndexAndLen.BATTERY_TOTAL_VOL.getLen(), DataAnalyseWayEnum.Int16);
			brmInfo.setBatteryTotalVol(batteryVol);
		}
		// BATTERY_MANUFACT(8, 4),//电池生产厂商名称 4
		{
			String batteryManufact = (String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
					T2H_BrmRecIndexAndLen.BATTERY_MANUFACT.getIndex(),
					T2H_BrmRecIndexAndLen.BATTERY_MANUFACT.getLen(), DataAnalyseWayEnum.StrASCII);
			brmInfo.setBatteryManufact(batteryManufact);
		}
		//BATTERY_PACK_SN(12, 4),//电池组序号	4
		{
			String batteryPackSn = (String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
					T2H_BrmRecIndexAndLen.BATTERY_PACK_SN.getIndex(),
					T2H_BrmRecIndexAndLen.BATTERY_PACK_SN.getLen(), DataAnalyseWayEnum.StrASCII);
			brmInfo.setBatteryPackSn(batteryPackSn);
		}
		//BATTERY_PACK_DATE_OF_PROD(16, 3),//电池组生产日期	3
		{
			Calendar dateOfProd = getCalendarBrmBatteryProdDateYMD(T2H_BrmRecIndexAndLen.BATTERY_PACK_DATE_OF_PROD.getIndex(), dataAfterCmdSeq);
			brmInfo.setBatteryPackDateOfProd(dateOfProd);
		}
		// BATTERY_PACK_CHARG_TIMES(19, 3),//电池组充电次数 3
		{
			Double batteryChargTimes = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
					T2H_BrmRecIndexAndLen.BATTERY_PACK_CHARG_TIMES.getIndex(),
					T2H_BrmRecIndexAndLen.BATTERY_PACK_CHARG_TIMES.getLen(), DataAnalyseWayEnum.Int16);
			brmInfo.setBatteryPackChargTimes(batteryChargTimes.intValue());
		}
		// BATTERY_PACK_PROP_ID(22, 1),//电池组产权标识 1  0:租赁；1:车自有
		{
			Byte propId = dataAfterCmdSeq[T2H_BrmRecIndexAndLen.BATTERY_PACK_PROP_ID.getIndex()];
			brmInfo.setBatteryPackPropId(propId.intValue());
		}
		// CAR_VIN(24, 17),//车辆识别码VIN 17
		{
			String carVin = (String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
					T2H_BrmRecIndexAndLen.CAR_VIN.getIndex(),
					T2H_BrmRecIndexAndLen.CAR_VIN.getLen(), DataAnalyseWayEnum.StrASCII);
			brmInfo.setCarVin(carVin);
		}
		// BMS_VERSION(41, 8);//BMS软件版本号 8
		//BYTE8~BYTE6预留填充0xFFFFFF；BYTE5~BYTE4填充BMS软件版本编译时间年；BYTE3填充月；BYTE2填充日；
		//BYTE1填充版本流水号
		{
//			Calendar versionCal = ProtocolDataGenerator.getCalendarYMD(
//					T2H_BrmRecIndexAndLen.BMS_VERSION.getIndex() + 3, dataAfterCmdSeq);
//			String versionDateStr = format.format(versionCal);
//			byte sn = dataAfterCmdSeq[T2H_BrmRecIndexAndLen.BMS_VERSION.getIndex()
//			                          + T2H_BrmRecIndexAndLen.BMS_VERSION.getLen() - 1];

			//年份  2个字节
			final int indexYear = T2H_BrmRecIndexAndLen.BMS_VERSION.getIndex() + 3;
			final int lenYear = 2;
			Double year = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexYear, lenYear, DataAnalyseWayEnum.CharReverse);
			//月  1个字节
			final int indexMonth = indexYear - lenYear;
			final int lenMonth = 1;
			int month = dataAfterCmdSeq[indexMonth];
			//日  1个字节
			final int indexDay = indexMonth - lenMonth;
			int day = dataAfterCmdSeq[indexDay];

			Calendar cal = Calendar.getInstance();
			cal.set(year.intValue(), month, day, 0, 0, 0);
			String versionDateStr = format.format(cal);

			byte sn = dataAfterCmdSeq[T2H_BrmRecIndexAndLen.BMS_VERSION.getIndex()];

			brmInfo.setBmsSoftVersion(versionDateStr + sn);
		}

		return brmInfo;
	}

}
