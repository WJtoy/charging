/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.ib.execute.receive;

import java.text.DecimalFormat;
import java.util.Calendar;

import com.gdcdgj.charging.api.vo.srv2gw.ChargeRecordInfo;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbProtocolUtil;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;
import com.gdcdgj.charging.gateway.util.ZoomFactor;

import lombok.extern.slf4j.Slf4j;

/**
 * 10.3.8	充电桩上报充电记录命令(0x78)
	 * 充电桩在一次充电结束后，将本次充电的信息上报后台，
	 * 后台根据具体内容进行审核和费用计算，
	 * 并将结果通过“中心系统应答上报充电记录应答”返回。
 * @author ouxx
 * @since 2016-11-14 下午4:47:44
 *
 */
@Slf4j
public class RecChargingRecordReportCmd implements BaseReceiveCmdExecute {

	@Override
	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
		ChargeRecordInfo chargingRecord = new ChargeRecordInfo();
		IbProtocolUtil.setMemberIdAndCmdSeqAndConnectorNo(chargingRecord, fullData);
		return recChargingRecordReport(fullData, chargingRecord);
	}

	/**
	 * 10.3.8	充电桩上报充电记录命令(0x78)
	 * 充电桩在一次充电结束后，将本次充电的信息上报后台，
	 * 后台根据具体内容进行审核和费用计算，
	 * 并将结果通过“中心系统应答上报充电记录应答”返回。
	 * @param fullData
	 * @param chargingRecord
	 * @return
	 * @throws Exception
	 * @author ouxx
	 * @date 2016-11-14 下午4:49:40
	 */
	public ChargeRecordInfo recChargingRecordReport(byte[] fullData, ChargeRecordInfo chargingRecord) throws Exception{
		try {
			byte[] dataAfterCmdSeq = IbProtocolUtil.getDataAfterConnectorNoInDataField(fullData);
			//充电位置类型  1=直流；2=交流    1个字节
			DecimalFormat df = new DecimalFormat("#0.00");
			chargingRecord.setLocationType(((Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
					0, 1, DataAnalyseWayEnum.Byte)).intValue());
			//卡号  16个字节
			chargingRecord.setChargeNo((String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
					1, 16, DataAnalyseWayEnum.StrASCII));
			//中心交易流水号  15个字节
			chargingRecord.setSerialNum((String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
					17, 15, DataAnalyseWayEnum.StrASCII));
			//充电预约序号  20个字节
			chargingRecord.setBookSeq((String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
					32, 20, DataAnalyseWayEnum.StrASCII));
			//充电机编码  8个字节
			chargingRecord.setPileCode((String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
					52, 8, DataAnalyseWayEnum.StrASCII));
			//车辆VIN  17个字节
			chargingRecord.setCarVIN((String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
					60, 17, DataAnalyseWayEnum.StrASCII));
			//车牌号  8个字节
			chargingRecord.setCarLpn((String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
					77, 8, DataAnalyseWayEnum.StrASCII));
			{
				//开始充电SOC  1个字节
				Double data = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
						85, 1, DataAnalyseWayEnum.Byte);
				chargingRecord.setStartSOC(data.intValue());
				//结束充电SOC  1个字节
				Double data1 = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
						86, 1, DataAnalyseWayEnum.Byte);
				chargingRecord.setStopSOC(data1.intValue());
				//本次累计充电量 Ah  2个字节
				Double data2 = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
						87, 2, DataAnalyseWayEnum.UInt16);
				chargingRecord.setCurrentChargeCount(data2);
			}
			//本次累计充电能  2个字节
			{
				final DataAnalyzer analyzerKwh = new DataAnalyzer();
				analyzerKwh.setAnalyseWay(DataAnalyseWayEnum.UInt16);
				analyzerKwh.setZoomFactor(ZoomFactor.Kwh);
				byte[] kwh = IbProtocolUtil.getDataByIndexAndSize(dataAfterCmdSeq
						, 89					//数据起始位置
						, 2); 						//数据字节数
				Double kwhVal = (Double) DataAnalyzer.analyseAnalogData(analyzerKwh, kwh);
				chargingRecord.setKwh(Double.valueOf(df.format(kwhVal)));
			}
			//充电时间长度  4个字节
			chargingRecord.setChargeTimeLen(((Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
					91, 4, DataAnalyseWayEnum.UInt32)).intValue());
			//充电满策略  1个字节
			chargingRecord.setChargePolicy(((Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
					95, 1, DataAnalyseWayEnum.Byte)).intValue());
			//充电满策略参数  2个字节
			chargingRecord.setChargePolicyParam(((Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
					96, 2, DataAnalyseWayEnum.UInt16)).intValue());
			//是否正常结束  1个字节
				Double chargeStopCause = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
				98, 1, DataAnalyseWayEnum.Byte);
				chargingRecord.setFalutCode(chargeStopCause.intValue());
				chargingRecord.setChargeStopCause(getChargeStopCauses(chargeStopCause.intValue()));
			{
				Calendar a = ProtocolDataGenerator.getCalendar(99, dataAfterCmdSeq);
				//开始充电日期时间 8个字节
				chargingRecord.setStartChargeTime(a);
				//结束充电日期时间 8个字节
				Calendar b = ProtocolDataGenerator.getCalendar(107, dataAfterCmdSeq);
				chargingRecord.setStopChargeTime(b);
				//交易日期时间 8个字节
				Calendar c = ProtocolDataGenerator.getCalendar(115, dataAfterCmdSeq);
				chargingRecord.setTradeDate(c);	
			}
				//			//开始电表度数  4个字节
//			chargingRecord.setKwhBegin(((Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
//					T2H_ChargingRecordReportIndexAndLen.KWH_BEGIN.getIndex(), T2H_ChargingRecordReportIndexAndLen.KWH_BEGIN.getLen(), DataAnalyseWayEnum.UInt32)).intValue());
	//
//			//结束电表度数  4个字节
//			chargingRecord.setKwhEnd(((Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
//					T2H_ChargingRecordReportIndexAndLen.KWH_END.getIndex(), T2H_ChargingRecordReportIndexAndLen.KWH_END.getLen(), DataAnalyseWayEnum.UInt32)).intValue());



			{
				final DataAnalyzer analyzerKwhBeginAndEnd = new DataAnalyzer();
				analyzerKwhBeginAndEnd.setAnalyseWay(DataAnalyseWayEnum.UInt32);
				analyzerKwhBeginAndEnd.setZoomFactor(ZoomFactor.Kwh);

				//开始电表度数  4个字节 Double.valueOf(df.format(kwhVal))
				chargingRecord.setBeforeAmmeterNum(Double.valueOf(df.format(ProtocolDataGenerator.getOneData2(dataAfterCmdSeq,
						123, 4, analyzerKwhBeginAndEnd))));
				//结束电表度数  4个字节
				chargingRecord.setAfterAmmeterNum(Double.valueOf(df.format(ProtocolDataGenerator.getOneData2(dataAfterCmdSeq,
						127, 4, analyzerKwhBeginAndEnd))));
			}
			log.info("充电桩上报充电记录命令(0x78)");
			log.info("充电位置类型  1=直流；2=交流：{}",chargingRecord.getLocationType());
			log.info("卡号：{} ",chargingRecord.getChargeNo());
			log.info("中心交易流水号：{}",chargingRecord.getSerialNum());
			log.info("充电预约序号：{}",chargingRecord.getBookSeq());
			log.info("充电机编码 ：{}",chargingRecord.getPileCode());
			log.info("车辆VIN：{}",chargingRecord.getCarVIN());
			log.info("车牌号：{}",chargingRecord.getCarLpn());
			log.info("开始充电SOC：{}",chargingRecord.getStartSOC());
			log.info("结束充电SOC：{}",chargingRecord.getStopSOC());
			log.info("本次累计充电量 Ah：{}",chargingRecord.getCurrentChargeCount());
			log.info("本次累计充电能：{}",chargingRecord.getKwh());
			log.info("充电时间长度：{}",chargingRecord.getChargeTimeLen());
			log.info("充电满策：{}",chargingRecord.getChargePolicy());
			log.info("充电满策略参数：{}",chargingRecord.getChargePolicyParam());
			log.info("是否正常结束：{}",chargingRecord.getChargeStopCause());
			log.info("结束原因码 ：{}",chargingRecord.getFalutCode());
			log.info("开始充电日期时间：{}",chargingRecord.getStartChargeTime());
			log.info("结束充电日期时间：{}",chargingRecord.getStopChargeTime());
			log.info("交易日期时间：{}",chargingRecord.getTradeDate());
			log.info("开始电表度数：{} ",chargingRecord.getBeforeAmmeterNum());
			log.info("结束电表度数：{}",chargingRecord.getAfterAmmeterNum());
		}catch (Exception e) {
			log.error("RecChargingRecordReportCmd 报错：{}",e);
		}
		return chargingRecord;
	}
	private Integer getChargeStopCauses(int a) {
		if(a == 1) return 3;
		if(a == 3) return 1;
		if(a == 80) return 2;
		if(a == 81) return 0;
		//或者余额不足   return 4;	
		return 5;
	}
}
