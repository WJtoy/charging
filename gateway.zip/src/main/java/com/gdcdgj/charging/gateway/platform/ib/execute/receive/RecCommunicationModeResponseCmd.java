package com.gdcdgj.charging.gateway.platform.ib.execute.receive;

import com.gdcdgj.charging.api.vo.srv2gw.CommunicationMode;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbCmdEnum;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbProtocolUtil;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;

/**
 * 10.2.8	通讯模式设置命令应答(0xF0)
 * @author ouxx
 * @since 2016-11-14 下午4:11:14
 *
 */
public class RecCommunicationModeResponseCmd implements BaseReceiveCmdExecute{

	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
		CommunicationMode mode = new CommunicationMode();
		IbProtocolUtil.setMemberIdAndCmdSeqAndConnectorNo(mode, fullData);
		return recCommunicationModeResponse(fullData, mode);
	}

	/**
	 * 10.2.8	通讯模式设置命令应答(0xF0)
	 * @param fullData
	 * @return
	 * @throws Exception
	 * @author ouxx
	 * @date 2016-11-4 上午9:18:32
	 */
	public static CommunicationMode recCommunicationModeResponse(byte[] fullData, CommunicationMode mode) throws Exception{
		byte[] dataAfterCmdSeq = IbProtocolUtil.getDataAfterConnectorNoInDataField(fullData);

		final int index0 = 0;
		final int len0 = 1;
		Double m = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index0, len0, DataAnalyseWayEnum.Byte);
		mode.setMode(m.byteValue());
		//如果数据长度为2字节，并且为上报模式，则设置上报间隔
		if(2 == dataAfterCmdSeq.length && 2 == m){
			final int index1 = index0 + len0;
			final int len1 = 1;
			mode.setReportInterval(((Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index1, len1, DataAnalyseWayEnum.Byte)).byteValue());
		}
		return mode;
	}
}
