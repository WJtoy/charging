package com.gdcdgj.charging.gateway.platform.ib.execute.receive;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.HeartBeatSetting;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbProtocolUtil;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;

/**
 * 10.1.8	系统心跳包信息设置应答(0x59)
 * <p>充电桩为确保与服务器远端连接的正常，定期发送该指令向服务器传递连接心跳包信息。
 * 中心服务器接收该信息后给出应答。充电桩接收到中心服务器发送的“心跳间隔周期和超时检测次数”参数后，
 * 修改并记忆该参数，并且此后按照此参数发送和检测心跳包。
 * @author ouxx
 * @since 2016-11-14 下午3:43:39
 *
 */
public class RecHeartBeatResponseCmd implements BaseReceiveCmdExecute {

	@Override
	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
		HeartBeatSetting heartBeatSetting = new HeartBeatSetting();
		IbProtocolUtil.setMemberIdAndCmdSeqAndConnectorNo(heartBeatSetting, fullData);
		return recHeartBeatResponse(fullData, heartBeatSetting);
	}

	/**
	 * 10.1.8	系统心跳包信息设置应答(0x59)
	 * <p>充电桩为确保与服务器远端连接的正常，定期发送该指令向服务器传递连接心跳包信息。
	 * 中心服务器接收该信息后给出应答。充电桩接收到中心服务器发送的“心跳间隔周期和超时检测次数”参数后，
	 * 修改并记忆该参数，并且此后按照此参数发送和检测心跳包。
	 * @param fullData
	 * @param heartBeatSetting
	 * @return
	 * @throws Exception
	 * @author ouxx
	 * @date 2016-11-14 下午3:49:07
	 */
	public static HeartBeatSetting recHeartBeatResponse(byte[] fullData, HeartBeatSetting heartBeatSetting) throws Exception{
		byte[] dataAfterCmdSeq = IbProtocolUtil.getDataAfterConnectorNoInDataField(fullData);

		//心跳上报周期
		final int index0 = 0;
		final int len0 = 1;
		Double period = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index0, len0, DataAnalyseWayEnum.Byte);
		heartBeatSetting.setPeriod(period.byteValue());

		//心跳包检测超时次数
		final int index1 = index0 + len0;
		final int len1 = 1;
		Double timeOutCnt = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index1, len1, DataAnalyseWayEnum.Byte);
		heartBeatSetting.setTimeOutCnt(timeOutCnt.byteValue());

		return heartBeatSetting;
	}
}
