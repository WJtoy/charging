package com.gdcdgj.charging.gateway.platform.ib.execute.receive;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.HeartBeat;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbProtocolUtil;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;

/**
 * 10.1.6	远端心跳包上报(0x58)
 * <p>接收充电桩发来的心跳包报文 </p>
 *
 * @author Changliang Tao
 * @date 2020/4/30 14:56
 * @since JDK 1.8
 */
public class RecHeartbeatCmdExecute implements BaseReceiveCmdExecute {
    /**
     * 接收心跳报文数据的执行方法
     *
     * @param fullData
     * @return
     * @throws Exception
     * @author ouxx
     */
    @Override
    public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
        HeartBeat heartBeat = new HeartBeat();
        IbProtocolUtil.setMemberIdAndCmdSeqAndConnectorNo(heartBeat, fullData);
        byte[] dataAfterConnectorNoInDataField = IbProtocolUtil.getDataAfterConnectorNoInDataField(fullData);
        Double response = (Double) ProtocolDataGenerator.getOneData(dataAfterConnectorNoInDataField, 0, 2, DataAnalyseWayEnum.UInt16);
        heartBeat.setResponse(response.intValue());
        return heartBeat;
    }
}