/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.ib.execute.receive;

import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.HistoryChargeRecord;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbProtocolUtil;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;

/**
 * 10.3.8	充电桩上报、应答历史充电记录命令(0x92)
 *
 * @author ouxx
 * @since 2016-11-14 下午4:47:44
 *
 */
public class RecHistoryChargingRecordReportCmd implements BaseReceiveCmdExecute {

	@Override
	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
		HistoryChargeRecord historyChargeRecord = new HistoryChargeRecord();
		IbProtocolUtil.setMemberIdAndCmdSeqAndConnectorNo(historyChargeRecord, fullData);
		return rechistoryChargeRecordReport(fullData, historyChargeRecord);
	}

	/**
	 * 10.3.8	充电桩上报、应答历史充电记录命令(0x92)
	 *
	 * @param fullData
	 * @param historyChargeRecord
	 * @return
	 * @throws Exception
	 * @author ouxx
	 * @date 2016-11-14 下午4:49:40
	 */
	public static HistoryChargeRecord rechistoryChargeRecordReport(byte[] fullData, HistoryChargeRecord historyChargeRecord) throws Exception{

		byte[] dataAfterCmdSeq = IbProtocolUtil.getDataAfterConnectorNoInDataField(fullData);
		final int len1 = 1;
		final int len2 = 2;
		final int len4 = 4;
		final int len8 = 8;
		final int len16 = 16;
		DecimalFormat df = new DecimalFormat("#0.00");
		//记录数
		final int index0 = 0;
		{
			Double data = (Double)ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index0, len1, DataAnalyseWayEnum.Byte);
			historyChargeRecord.setRecordCount(data.intValue());
		}
		//记录序号Map<recordSerial,recordSerial>
		Map<Integer,Integer> recordSerialMap = new HashMap<>();
		//充电位置类型map
		Map<Integer,Integer> locationTypeMap = new HashMap<>();
		//充电桩编码Map
		Map<Integer,String> pileCodeMap = new HashMap<>();
		//卡号map
		Map<Integer,String> chargeNoMap = new HashMap<>();
		//中心交易流水号map
		Map<Integer,String> serialNumMap = new HashMap<>();
		//充电预约序号map
		Map<Integer,String> orderIndexNumMap = new HashMap<>();
		//车辆VINmap
		Map<Integer,String> carVINMap = new HashMap<>();
		//车牌号map
		Map<Integer,String> carLPNMap = new HashMap<>();
		//开始充电SOCmap
		Map<Integer,Integer> startSOCMap = new HashMap<>();
		//结束充电SOCmap
		Map<Integer,Integer> endSOCMap = new HashMap<>();
		//本次充电电量map
		Map<Integer,Double> chargeQualityMap = new HashMap<>();
		//本次充电电能map
		Map<Integer,Double> chargePowerMap = new HashMap<>();
		//充电时间长度map
		Map<Integer,Integer> chargeTimeLenMap = new HashMap<>();
		//充电策略map
		Map<Integer,Integer> chargePolicyMap = new HashMap<>();
		//充电结束原因map
		Map<Integer,Integer> stopCauseMap = new HashMap<>();
		//开始充电日期时间map
		Map<Integer,Calendar> startChargeTimeMap = new HashMap<>();
		//结束充电日期时间map
		Map<Integer,Calendar> stopChargeTimeMap = new HashMap<>();
		//交易日期时间map
		Map<Integer,Calendar> treadTimeMap = new HashMap<>();
		//开始电表读数map
		Map<Integer,Double> beforeAmmeterNumMap = new HashMap<>();
		//结束电表读数map
		Map<Integer,Double> afterAmmeterNumMap = new HashMap<>();
		final int recordCount = historyChargeRecord.getRecordCount();
		if(recordCount > 0) {
			int index = len1;
			for (int i = 1; i <= recordCount; i++) {
				//记录序号 4
				{
					Double data = (Double)ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index, len4, DataAnalyseWayEnum.Int32);
					recordSerialMap.put(i, data.intValue());
				}
				//充电位置类型 1
				index += len4;
				{
					Double data = (Double)ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index, len1, DataAnalyseWayEnum.Byte);
					locationTypeMap.put(i, data.intValue());
				}
				//充电桩编码 8
				index += len1;
				{
					String data = (String)ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index, len8, DataAnalyseWayEnum.StrASCII);
					pileCodeMap.put(i, data);
				}
				//卡号 16
				index += len8;
				{
					String data = (String)ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index, len16, DataAnalyseWayEnum.StrASCII);
					chargeNoMap.put(i, data);
				}
				//中心交易流水号 15
				index += len16;
				{
					String data = (String)ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index, 15, DataAnalyseWayEnum.StrASCII);
					serialNumMap.put(i, data);
				}
				//充电预约序号 20
				index += 15;
				{
					String data = (String)ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index, 20, DataAnalyseWayEnum.StrASCII);
					orderIndexNumMap.put(i, data);
				}
				//车辆VIN 17
				index += 20;
				{
					String data = (String)ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index, 17, DataAnalyseWayEnum.StrASCII);
					carVINMap.put(i, data);
				}
				//车牌号 8
				index += 17;
				{
					String data = (String)ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index, len8, DataAnalyseWayEnum.StrASCII);
					carLPNMap.put(i, data);
				}
				//开始SOC 1
				index += len8;
				{
					Double data = (Double)ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index, len1, DataAnalyseWayEnum.Byte);
					startSOCMap.put(i, data.intValue());
				}
				//结束SOC 1
				index += len1;
				{
					Double data = (Double)ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index, len1, DataAnalyseWayEnum.Byte);
					endSOCMap.put(i, data.intValue());
				}
				//本次充电电量 2
				index += len1;
				{
					Double data = (Double)ProtocolDataGenerator.getOneData(dataAfterCmdSeq, 0, 4, DataAnalyseWayEnum.Int16);
					chargeQualityMap.put(i, Double.valueOf(df.format(data)));
				}
				//本次充电电能 2
				index += len2;
				{
					Double data = (Double)ProtocolDataGenerator.getOneData(dataAfterCmdSeq, 0, 4, DataAnalyseWayEnum.Int16);
					chargePowerMap.put(i, Double.valueOf(df.format(data)));
				}
				//充电时间长度 4
				index += len2;
				{
					Double data = (Double)ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index, len4, DataAnalyseWayEnum.Int32);
					chargeTimeLenMap.put(i, data.intValue());
				}
				//充电策略 1
				index += len4;
				{
					Double data = (Double)ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index, len1, DataAnalyseWayEnum.Byte);
					chargePolicyMap.put(i, data.intValue());
				}
				//充电结束原因 1
				index += len1;
				{
					Double data = (Double)ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index, len1, DataAnalyseWayEnum.Byte);
					stopCauseMap.put(i, data.intValue());
				}
				//开始充电时间 8
				index += len1;
				{
					Calendar data = (Calendar)ProtocolDataGenerator.getCalendar(index, dataAfterCmdSeq);
					startChargeTimeMap.put(i, data);
				}
				//结束充电时间 8
				index += len8;
				{
					Calendar data = (Calendar)ProtocolDataGenerator.getCalendar(index, dataAfterCmdSeq);
					stopChargeTimeMap.put(i, data);
				}
				//交易时间 8
				index += len8;
				{
					Calendar data = (Calendar)ProtocolDataGenerator.getCalendar(index, dataAfterCmdSeq);
					treadTimeMap.put(i, data);
				}
				//开始电表读数 4
				index += len8;
				{
					Double data = (Double)ProtocolDataGenerator.getOneData(dataAfterCmdSeq, 0, 4, DataAnalyseWayEnum.Int32);
					beforeAmmeterNumMap.put(i, Double.valueOf(df.format(data)));
				}
				//结束电表读数 4
				index += len4;
				{
					Double data = (Double)ProtocolDataGenerator.getOneData(dataAfterCmdSeq, 0, 4, DataAnalyseWayEnum.Int32);
					afterAmmeterNumMap.put(i, Double.valueOf(df.format(data)));
					index += 4;
				}
			}
			historyChargeRecord.setRecordSerialMap(recordSerialMap);
			historyChargeRecord.setLocationTypeMap(locationTypeMap);
			historyChargeRecord.setPileCodeMap(pileCodeMap);
			historyChargeRecord.setChargeNoMap(chargeNoMap);
			historyChargeRecord.setSerialNumMap(serialNumMap);
			historyChargeRecord.setOrderIndexNumMap(orderIndexNumMap);
			historyChargeRecord.setCarVINMap(carVINMap);
			historyChargeRecord.setCarLPNMap(carLPNMap);
			historyChargeRecord.setStartSOCMap(startSOCMap);
			historyChargeRecord.setEndSOCMap(endSOCMap);
			historyChargeRecord.setChargeQualityMap(chargeQualityMap);
			historyChargeRecord.setChargePowerMap(chargePowerMap);
			historyChargeRecord.setChargeTimeLenMap(chargeTimeLenMap);
			historyChargeRecord.setChargePolicyMap(chargePolicyMap);
			historyChargeRecord.setStopCauseMap(stopCauseMap);
			historyChargeRecord.setStartChargeTimeMap(startChargeTimeMap);
			historyChargeRecord.setStopChargeTimeMap(stopChargeTimeMap);
			historyChargeRecord.setTreadTimeMap(treadTimeMap);
			historyChargeRecord.setBeforeAmmeterNumMap(beforeAmmeterNumMap);
			historyChargeRecord.setAfterAmmeterNumMap(afterAmmeterNumMap);
		}
		return historyChargeRecord;
	}
}
