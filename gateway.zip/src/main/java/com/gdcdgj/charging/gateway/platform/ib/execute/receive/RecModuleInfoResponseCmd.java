package com.gdcdgj.charging.gateway.platform.ib.execute.receive;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.ModuleChargingInfo;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbProtocolUtil;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;
import com.gdcdgj.charging.gateway.util.DataType;
import com.gdcdgj.charging.gateway.util.ZoomFactor;


/**
 * 10.2.12	当前充电模块充电信息查询应答/上报(0x33)
 * 充电桩接收到查询“当前充电模块充电信息”报文后，以“充电模块充电信息查询应答“消息的格式，
 * 进行相关信息的应答上报。充电桩如果工作在上报模式情况下，
 * 通过本报文上报” 当前充电模块充电信息”
 *
 * @author ouxx
 * @since 2016-11-14 下午4:17:23
 */
public class RecModuleInfoResponseCmd implements BaseReceiveCmdExecute {


    @Override
    public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
        ModuleChargingInfo info = new ModuleChargingInfo();
        IbProtocolUtil.setMemberIdAndCmdSeqAndConnectorNo(info, fullData);
        return recModuleInfoResponse(fullData, info);
    }

    /**
     * 10.2.12	当前充电模块充电信息查询应答/上报(0x33)
     * 充电桩接收到查询“当前充电模块充电信息”报文后，以“充电模块充电信息查询应答“消息的格式，
     * 进行相关信息的应答上报。充电桩如果工作在上报模式情况下，
     * 通过本报文上报” 当前充电模块充电信息”
     *
     * @param fullData
     * @param info
     * @return
     * @throws Exception
     * @author ouxx
     * @date 2016-11-14 下午4:19:21
     */
    public static ModuleChargingInfo recModuleInfoResponse(byte[] fullData, ModuleChargingInfo info) throws Exception {
        byte[] dataAfterCmdSeq = IbProtocolUtil.getDataAfterConnectorNoInDataField(fullData);

        DecimalFormat df = new DecimalFormat("#0.00");

        //长度，字节数
        final int len1 = 1;
        final int len2 = 2;
        final int len4 = 4;

        //1字节
        final DataAnalyseWayEnum analyseWay1 = DataAnalyseWayEnum.Byte;
        //2字节
        final DataAnalyseWayEnum analyseWay2 = DataAnalyseWayEnum.UInt16;//.CharReverse;

        //充电机故障编码  4字节	每位表示一个故障
        final byte indexFault = 0;
        final byte lenFault = len4;
        {
            final DataAnalyzer analyzerFault = new DataAnalyzer();
            analyzerFault.setAnalyseWay(DataAnalyseWayEnum.UInt32);

            byte[] faultCodeBytes = IbProtocolUtil.getDataByIndexAndSize(dataAfterCmdSeq
                    , indexFault                    //数据起始位置
                    , lenFault);                        //数据字节数
            Double faultCode = (Double) DataAnalyzer.analyseAnalogData(analyzerFault, faultCodeBytes);
            info.setFaultCode(faultCode.longValue());
        }

        //充电枪数量
        final byte index0 = indexFault + lenFault;
        final byte len0 = len1;
        byte connectorCnt = ((Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index0, len0, analyseWay1)).byteValue();
        info.setConnectorCnt(connectorCnt);

        //充电枪位置N充电类型  1=直流；2=交流  Map<充电枪位置, 类型>
        Map<Byte, Byte> typeMap = new HashMap<Byte, Byte>();

        //位置N状态 0：充电位待机 1：充电中 2：充电结束 3：充电位故障
        //Map<充电枪位置, 状态>
        Map<Byte, Byte> stateMap = new HashMap<Byte, Byte>();

        //位置N本次累计充电kwh  Map<充电枪位置, kwh>
        Map<Byte, Double> kwhTotalMap = new HashMap<Byte, Double>();

        //位置N本次累计充电Ah  Map<充电枪位置, Ah>
        Map<Byte, Integer> ahMap = new HashMap<Byte, Integer>();

        //位置N本次累计充电时间  Map<充电枪位置, 时间>
        Map<Byte, Double> timeMap = new HashMap<Byte, Double>();

        //充电枪位置N起始充电SOC   Map<充电枪位置, soc>
        Map<Byte, Byte> socBeginMap = new HashMap<Byte, Byte>();

        //充电枪位置N当前SOC   Map<充电枪位置, soc>
        Map<Byte, Byte> socNowMap = new HashMap<Byte, Byte>();

        //位置N电表度数kwh  Map<充电枪位置, kwh>
        Map<Byte, Double> kwhMap = new HashMap<Byte, Double>();

        //位置N电压V  Map<充电枪位置, V>
        Map<Byte, Double> voltageMap = new HashMap<Byte, Double>();

        //位置N电流A  Map<充电枪位置, A>
        Map<Byte, Double> currentMap = new HashMap<Byte, Double>();

        //预估充满时间(分钟)  Map<充电枪位置, 分钟>
        Map<Byte, Double> remainTimeMap = new HashMap<Byte, Double>();

        //充电枪位置N连接状态   Map<充电枪位置, 连接状态>  0未连接，1已连接
        Map<Byte, Byte> connectedStateMap = new HashMap<Byte, Byte>();

        int firstStartIndexAfterCmdSeq = 1 + 4;// 1 : 充电枪数量占1字节， 4 ： 充电机故障编码占4字节
        int length = 21;//1个充电枪的数据总字节数
        for (byte i = 1; i <= connectorCnt; ++i) {

            //充电枪位置n充电类型  	1字节
            final int startIndex1 = firstStartIndexAfterCmdSeq + ((i - 1) * length);
            {
                final DataAnalyzer analyzer1 = new DataAnalyzer();
                analyzer1.setAnalyseWay(analyseWay1);
                analyzer1.setDataType(DataType.Integer);
                byte[] type = IbProtocolUtil.getDataByIndexAndSize(dataAfterCmdSeq
                        , startIndex1                    //数据起始位置
                        , len1);                        //数据字节数
                typeMap.put(i, ((Integer) DataAnalyzer.analyseAnalogData(analyzer1, type)).byteValue());
            }

            //充电枪位置n状态  	1字节
            final int startIndexState = startIndex1 + len1;
            {
                final DataAnalyzer analyzer1 = new DataAnalyzer();
                analyzer1.setAnalyseWay(analyseWay1);
                analyzer1.setDataType(DataType.Integer);
                byte[] state = IbProtocolUtil.getDataByIndexAndSize(dataAfterCmdSeq
                        , startIndexState                    //数据起始位置
                        , len1);                        //数据字节数
                stateMap.put(i, ((Integer) DataAnalyzer.analyseAnalogData(analyzer1, state)).byteValue());
            }

            //位置n本次累计充电kwh 	2字节
            final int startIndex2 = startIndexState + len1;
            {
                final DataAnalyzer analyzer2 = new DataAnalyzer();
                analyzer2.setAnalyseWay(analyseWay2);
                analyzer2.setZoomFactor(ZoomFactor.Kwh);
                byte[] kwhTotal = IbProtocolUtil.getDataByIndexAndSize(dataAfterCmdSeq
                        , startIndex2                    //数据起始位置
                        , len2);                        //数据字节数
                Double kwhTotalVal = (Double) DataAnalyzer.analyseAnalogData(analyzer2, kwhTotal);
                kwhTotalMap.put(i, Double.valueOf(df.format(kwhTotalVal)));
            }

            //位置n本次累计充电Ah 	2字节
            final int startIndex3 = startIndex2 + len2;
            {
                final DataAnalyzer analyzer3 = new DataAnalyzer();
                analyzer3.setAnalyseWay(analyseWay2);
                analyzer3.setZoomFactor(ZoomFactor.Quantity);
                byte[] ahTotal = IbProtocolUtil.getDataByIndexAndSize(dataAfterCmdSeq
                        , startIndex3                    //数据起始位置
                        , len2);                        //数据字节数
                ahMap.put(i, ((Double) DataAnalyzer.analyseAnalogData(analyzer3, ahTotal)).intValue());
            }
            //位置n本次累计充电时间 	2字节
            final int startIndex4 = startIndex3 + len2;
            {
                final DataAnalyzer analyzer4 = new DataAnalyzer();
                analyzer4.setAnalyseWay(analyseWay2);
                byte[] time = IbProtocolUtil.getDataByIndexAndSize(dataAfterCmdSeq
                        , startIndex4                    //数据起始位置
                        , len2);                        //数据字节数
                timeMap.put(i, ((Double) DataAnalyzer.analyseAnalogData(analyzer4, time)));
            }
            //位置n起始充电SOC  	1字节
            final int startIndex5 = startIndex4 + len2;
            {
                final DataAnalyzer analyzer5 = new DataAnalyzer();
                analyzer5.setAnalyseWay(analyseWay1);
                analyzer5.setZoomFactor(ZoomFactor.Soc);
                byte[] socBegin = IbProtocolUtil.getDataByIndexAndSize(dataAfterCmdSeq
                        , startIndex5                    //数据起始位置
                        , len1);                        //数据字节数
                socBeginMap.put(i, ((Double) DataAnalyzer.analyseAnalogData(analyzer5, socBegin)).byteValue());
            }
            //位置n当前SOC  		1字节
            final int startIndex6 = startIndex5 + len1;
            {
                final DataAnalyzer analyzer6 = new DataAnalyzer();
                analyzer6.setAnalyseWay(analyseWay1);
                analyzer6.setZoomFactor(ZoomFactor.Soc);
                byte[] socNow = IbProtocolUtil.getDataByIndexAndSize(dataAfterCmdSeq
                        , startIndex6                    //数据起始位置
                        , len1);                        //数据字节数
                socNowMap.put(i, ((Double) DataAnalyzer.analyseAnalogData(analyzer6, socNow)).byteValue());
            }
            //位置n电表度数kwh  	4字节
            final int startIndex7 = startIndex6 + len1;
            {
                final DataAnalyzer analyzer7 = new DataAnalyzer();
                analyzer7.setAnalyseWay(DataAnalyseWayEnum.UInt32);
                analyzer7.setZoomFactor(ZoomFactor.Kwh);

                byte[] kwh = IbProtocolUtil.getDataByIndexAndSize(dataAfterCmdSeq
                        , startIndex7                    //数据起始位置
                        , len4);                        //数据字节数
                Double kwhVal = (Double) DataAnalyzer.analyseAnalogData(analyzer7, kwh);
                kwhMap.put(i, Double.valueOf(df.format(kwhVal)));
            }
            //电压 2字节
            final int startIndex8 = startIndex7 + len4;
            {
                final DataAnalyzer analyzer8 = new DataAnalyzer();
                analyzer8.setAnalyseWay(analyseWay2);
                analyzer8.setZoomFactor(ZoomFactor.Voltage);

                byte[] voltageBytes = IbProtocolUtil.getDataByIndexAndSize(dataAfterCmdSeq
                        , startIndex8                    //数据起始位置
                        , len2);                        //数据字节数
                Double voltage = (Double) DataAnalyzer.analyseAnalogData(analyzer8, voltageBytes);
                voltageMap.put(i, Double.valueOf(df.format(voltage)));
            }
            //电流 2字节
            final int startIndex9 = startIndex8 + len2;
            {
                final DataAnalyzer analyzer9 = new DataAnalyzer();
                analyzer9.setAnalyseWay(analyseWay2);
                analyzer9.setZoomFactor(ZoomFactor.Current);

                byte[] currentBytes = IbProtocolUtil.getDataByIndexAndSize(dataAfterCmdSeq
                        , startIndex9                    //数据起始位置
                        , len2);                        //数据字节数
                Double current = (Double) DataAnalyzer.analyseAnalogData(analyzer9, currentBytes);
                currentMap.put(i, Double.valueOf(df.format(current)));
            }
            //预估充满时间 2字节
            final int startIndex10 = startIndex9 + len2;
            {
                final DataAnalyzer analyzer10 = new DataAnalyzer();
                analyzer10.setAnalyseWay(analyseWay2);

                byte[] remainTimeBytes = IbProtocolUtil.getDataByIndexAndSize(dataAfterCmdSeq
                        , startIndex10                    //数据起始位置
                        , len2);                        //数据字节数
                Double remainTime = (Double) DataAnalyzer.analyseAnalogData(analyzer10, remainTimeBytes);
                remainTimeMap.put(i, remainTime);
            }
            //枪连接状态 1字节
            final int startIndex11 = startIndex10 + len2;
            {
//				final DataAnalyzer analyzer11 = new DataAnalyzer();
//				analyzer11.setAnalyseWay(analyseWay1);
//
//				byte[] connectedStateBytes = ProtocolUtil.getDataByIndexAndSize(dataAfterCmdSeq
//						, startIndex11					//数据起始位置
//						, len1); 						//数据字节数
//				Double connectedState = (Double) DataAnalyzer.analyseAnalogData(analyzer11, connectedStateBytes);
//				connectedStateMap.put(i, connectedState.byteValue());
                connectedStateMap.put(i, dataAfterCmdSeq[startIndex11]);
            }


        }

        info.setStateMap(stateMap);
        info.setAhMap(ahMap);
        info.setKwhMap(kwhMap);
        info.setKwhTotalMap(kwhTotalMap);
        info.setSocBeginMap(socBeginMap);
        info.setSocNowMap(socNowMap);
        info.setTimeMap(timeMap);
        info.setTypeMap(typeMap);
        info.setVoltageMap(voltageMap);
        info.setCurrentMap(currentMap);
        info.setRemainTimeMap(remainTimeMap);
        info.setConnectedStateMap(connectedStateMap);

        return info;
    }
}
