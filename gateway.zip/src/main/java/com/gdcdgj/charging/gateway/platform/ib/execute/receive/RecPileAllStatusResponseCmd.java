/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.ib.execute.receive;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.StateInfo;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbProtocolUtil;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;
import com.gdcdgj.charging.gateway.util.Offset;
import com.gdcdgj.charging.gateway.util.ZoomFactor;

/**
 * 10.2.10	当前充电桩总体状态应答/上报(0x31)
 * @author ouxx
 * @since 2016-11-14 下午4:14:21
 *
 */
public class RecPileAllStatusResponseCmd implements BaseReceiveCmdExecute{

	@Override
	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
		StateInfo stateInfo = new StateInfo();
		IbProtocolUtil.setMemberIdAndCmdSeqAndConnectorNo(stateInfo, fullData);
		return recPileAllStatusResponse(fullData, stateInfo);
	}

	/**
	 * 10.2.10	当前充电桩总体状态应答/上报(0x31)
	 * @param fullData
	 * @param pileOverAllStatus
	 * @return
	 * @throws Exception
	 * @author ouxx
	 * @date 2016-11-14 下午4:16:09
	 */
	public static StateInfo recPileAllStatusResponse(byte[] fullData, StateInfo stateInfo) throws Exception{
		byte[] dataAfterCmdSeq = IbProtocolUtil.getDataAfterConnectorNoInDataField(fullData);

		//输入电源状态 1- 正常  2- 异常
		final int index0 = 0;
		final int len0 = 1;
		{
			Double inputPowerStatus = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index0, len0, DataAnalyseWayEnum.Byte);
			stateInfo.setInputPowerStatus(inputPowerStatus.byteValue());
		}

		//平均温度
		final int index1 = index0 + len0;
		final int len1 = 1;
		final DataAnalyzer analyzerTemperature = new DataAnalyzer();
		analyzerTemperature.setAnalyseWay(DataAnalyseWayEnum.Byte);
		analyzerTemperature.setOffset(Offset.Temperature);
		analyzerTemperature.setZoomFactor(ZoomFactor.Temperature);
		{
			final byte[] meanTempBytes = IbProtocolUtil.getDataByIndexAndSize(dataAfterCmdSeq, index1	, len1);
			final Double meanTemp = (Double) DataAnalyzer.analyseAnalogData(analyzerTemperature, meanTempBytes);
			stateInfo.setMeanTemp(meanTemp.byteValue());
		}

		//外部温度
		final int index2 = index1 + len1;
		final int len2 = 1;
		{
			final byte[] outsideTempBytes = IbProtocolUtil.getDataByIndexAndSize(dataAfterCmdSeq, index2	, len2);
			final Double outsideTemp = (Double) DataAnalyzer.analyseAnalogData(analyzerTemperature, outsideTempBytes);
			stateInfo.setOutsideTemp(outsideTemp.byteValue());
		}

		//工作状态
		//1=管理状态
		//2=服务状态
		//3=故障状态
		//9=初始化状态
		final int index3 = index2 + len2;
		final int len3 = 1;
		{
			Double workState = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index3, len3, DataAnalyseWayEnum.Byte);
			stateInfo.setWorkState(workState.byteValue());
		}

		//可充电模块数量
		final int index4 = index3 + len3;
		final int len4 = 1;
		{
			Double rechargeableCnt = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index4, len4, DataAnalyseWayEnum.Byte);
			stateInfo.setConnectorCount(rechargeableCnt.byteValue());
		}
		//输出有功功率
		final int index5 = index4 + len4;
		final int len5 = 2;
		final DataAnalyzer analyzerPower = new DataAnalyzer();
		analyzerPower.setAnalyseWay(DataAnalyseWayEnum.UInt16Reverse);
		analyzerPower.setZoomFactor(ZoomFactor.Power);
		{
			final byte[] outputActivePowerBytes = IbProtocolUtil.getDataByIndexAndSize(dataAfterCmdSeq, index5, len5);
			final Double outputActivePower = (Double) DataAnalyzer.analyseAnalogData(analyzerPower, outputActivePowerBytes);
			stateInfo.setOutputActivePower(outputActivePower.intValue());
		}

		//输出无功功率
		final int index6 = index5 + len5;
		final int len6 = 2;
		{
			final byte[] outputReactivePowerBytes = IbProtocolUtil.getDataByIndexAndSize(dataAfterCmdSeq, index6, len6);
			final Double outputReactivePower = (Double) DataAnalyzer.analyseAnalogData(analyzerPower, outputReactivePowerBytes);
			stateInfo.setOutputReactivePower(outputReactivePower.intValue());
		}

		//充电系统总体状态
		//bit0=0：正常；bit0=1：故障
		//bit1=0：门关闭；bit1=1：门开
		//bit2=0：桩位空闲；bit2=1：桩位占用
		//bit7~bit4=0000 独立工作
		//bit7~bit4=0001 并机工作
		final int index7 = index6 + len6;
		final int len7 = 1;
		{
			Double overallStatus = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index7, len7, DataAnalyseWayEnum.Byte);
			stateInfo.setOverallStatus(overallStatus.byteValue());
		}

		//充电系统故障状态
		final int index8 = index7 + len7;
		final int len8 = 4;
		{
			Double faultStatus = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index8, len8, DataAnalyseWayEnum.UInt32Reverse);
			stateInfo.setFaultStatus(faultStatus.intValue());
		}

		//AC/DC模块控制故障状态
		final int index9 = index8 + len8;
		final int len9 = 4;
		{
			Double acDcFaultStatus = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index9, len9, DataAnalyseWayEnum.UInt32Reverse);
			stateInfo.setAcDcFaultStatus(acDcFaultStatus.intValue());
		}

		//风扇总状态  2=运行/1=停止/3 故障
		final int index10 = index9 + len9;
		final int len10 = 1;
		{
			Double fanStatus = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index10, len10, DataAnalyseWayEnum.Byte);
			stateInfo.setFanStatus(fanStatus.byteValue());
		}

		//空调总状态  2=运行/1=停止/3 故障
		final int index11 = index10 + len10;
		final int len11 = 1;
		{
			Double airCondStatus = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index11, len11, DataAnalyseWayEnum.Byte);
			stateInfo.setAirCondStatus(airCondStatus.byteValue());
		}

		//加热器总状态  2=运行/1=停止/3 故障
		final int index12 = index11 + len11;
		final int len12 = 1;
		{
			Double heaterStatus = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index12, len12, DataAnalyseWayEnum.Byte);
			stateInfo.setHeaterStatus(heaterStatus.byteValue());
		}

		//烟雾报警总状态  1=异常/2=正常/3 故障
		final int index13 = index12 + len12;
		final int len13 = 1;
		{
			Double smokeAlarmStatus = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index13, len13, DataAnalyseWayEnum.Byte);
			stateInfo.setSmokeAlarmStatus(smokeAlarmStatus.byteValue());
		}

		//震动传感器报警总状态  1=异常/2=正常/3 故障
		final int index14 = index13 + len13;
		final int len14 = 1;
		{
			Double vibratAlarmStatus = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index14, len14, DataAnalyseWayEnum.Byte);
			stateInfo.setVibratAlarmStatus(vibratAlarmStatus.byteValue());
		}

		//充电枪数量
		final int index15 = index14 + len14;
		final int len15 = 1;
		{
			Double connectorCnt = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index15, len15, DataAnalyseWayEnum.Byte);
			stateInfo.setConnectorCount(connectorCnt.byteValue());
		}

		//地锁数量
		final int index16 = index15 + len15;
		final int len16 = 1;
		{
			Double lockCnt = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index16, len16, DataAnalyseWayEnum.Byte);
			stateInfo.setLockCnt(lockCnt.byteValue());
		}

		return stateInfo;
	}
}
