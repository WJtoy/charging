/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.ib.execute.receive;

import java.util.HashMap;
import java.util.Map;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.PileCtrl;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbProtocolUtil;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;

/**
 * 10.2.5	中心系统远程充电设备控制应答(0x15)
 * @author ouxx
 * @since 2016-11-14 下午4:07:56
 *
 */
public class RecPileCtrlResponseCmd implements BaseReceiveCmdExecute {

	@Override
	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
		PileCtrl pileCtrl = new PileCtrl();
		IbProtocolUtil.setMemberIdAndCmdSeqAndConnectorNo(pileCtrl, fullData);
		return recPileCtrlResponse(fullData, pileCtrl);
	}


	/**
	 * 10.2.5	中心系统远程充电设备控制应答(0x65)
	 * @param fullData
	 * @param pileCtrl
	 * @return
	 * @throws Exception
	 * @author ouxx
	 * @date 2016-11-14 下午4:09:57
	 */
	public static PileCtrl recPileCtrlResponse(byte[] fullData, PileCtrl pileCtrl) throws Exception{
		byte[] dataAfterCmdSeq = IbProtocolUtil.getDataAfterConnectorNoInDataField(fullData);

		//参数类型
		final int index0 = 0;
		final int len0 = 1;
		pileCtrl.setParamType(((Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index0, len0, DataAnalyseWayEnum.Byte)).byteValue());

		//参数个数
		final int index1 = index0 + len0;
		final int len1 = 1;
		Byte count = ((Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index1, len1, DataAnalyseWayEnum.Byte)).byteValue();
		count = (null != count) ? count.byteValue() : 0;
		pileCtrl.setConnectorCount(count);

		//充电模块位置编号、充电模块控制参数
		//充电模块位置编号   Map<充电模块位置, 编号>
		Map<Byte, Byte> connectorNoMap = new HashMap<Byte, Byte>();
		//充电模块 控制参数值  Map<充电模块位置, 控制参数值>
		Map<Byte, Integer> valueMap = new HashMap<Byte, Integer>();

		final int lenNo = 1;
		final int lenVal = 2;
		final int offset = 2;///充电模块位置编号在指令序号后2个字节
		for(byte i = 0; i < count; ++i){
			//充电模块位置编号 索引
			int indexNo = offset + (lenNo + lenVal) * i;
			connectorNoMap.put((byte)(i + 1),
					((Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexNo, lenNo, DataAnalyseWayEnum.Byte)).byteValue());

			//充电模块 控制参数 索引
			int indexVal = indexNo + lenNo;
			valueMap.put((byte)(i + 1),
					((Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexVal, lenVal, DataAnalyseWayEnum.Int16)).intValue());
		}
		pileCtrl.setConnectorNoMap(connectorNoMap);
		pileCtrl.setValueMap(valueMap);

		return pileCtrl;
	}
}
