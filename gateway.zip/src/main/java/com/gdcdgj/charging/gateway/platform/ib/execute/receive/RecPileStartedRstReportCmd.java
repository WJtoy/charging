/*
 *
 */
package com.gdcdgj.charging.gateway.platform.ib.execute.receive;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.PileStartedRst;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbProtocolUtil;
import com.gdcdgj.charging.gateway.platform.ib.protocol.indexAndLen.T2H_PileStartedRstIndexAndLen;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;

/**
 * 充电桩启动成功后，向平台上报的命令0X06
 * @author ouxx
 * @since 2017-3-1 下午8:09:07
 *
 */
public class RecPileStartedRstReportCmd implements BaseReceiveCmdExecute {

	/* (non-Javadoc)
	 * @see com.gdcdgj.service.provider.piles.echarging.cmd.BaseRecCmd#recExecute(byte[])
	 */
	@Override
	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
		PileStartedRst startedRst = new PileStartedRst();
		IbProtocolUtil.setMemberIdAndCmdSeqAndConnectorNo(startedRst, fullData);
		return recPileStartedRstReport(fullData, startedRst);
	}

	public static PileStartedRst recPileStartedRstReport(byte[] fullData, PileStartedRst startedRst) throws Exception{
		byte[] dataAfterCmdSeq = IbProtocolUtil.getDataAfterConnectorNoInDataField(fullData);
		//用户名
		startedRst.setCustomName((String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
				T2H_PileStartedRstIndexAndLen.CUSTOM_NAME.getIndex(), T2H_PileStartedRstIndexAndLen.CUSTOM_NAME.getLen(), DataAnalyseWayEnum.StrASCII));
		//网点名
		startedRst.setParkName((String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
				T2H_PileStartedRstIndexAndLen.PARK_NAME.getIndex(), T2H_PileStartedRstIndexAndLen.PARK_NAME.getLen(), DataAnalyseWayEnum.StrASCII));
		//启动结果 1字节
		startedRst.setResult((int) dataAfterCmdSeq[T2H_PileStartedRstIndexAndLen.RESULT.getIndex()]);

		return startedRst;
	}

}
