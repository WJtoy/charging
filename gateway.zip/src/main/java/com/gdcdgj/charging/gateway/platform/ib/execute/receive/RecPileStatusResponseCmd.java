/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.ib.execute.receive;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.StateInfo;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbProtocolUtil;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;

/**
 * 10.2.3	充电桩状态上报(0x11)
 * 充电桩故障上报报文是用于传送充电桩工作故障状态的数据消息格式。
 * 充电桩在工作状态发生切换的时候，上传系统实时工作状态到智能加电运营管理系统。系统有四种工作状态：
 * 1) 初始化状态
 * 2) 管理状态；
 * 3) 服务状态；
 * 4) 故障状态
 * @author ouxx
 * @since 2016-11-14 下午4:02:17
 */
public class RecPileStatusResponseCmd implements BaseReceiveCmdExecute {

	@Override
	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
		StateInfo stateInfo = new StateInfo();
		IbProtocolUtil.setMemberIdAndCmdSeqAndConnectorNo(stateInfo, fullData);
		return recPileStatusResponse(fullData, stateInfo);
	}

	/**
	 * 10.2.3	充电桩状态上报(0x11)
	 * 充电桩故障上报报文是用于传送充电桩工作故障状态的数据消息格式。
	 * 充电桩在工作状态发生切换的时候，上传系统实时工作状态到智能加电运营管理系统。系统有四种工作状态：
	 * 1) 初始化状态
	 * 2) 管理状态；
	 * 3) 服务状态；
	 * 4) 故障状态
	 * @param fullData
	 * @param pileStatus
	 * @return
	 * @throws Exception
	 * @author ouxx
	 * @date 2016-11-14 下午4:04:52
	 */
	public static StateInfo recPileStatusResponse(byte[] fullData, StateInfo pileStatus) throws Exception{
		byte[] dataAfterCmdSeq = IbProtocolUtil.getDataAfterConnectorNoInDataField(fullData);

		//充电桩编码
		final int index0 = 0;
		final int len0 = 8;
		pileStatus.setPileCode((String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
				index0, len0, DataAnalyseWayEnum.StrASCII));

		//工作状态
		final int index1 = index0 + len0;
		final int len1 = 1;
		if(dataAfterCmdSeq.length > index1 + len1){
			pileStatus.setWorkState((Byte) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
					index1, len1, DataAnalyseWayEnum.Byte));
		}

		//系统故障状态
		final int index2 = index1 + len1;
		final int len2 = 1;
		if(dataAfterCmdSeq.length == index2 + len2){
			pileStatus.setAlarmCode((Integer) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
					index2, len2, DataAnalyseWayEnum.UInt32Reverse));
		}

		return pileStatus;
	}
}
