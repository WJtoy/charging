/*
 *
 */
package com.gdcdgj.charging.gateway.platform.ib.execute.receive;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.RemoteUpgrade;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbProtocolUtil;

/**
 * @author ouxx
 * @since 2017-3-21 下午4:58:03
 *
 */
public class RecRemoteUpgradeCmd implements BaseReceiveCmdExecute{

	@Override
	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
		RemoteUpgrade remoteUpgrade = new RemoteUpgrade();
		IbProtocolUtil.setMemberIdAndCmdSeqAndConnectorNo(remoteUpgrade, fullData);
		final byte[] dataAfterCmdSeq = IbProtocolUtil.getDataAfterConnectorNoInDataField(fullData);
		//升级结果
		remoteUpgrade.setResult(dataAfterCmdSeq[0]);
		return remoteUpgrade;
	}

}
