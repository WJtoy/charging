package com.gdcdgj.charging.gateway.platform.ib.execute.receive;

import java.util.Calendar;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.SignIn;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbProtocolUtil;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;

/**
 * @author Changliang Tao
 * @date 2020/5/6 17:23
 * @since JDK 1.8
 */
public class RecSignInCmdExecute implements BaseReceiveCmdExecute {
    /**
     * 接收报文数据的执行方法
     *
     * @param fullData
     * @return
     * @throws Exception
     * @author ouxx
     * @date 2016-11-14 下午5:09:35
     */
    public DataBaseVo signInHandle(byte[] fullData,SignIn signIn) throws Exception {
    	byte[] dataAfterCmdSeq = IbProtocolUtil.getDataAfterConnectorNoInDataField(fullData);
    	
		//充电桩编码
		final int index0 = 0;
		final int len0 = 8;
		String pileCode = (String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
				index0, len0, DataAnalyseWayEnum.StrASCII);
		signIn.setPileCode(pileCode);

		//设备资产编码
		final int index1 = index0 + len0;
		final int len1 = 20;
		String assetCode = (String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
				index1, len1, DataAnalyseWayEnum.StrASCII);
		signIn.setAssetCode(assetCode);

		//系统软件版本
		final int index2 = index1 + len1;
		final int len2 = 4;
		Double version = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
				index2, len2, DataAnalyseWayEnum.UInt32Reverse);
		signIn.setVersion(version);
		//存版本号字符串(因为传来的是大端模式，所以要颠倒顺序)
		StringBuffer versionStr = new StringBuffer("");
//		for(int i = index2 + len2 - 1; i >= index2 ; --i){
		for(int i = index2; i < index2  + len2; ++i){
			versionStr.append(dataAfterCmdSeq[i] + ".");
		}
		signIn.setVersionStr(versionStr.substring(0, versionStr.length() - 1));

		//启动次数
		final int index3 = index2 + len2;
		final int len3 = 4;
		Double bootTimes = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
				index3, len3, DataAnalyseWayEnum.UInt32Reverse);
		signIn.setBootTimes(bootTimes.longValue());

		//存储空间容量  按照M 为单位（可选）
		final int index4 = index3 + len3;
		final int len4 = 4;
		Double capacity = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
				index4, len4, DataAnalyseWayEnum.UInt32Reverse);
		signIn.setCapacity(capacity.longValue());

		//软件持续运行时间  按照分钟为单位（可选）
		final int index5 = index4 + len4;
		final int len5 = 4;
		Double continuousRunPeriod = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
				index5, len5, DataAnalyseWayEnum.UInt32Reverse);
		signIn.setContinuousRunPeriod(continuousRunPeriod.longValue());

		//最近一次启动时间
		final int index6 = index5 + len5;
		final int len6 = 8;
		Calendar lastBootTime = ProtocolDataGenerator.getCalendar(index6, dataAfterCmdSeq);
		signIn.setLastBootTime(lastBootTime);
		signIn.setStartStopSingal((byte) 1);
		//最近一次签到时间
		final int index7 = index6 + len6;
		Calendar lastSignInTime = ProtocolDataGenerator.getCalendar(index7, dataAfterCmdSeq);
		signIn.setLastSignInTime(lastSignInTime);
		
		return signIn;
    }

	@Override
	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
		SignIn signIn = new SignIn();
		IbProtocolUtil.setMemberIdAndCmdSeqAndConnectorNo(signIn, fullData);
		return signInHandle(fullData,signIn);
	}
}