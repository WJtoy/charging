/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.ib.execute.receive;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.ValidAuthen;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbProtocolUtil;
import com.gdcdgj.charging.gateway.platform.ib.protocol.indexAndLen.T2H_ValidAuthenIndexAndLen;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;

/**
 * @author ouxx
 * @since 2017-1-16 下午6:18:48
 *
 */
public class RecValidAuthenCmd implements BaseReceiveCmdExecute {

	@Override
	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
		ValidAuthen authen = new ValidAuthen();
		IbProtocolUtil.setMemberIdAndCmdSeqAndConnectorNo(authen, fullData);
		return recAuthen(fullData, authen);
	}

	/**
	 * 充电桩应答中心合法用户认证通过信息(0x7a)
	 * @param fullData
	 * @param authen
	 * @return
	 * @throws Exception
	 * @author ouxx
	 * @date 2016-11-14 下午4:46:59
	 */
	public static ValidAuthen recAuthen(byte[] fullData, ValidAuthen authen) throws Exception{
		byte[] dataAfterCmdSeq = IbProtocolUtil.getDataAfterConnectorNoInDataField(fullData);

		//设置结果
		authen.setResult(((Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
				T2H_ValidAuthenIndexAndLen.RESULT.getIndex(),
				T2H_ValidAuthenIndexAndLen.RESULT.getLen(), DataAnalyseWayEnum.UInt32)).intValue());
		return authen;
	}
}
