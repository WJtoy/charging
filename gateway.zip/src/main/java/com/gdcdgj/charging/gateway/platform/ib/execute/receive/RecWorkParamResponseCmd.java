/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.ib.execute.receive;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.WorkParam;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbProtocolUtil;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;

/**
 * 工作参数
 * @author ouxx
 * @since 2016-11-14 下午2:44:35
 *
 */
public class RecWorkParamResponseCmd implements BaseReceiveCmdExecute {

	@Override
	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception{
		WorkParam workParam = new WorkParam();
		IbProtocolUtil.setMemberIdAndCmdSeqAndConnectorNo(workParam, fullData);
		workParam.setSettingRst(recWorkParam(fullData));
		return workParam;
	}

	/**
	 * 10.1.4	充电桩工作参数应答(0x56)
	 * <p>设置成功就返回0，否则非0</p>
	 * @param fullData
	 * @return
	 * @throws Exception
	 * @author ouxx
	 * @date 2016-11-3 上午11:36:44
	 */
	public static int recWorkParam(byte[] fullData) throws Exception{
		byte[] dataAfterCmdSeq = IbProtocolUtil.getDataAfterConnectorNoInDataField(fullData);
		Double rst = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, 0, 4,  DataAnalyseWayEnum.Int32);
		return rst.intValue();
	}
}
