/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.ib.execute.send;

import java.util.Calendar;

import com.gdcdgj.charging.api.vo.srv2gw.AccountInfo;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbCmdEnum;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.platform.ib.protocol.indexAndLen.H2T_AccountQueryResponseIndexAndLen;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;

/**
 * 10.3.5 中心系统应答账户查询(0x60)
 * <p>充电桩根据读到的卡信息，向后台进行账户查询，后台根据具体内容进行审核，并将结果通过本命令返回。
 *
 * @author ouxx
 * @since 2016-11-15 上午9:42:56
 *
 */
public class SendAccountQueryResponseCmd implements BaseSendCmdExecute{

	public byte[] generateSendDatas(DataBaseVo vo) {
		AccountInfo accountQuery = (AccountInfo) vo;
		byte[] datas = new byte[163];
		{
			// 卡号
			byte[] cardNum = DataAnalyzer.analyseCommandData(accountQuery.getCardNum(),
					DataAnalyseWayEnum.StrASCII
//					, H2T_AccountQueryResponseIndexAndLen.CARDNUM.getLen()
					);
			System.arraycopy(cardNum, 0, datas, H2T_AccountQueryResponseIndexAndLen.CARDNUM.getIndex(),
//					H2T_AccountQueryResponseIndexAndLen.CARDNUM.getLen()
					cardNum.length);
		}
		{
			// 客户姓名
			byte[] customName = DataAnalyzer.analyseCommandData(accountQuery.getCustomName(),
					DataAnalyseWayEnum.StrASCII
//					, H2T_AccountQueryResponseIndexAndLen.CUSTOM_NAME.getLen()
					);
			System.arraycopy(customName, 0, datas, H2T_AccountQueryResponseIndexAndLen.CUSTOM_NAME.getIndex(),
//					H2T_AccountQueryResponseIndexAndLen.CUSTOM_NAME.getLen()
					customName.length);
		}
		{
			// 响应码
			byte[] respCode = DataAnalyzer.analyseCommandData(accountQuery.getRespCode(),
					DataAnalyseWayEnum.StrASCII
//					, H2T_AccountQueryResponseIndexAndLen.RESP_CODE.getLen()
					);
			System.arraycopy(respCode, 0, datas, H2T_AccountQueryResponseIndexAndLen.RESP_CODE.getIndex(),
//					H2T_AccountQueryResponseIndexAndLen.RESP_CODE.getLen()
					respCode.length);
		}
		{
			// 响应码描述
			byte[] respDesc = DataAnalyzer.analyseCommandData(accountQuery.getRespDesc(),
					DataAnalyseWayEnum.StrASCII
//					, H2T_AccountQueryResponseIndexAndLen.RESP_DESC.getLen()
					);
			System.arraycopy(respDesc, 0, datas, H2T_AccountQueryResponseIndexAndLen.RESP_DESC.getIndex(),
//					H2T_AccountQueryResponseIndexAndLen.RESP_DESC.getLen()
					respDesc.length);

		}
		{
			// 客户号
			byte[] customNum = DataAnalyzer.analyseCommandData(accountQuery.getCustomNum(),
					DataAnalyseWayEnum.StrASCII
//					, H2T_AccountQueryResponseIndexAndLen.CUSTOM_NUM.getLen()
					);
			System.arraycopy(customNum, 0, datas, H2T_AccountQueryResponseIndexAndLen.CUSTOM_NUM.getIndex(),
//					H2T_AccountQueryResponseIndexAndLen.CUSTOM_NUM.getLen()
					customNum.length);

		}
		{
			// 电费主账户余额
			byte[] chargeAllBalance = DataAnalyzer.analyseCommandData(accountQuery.getChargeAllBalance(),
					DataAnalyseWayEnum.DoubleReverse
//					, H2T_AccountQueryResponseIndexAndLen.CHARGE_ALL_BALANCE.getLen()
					);
			System.arraycopy(chargeAllBalance, 0, datas,
					H2T_AccountQueryResponseIndexAndLen.CHARGE_ALL_BALANCE.getIndex(),
//					H2T_AccountQueryResponseIndexAndLen.CHARGE_ALL_BALANCE.getLen()
					chargeAllBalance.length);

		}
		{
			// 电费主账户可用余额
			byte[] chargeBalance = DataAnalyzer.analyseCommandData(accountQuery.getChargeAllBalance(),
					DataAnalyseWayEnum.DoubleReverse
//					, H2T_AccountQueryResponseIndexAndLen.CHARGE_BALANCE.getLen()
					);
			System.arraycopy(chargeBalance, 0, datas, H2T_AccountQueryResponseIndexAndLen.CHARGE_BALANCE.getIndex(),
//					H2T_AccountQueryResponseIndexAndLen.CHARGE_BALANCE.getLen()
					chargeBalance.length);

		}
		{
			// 服务费账户余额
			byte[] serviceAllBalance = DataAnalyzer.analyseCommandData(accountQuery.getServiceAllBalance(),
					DataAnalyseWayEnum.DoubleReverse
//					, H2T_AccountQueryResponseIndexAndLen.SERVICE_ALL_BALANCE.getLen()
					);
			System.arraycopy(serviceAllBalance, 0, datas,
					H2T_AccountQueryResponseIndexAndLen.SERVICE_ALL_BALANCE.getIndex(),
//					H2T_AccountQueryResponseIndexAndLen.SERVICE_ALL_BALANCE.getLen()
					serviceAllBalance.length);

		}
		{
			// 服务费账户可用余额
			byte[] serviceBalance = DataAnalyzer.analyseCommandData(accountQuery.getServiceBalance(),
					DataAnalyseWayEnum.DoubleReverse
//					, H2T_AccountQueryResponseIndexAndLen.SERVICE_BALANCE.getLen()
					);
			System.arraycopy(serviceBalance, 0, datas, H2T_AccountQueryResponseIndexAndLen.SERVICE_BALANCE.getIndex(),
//					H2T_AccountQueryResponseIndexAndLen.SERVICE_BALANCE.getLen()
					serviceBalance.length);

		}
		{
			// 中心交易流水
			byte[] tradeSeq = DataAnalyzer.analyseCommandData(accountQuery.getTradeSeq(),
					DataAnalyseWayEnum.StrASCII
//					, H2T_AccountQueryResponseIndexAndLen.TRADE_SEQ.getLen()
					);
			System.arraycopy(tradeSeq, 0, datas, H2T_AccountQueryResponseIndexAndLen.TRADE_SEQ.getIndex(),
//					H2T_AccountQueryResponseIndexAndLen.TRADE_SEQ.getLen()
					tradeSeq.length);

		}
		{
			// 出单机构流水号
			byte[] operSeq = DataAnalyzer.analyseCommandData(accountQuery.getOperSeq(),
					DataAnalyseWayEnum.StrASCII
//					, H2T_AccountQueryResponseIndexAndLen.OPER_SEQ.getLen()
					);
			System.arraycopy(operSeq, 0, datas, H2T_AccountQueryResponseIndexAndLen.OPER_SEQ.getIndex(),
//					H2T_AccountQueryResponseIndexAndLen.OPER_SEQ.getLen()
					operSeq.length);
		}
		{
			// 本次允许充电电量
			byte[] permitKwh = DataAnalyzer.analyseCommandData(accountQuery.getPermitKwh(),
					DataAnalyseWayEnum.UInt32Reverse
//					, H2T_AccountQueryResponseIndexAndLen.PERMIT_KWH.getLen()
					);
			System.arraycopy(permitKwh, 0, datas, H2T_AccountQueryResponseIndexAndLen.PERMIT_KWH.getIndex(),
//					H2T_AccountQueryResponseIndexAndLen.PERMIT_KWH.getLen()
					permitKwh.length);
		}
		{
			// 本次允许充电时间
			byte[] permitTime = DataAnalyzer.analyseCommandData(accountQuery.getPermitTime(),
					DataAnalyseWayEnum.UInt32Reverse
//					, H2T_AccountQueryResponseIndexAndLen.PERMIT_TIME.getLen()
					);
			System.arraycopy(permitTime, 0, datas, H2T_AccountQueryResponseIndexAndLen.PERMIT_TIME.getIndex(),
//					H2T_AccountQueryResponseIndexAndLen.PERMIT_TIME.getLen()
					permitTime.length);
		}
		{
			// 交易日期时间
			Calendar cal = accountQuery.getTradeDate();
			System.arraycopy(ProtocolDataGenerator.calendar2ByteArray(cal), 0, datas,
					H2T_AccountQueryResponseIndexAndLen.TRADE_DATE.getIndex(),
					H2T_AccountQueryResponseIndexAndLen.TRADE_DATE.getLen());
		}
		{
			// 报文认证码
			byte[] authCode = DataAnalyzer.analyseCommandData(accountQuery.getAuthCode(),
					DataAnalyseWayEnum.StrASCII
//					, H2T_AccountQueryResponseIndexAndLen.AUTH_CODE.getLen()
					);
			System.arraycopy(authCode, 0, datas, H2T_AccountQueryResponseIndexAndLen.AUTH_CODE.getIndex(),
//					H2T_AccountQueryResponseIndexAndLen.AUTH_CODE.getLen()
					authCode.length);
		}

		return ProtocolDataGenerator.sendOneData(vo.getConnectorNo(), vo.getMemberId(), vo.getCmdSeq(), datas, IbCmdEnum.ACCOUNT_QUERY_RESP);

	}

	@Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		return generateSendDatas(dataVo);
	}

}
