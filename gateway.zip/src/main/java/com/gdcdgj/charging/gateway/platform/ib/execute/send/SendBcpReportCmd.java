/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.ib.execute.send;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbCmdEnum;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;

import lombok.extern.slf4j.Slf4j;

/**
 * 应答充电桩上报bcp报文(0x13)
 * @author ouxx
 * @since 2016-11-15 上午9:08:18
 *
 */
@Slf4j
public class SendBcpReportCmd implements BaseSendCmdExecute {

	/**
	 * 应答充电桩上报bcp报文(0x13)
	 */
	public byte[] generateSendDatas(DataBaseVo vo) {
		//命令无需额外数据
		log.info("应答充电桩上报bcp报文(0x13)");
		return ProtocolDataGenerator.sendOneData(vo.getConnectorNo(), vo.getMemberId(), vo.getCmdSeq(), null, IbCmdEnum.BCP_RESP);
	}
	@Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		return generateSendDatas(dataVo);
	}

}
