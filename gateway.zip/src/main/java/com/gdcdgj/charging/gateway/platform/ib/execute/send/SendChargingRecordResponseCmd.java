/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.ib.execute.send;

import java.util.Calendar;

import com.gdcdgj.charging.api.vo.srv2gw.ChargeRecordInfo;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbCmdEnum;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.platform.ib.protocol.indexAndLen.H2T_ChargingRecordResponseIndexAndLen;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;

/**
 * 10.3.4	中心系统应答充电记录上报(0x63)
 * 充电桩在一次充电结束后，将本次充电的信息上报后台，
 * 后台根据具体内容进行审核和费用计算，并将结果通过“中心系统应答上报充电记录应答”返回
 * @author ouxx
 * @since 2016-11-15 上午9:39:34
 *
 */
public class SendChargingRecordResponseCmd implements BaseSendCmdExecute {

	public byte[] generateSendDatas(DataBaseVo vo) {
		ChargeRecordInfo chargingRecord = (ChargeRecordInfo) vo;
		byte[] datas = new byte[138];
		{
			// 充电枪位置类型
			byte[] type = DataAnalyzer.analyseCommandData((byte)chargingRecord.getLocationType(), DataAnalyseWayEnum.Byte);
			System.arraycopy(type, 0, datas, H2T_ChargingRecordResponseIndexAndLen.TYPE.getIndex(), type.length);
		}
		{
			// 卡号 16字节
			byte[] cardNum = DataAnalyzer.analyseCommandData(chargingRecord.getChargeNo(), DataAnalyseWayEnum.StrASCII);
			System.arraycopy(cardNum, 0, datas, H2T_ChargingRecordResponseIndexAndLen.CARDNUM.getIndex(), cardNum.length);
		}

		// 客户号 30字节
		{	// TODO
			byte[] customNum = new byte[H2T_ChargingRecordResponseIndexAndLen.CUSTOM_NUM.getLen()];
//					DataAnalyzer.analyseCommandData(chargingRecord.getCustomerNum(),
//					DataAnalyseWayEnum.StrASCII);
			System.arraycopy(customNum, 0, datas,
					H2T_ChargingRecordResponseIndexAndLen.CUSTOM_NUM.getIndex(),
					customNum.length);
		}

		{
			// 本次充电结算时间和电量
			// 格式：充电时间;电量;结束SOC
			// “；”隔离
			// ①充电时间
			// 单位:分钟
			// ②电量
			// 单位：度
			// ③电量
			// 单位：%
			// 示例：10 分钟1.2 度结束SOC56%
			// 协议格式10;1.2;56
			String timeAndQuantityAndSocStr = chargingRecord.getChargeTimeLen() + ";" + chargingRecord.getCurrentChargeCount() + ";"
					+ chargingRecord.getStopSOC();
			byte[] timeAndQuantityAndSoc = DataAnalyzer.analyseCommandData(timeAndQuantityAndSocStr,
					DataAnalyseWayEnum.StrASCII);
			System.arraycopy(timeAndQuantityAndSoc, 0, datas,
					H2T_ChargingRecordResponseIndexAndLen.TIME_QUANTITY_SOC.getIndex(),
					timeAndQuantityAndSoc.length);
		}
		{
			// 本次充电结算电费 TODO
			byte[] chargingFee = new byte[H2T_ChargingRecordResponseIndexAndLen.CHARGING_FEE.getLen()];
//					DataAnalyzer.analyseCommandData(chargingRecord.getChargingFee(),
//					DataAnalyseWayEnum.DoubleReverse);
			System.arraycopy(chargingFee, 0, datas, H2T_ChargingRecordResponseIndexAndLen.CHARGING_FEE.getIndex(),
					chargingFee.length);
		}
		{
			// 本次充电结算电费 TODO
			byte[] serviceFee = new byte[H2T_ChargingRecordResponseIndexAndLen.SERVICE_FEE.getLen()];
//					DataAnalyzer.analyseCommandData(chargingRecord.getServiceFee(),
//					DataAnalyseWayEnum.DoubleReverse);
			System.arraycopy(serviceFee, 0, datas, H2T_ChargingRecordResponseIndexAndLen.SERVICE_FEE.getIndex(),
					serviceFee.length);
		}
		{
			// 本次累计消费总金额 TODO
			byte[] totalFee = new byte[H2T_ChargingRecordResponseIndexAndLen.TOTAL_FEE.getLen()];
//					DataAnalyzer.analyseCommandData(chargingRecord.getTotalFee(),
//					DataAnalyseWayEnum.DoubleReverse);
			System.arraycopy(totalFee, 0, datas, H2T_ChargingRecordResponseIndexAndLen.TOTAL_FEE.getIndex(),
					totalFee.length);
		}
		{
			// 中心交易流水
			byte[] tradeSeq = DataAnalyzer.analyseCommandData(chargingRecord.getSerialNum(),
					DataAnalyseWayEnum.StrASCII);
			System.arraycopy(tradeSeq, 0, datas, H2T_ChargingRecordResponseIndexAndLen.TRADE_SEQ.getIndex(),
					tradeSeq.length);
		}
		{
			// 出单机构流水号 TODO
			byte[] operSeq = new byte[H2T_ChargingRecordResponseIndexAndLen.OPER_SEQ.getLen()];
//					DataAnalyzer.analyseCommandData(chargingRecord.getOperSeq(),
//					DataAnalyseWayEnum.StrASCII);
			System.arraycopy(operSeq, 0, datas, H2T_ChargingRecordResponseIndexAndLen.OPER_SEQ.getIndex(),
					operSeq.length);
		}
		{
			// 交易日期时间
			Calendar cal = chargingRecord.getTradeDate();
			System.arraycopy(ProtocolDataGenerator.calendar2ByteArray(cal), 0, datas, H2T_ChargingRecordResponseIndexAndLen.TRADE_DATE.getIndex(),
					H2T_ChargingRecordResponseIndexAndLen.TRADE_DATE.getLen());
		}

		return ProtocolDataGenerator.sendOneData(vo.getConnectorNo(), vo.getMemberId(), vo.getCmdSeq(), datas, IbCmdEnum.CHARGING_RECORD_RESP);

	}

	@Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		return generateSendDatas(dataVo);
	}

}
