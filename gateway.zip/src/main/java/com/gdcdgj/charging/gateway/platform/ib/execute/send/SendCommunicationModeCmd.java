package com.gdcdgj.charging.gateway.platform.ib.execute.send;

import javax.websocket.SendHandler;

import com.gdcdgj.charging.api.vo.srv2gw.CommunicationMode;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbCmdEnum;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;

/**
 * 10.2.7 通讯模式设置命令(0x47)
 * <p>
 * 设置充电桩的通信模式，充电桩接收该命令后， 将当前工作模式按照命令要求进行切换，并且做出应答，将当前实际的通信模式回复确认
 *
 * @author ouxx
 * @since 2016-11-15 上午9:21:45
 *
 */
public class SendCommunicationModeCmd implements BaseSendCmdExecute {

	public byte[] generateSendDatas(int connectorNo, int memberId, int cmdSeq, DataBaseVo vo) {
		CommunicationMode communicationMode = (CommunicationMode) vo;
		// 通讯模式、定时上报间隔 都1个字节
		DataAnalyseWayEnum analyseWay = DataAnalyseWayEnum.Byte;

		byte[] datas = new byte[] { 0, 0 };
		// 通讯模式
		final int index0 = 0;
		final int len0 = 1;
		// 通讯模式 0x01:应答 0x02:上报
		Byte mode = communicationMode.getMode();
		byte[] modeBytes = DataAnalyzer.analyseCommandData(mode, analyseWay);
		System.arraycopy(modeBytes, 0, datas, index0, len0);

		// 定时上报间隔，上报模式，定时上报的间隔单位：秒； 缺省：15秒
		final int index1 = index0 + len0;
		final int len1 = 1;
		byte[] reportIntervalBytes = new byte[] { 15 };
//		if (null != mode && 2 == mode) {
//			Byte reportInterval = communicationMode.getReportInterval();
//			reportIntervalBytes = DataAnalyzer.analyseCommandData(reportInterval, analyseWay);
//		}
		System.arraycopy(reportIntervalBytes, 0, datas, index1, len1);

		return ProtocolDataGenerator.sendOneData(connectorNo, memberId, cmdSeq, datas, IbCmdEnum.COMMUN_MODE_SET);
	}

	@Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		return generateSendDatas(dataVo.getConnectorNo(), dataVo.getMemberId(), dataVo.getCmdSeq(), dataVo);
	}

}
