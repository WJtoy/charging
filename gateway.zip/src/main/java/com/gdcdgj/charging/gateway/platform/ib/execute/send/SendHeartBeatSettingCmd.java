package com.gdcdgj.charging.gateway.platform.ib.execute.send;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.HeartBeatSetting;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbCmdEnum;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;

/**
 * 10.1.7	系统心跳包信息设置(0x49)
 * @author ouxx
 * @since 2016-11-15 上午9:03:18
 *
 */
public class SendHeartBeatSettingCmd implements BaseSendCmdExecute{

	/**
	 * 10.1.7	系统心跳包信息设置(0x49)
	 */
	public byte[] generateSendDatas(DataBaseVo vo) {
		HeartBeatSetting heartBeatSetting = (HeartBeatSetting) vo;
		byte[] datas = new byte[2];

		//心跳上报周期
		final int index0 = 0;
		final int len0 = 1;
		byte[] period = DataAnalyzer.analyseCommandData(heartBeatSetting.getPeriod(), DataAnalyseWayEnum.Byte);
		System.arraycopy(period, 0, datas, index0, len0);

		//心跳包检测超时次数
		final int index1 = index0 + len0;
		final int len1 = 1;
		byte[] timeOutCnt = DataAnalyzer.analyseCommandData(heartBeatSetting.getTimeOutCnt(), DataAnalyseWayEnum.Byte);
		System.arraycopy(timeOutCnt, 0, datas, index1, len1);

		return ProtocolDataGenerator.sendOneData(vo.getConnectorNo(),vo.getMemberId(),vo.getCmdSeq(),datas, IbCmdEnum.HEART_BEAT_SET);
	}

	@Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		return generateSendDatas(dataVo);
	}

}
