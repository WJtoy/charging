package com.gdcdgj.charging.gateway.platform.ib.execute.send;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.HeartBeat;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbCmdEnum;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;

/**
 * 10.1.5	服务器系统心跳包应答(0x48)
 * <p>发送心跳包信息上报应答</p>
 *
 * @author Changliang Tao
 * @date 2020/4/30 16:14
 * @since JDK 1.8
 */
public class SendHeartbeatCmdExecute implements BaseSendCmdExecute {
    /**
     * 对象拼接成报文
     *
     * @param dataBaseVo
     * @return byte[]
     * @throws
     * @author Changliang Tao
     * @date 2020/4/26 17:38
     */
    @Override
    public byte[] sendCmdExecute(DataBaseVo dataBaseVo) {
        HeartBeat heartBeat = (HeartBeat) dataBaseVo;
        byte[] datas = new byte[2];
        if(null != heartBeat.getResponse()){
            datas = DataAnalyzer.analyseCommandData(heartBeat.getResponse(), DataAnalyseWayEnum.UInt16);
        }
        return ProtocolDataGenerator.sendOneData(heartBeat.getConnectorNo(), heartBeat.getMemberId(), heartBeat.getCmdSeq(), datas, IbCmdEnum.HEART_BEAT_REPORT_RESP);
    }
}