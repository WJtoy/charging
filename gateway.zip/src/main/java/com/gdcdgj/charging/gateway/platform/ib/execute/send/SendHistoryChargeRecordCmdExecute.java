package com.gdcdgj.charging.gateway.platform.ib.execute.send;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.HistoryChargeRecord;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbCmdEnum;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;

/**
 * 历史充电记录命令查询下达
 * @author ydc
 * @date 2020/5/6 17:24
 * @since JDK 1.8
 */
public class SendHistoryChargeRecordCmdExecute implements BaseSendCmdExecute {

	@Override
    public byte[] sendCmdExecute(DataBaseVo dataBaseVo) {
    	HistoryChargeRecord info = (HistoryChargeRecord) dataBaseVo;
    	byte[] datas = new byte[3];
		//记录起始位置 2
		byte[] startLocation = DataAnalyzer.analyseCommandData(info.getStartlocation(), DataAnalyseWayEnum.Int16);
		System.arraycopy(startLocation, 0, datas, 0, 2);
		//采集记录条数 1
		byte[] recordCount = DataAnalyzer.analyseCommandData(info.getRequireRecordCount(), DataAnalyseWayEnum.Byte);
		System.arraycopy(recordCount, 0, datas, 2, 1);
		return ProtocolDataGenerator.sendOneData(dataBaseVo.getConnectorNo(), dataBaseVo.getMemberId(), dataBaseVo.getCmdSeq(), datas, IbCmdEnum.SRV_SIGN_IN_RESP);
    }
}