/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.ib.execute.send;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.ModuleChargingInfo;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbCmdEnum;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;

/**
 * 10.2.11	当前充电模块充电信息查询(0x23)
 * @author ouxx
 * @since 2016-11-15 上午9:27:16
 *
 */
public class SendModuleInfoQueryCmd implements BaseSendCmdExecute {

	public byte[] generateSendDatas(DataBaseVo vo) {
		ModuleChargingInfo chargingInfo = (ModuleChargingInfo) vo;
		DataAnalyseWayEnum analyseWay = DataAnalyseWayEnum.Byte;
		byte connectorCnt = chargingInfo.getConnectorCnt();
		byte offset = 1;
		byte[] datas = new byte[offset + connectorCnt];

		//充电枪数量
		final int index0 = 0;
		final int len0 = 1;
		byte[] cnt = DataAnalyzer.analyseCommandData(connectorCnt, analyseWay);
		System.arraycopy(cnt, 0, datas, index0, len0);

		//充电枪位置N充电类型
		final int lenType = 1;

		for(byte i = 1; i <= connectorCnt; ++i){
			//充电枪位置N充电类型 索引
			int indexType = offset + (lenType * (i - 1));

			Byte type = chargingInfo.getTypeMap().get(i);
			byte[] typeBytes = new byte[]{0};
			if(null != type){
				typeBytes = DataAnalyzer.analyseCommandData(
						type, DataAnalyseWayEnum.Byte);
			}
			System.arraycopy(typeBytes, 0, datas, indexType, lenType);

		}

		return ProtocolDataGenerator.sendOneData(chargingInfo.getConnectorNo(), chargingInfo.getMemberId(), chargingInfo.getCmdSeq(), datas, IbCmdEnum.MODULE_INFO_QUERY);

	}

	@Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		return generateSendDatas(dataVo);
	}

}
