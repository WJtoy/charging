/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.ib.execute.send;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbCmdEnum;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;

/**
 * 10.2.9	当前充电桩总体状态查询(0x21)
 * @author ouxx
 * @since 2016-11-15 上午9:25:14
 *
 */
public class SendPileAllStatusQueryCmd implements BaseSendCmdExecute {

	public byte[] generateSendDatas(DataBaseVo vo) {
		return ProtocolDataGenerator.sendOneData(vo.getConnectorNo(), vo.getMemberId(), vo.getCmdSeq(), null, IbCmdEnum.PILE_ALL_STATUS_QUERY);
	}

	@Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		return generateSendDatas(dataVo);
	}

}
