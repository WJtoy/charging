/*
 *
 */
package com.gdcdgj.charging.gateway.platform.ib.execute.send;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.PileCtrl;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbCmdEnum;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;

/**
 * 10.2.6	中心系统非预约远程充电设备控制设置(0x55)
 * @author ouxx
 * @since 2017-3-22 上午11:09:15
 *
 */
public class SendPileCtrlWithoutOrdCmd implements BaseSendCmdExecute {

	public byte[] generateSendDatas(DataBaseVo vo) {
		PileCtrl pileCtrl = (PileCtrl) vo;
		// 充电模块个数
		Byte count = pileCtrl.getConnectorCount();
		final int offset = 2;
		// 充电模块位置编号在指令序号后2个字节
		// 充电模块位置编号、充电模块控制参数共占3个字节
		count = (null != count) ? count.byteValue() : 0;
		byte[] datas = new byte[offset + 3 * count];

		// 参数类型
		final int index0 = 0;
		final int len0 = 1;
		{
			byte[] type = DataAnalyzer.analyseCommandData(pileCtrl.getParamType(), DataAnalyseWayEnum.Byte);
			System.arraycopy(type, 0, datas, index0, len0);
		}
		// 充电模块个数
		if (null != count && 0 < count) {
			final int index1 = index0 + len0;
			final int len1 = 1;
			{
				byte[] countBytes = DataAnalyzer.analyseCommandData(count, DataAnalyseWayEnum.Byte);
				System.arraycopy(countBytes, 0, datas, index1, len1);
			}
		}

		final int lenNo = 1;
		final int lenVal = 2;

		for (byte i = 1; i <= count; ++i) {
			// 充电模块位置编号
			int indexNo = offset + (lenNo + lenVal) * (i - 1);
			Byte no = pileCtrl.getConnectorNoMap().get(i);
			byte[] noBytes = new byte[] { 0 };
			if (null != no) {
				noBytes = DataAnalyzer.analyseCommandData(no, DataAnalyseWayEnum.Byte);
			}
			System.arraycopy(noBytes, 0, datas, indexNo, lenNo);

			// 充电模块 控制参数
			int indexVal = indexNo + lenNo;
			Integer val = pileCtrl.getValueMap().get(i);
			byte[] valBytes = new byte[] { 0, 0 };
			if (null != val) {
				valBytes = DataAnalyzer.analyseCommandData(val, DataAnalyseWayEnum.Int16);
			}
			System.arraycopy(valBytes, 0, datas, indexVal, lenVal);
		}
		return ProtocolDataGenerator.sendOneData(vo.getConnectorNo(), vo.getMemberId(), vo.getCmdSeq(), datas, IbCmdEnum.PILE_CTRL_WITHOUT_ORD_SET);
	}

	@Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		return generateSendDatas(dataVo);
	}
}
