package com.gdcdgj.charging.gateway.platform.ib.execute.send;

import java.io.UnsupportedEncodingException;
import lombok.extern.slf4j.Slf4j;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.PileStartedRst;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbCmdEnum;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.platform.ib.protocol.indexAndLen.H2T_PileStartedRstIndexAndLen;

/**
 * 充电桩启动成功后，平台收到桩的0x06上报后的应答0x16
 * @author ouxx
 * @since 2017-3-1 下午8:03:58
 *
 */
@Slf4j
public class SendPileStartedRstRespCmd implements BaseSendCmdExecute {

	public byte[] generateSendDatas(DataBaseVo vo) {
		PileStartedRst startedRst = (PileStartedRst) vo;
		byte[] datas = new byte[48];
		{
			//客户姓名
//			byte[] customName = DataAnalyzer.analyseCommandData(authen.getCustomName(), DataAnalyseWayEnum.UTF8
////					, H2T_PileStartedRstIndexAndLen.CUSTOM_NAME.getLen()
//					);

			byte[] customName;
			try {
				customName = startedRst.getCustomName().getBytes("GB2312");
				System.arraycopy(customName, 0, datas, H2T_PileStartedRstIndexAndLen.CUSTOM_NAME.getIndex(),
						customName.length);
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				log.error(e.getMessage(),e);
			}

		}
		{
			// 流程序号
//			byte[] parkName = DataAnalyzer.analyseCommandData(authen.getParkName(), DataAnalyseWayEnum.UTF8
////					, H2T_PileStartedRstIndexAndLen.PARK_NAME.getLen()
//					);
			byte[] parkName;
			try {
				parkName = startedRst.getParkName().getBytes("GB2312");
				System.arraycopy(parkName, 0, datas, H2T_PileStartedRstIndexAndLen.PARK_NAME.getIndex(),
						parkName.length);
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
			log.error(e.getMessage(),e);
			}

		}

		return ProtocolDataGenerator.sendOneData(vo.getConnectorNo(), vo.getMemberId(), vo.getCmdSeq(), datas, IbCmdEnum.PILE_STARTED_RESP);
	}

	@Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		return generateSendDatas(dataVo);
	}

}
