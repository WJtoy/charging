/*
 *
 */
package com.gdcdgj.charging.gateway.platform.ib.execute.send;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.RemoteUpgrade;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbCmdEnum;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.platform.ib.protocol.indexAndLen.H2T_RemoteUpgradeIndexAndLen;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;

/**
 * 中心系统下发充电桩远程升级命令(0x29)
 * @author ouxx
 * @since 2017-3-21 下午2:32:52
 *
 */
public class SendRemoteUpgradeCmd implements BaseSendCmdExecute {

	public byte[] generateSendDatas(DataBaseVo vo) {
		RemoteUpgrade remoteUpgrade = (RemoteUpgrade)vo;

		byte[] datas = new byte[H2T_RemoteUpgradeIndexAndLen.VERSION.getIndex()
		                        + H2T_RemoteUpgradeIndexAndLen.VERSION.getLen()] ;

		//IP
		{
			String ip = remoteUpgrade.getIp();
			String[] ips = ip.split("\\.");
			int length = ips.length;
			byte[] ipBytes = new byte[length * 2];//一段用两个字节存
			for(int i = 0; i < length; ++i){
				byte high = Byte.valueOf((byte)(Integer.valueOf(ips[i]).intValue() / 100));
				byte low = Byte.valueOf((byte)(Integer.valueOf(ips[i]).intValue() % 100));
				ipBytes[i * 2] = high;
				ipBytes[i * 2 + 1] = low;
			}
			System.arraycopy(ipBytes, 0, datas,
					H2T_RemoteUpgradeIndexAndLen.IP.getIndex(),
					H2T_RemoteUpgradeIndexAndLen.IP.getLen());
		}

		//ftp登陆账号
		{
			byte[] accountBytes = DataAnalyzer.analyseCommandData(remoteUpgrade.getFtpAccount(),
					DataAnalyseWayEnum.StrASCII);
			System.arraycopy(accountBytes, 0, datas,
					H2T_RemoteUpgradeIndexAndLen.FTP_ACCOUNT.getIndex(), accountBytes.length);
		}
		//ftp登陆密码
		{
			byte[] passwdBytes = DataAnalyzer.analyseCommandData(remoteUpgrade.getFtpPassword(),
					DataAnalyseWayEnum.StrASCII);
			System.arraycopy(passwdBytes, 0, datas,
					H2T_RemoteUpgradeIndexAndLen.FTP_PWD.getIndex(), passwdBytes.length);
		}
		//文件路径
		{
			byte[] pathBytes = DataAnalyzer.analyseCommandData(remoteUpgrade.getPath(),
					DataAnalyseWayEnum.StrASCII);
			System.arraycopy(pathBytes, 0, datas,
					H2T_RemoteUpgradeIndexAndLen.PATH.getIndex(), pathBytes.length);
		}
		//软件版本
		{
			String[] versionArr = remoteUpgrade.getVersion().split("\\.");
			byte[] versionBytes = new byte[versionArr.length];
			for(int i = 0; i < versionArr.length; ++i){
				versionBytes[i] = Byte.valueOf(versionArr[i]);
			}
			System.arraycopy(versionBytes, 0, datas,
					H2T_RemoteUpgradeIndexAndLen.VERSION.getIndex(), versionBytes.length);
		}

		return ProtocolDataGenerator.sendOneData(remoteUpgrade.getConnectorNo(), remoteUpgrade.getMemberId(), remoteUpgrade.getCmdSeq(), datas, IbCmdEnum.REMOTE_UPGRADE_SET);

	}

	@Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		return generateSendDatas(dataVo);
	}
}
