/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.ib.execute.send;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbCmdEnum;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;

/**
 * 10.2.1	中心系统下达签到命令(0x01)
 * @author ouxx
 * @since 2016-11-15 上午9:08:18
 *
 */
public class SendSignInCmd implements BaseSendCmdExecute {

	/**
	 * 10.2.1	中心系统下达签到命令(0x01)
	 * 发送签到命令无需额外数据，所以vo可以传null
	 */
	public byte[] generateSendDatas(DataBaseVo vo) {
		//签到命令无需额外数据
		return ProtocolDataGenerator.sendOneData(vo.getConnectorNo(), vo.getMemberId(), 0, null, IbCmdEnum.SEND_SIGN_IN_SET);
	}
	@Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		return generateSendDatas(dataVo);
	}

}
