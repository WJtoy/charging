package com.gdcdgj.charging.gateway.platform.ib.execute.send;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.SignIn;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbCmdEnum;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;

/**
 * @author Changliang Tao
 * @date 2020/5/6 17:24
 * @since JDK 1.8
 */
public class SendSignInCmdExecute implements BaseSendCmdExecute {
    /**
     * 对象拼接成报文
     *
     * @param channel
     * @param dataBaseVo
     * @return byte[]
     * @throws
     * @author Changliang Tao
     * @date 2020/4/26 17:38
     */
    @Override
    public byte[] sendCmdExecute(DataBaseVo dataBaseVo) {
    	SignIn signIn = (SignIn) dataBaseVo;
		byte[] equipmentCodeBytes = null;
		//充电桩编码 8个字节
		equipmentCodeBytes = DataAnalyzer.analyseCommandData(signIn.getPileCode(), DataAnalyseWayEnum.StrASCII);
		byte[] datas = new byte[8];
		System.arraycopy(equipmentCodeBytes, 0, datas, 0, equipmentCodeBytes.length);
		return ProtocolDataGenerator.sendOneData(dataBaseVo.getConnectorNo(), dataBaseVo.getMemberId(), dataBaseVo.getCmdSeq(), datas, IbCmdEnum.SRV_SIGN_IN_RESP);
    }
}