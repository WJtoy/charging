/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.ib.execute.send;

import java.util.Calendar;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.ServiceType;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbCmdEnum;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.platform.ib.protocol.indexAndLen.H2T_SrvTypeIndexAndLen;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;


/**
 * 10.3.3	中心系统应答服务类型(0x61)
 * @author ouxx
 * @since 2016-11-15 上午9:36:49
 *
 */
public class SendSrvTypeResponseCmd implements BaseSendCmdExecute {

	public byte[] generateSendDatas(DataBaseVo vo) {
		ServiceType serviceType = (ServiceType) vo;
		byte[] datas = new byte[25];
		{
			// 卡号 16字节
			byte[] cardNum = DataAnalyzer.analyseCommandData(serviceType.getCardNum(), DataAnalyseWayEnum.StrASCII);
//			byte[] cardNum = new byte[16];
			System.arraycopy(cardNum, 0, datas, H2T_SrvTypeIndexAndLen.CARDNUM.getIndex(),
					cardNum.length);
		}
		{
			// 交易类型
			byte[] type = DataAnalyzer.analyseCommandData(serviceType.getType(), DataAnalyseWayEnum.Byte);
			System.arraycopy(type, 0, datas, H2T_SrvTypeIndexAndLen.TYPE.getIndex(),
					type.length);
		}
		{
			// 交易日期时间
			Calendar cal = serviceType.getTradeDate();
			System.arraycopy(ProtocolDataGenerator.calendar2ByteArray(cal), 0, datas, H2T_SrvTypeIndexAndLen.TRADE_DATE.getIndex(),
					H2T_SrvTypeIndexAndLen.TRADE_DATE.getLen());
		}

		return ProtocolDataGenerator.sendOneData(serviceType.getConnectorNo(), serviceType.getMemberId(), serviceType.getCmdSeq(), datas, IbCmdEnum.SRV_TYPE_RESP);
	}

	@Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		return generateSendDatas(dataVo);
	}

}
