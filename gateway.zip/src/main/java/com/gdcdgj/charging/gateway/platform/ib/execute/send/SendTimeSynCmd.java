/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.ib.execute.send;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.TimeSyn;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbCmdEnum;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;

/**
 * 充电桩时间同步(0x42)
 * <p>中心监控系统可以下发该指令设置充电桩时钟时间。
 * 充电桩总体系统时钟时间修改后立即生效。
 * @author ouxx
 * @since 2016-11-15 上午8:30:58
 *
 */
public class SendTimeSynCmd implements BaseSendCmdExecute {

	public byte[] generateSendDatas(DataBaseVo vo) {
		TimeSyn timeSyn = (TimeSyn) vo;
		byte[] datas = ProtocolDataGenerator.calendar2ByteArray(timeSyn.getClock());
		return ProtocolDataGenerator.sendOneData(vo.getConnectorNo(), vo.getMemberId(), vo.getCmdSeq(), datas, IbCmdEnum.TIME_SYN_SET);
	}

	@Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		return generateSendDatas(dataVo);
	}
	
}
