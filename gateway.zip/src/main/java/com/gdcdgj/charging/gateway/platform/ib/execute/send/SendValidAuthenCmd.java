/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.ib.execute.send;

import java.io.UnsupportedEncodingException;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.ValidAuthen;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbCmdEnum;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.platform.ib.protocol.indexAndLen.H2T_ValidAuthenIndexAndLen;

import lombok.extern.slf4j.Slf4j;

/**
 * 中心系统下发合法用户认证信息(0x6a)
 * @author ouxx
 * @since 2017-1-16 下午6:07:21
 *
 */
@Slf4j
public class SendValidAuthenCmd implements BaseSendCmdExecute{

	public byte[] generateSendDatas(DataBaseVo vo) {
		ValidAuthen authen = (ValidAuthen) vo;
		byte[] datas = new byte[48];
		{
			//客户姓名
//			byte[] customName = DataAnalyzer.analyseCommandData(authen.getCustomName(), DataAnalyseWayEnum.UTF8
////					, H2T_ValidAuthenIndexAndLen.CUSTOM_NAME.getLen()
//					);

			byte[] customName;
			try {
				customName = authen.getCustomName().getBytes("GB2312");
				System.arraycopy(customName, 0, datas, H2T_ValidAuthenIndexAndLen.CUSTOM_NAME.getIndex(),
						customName.length);
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				log.error(e.getMessage(),e);
			}

		}
		{
			// 流程序号
//			byte[] parkName = DataAnalyzer.analyseCommandData(authen.getParkName(), DataAnalyseWayEnum.UTF8
////					, H2T_ValidAuthenIndexAndLen.PARK_NAME.getLen()
//					);
			byte[] parkName;
			try {
				parkName = authen.getParkName().getBytes("GB2312");
				System.arraycopy(parkName, 0, datas, H2T_ValidAuthenIndexAndLen.PARK_NAME.getIndex(),
						parkName.length);
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				log.error(e.getMessage(),e);
			}

		}

		return ProtocolDataGenerator.sendOneData(authen.getConnectorNo(), authen.getMemberId(), authen.getCmdSeq(), datas, IbCmdEnum.VALID_USER_AUTHEN_SET);
	}

	@Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		return generateSendDatas(dataVo);
	}
}
