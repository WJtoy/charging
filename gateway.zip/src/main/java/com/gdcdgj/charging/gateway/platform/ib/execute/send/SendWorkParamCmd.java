/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.ib.execute.send;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.WorkParam;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbCmdEnum;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;

/**
 * 10.1.3	充电桩工作参数(0x46)
	 * <p>中心监控系统可以下发该指令查询当前充电桩总体工作参数信息；
	 * 充电桩在接收本指令进行应答，之后要求充电桩按照指令参数修改对应配置，
	 * 并自动重启。确保充电桩的参数在无人干预的情况下自动生效
 * @author ouxx
 * @since 2016-11-15 上午8:37:15
 *
 */
public class SendWorkParamCmd implements BaseSendCmdExecute {

	/**
	 * 10.1.3	充电桩工作参数(0x46)
	 * <p>中心监控系统可以下发该指令查询当前充电桩总体工作参数信息；
	 * 充电桩在接收本指令进行应答，之后要求充电桩按照指令参数修改对应配置，
	 * 并自动重启。确保充电桩的参数在无人干预的情况下自动生效
	 */
	public byte[] generateSendDatas( DataBaseVo vo) {
		WorkParam param = (WorkParam) vo;
		byte[] datas = new byte[17];
		//充电桩编码 ，8字节
		final int index0 = 0;
		final int len0 = 8;
		byte[] equipmentCode = DataAnalyzer.analyseCommandData(param.getPileCode(), DataAnalyseWayEnum.StrASCII);
		System.arraycopy(equipmentCode, 0, datas, index0, len0);

		//充电桩类型
		final int index1 = index0 + len0;
		final int len1 = 1;
		byte[] type = DataAnalyzer.analyseCommandData(param.getType(), DataAnalyseWayEnum.Byte);
		System.arraycopy(type, 0, datas, index1, len1);

		//可服务电池类型
		final int index2 = index1 + len1;
		final int len2 = 1;
		byte[] batteryType = DataAnalyzer.analyseCommandData(param.getBatteryType(), DataAnalyseWayEnum.Byte);
		System.arraycopy(batteryType, 0, datas, index2, len2);

		//充电枪个数
		final int index3 = index2 + len2;
		final int len3 = 1;
		byte[] connectorCnt = DataAnalyzer.analyseCommandData(param.getConnectorCnt(), DataAnalyseWayEnum.Byte);
		System.arraycopy(connectorCnt, 0, datas, index3, len3);

		//中心服务器地址 ，4字节
		//按照字节顺序：
		//0x11 0x12 0x13 0x14
		//(表示IP：17.18.19.20)
		final int index4 = index3 + len3;
		final int len4 = 4;
		String ip = param.getSrvIp();
		String[] ips = ip.split("\\.");
		int length = ips.length;
		byte[] srvIp = new byte[length];
		for(int i = 0; i < length; ++i){
			srvIp[i] = Byte.parseByte(ips[i]);
		}
		System.arraycopy(srvIp, 0, datas, index4, len4);

		//中心服务器端口，低字节在前
		//例如：端口8899
		//按照字节顺序：0xC3 0x22
		final int index5 = index4 + len4;
		final int len5 = 2;
		byte[] srvPort = DataAnalyzer.analyseCommandData(param.getSrvPort(), DataAnalyseWayEnum.UInt16Reverse);
		System.arraycopy(srvPort, 0, datas, index5, len5);

		return ProtocolDataGenerator.sendOneData(vo.getConnectorNo(),vo.getMemberId(), vo.getCmdSeq(), datas, IbCmdEnum.WORK_PARAM_SET);
	}

	@Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		return generateSendDatas(dataVo);
	}

}
