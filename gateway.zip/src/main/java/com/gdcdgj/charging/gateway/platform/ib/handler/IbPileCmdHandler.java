package com.gdcdgj.charging.gateway.platform.ib.handler;

import java.util.Calendar;
import java.util.Date;

import org.springframework.amqp.AmqpException;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessagePostProcessor;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.gdcdgj.charging.api.constant.RabbitmqConstant;
import com.gdcdgj.charging.api.vo.srv2gw.BcpInfo;
import com.gdcdgj.charging.api.vo.srv2gw.ChargeRecordInfo;
import com.gdcdgj.charging.api.vo.srv2gw.CommunicationMode;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.HeartBeatSetting;
import com.gdcdgj.charging.api.vo.srv2gw.HistoryChargeRecord;
import com.gdcdgj.charging.api.vo.srv2gw.ModuleChargingInfo;
import com.gdcdgj.charging.api.vo.srv2gw.PileCtrl;
import com.gdcdgj.charging.api.vo.srv2gw.PileStartedRst;
import com.gdcdgj.charging.api.vo.srv2gw.RemoteUpgrade;
import com.gdcdgj.charging.api.vo.srv2gw.SignIn;
import com.gdcdgj.charging.api.vo.srv2gw.StateInfo;
import com.gdcdgj.charging.api.vo.srv2gw.TimeSyn;
import com.gdcdgj.charging.api.vo.srv2gw.ValidAuthen;
import com.gdcdgj.charging.api.vo.srv2gw.WorkParam;
import com.gdcdgj.charging.gateway.platform.PileCmdHandler;
import com.gdcdgj.charging.gateway.platform.ib.execute.receive.RecBcpCmd;
import com.gdcdgj.charging.gateway.platform.ib.execute.receive.RecBrmCmd;
import com.gdcdgj.charging.gateway.platform.ib.execute.receive.RecChargingRecordReportCmd;
import com.gdcdgj.charging.gateway.platform.ib.execute.receive.RecCommunicationModeResponseCmd;
import com.gdcdgj.charging.gateway.platform.ib.execute.receive.RecHeartbeatCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.execute.receive.RecHistoryChargingRecordReportCmd;
import com.gdcdgj.charging.gateway.platform.ib.execute.receive.RecModuleInfoResponseCmd;
import com.gdcdgj.charging.gateway.platform.ib.execute.receive.RecPileAllStatusResponseCmd;
import com.gdcdgj.charging.gateway.platform.ib.execute.receive.RecPileCtrlResponseCmd;
import com.gdcdgj.charging.gateway.platform.ib.execute.receive.RecPileStartedRstReportCmd;
import com.gdcdgj.charging.gateway.platform.ib.execute.receive.RecRemoteUpgradeCmd;
import com.gdcdgj.charging.gateway.platform.ib.execute.receive.RecSignInCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.execute.receive.RecTimeSynRespCmd;
import com.gdcdgj.charging.gateway.platform.ib.execute.receive.RecValidAuthenCmd;
import com.gdcdgj.charging.gateway.platform.ib.execute.receive.RecWorkParamResponseCmd;
import com.gdcdgj.charging.gateway.platform.ib.execute.send.SendBcpReportCmd;
import com.gdcdgj.charging.gateway.platform.ib.execute.send.SendBrmCmd;
import com.gdcdgj.charging.gateway.platform.ib.execute.send.SendChargingRecordResponseCmd;
import com.gdcdgj.charging.gateway.platform.ib.execute.send.SendCommunicationModeCmd;
import com.gdcdgj.charging.gateway.platform.ib.execute.send.SendHeartBeatSettingCmd;
import com.gdcdgj.charging.gateway.platform.ib.execute.send.SendHeartbeatCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.execute.send.SendPileAllStatusQueryCmd;
import com.gdcdgj.charging.gateway.platform.ib.execute.send.SendPileStartedRstRespCmd;
import com.gdcdgj.charging.gateway.platform.ib.execute.send.SendSignInCmd;
import com.gdcdgj.charging.gateway.platform.ib.execute.send.SendSignInCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.execute.send.SendTimeSynCmd;
import com.gdcdgj.charging.gateway.server.handler.ChannelSender;
import com.gdcdgj.charging.gateway.server.handler.H2TServer;

import io.netty.channel.ChannelHandlerContext;
import lombok.extern.slf4j.Slf4j;

/**
 * 宜步报文处理器
 *
 * @author ydc
 * @date 2020/4/30 14:41
 * @since JDK 1.8
 */
@Component
@Slf4j
public class IbPileCmdHandler implements PileCmdHandler {
	
	@Autowired
	private AmqpTemplate amqp;

	/**
     * 报文心跳处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/26 16:57
     */
    @Override
    public void heartbeatCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
    	if(H2TServer.channelPileMap.get(ctx.channel()) == null) {
    		log.info("断链 签到信息主动上报");
    		SendSignInCmd sendSignInCmd = new SendSignInCmd();
            byte[] datas = sendSignInCmd.sendCmdExecute(new SignIn());
            ChannelSender.send(ctx.channel(), datas);
    	}else {
    		// 接收报文后执行
    		RecHeartbeatCmdExecute recHeartbeatCmdExecute = new RecHeartbeatCmdExecute();
    		DataBaseVo dataBaseVo = recHeartbeatCmdExecute.receiveCmdExecute(fullData);
    		// 心跳包应答
    		SendHeartbeatCmdExecute sendHeartbeatCmdExecute = new SendHeartbeatCmdExecute();
    		byte[] bytes = sendHeartbeatCmdExecute.sendCmdExecute(dataBaseVo);
    		// 后台返回应答
    		ChannelSender.send(ctx.channel(),bytes);
    		log.info("心跳包上报应答完成(0x58)\n");
    	}
	}

    /**
     * 报文签到处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:36
     */
    @Override
    public void signInCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
        // 获取到设备上报签到信息,解析出设备编码equipmentCode
    	RecSignInCmdExecute recSignInCmdExecute = new RecSignInCmdExecute();
    	SignIn signIn = (SignIn) recSignInCmdExecute.receiveCmdExecute(fullData);
        // 存储equipmentCode、channel，以便推送
        String tmpCode = signIn.getPileCode();
        log.info("保存equipmentCode========{}", tmpCode);
        H2TServer.saveChannel(tmpCode, ctx.channel());
        SendSignInCmdExecute sign = new SendSignInCmdExecute();
        byte[] bytes = sign.sendCmdExecute(signIn);
        ChannelSender.send(ctx.channel(),bytes);
        //如果之前桩断连或故障，现在连上了，则激活充电桩，把桩编码为equipmentCode的桩下的所有枪的状态改为空闲
        amqp.convertAndSend(RabbitmqConstant.SIGN_IN_PILE_EXCHANGE, RabbitmqConstant.SIGN_IN_PILE_ROUTING_KEY, signIn);
        log.info("中心系统查询签到应答完成\n");
        //更新桩程序的版本号
        SendTimeSynCmd recTimeSynRespCmd = new SendTimeSynCmd();
        TimeSyn timeSyns = new TimeSyn();
        Calendar cal = Calendar.getInstance();
        timeSyns.setClock(cal);
        byte[] timeSyn = recTimeSynRespCmd.sendCmdExecute(timeSyns);
        ChannelSender.send(ctx.channel(),timeSyn);
        log.info("签到完成后同步时间处理完成\n");
        //设置通讯上报为15秒
        SendCommunicationModeCmd cmd = new SendCommunicationModeCmd();
        CommunicationMode dataVo = new CommunicationMode();
        dataVo.setMode((byte) 0x02);
        dataVo.setReportInterval((byte) 0x0f);
        byte[] sendCmdExecute = cmd.sendCmdExecute(dataVo);
        ChannelSender.send(ctx.channel(), sendCmdExecute);
        log.info("通讯模式设置为15秒一报\n");
        //设置心跳上报为15秒
        SendHeartBeatSettingCmd cmdExecute = new SendHeartBeatSettingCmd();
        HeartBeatSetting dataBaseVo = new HeartBeatSetting();
        dataBaseVo.setPeriod((byte) 0x0f);
        dataBaseVo.setTimeOutCnt((byte) 0x04);
        byte[] sendCmdExecute2 = cmdExecute.sendCmdExecute(dataBaseVo);
        ChannelSender.send(ctx.channel(), sendCmdExecute2);
        log.info("设置心跳上报为15秒一报\n");
    }

    /**
     * 充电桩上报状态
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:38
     */
    @Override
    public void moduleInfoCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
    	RecModuleInfoResponseCmd recModuleInfoResponseCmd = new RecModuleInfoResponseCmd();
    	ModuleChargingInfo moduleChargingInfo = (ModuleChargingInfo) recModuleInfoResponseCmd.receiveCmdExecute(fullData);
    	//        SendModuleInfoQueryCmd cmd = new SendModuleInfoQueryCmd();
    	//        byte[] datas = cmd.generateSendDatas(moduleChargingInfo);
    	//        ChannelSender.send(ctx.channel(), datas);
    	moduleChargingInfo.setPileCode(H2TServer.channelPileMap.get(ctx.channel()));
        amqp.convertAndSend(RabbitmqConstant.MOUDLEINFO_STATUS_EXCHANGE, RabbitmqConstant.MOUDLEINFO_STATUS_ROUTING_KEY, moduleChargingInfo);
        log.info("当前充电模块充电信息查询应答处理完成(0x33) 查询结果 : {}\n" , moduleChargingInfo.getFaultCode() > 0 ? "充电桩有故障" : "充电桩无故障");
        
    }

    /**
     * 充电桩上报启动结果
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
    
    @Override
    public void startResultCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
    	RecPileStartedRstReportCmd recPileStartedRstReportCmd = new RecPileStartedRstReportCmd();
    	PileStartedRst pileStartedRst = (PileStartedRst) recPileStartedRstReportCmd.receiveCmdExecute(fullData);
    	SendPileStartedRstRespCmd sendPileStartedRstRespCmd = new SendPileStartedRstRespCmd();
    	byte[] datas = sendPileStartedRstRespCmd.sendCmdExecute(pileStartedRst);
    	ChannelSender.send(ctx.channel(), datas);
    	pileStartedRst.setPileCode(H2TServer.channelPileMap.get(ctx.channel()));
        log.info("启动结果应答处理完成(0x06) 最终启动结果 ：{}\n" , pileStartedRst.getResult() == 1 ? "成功" : "失败");
        amqp.convertAndSend(RabbitmqConstant.STARTED_STATUS_EXCHANGE, RabbitmqConstant.STARTED_STATUS_ROUTING_KEY, pileStartedRst);
    }
    
    /**
     * 充电桩上报启动停止
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
    
	@Override
	public void startCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		RecPileCtrlResponseCmd recPileCtrlResponseCmd = new RecPileCtrlResponseCmd();
		PileCtrl pileCtrl = (PileCtrl) recPileCtrlResponseCmd.receiveCmdExecute(fullData);
		pileCtrl.setPileCode(H2TServer.channelPileMap.get(ctx.channel()));
		log.info("启动-停止应答完成(0x65) 启停完成：{}\n" , pileCtrl);
	}
	
	/**
     * 充电桩上报启动停止
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
    
	@Override
	public void stopCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		System.err.println("宜步---启停同体 ---同上");
	}

	/**
     * 充电桩上报全状态信息包
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
	
	@Override
	public void stateInfoCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		RecPileAllStatusResponseCmd recPileAllStatusResponseCmd = new RecPileAllStatusResponseCmd();
		StateInfo stateInfo = (StateInfo) recPileAllStatusResponseCmd.receiveCmdExecute(fullData);
		log.info("充电桩上报总状态信息包完成\n");
	}

	@Override
	public void strParamSetCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {

	}

	@Override
	public void voluationPolicyCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {

	}

	@Override
	public void alarmInfoCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {

	}

	@Override
	public void plasticParamSetCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		
	}

	@Override
	public void accountInfoCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		
	}

	@Override
	public void chargeTimeFrameInfoCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		
	}

	/**
     * 充电桩上报充电记录命令
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
	
	@Override
	public void chargeRecordInfoCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		RecChargingRecordReportCmd cmd = new RecChargingRecordReportCmd();
		ChargeRecordInfo chargeRecordInfo = (ChargeRecordInfo) cmd.receiveCmdExecute(fullData);
		SendChargingRecordResponseCmd sendCmd = new SendChargingRecordResponseCmd();
		byte[] datas = sendCmd.sendCmdExecute(chargeRecordInfo);
		ChannelSender.send(ctx.channel(), datas);
		amqp.convertAndSend(RabbitmqConstant.CHARGEINFO_STATUS_EXCHANGE, RabbitmqConstant.CHARGEINFO_STATUS_ROUTING_KEY, chargeRecordInfo);
		log.info("充电桩上报充电记录命令应答完成");
	}
	
	/**
     * 充电桩历史充电记录命令应答
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
	
	@Override
	public void HistoryChargeRecordInfoCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		RecHistoryChargingRecordReportCmd chargingRecordReportCmd = new RecHistoryChargingRecordReportCmd();
		HistoryChargeRecord chargeRecord = (HistoryChargeRecord) chargingRecordReportCmd.receiveCmdExecute(fullData);
		log.info("充电桩历史充电记录命令应答完成 ：{}",chargeRecord);
	}
	
	/**
     * 充电桩时间同步
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
	
	@Override
	public void timeSyncCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		RecTimeSynRespCmd recTimeSynRespCmd = new RecTimeSynRespCmd();
		TimeSyn timeSyn = (TimeSyn) recTimeSynRespCmd.receiveCmdExecute(fullData);
		long res = timeSyn.getClock().getTime().getTime()-new Date().getTime();
		log.info("充电桩时间同步应答完成(0x52) 同步结果 ：{}\n", res > 5000 ? "失败" : "成功");
	}

	/**
     * 工作参数应答处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
	
	@Override
	public void workParamCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		RecWorkParamResponseCmd recWorkParamResponseCmd = new RecWorkParamResponseCmd(); 
		WorkParam workParam = (WorkParam) recWorkParamResponseCmd.receiveCmdExecute(fullData);
		log.info("工作参数应答处理完成(0x56) 设置结果：{}\n" , workParam.getSettingRst() > 0 ? "成功" : "失败");
	}
	
	/**
     * 充电桩应答中心合法用户认证通过信息
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
	
	@Override
	public void validAuthenCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		RecValidAuthenCmd recValidAuthenCmd = new RecValidAuthenCmd();
		ValidAuthen validAuthen = (ValidAuthen)recValidAuthenCmd.receiveCmdExecute(fullData);
		log.info("充电桩应答中心合法用户认证通过信息处理完成(0x7a) 处理结果：{}" , validAuthen.getResult() > 0 ? "成功" : "失败");
	}

	/**
	 * 远程系统升级
	 * 
	 * @param ctx
	 * @param fullData
	 * @throws Exception
	 * @author ydc
     * @date 2020/4/30 14:40
	 */
	
	@Override
	public void remoteUpgradeCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		RecRemoteUpgradeCmd recRemoteUpgradeCmd = new RecRemoteUpgradeCmd();
		RemoteUpgrade remoteUpgrade = (RemoteUpgrade) recRemoteUpgradeCmd.receiveCmdExecute(fullData);
		log.info("充电桩远程系统升级应答完成(0x7a) 升级结果：{}" , remoteUpgrade.getResult() > 0 ? "成功" : "失败");
	}
	
	/**
	 * 中心下发服务类型
	 * 
	 * @param ctx
	 * @param fullData
	 * @throws Exception
	 * @author ydc
     * @date 2020/4/30 14:40
	 */
	
	@Override
	public void serviceTypeCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		log.info("此命令不用应答");
	}
	
	/**
	 * BMS车辆辨识报文处理
	 * 
	 * @param ctx
	 * @param fullData
	 * @throws Exception
	 * @author ydc
     * @date 2020/4/30 14:40
	 */
	
	@Override
	public void BRMCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		RecBrmCmd brmCmd = new RecBrmCmd();
		DataBaseVo receiveCmdExecute = brmCmd.receiveCmdExecute(fullData);
		SendBrmCmd brmCmd2 = new SendBrmCmd();
		byte[] datas = brmCmd2.sendCmdExecute(receiveCmdExecute);
		ChannelSender.send(ctx.channel(), datas);
		log.info("处理BMS车辆辨识报文完成 :{}  \n",receiveCmdExecute);
	}

	/**
	 * 通讯模式设置应答
	 * 
	 * @param ctx
	 * @param fullData
	 * @throws Exception
	 * @author ydc
     * @date 2020/4/30 14:40
	 */
	
	@Override
	public void ReportTypeCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		RecCommunicationModeResponseCmd cmd = new RecCommunicationModeResponseCmd();
		CommunicationMode receiveCmdExecute = (CommunicationMode) cmd.receiveCmdExecute(fullData);
		log.info("通讯模式设置应答(0x57) 设置间隔时间:{}",receiveCmdExecute.getReportInterval());
	}
	
	/**
	 * 桩上报BCP报文
	 * 
	 * @param ctx
	 * @param fullData
	 * @throws Exception
	 * @author ydc
     * @date 2020/4/30 14:40
	 */
	
	@Override
	public void BCPCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		RecBcpCmd bcpCmd = new RecBcpCmd();
		BcpInfo receiveCmdExecute = (BcpInfo) bcpCmd.receiveCmdExecute(fullData);
		SendBcpReportCmd bcpReportCmd = new SendBcpReportCmd();
		byte[] sendCmdExecute = bcpReportCmd.sendCmdExecute(receiveCmdExecute);
		ChannelSender.send(ctx.channel(), sendCmdExecute);
		log.info("桩上报BCP报文(0x03)");
	}
}
