package com.gdcdgj.charging.gateway.platform.ib.protocol;


import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.gateway.platform.kw.protocol.KwCmdEnum;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * 命令数据VO
 * @author ouxx
 * @since 2017-2-24 上午10:07:25
 *
 */
@Data
@Accessors(chain = true)
@EqualsAndHashCode
public class CmdData {

	//协议报文数据
	private byte[] fullData;
	//上次发送时间
	private long lastSendTime;
	//对应的命令枚举
	private IbCmdEnum cmdEnum;
	//科旺的命令枚举
	private KwCmdEnum kwCmdEnum;
	//已经发送了的次数，初始是1，因为肯定会先发一次
	private int sentNumOfTimes = 1;
	//枪编号
	private int connectorNo;
	//命令VO
	private DataBaseVo cmdVo;

	public int getConnectorNo() {
		return connectorNo;
	}

	public void setConnectorNo(int connectorNo) {
		this.connectorNo = connectorNo;
	}

	public byte[] getFullData() {
		return fullData;
	}

	public void setFullData(byte[] fullData) {
		this.fullData = fullData;
	}

	public long getLastSendTime() {
		return lastSendTime;
	}

	public void setLastSendTime(long lastSendTime) {
		this.lastSendTime = lastSendTime;
	}

	public IbCmdEnum getCmdEnum() {
		return cmdEnum;
	}

	public void setCmdEnum(IbCmdEnum cmdEnum) {
		this.cmdEnum = cmdEnum;
	}

	public int getSentNumOfTimes() {
		return sentNumOfTimes;
	}

	public void setSentNumOfTimes(int sentNumOfTimes) {
		this.sentNumOfTimes = sentNumOfTimes;
	}

	public DataBaseVo getCmdVo() {
		return cmdVo;
	}

	public void setCmdVo(DataBaseVo cmdVo) {
		this.cmdVo = cmdVo;
	}

}