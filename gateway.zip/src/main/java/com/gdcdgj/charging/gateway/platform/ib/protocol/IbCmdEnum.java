/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.ib.protocol;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 服务端与充电桩通信的命令
 *
 * @author ouxx
 * @since 2016-11-1 下午6:37:21
 */
public enum IbCmdEnum {
    //后台:H
    //充电桩:T
    // H - T : 表示 H 发送给 T
    // T - H : 表示 T 发送给 H

    /**
     * BMS相关的报文命令
     */
    //T - H 充电桩在充电准备阶段上报BMS与车辆辨识报文BRM
    BRM_REC((byte) 0x02),
    //H - T 平台收到“充电桩上报BRM”报文后，应答充电桩
    BRM_RESP((byte) 0x12),//18
    //T - H 充电桩在充电准备阶段上报BCP
    BCP_REC((byte) 0x03),// OK
    //H - T 平台收到“充电桩上报BCP”报文后，应答充电桩
    BCP_RESP((byte) 0x13),//19 // OK
    //T - H 充电桩在参数配置阶段上报CML
    CML_REC((byte) 0x04),        // OK1
    //H - T 平台收到“充电桩上报CML”报文后，应答充电桩
    CML_RESP((byte) 0x14),//20  // OK1
    //T - H 充电桩在充电阶段上报BCL
    BCL_REC((byte) 0x25),//37 	// OK1
    //T - H 充电桩在充电阶段上报BCS
    BCS_REC((byte) 0x26),//38	// OK1
    //T - H 充电桩在充电阶段上报BSM
    BSM_REC((byte) 0x07),        // OK1
    //T - H 充电桩在充电阶段上报BST
    BST_REC((byte) 0x08),        // OK1
    //H - T 平台收到“充电桩上报BST”报文后，应答充电桩
    BST_RESP((byte) 0x18),//24 	// OK1
    //T - H 充电桩在充电阶段上报CST
    CST_REC((byte) 0x79),//121	// OK1
    //H - T 平台收到“充电桩上报CST”报文后，应答充电桩
    CST_RESP((byte) 0x19),//25 	// OK1
    //T - H 充电桩在各阶段上报BEM
    BEM_REC((byte) 0x0A),//10	// OK1
    //H - T 平台收到“充电桩上报BEM”报文后，应答充电桩
    BEM_RESP((byte) 0x1A),//26	// OK1
    //T - H 充电桩在各阶段上报CEM
    CEM_REC((byte) 0x0B),//11 	// OK
    //H - T 平台收到“充电桩上报CEM”报文后，应答充电桩
    CEM_RESP((byte) 0x1B),//27 	// OK


    TIME_SYN_SET((byte) 0x42),//充电桩时间同步  		H - T
    TIME_SYN_RESP((byte) 0x52),//充电桩时间同步应答 	T - H

    WORK_PARAM_SET((byte) 0x46),//充电桩工作参数设置 	H - T
    WORK_PARAM_RESP((byte) 0x56),//充电桩工作参数设置应答  T - H

    HEART_BEAT_REPORT((byte) 0x58),//心跳包信息上报	T - H
    HEART_BEAT_REPORT_RESP((byte) 0x48),//心跳包信息上报应答	H - T

    HEART_BEAT_SET((byte) 0x49),//心跳包信息设置		H - T
    HEART_BEAT_RESP((byte) 0x59),//心跳包信息设置应答 T - H

    SEND_SIGN_IN_SET((byte) 0x01),//中心系统下达签到查询命令	H - T
    SEND_SIGN_IN_RESP((byte) 0x10),//中心系统查询签到应答/上报	T - H
    SRV_SIGN_IN_RESP((byte) 0x09),//中心系统答复签到命令		H - T
    PILE_STATUS_RESP((byte) 0x11),//充电桩状态上报			T - H

    PILE_CTRL_SET((byte) 0x05),//充电桩远程充电机控制设置	H - T
    PILE_CTRL_RESP((byte) 0x15),//充电桩远程充电机控制应答	T - H

    PILE_STARTED_REPORT((byte) 0x06),//充电桩启动成功后，向平台上报的命令			T - H
    PILE_STARTED_RESP((byte) 0x16),//充电桩启动成功后，平台收到桩的0x06上报后的应答	H - T

    COMMUN_MODE_SET((byte) 0x47),//通信模式设置命令		H - T
    COMMUN_MODE_RESP((byte) 0x57),//通信模式设置命令应答	T - H

    PILE_ALL_STATUS_QUERY((byte) 0x21),//当前充电桩总体状态查询		H - T
    PILE_ALL_STATUS_RESP((byte) 0x31),//当前充电桩总体状态应答/上报  T - H

    MODULE_INFO_QUERY((byte) 0x23),//当前充电模块充电信息查询			H - T
    MODULE_INFO_QUERY_RESP((byte) 0x33),//当前充电模块充电信息查询应答/上报	T - H

    LOCK_CTRL_SET((byte) 0x43),//当前充电设备地锁信息查询控制		H - T
    LOCK_CTRL_RESP((byte) 0x53),//充电设备地锁控制查询控制应答/上报	T - H

    ACCOUNT_QUERY_REPORT((byte) 0x70),//充电桩上报账户查询命令	T - H
    ACCOUNT_QUERY_RESP((byte) 0x60),//中心系统应答账户查询	H - T

    SRV_TYPE_REPORT((byte) 0x71),//充电桩上报服务类型申请命令	T - H
    SRV_TYPE_RESP((byte) 0x61),//中心系统应答服务类型命令	H - T

    CHARGING_RECORD_REPORT((byte) 0x78),//充电桩上报充电记录命令	T - H
    CHARGING_RECORD_RESP((byte) 0x63),//中心系统应答充电记录上报	H - T

    AUTHEN_SET((byte) 0x6a),//中心系统下达合法用户认证通过信息		H - T
    AUTHEN_RESP((byte) 0x7a),//充电桩应答中心合法用户认证通过信息命令	T - H

    CHARGING_HISTORT_RECORD_QUERY((byte) 0x80),//查询充电桩历史充电记录命令	H - T
    CHARGING_HISTORT_RECORD_RESP((byte) 0x92),//查询充电桩历史充电记录命令应答	T - H

    EVENT_HISTORT_RECORD_QUERY((byte) 0x86),//查询充电桩历史事件记录命令	H - T
    EVENT_HISTORT_RECORD_RESP((byte) 0x96),//查询充电桩历史事件记录命令应答	T - H

    ALARM_HISTORT_RECORD_QUERY((byte) 0x87),//查询充电桩历史告警记录命令	H - T
    ALARM_HISTORT_RECORD_RESP((byte) 0x97),//查询充电桩历史告警记录命令应答	T - H

    /**********新增**************/
    VALID_USER_AUTHEN_SET((byte) 0x6A),//中心系统下发合法用户认证信息		H - T
    VALID_USER_AUTHEN_RESP((byte) 0x7A),//充电桩应答中心合法用户认证通过信息命令	T - H

    CANCEL_ORDER_SET((byte) 0x6B),//取消预约		H - T
    CANCEL_ORDER_RESP((byte) 0x7B),//取消预约应答	T - H

    PRICE_SET((byte) 0x20),//下发计费价格指令  		H - T
    PRICE_RESP((byte) 0x30),//充电桩应答计费价格  		T - H

    MEDIA_SET((byte) 0x66),//下发媒体文件  		H - T
    MEDIA_RESP((byte) 0x76),//应答媒体文件  		T - H

    REMOTE_UPGRADE_SET((byte) 0x29),//中心系统下发充电桩远程升级命令(0x29)  		H - T
    REMOTE_UPGRADE_RESP((byte) 0x39),//充电桩远程升级应答(0x39)  		T - H

    PILE_CTRL_WITHOUT_ORD_SET((byte) 0x55),//无需预约即启停充电,中心系统非预约远程充电设备控制设置  		H - T
    PILE_CTRL_WITHOUT_ORD_RESP((byte) 0x65);//无需预约即启停充电,中心系统非预约远程充电设备控制应答  		T - H

    private static final Logger logger = LoggerFactory
            .getLogger(IbCmdEnum.class);

    private byte cmd;

    private IbCmdEnum(byte cmd) {
        this.cmd = cmd;
    }

    public byte getValue() {
        return this.cmd;
    }

    public static IbCmdEnum valueOf(byte cmd) {
        IbCmdEnum tempEnum = null;
        for (IbCmdEnum en : IbCmdEnum.values()) {
            if (en.getValue() == cmd) {
                tempEnum = en;
                break;
            }
        }
        if (tempEnum == null) {
            logger.error("Enum value not exist : " + cmd);
//			throw new RuntimeException("Enum value not exist");
        }
        return tempEnum;
    }

    public static void main(String[] args) {
        System.out.println((byte) 0x99);
        System.out.println((byte) 0xA9);
        System.out.println(Byte.MAX_VALUE);
    }
}
