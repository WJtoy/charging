/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.ib.protocol;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.gateway.enums.MsgProviderEnum;
import com.gdcdgj.charging.gateway.util.MathConverterHelper;

import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;

/**
 * 易充 协议工具类 本协议中，所有数值类型的多字节段，均是低位在前，高位在后， 其它数据均是十六进制顺序表示； 起始域：固定为 先0x59、 后0x43；
 * 长度域：包含从序列号域到校验和域的所有字节数； 版本域：本次版本 0x10； 序列号域：报文的流水号； 命令代码：即消息类型，代表不同功能要求；
 * 数据域：具体的信息数据区域，不同的命令代码对应的内容不同； 校验和域：采用累计和计算校验值，计算范围包含从命令代码和数据域
 *
 * @author ouxx
 * @since 2016-10-31 上午11:54:47
 */
@Slf4j
public class IbProtocolUtil {

    /**
     * 数据域
     *
     * @author ouxx
     * @since 2016-11-1 下午6:35:27
     */
    public static class DataField {
        public DataField(byte[] memberId, byte[] cmd) {
            this.memberId = memberId;
            this.cmd = cmd;
        }

        private byte[] memberId = new byte[2];// 用户ID，2字节
        private byte[] cmd = new byte[2];// 指令序号，2字节
        private List<Byte> data = new ArrayList<Byte>();// 其他数据，因无法预料数据长度，所以用List

        public byte[] getMemberId() {
            return memberId;
        }

        public void setMemberId(byte[] memberId) {
            this.memberId = memberId;
        }

        public byte[] getCmd() {
            return cmd;
        }

        public void setCmd(byte[] cmd) {
            this.cmd = cmd;
        }

        public List<Byte> getData() {
            return data;
        }

        public void setData(List<Byte> data) {
            this.data = data;
        }
    }

    // 第6个字节后开始是数据域
    private static final int DATA_FIELD_START_INDEX = 6;

    private static final int CONNECTOR_NO_LEN = 2;// 枪编码数据占2字节
    private static final int EQUIPMENT_CODE_LEN = 8;// 桩编码数据占8字节
    /**
     * 数据域中，在用户ID和指令序号和枪编码之后的数据的起始索引
     */
    private static final int DATA_AFTER_CMD_SEQ_START_INDEX = 10 + CONNECTOR_NO_LEN;// 增加2字节的枪编码

    private static final byte[] START_FIELD = new byte[]{0x59, 0x43};// 起始域
    private static final byte VERSION_FIELD = 0x10; // 版本域

    public static final int getEquipmentCodeLen() {
        return EQUIPMENT_CODE_LEN;
    }

    /**
     * 校验接收到的数据
     *
     * @param fullData
     * @return
     * @author ouxx
     * @date 2017-2-10 上午9:42:49
     */
    public static boolean verifyRecData(byte[] fullData) {
        // 起始域
        boolean matchHead = ((START_FIELD[0] == fullData[0]) && (START_FIELD[1] == fullData[1]));
        // 版本域
        boolean matchVersion = (VERSION_FIELD == fullData[3]);
        // 长度
        byte len = fullData[2];
        Integer len1 = fullData.length - 4;
        Integer len3 = fullData.length - 5;
        Integer len2 = fullData.length - 6;
        boolean matchLen = (len1.byteValue() == len || len3.byteValue() == len || len2.byteValue() == len);
        return (matchHead && matchVersion && matchLen);
    }

    public static byte[] getFullDataBytes(byte cmdCode, byte serialField, byte... dataField) {
        byte[] datas6 = new byte[6];// 协议数组的前6个字节
        datas6[0] = START_FIELD[0];
        datas6[1] = START_FIELD[1];
        // //长度域数值：包含从 序列号域到校验和域 的所有字节数
        datas6[2] = getLength(dataField);
        // 版本域
        datas6[3] = VERSION_FIELD;
        // 序列号域
        datas6[4] = serialField;
        // 命令代码
        datas6[5] = cmdCode;
        try {
            // 把数据域的数组合并到前6个字节的数据后
            byte[] datasWithDataField = MathConverterHelper.byteMerger(datas6, dataField);
            // 添上最后的校验和，校验和域：采用累计和计算校验值，计算范围包含从命令代码到数据域
            return MathConverterHelper.byteMerger(datasWithDataField, new byte[]{getCheckSum(cmdCode, dataField)});
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 获取命令代码
     *
     * @param fullData
     * @return
     * @author ouxx
     * @date 2016-11-11 下午5:54:20
     */
    public static byte getCmdCode(byte[] fullData) {
        return fullData[DATA_FIELD_START_INDEX - 1];
    }

    /**
     * 获取命令代码对应的枚举
     *
     * @param fullData
     * @return
     * @author ouxx
     * @date 2016-11-11 下午5:54:20
     */
    public static IbCmdEnum getCmdCodeEnum(byte[] fullData) {
        return IbCmdEnum.valueOf(getCmdCode(fullData));
    }

    /**
     * 获取长度域的值: 包含从 序列号域到校验和域 的所有字节数
     *
     * @param dataField
     * @return
     * @author ouxx
     * @date 2016-11-1 下午6:19:14
     */
    public static byte getLength(byte[] dataField) {
        if (null != dataField) {
            return (byte) (1 + 1 + dataField.length + 1);
        } else {
            return 3;
        }
    }

    /**
     * 校验和域：采用累计和计算校验值，计算范围包含从命令代码到数据域
     *
     * @param cmdCode
     * @param dataField
     * @return
     * @author ouxx
     * @date 2016-11-1 下午6:15:48
     */
    public static byte getCheckSum(byte cmdCode, byte... dataField) {
        byte checkSum = cmdCode;
        for (byte b : dataField) {
            checkSum = (byte) (checkSum + b);
        }
        return checkSum;
    }

    /**
     * @param fullData
     * @param index
     * @return
     * @author ouxx
     * @date 2016-11-3 上午11:22:21
     */
    private static byte[] getDataWithStartIndex(byte[] fullData, int index) {
        // 长度要减去1，因为最后还有检验和域
        int dataFieldLength = fullData.length - index  - 1;
        return getDataByIndexAndSize(fullData, index, dataFieldLength);
    }

    /**
     * 获取数据域的数据
     *
     * @param fullData
     * @return
     * @author ouxx
     * @date 2016-11-1 下午6:03:27
     */
    public static byte[] getDataField(byte[] fullData) {
        return getDataWithStartIndex(fullData, DATA_FIELD_START_INDEX);
    }

    /**
     * 数据域中，在用户ID和指令序号之后的数据
     *
     * @param fullData
     * @return
     * @author ouxx
     * @date 2016-11-3 上午11:20:42
     */
    public static byte[] getDataAfterConnectorNoInDataField(byte[] fullData) {
        return getDataWithStartIndex(fullData, DATA_AFTER_CMD_SEQ_START_INDEX);
    }

    /**
     * 从datas截取数据片段，
     *
     * @param datas
     * @param startIndex
     * @param length
     * @return
     * @author ouxx
     * @date 2016-11-4 下午2:09:56
     */
    public static byte[] getDataByIndexAndSize(byte[] datas, int startIndex, int length) {
        byte[] data = new byte[length];
        if (1 == length) {
            data[0] = datas[startIndex];
            return data;
        }
        try {
            System.arraycopy(datas, startIndex, data, 0, length);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return data;
    }

    /**
     * 获取数据域中的指令序号 数组
     *
     * @param fullData
     * @return
     * @author ouxx
     * @date 2016-11-3 上午10:09:19
     */
    public static byte[] getCmdSeqInDataField(byte[] fullData) {
        return new byte[]{fullData[8], fullData[9]};
    }

    /**
     * 获取数据域中的用户ID 数组
     *
     * @param fullData
     * @return
     * @author ouxx
     * @date 2016-11-12 下午3:57:55
     */
    public static byte[] getMemberIdBytesInDataField(byte[] fullData) {
        return new byte[]{fullData[6], fullData[7]};
    }

    /**
     * 枪编码
     *
     * @param fullData
     * @return
     * @author ouxx
     * @date 2017-2-9 上午9:42:41
     */
    public static byte[] getConnectorNoBytesInDataField(byte[] fullData) {
        return new byte[]{fullData[10], fullData[11]};
    }

    /**
     * 充电桩编码(8字节)
     *
     * @param fullData
     * @return
     * @author ouxx
     * @date 2017-2-9 上午9:42:41
     */
    public static byte[] getEquipmentCodeBytesInDataField(byte[] fullData) {
        return new byte[]{fullData[12], fullData[19]};
    }

    /**
     * 获取数据域中的指令序号 int数值
     * <p>
     * char是16bit长的无符号整数，因此范围是：0～65535，而short则是16bit长的带符号整数，范围是-32768～32767
     *
     * @param fullData
     * @return
     * @throws Exception
     * @author ouxx
     * @date 2016-11-3 下午4:43:23
     */
    public static int getCmdSeqNumInDataField(byte[] fullData) throws Exception {
        byte[] cmdSeqBytes = getCmdSeqInDataField(fullData);
//		return MathConverterHelper.toCharReverse(cmdSeqBytes, 0);//TODO 改
        return MathConverterHelper.toChar(cmdSeqBytes, 0);
    }

    /**
     * 获取数据域中的用户ID int数值
     * <p>
     * char是16bit长的无符号整数，因此范围是：0～65535，而short则是16bit长的带符号整数，范围是-32768～32767
     *
     * @param fullData
     * @return
     * @throws Exception
     * @author ouxx
     * @date 2016-11-12 下午3:59:28
     */
    public static int getMemberIdInDataField(byte[] fullData) throws Exception {
        byte[] memberIdBytes = getMemberIdBytesInDataField(fullData);
//		return MathConverterHelper.toCharReverse(memberIdBytes, 0);//TODO 改
        return MathConverterHelper.toChar(memberIdBytes, 0);
    }

    public static int getConnectorNoInDataField(byte[] fullData) throws Exception {
        byte[] connectorNoBytes = getConnectorNoBytesInDataField(fullData);
//		return MathConverterHelper.toCharReverse(connectorNoBytes, 0);//TODO 改
        return MathConverterHelper.toChar(connectorNoBytes, 0);
    }

    /**
     * 获取桩编码
     *
     * @param fullData
     * @return
     * @throws Exception
     * @author ouxx
     * @date 2017-3-7 上午10:59:33
     */
    public static String getEquipmentCodeInDataField(byte[] fullData) throws Exception {
        byte[] equipmentCodeBytes = getEquipmentCodeBytesInDataField(fullData);
        return MathConverterHelper.toASCIIString(equipmentCodeBytes, 0);
    }

    /**
     * 设置vo的用户ID和指令序号、枪编号
     *
     * @param vo
     * @param fullData
     * @throws Exception
     * @author ouxx
     * @date 2016-11-14 下午2:20:38
     */
    public static void setMemberIdAndCmdSeqAndConnectorNo(DataBaseVo vo, byte[] fullData) throws Exception {
        vo.setMemberId(IbProtocolUtil.getMemberIdInDataField(fullData));
        vo.setCmdSeq(IbProtocolUtil.getCmdSeqNumInDataField(fullData));
        vo.setConnectorNo(IbProtocolUtil.getConnectorNoInDataField(fullData));
        //宜步供应商id 2号
        vo.setProviderId(MsgProviderEnum.IB_PROVIDER.getValue());
    }
}