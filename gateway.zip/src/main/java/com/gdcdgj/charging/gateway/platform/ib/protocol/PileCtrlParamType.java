/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.ib.protocol;

/**
 * 充电设备控制 参数类型 (0x05)
 * @author ouxx
 * @since 2016-11-11 上午9:43:37
 *
 */
public enum PileCtrlParamType {

	PILE_START_STOP((byte)2),//	2：设置充电机启停
	OUTPUT_POWER((byte)3),	 //	3：设置输出功率
	UNIT_VOL_MAX((byte)4),	 //	4：设置单体最高允许电压
	UNIT_TEMP_MAX((byte)5),	 //	5：设置单体最高允许温度
	PROMPT_START_STOP((byte)6),//	6: 设置语音提示功能启停
	SERVICE_START_STOP((byte)7);//	7：设置充电设备服务启停

	private byte type;
	private PileCtrlParamType(byte type){
		this.type = type;
	}
	public byte getType(){
		return this.type;
	}

	public static PileCtrlParamType valueOf(byte value) throws RuntimeException{
		PileCtrlParamType tempEnum = null;
		for(PileCtrlParamType en: PileCtrlParamType.values()){
			if(en.getType() == value){
				tempEnum = en;
				break;
			}
		}
		if(tempEnum == null){
			throw new RuntimeException("Enum value not exist");
		}
		return tempEnum;
	}
}
