package com.gdcdgj.charging.gateway.platform.ib.protocol;

import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;
import com.gdcdgj.charging.gateway.util.MathConverterHelper;

import lombok.extern.slf4j.Slf4j;

import java.util.Calendar;

/**
 * 协议数据构造器
 *
 * @author Changliang Tao
 * @date 2020/4/14 15:40
 * @since JDK 1.8
 */
@Slf4j
public class ProtocolDataGenerator {
    /**
     * 序列号域的值
     * 序列号域：报文的流水号
     * 为了在网络链路不稳定时，如果报文重复发送，用序列号可以判断指令是否已经执行
     */
    private static byte serialField = 0;
    
    /**
     * 后台发送一个数据给充电桩的公用方法
     *
     * @param memberId
     * @param cmdSeq
     * @param datas
     * @param cmd
     * @return
     * @author ouxx
     * @date 2016-11-3 下午3:29:15
     */
    public static byte[] sendOneData(int connectorNo, int memberId, int cmdSeq, byte[] datas, IbCmdEnum cmd) {
        //序列号增1
        ++serialField;
        //获取用户ID、指令序号数据
        byte[] memberAndSeqBytes = getMemberIdAndCmdSeqBytesAndConnectorNo(connectorNo, memberId, cmdSeq);
        //拼接完整的报文
        try {
            return IbProtocolUtil.getFullDataBytes(cmd.getValue(), serialField, MathConverterHelper.byteMerger(memberAndSeqBytes, datas));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    /**
     * @param connectorNo
     * @param memberId
     * @param cmdSeq
     * @return
     * @throws
     * @author Changliang Tao
     * @date 2020/4/14 16:11
     */

    public static byte[] getMemberIdAndCmdSeqBytesAndConnectorNo(int connectorNo, int memberId, int cmdSeq) {
        byte[] memberIdBytes = DataAnalyzer.analyseCommandData(memberId, DataAnalyseWayEnum.Char);
        byte[] cmdSeqBytes = DataAnalyzer.analyseCommandData(cmdSeq, DataAnalyseWayEnum.Char);
        byte[] connectorNoBytes = DataAnalyzer.analyseCommandData(connectorNo, DataAnalyseWayEnum.Char);
        try {
            byte[] tmp = MathConverterHelper.byteMerger(MathConverterHelper.byteMerger(memberIdBytes, cmdSeqBytes), connectorNoBytes);
            return tmp;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }


    /**
     * 获取数据域
     *
     * @param dataAfterCmdSeq
     * @param index
     * @param len
     * @param analyseWay
     * @return
     * @throws
     * @author Changliang Tao
     * @date 2020/4/17 9:06
     */

    public static Object getOneData(final byte[] dataAfterCmdSeq, final int index, final int len, final DataAnalyseWayEnum analyseWay) {
        final byte[] bytes = IbProtocolUtil.getDataByIndexAndSize(dataAfterCmdSeq, index, len);
        final DataAnalyzer analyzer = new DataAnalyzer();
        analyzer.setAnalyseWay(analyseWay);
        return DataAnalyzer.analyseAnalogData(analyzer, bytes);
    }
    
    /**
     * 获取数据域
     *
     * @param dataAfterCmdSeq
     * @param index
     * @param len
     * @param analyseWay
     * @return
     * @throws
     * @author Changliang Tao
     * @date 2020/4/17 9:06
     */
    
    public static Object getOneData2(final byte[] dataAfterCmdSeq,
			final int index, final int len, final DataAnalyzer analyzer){
		final byte[] bytes = IbProtocolUtil.getDataByIndexAndSize(dataAfterCmdSeq, index, len);
		return DataAnalyzer.analyseAnalogData(analyzer, bytes);
	}
    
    /**
     * 构建日期时间对象
     * 默认为8个字节
     *
     * @param index
     * @param dataAfterCmdSeq
     * @return
     * @author ouxx
     * @date 2016-11-7 上午9:49:29
     */
    public static Calendar getCalendar(final int index, final byte[] dataAfterCmdSeq) {
        //年份  2个字节
        final int indexYear = index;
        final int lenYear = 2;
        Double year = (Double) getOneData(dataAfterCmdSeq, indexYear, lenYear, DataAnalyseWayEnum.CharReverse);
        //月  1个字节
        final int indexMonth = indexYear + lenYear;
        final int lenMonth = 1;
        Double months = (Double) getOneData(dataAfterCmdSeq, indexMonth, lenMonth, DataAnalyseWayEnum.Byte);
        //日  1个字节
        final int indexDay = indexMonth + lenMonth;
        final int lenDay = 1;
		Double days = (Double) getOneData(dataAfterCmdSeq, indexDay, lenDay, DataAnalyseWayEnum.Byte);
        //时  1个字节
        final int indexHour = indexDay + lenDay;
        final int lenHour = 1;
		Double hours = (Double) getOneData(dataAfterCmdSeq, indexHour, lenHour, DataAnalyseWayEnum.Byte);
        //分  1个字节
        final int indexMin = indexHour + lenHour;
        final int lenMin = 1;
		Double mins = (Double) getOneData(dataAfterCmdSeq, indexMin, lenMin, DataAnalyseWayEnum.Byte);
        //秒  1个字节
        final int indexSecond = indexMin + lenMin;
        final int lenSecond = 1;
		Double seconds = (Double) getOneData(dataAfterCmdSeq, indexSecond, lenSecond, DataAnalyseWayEnum.Byte);

        Calendar cal = Calendar.getInstance();
		cal.set(year.intValue(), months.intValue(), days.intValue(), hours.intValue(), mins.intValue(), seconds.intValue());
        return cal;
    }


    /**
     * 从Calendar对象转为byte数组
     *
     * @param cal
     * @return
     * @author ouxx
     * @date 2016-11-9 下午4:54:36
     */
    public static byte[] calendar2ByteArray(Calendar cal) {
        byte[] datas = new byte[8];
        byte[] year = DataAnalyzer.analyseCommandData(cal.get(Calendar.YEAR), DataAnalyseWayEnum.CharReverse);
        datas[0] = year[0];
        datas[1] = year[1];
        datas[2] = DataAnalyzer.analyseCommandData((byte) cal.get(Calendar.MONTH), DataAnalyseWayEnum.Byte)[0];
        datas[3] = DataAnalyzer.analyseCommandData((byte) cal.get(Calendar.DAY_OF_MONTH), DataAnalyseWayEnum.Byte)[0];
        datas[4] = DataAnalyzer.analyseCommandData((byte) cal.get(Calendar.HOUR_OF_DAY), DataAnalyseWayEnum.Byte)[0];
        datas[5] = DataAnalyzer.analyseCommandData((byte) cal.get(Calendar.MINUTE), DataAnalyseWayEnum.Byte)[0];
        datas[6] = DataAnalyzer.analyseCommandData((byte) cal.get(Calendar.SECOND), DataAnalyseWayEnum.Byte)[0];
        datas[7] = (byte) 0xff;// 保留
        return datas;
    }
}