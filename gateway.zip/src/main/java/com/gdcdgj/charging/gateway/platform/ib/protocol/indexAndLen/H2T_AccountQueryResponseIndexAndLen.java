/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.ib.protocol.indexAndLen;

/**
 * 中心系统应答账户查询(0x60)
 * <p>
 * 充电桩根据读到的卡信息，向后台进行账户查询，后台根据具体内容进行审核，并将结果通过本命令返回
 * <p>
 * 起始位置是从用户ID、指令序号后开始算
 * <p>
 * 后台:H
 * <p>
 * 充电桩:T
 * <p>
 * H2T : 表示 H 发送给 T
 * <p>
 * T2H : 表示 T 发送给 H
 * @author ouxx
 * @since 2016-11-10 下午3:53:49
 *
 */
public enum H2T_AccountQueryResponseIndexAndLen {

	CARDNUM(0, 16),//卡号
	CUSTOM_NAME(16, 20),//客户姓名
	RESP_CODE(36, 6),//响应码
	RESP_DESC(42, 64),//响应码描述
	CUSTOM_NUM(106, 30),//客户号
	CHARGE_ALL_BALANCE(136, 12),//电费主账户余额
	CHARGE_BALANCE(148, 12),//电费主账户可用余额
	SERVICE_ALL_BALANCE(160, 12),//服务费账户余额
	SERVICE_BALANCE(172, 12),//服务费账户可用余额
	TRADE_SEQ(184, 15),//中心交易流水号
	OPER_SEQ(199, 20),//出单机构流水号
	PERMIT_KWH(219, 4),//本次允许充电电量
	PERMIT_TIME(223, 4),//本次允许充电时间
	TRADE_DATE(227, 8),//交易日期时间
	AUTH_CODE(235, 8);//报文认证码


	private int index;
	private int len;
	private H2T_AccountQueryResponseIndexAndLen(int index, int len){
		this.index = index;
		this.len = len;
	}
	public int getIndex(){
		return this.index;
	}
	public int getLen(){
		return this.len;
	}
}
