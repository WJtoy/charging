package com.gdcdgj.charging.gateway.platform.ib.protocol.indexAndLen;

/**
 * 10.3.4	中心系统应答充电记录上报(0x63)
 * 的协议数据的起始位置index和字节数（长度）len
 * <p>
 * 充电桩在一次充电结束后，将本次充电的信息上报后台，
 * 后台根据具体内容进行审核和费用计算，并将结果通过“中心系统应答上报充电记录应答”返回
 * <p>
 * 起始位置是从用户ID、指令序号后开始算
 * <p>
 * 后台:H
 * <p>
 * 充电桩:T
 * <p>
 * H2T : 表示 H 发送给 T
 * <p>
 * T2H : 表示 T 发送给 H
 * @author ouxx
 * @since 2016-11-7 上午11:43:10
 *
 */
public enum H2T_ChargingRecordResponseIndexAndLen {

	TYPE(0, 1),//充电位置类型  1=直流；2=交流    1个字节
	CARDNUM(1, 16),//卡号
	CUSTOM_NUM(17, 30),//客户号

	TIME_QUANTITY_SOC(47, 12),//本次充电结算时间和电量
	CHARGING_FEE(59, 12),//本次充电结算电费
	SERVICE_FEE(71, 12),//本次充电结算电费
	TOTAL_FEE(83, 12),//本次累计消费总金额

	TRADE_SEQ(95, 15),//中心交易流水号
	OPER_SEQ(110, 20),//出单机构流水号

	TRADE_DATE(130, 8);//交易日期时间


	private int index;
	private int len;
	private H2T_ChargingRecordResponseIndexAndLen(int index, int len){
		this.index = index;
		this.len = len;
	}
	public int getIndex(){
		return this.index;
	}
	public int getLen(){
		return this.len;
	}
}
