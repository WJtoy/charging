/*
 *
 */
package com.gdcdgj.charging.gateway.platform.ib.protocol.indexAndLen;

/**
 * 充电桩启动成功后，平台收到桩的0x06上报后的应答0x16
 * @author ouxx
 * @since 2017-3-1 下午7:58:06
 *
 */
public enum H2T_PileStartedRstIndexAndLen {

	CUSTOM_NAME(0, 16),//客户姓名
	PARK_NAME(16, 32);//网点名

	private int index;
	private int len;
	private H2T_PileStartedRstIndexAndLen(int index, int len){
		this.index = index;
		this.len = len;
	}
	public int getIndex(){
		return this.index;
	}
	public int getLen(){
		return this.len;
	}
}
