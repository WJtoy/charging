/*
 *
 */
package com.gdcdgj.charging.gateway.platform.ib.protocol.indexAndLen;

/**
 * 中心系统下发充电桩远程升级命令(0x29)
 * @author ouxx
 * @since 2017-3-21 下午3:10:22
 *
 */
public enum H2T_RemoteUpgradeIndexAndLen {
	IP(0, 8),//IP地址 8字节.按照字节顺序：
			 //	两个字节相加为一个字段,低字节为除以100的商,高字节为100的余数：
			//	255=0x02,0x37
			//	68 =0x00,0x44
			//	1  =0x00,0x01
			//	205=0x02,0x05


	//以下三个,Ascii码不足补0x00
	FTP_ACCOUNT(8, 32),//ftp登陆账号
	FTP_PWD(40, 16),//ftp登陆密码
	PATH(56, 50),//文件路径
	VERSION(106, 4);//软件版本

	private int index;
	private int len;
	private H2T_RemoteUpgradeIndexAndLen(int index, int len){
		this.index = index;
		this.len = len;
	}
	public int getIndex(){
		return this.index;
	}
	public int getLen(){
		return this.len;
	}

}
