/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.ib.protocol.indexAndLen;

/**
 * 中心系统应答服务类型(0x61)
 * <p>
 * 中心系统接收交服务请求，判断该卡号用户是否具备服务条件，并将结果通过“中心系统应答服务类型”返回。
 * <p>
 * 起始位置是从用户ID、指令序号后开始算
 * <p>
 * 后台:H
 * <p>
 * 充电桩:T
 * <p>
 * H2T : 表示 H 发送给 T
 * <p>
 * T2H : 表示 T 发送给 H
 * @author ouxx
 * @since 2016-11-9 下午8:10:45
 *
 */
public enum H2T_SrvTypeIndexAndLen {

	CARDNUM(0, 16),//卡号
	TYPE(16, 1),//交易类型
	TRADE_DATE(17, 8),//交易日期时间
	TRADE_SEQ(25, 15),//中心交易流水号
	OPER_SEQ(40, 20),//出单机构流水号
	SRV_CTRL_VAL(25, 4);//控制参数. 按时间：分钟数； 按电量：单位为0.01度


	private int index;
	private int len;
	private H2T_SrvTypeIndexAndLen(int index, int len){
		this.index = index;
		this.len = len;
	}
	public int getIndex(){
		return this.index;
	}
	public int getLen(){
		return this.len;
	}
}
