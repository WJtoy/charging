/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.ib.protocol.indexAndLen;

/**
 * 中心系统下发合法用户认证信息(0x6a)
 * @author ouxx
 * @since 2017-1-16 下午5:41:00
 *
 */
public enum H2T_ValidAuthenIndexAndLen {
	CUSTOM_NAME(0, 16),//客户姓名
	PARK_NAME(16, 32);//网点名

	private int index;
	private int len;
	private H2T_ValidAuthenIndexAndLen(int index, int len){
		this.index = index;
		this.len = len;
	}
	public int getIndex(){
		return this.index;
	}
	public int getLen(){
		return this.len;
	}
}
