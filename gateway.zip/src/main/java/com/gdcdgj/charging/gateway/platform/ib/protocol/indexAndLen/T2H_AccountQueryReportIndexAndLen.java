/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.ib.protocol.indexAndLen;

/**
 * 充电桩上报账户查询命令(0x70)
 * <p>
 * 充电桩根据读到的卡信息，向后台进行账户查询，后台根据具体内容进行审核，并将结果通过“中心系统应答账户查询应答”返回
 * <p>
 * 起始位置是从用户ID、指令序号后开始算
 * <p>
 * 后台:H
 * <p>
 * 充电桩:T
 * <p>
 * H2T : 表示 H 发送给 T
 * <p>
 * T2H : 表示 T 发送给 H
 *
 * @author ouxx
 * @since 2016-11-10 上午11:14:20
 *
 */
public enum T2H_AccountQueryReportIndexAndLen {

	CARDNUM(0, 16),//卡号
	CERT_TYPE(16, 1),//客户证件类型
	CERT_NUM(17, 20),//客户证件号码
	APPROVAL_CHANNEL(37, 2),//受理渠道
	OPER_SEQ(39, 20),//出单机构流水号
	OPER_CODE(59, 15),//出单机构代码
	APPROVAL_OPER_NUM(74, 20),//受理操作员编号
	TRADE_DATE(94, 8),//交易日期时间
	PAY_PASSWORD(102, 16),//支付密码
	SERVICE_FEE_ID(118, 1),//服务收费标识
	SERVICE_FEE(119, 12),//服务收费金额
	AUTH_CODE(131, 8);//报文认证码

	private int index;
	private int len;
	private T2H_AccountQueryReportIndexAndLen(int index, int len){
		this.index = index;
		this.len = len;
	}
	public int getIndex(){
		return this.index;
	}
	public int getLen(){
		return this.len;
	}
}
