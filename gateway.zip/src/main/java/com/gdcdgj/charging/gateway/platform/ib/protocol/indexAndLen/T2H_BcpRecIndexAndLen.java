/*
 *
 */
package com.gdcdgj.charging.gateway.platform.ib.protocol.indexAndLen;

/**
 * 充电桩在充电准备阶段上报BCP 0x03
 * @author ouxx
 * @since 2017-4-28 下午5:20:14
 *
 */
public enum T2H_BcpRecIndexAndLen {
	BATTERY_CELL_VOL_LIMIT(0, 2),//单体动力电池最高允许充电电压	2
	CURR_LIMIT(2, 2),//最高允许充电电流	2
	TOTAL_KWH(4, 2),//动力蓄电池标称总能量	2
	TOTAL_VOL(6, 2),//最高允许充电总电压	2
	TEMPRETURE_LIMIT(8, 1),//最高允许温度	1
	SOC(9, 2),//整车动力蓄电池荷电状态	2
	CURRENT_VOL(11, 2);//动力蓄电池当前电池电压	2

	private int index;
	private int len;
	private T2H_BcpRecIndexAndLen(int index, int len){
		this.index = index;
		this.len = len;
	}
	public int getIndex(){
		return this.index;
	}
	public int getLen(){
		return this.len;
	}
}
