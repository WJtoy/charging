/*
 *
 */
package com.gdcdgj.charging.gateway.platform.ib.protocol.indexAndLen;

/**
 * 充电桩在充电准备阶段上报BMS与车辆辨识报文BRM 0x02
 * @author ouxx
 * @since 2017-4-27 下午4:36:57
 *
 */
public enum T2H_BrmRecIndexAndLen {

	PROTOCOL_VERSION(0, 3),//BMS协议版本 3
	BATTERY_TYPE(3, 1),//电池类型	1
	BATTERY_AH(4, 2),//动力电池额定容量	2
	BATTERY_TOTAL_VOL(6, 2),//动力电池额定总电压	2
	BATTERY_MANUFACT(8, 4),//电池生产厂商名称	4
	BATTERY_PACK_SN(12, 4),//电池组序号	4
	BATTERY_PACK_DATE_OF_PROD(16, 3),//电池组生产日期	3
	BATTERY_PACK_CHARG_TIMES(19, 3),//电池组充电次数	3
	BATTERY_PACK_PROP_ID(22, 1),//电池组产权标识	1
	RESERVATION(23, 1),//预留	1
	CAR_VIN(24, 17),//车辆识别码VIN	17
	BMS_VERSION(41, 8);//BMS软件版本号	8

	private int index;
	private int len;
	private T2H_BrmRecIndexAndLen(int index, int len){
		this.index = index;
		this.len = len;
	}
	public int getIndex(){
		return this.index;
	}
	public int getLen(){
		return this.len;
	}
}
