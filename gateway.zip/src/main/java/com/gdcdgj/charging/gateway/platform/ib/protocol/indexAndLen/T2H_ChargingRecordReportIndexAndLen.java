/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.ib.protocol.indexAndLen;

/**
 * 10.3.8	充电桩上报充电记录命令(0x78)的协议数据的起始位置index和字节数（长度）len
 * <p>
 * 起始位置是从用户ID、指令序号后开始算
 * <p>
 * 后台:H
 * <p>
 * 充电桩:T
 * <p>
 * H2T : 表示 H 发送给 T
 * <p>
 * T2H : 表示 T 发送给 H
 * @author ouxx
 * @since 2016-11-7 上午11:11:20
 *
 */
public enum T2H_ChargingRecordReportIndexAndLen {

	TYPE(0, 1),//充电位置类型  1=直流；2=交流    1个字节
	CARDNUM(1, 16),//卡号
	TRADE_SEQ(17, 15),//中心交易流水号
	BOOK_SEQ(32, 20),//充电预约序号
	EQUIP_CODE(52, 8),//充电机编码

	VIN(60, 17),//车辆VIN
	LPN(77, 8),//车牌号
	SOC_BEGIN(85, 1),//开始充电SOC
	SOC_END(86, 1),//结束充电SOC

	QUANTITY(87, 2),//本次累计充电量  Ah
	KWH(89, 2),//本次累计充电能  Kwh
	TIME(91, 4),//充电时间长度  秒
	STRATEGY(95, 1),//充电策略
	STRATEGY_PARAM(96, 2),//充电满策略参数
	NORMAL_END(98, 1),//是否正常结束

	BEGIN_DATE(99, 8),//开始充电日期时间
	END_DATE(107, 8),//结束充电日期时间
	TRADE_DATE(115, 8),//交易日期时间
	KWH_BEGIN(123, 4),//开始电表度数
	KWH_END(127, 4);//结束电表度数


	private int index;
	private int len;
	private T2H_ChargingRecordReportIndexAndLen(int index, int len){
		this.index = index;
		this.len = len;
	}
	public int getIndex(){
		return this.index;
	}
	public int getLen(){
		return this.len;
	}
}
