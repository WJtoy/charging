package com.gdcdgj.charging.gateway.platform.ib.protocol.indexAndLen;

/**
 * 充电桩启动成功后，向平台上报的命令0x06
 * @author ouxx
 * @since 2017-3-1 下午7:57:24
 *
 */
public enum T2H_PileStartedRstIndexAndLen {

	CUSTOM_NAME(0, 16),//客户姓名
	PARK_NAME(16, 32),//网点名
	RESULT(48, 1);//结果

	private int index;
	private int len;
	private T2H_PileStartedRstIndexAndLen(int index, int len){
		this.index = index;
		this.len = len;
	}
	public int getIndex(){
		return this.index;
	}
	public int getLen(){
		return this.len;
	}
}
