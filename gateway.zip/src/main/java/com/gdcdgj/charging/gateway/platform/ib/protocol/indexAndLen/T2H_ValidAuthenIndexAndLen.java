/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.ib.protocol.indexAndLen;

/**
 * 充电桩应答中心合法用户认证通过信息命令(0x74)
 * @author ouxx
 * @since 2017-1-16 下午5:47:38
 *
 */
public enum T2H_ValidAuthenIndexAndLen {

	RESULT(0, 4);//设置结果

	private int index;
	private int len;
	private T2H_ValidAuthenIndexAndLen(int index, int len){
		this.index = index;
		this.len = len;
	}
	public int getIndex(){
		return this.index;
	}
	public int getLen(){
		return this.len;
	}
}
