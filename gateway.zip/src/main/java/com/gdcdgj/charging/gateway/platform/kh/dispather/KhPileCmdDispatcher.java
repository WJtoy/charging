package com.gdcdgj.charging.gateway.platform.kh.dispather;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.gdcdgj.charging.gateway.platform.kh.handler.KhPileCmdHandler;
import com.gdcdgj.charging.gateway.platform.kh.protocol.KhCmdEnum;
import com.gdcdgj.charging.gateway.platform.kh.protocol.KhProtocolUtil;
import com.gdcdgj.charging.gateway.platform.kw.protocol.KwCmdEnum;
import com.gdcdgj.charging.gateway.platform.kw.protocol.KwProtocolUtil;

import io.netty.channel.ChannelHandlerContext;
import lombok.extern.slf4j.Slf4j;

/**
 * 科华桩上报命令分发
 *
 * @author ydc
 * @date 2020/6/1
 * @since JDK 1.8
 */
@Slf4j
@Component
public class KhPileCmdDispatcher {

	// 科华命令处理器
    @Autowired
    KhPileCmdHandler khPileCmdHandler;

    /**
     * 科华根据命令枚举分发不同命令处理
     *
     * @param
     * @return
     * @throws
     * @author ydc
     * @date 2020/6/1
     */
    public void dispatcher(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
        // 报文验证
        if (!KhProtocolUtil.verifyRecData(fullData)) {
        	KhCmdEnum cmdEnums = KhProtocolUtil.getCmdCodeEnum(fullData);
            log.error("报文验证错误 数据长度：{},kw_cmdEnum:{}",fullData.length,cmdEnums);
            return;
        }
        // 获取命令代码枚举
        final KhCmdEnum cmdEnum = KhProtocolUtil.getCmdCodeEnum(fullData);
        log.info("kh_cmdEnum => {}", cmdEnum);
        switch (cmdEnum) {
            case HEART_BEAT_REPORT:
                // 心跳处理
            	log.info("进行心跳处理");
            	khPileCmdHandler.heartbeatCmdHandle(ctx, fullData);
                break;
            case SEND_SIGN_IN_RESP:
                // 签到处理
            	log.info("进行签到处理");
            	khPileCmdHandler.signInCmdHandle(ctx, fullData);
                break;
            case MODULE_INFO_QUERY_RESP:
                // 当前充电模块充电信息查询应答/上报
            	log.info("进行当前模块充电信息查询处理");
            	khPileCmdHandler.moduleInfoCmdHandle(ctx, fullData);
                break;
            case PILE_STARTED_REPORT:
                // 充电桩启动成功后，向平台上报的命令
            	log.info("进行充电桩启动充电结果处理");
            	khPileCmdHandler.startResultCmdHandle(ctx, fullData);
                break;
            default:
                log.info("其他");
                break;
        }
    }
}
