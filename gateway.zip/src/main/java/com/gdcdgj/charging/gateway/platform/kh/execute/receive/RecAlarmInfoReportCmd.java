/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.kh.execute.receive;


import java.util.Calendar;

import com.gdcdgj.charging.api.vo.srv2gw.AlarmInfo;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.kh.protocol.KhProtocolUtil;
import com.gdcdgj.charging.gateway.platform.kh.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;

import lombok.extern.slf4j.Slf4j;

/**
 * 告警信息包上报(0x0f)
 * <p>发送报文 </p>
 *
 * @author ydc
 * @since 2016-11-14 下午3:35:46
 */
@Slf4j
public class RecAlarmInfoReportCmd implements BaseReceiveCmdExecute{

    /**
     * 告警信息包上报(0x0f)
     *
     * @param fullData
     * @return
     * @throws Exception
     * @author ouxx
     * @date 2016-11-3 下午1:50:21
     */
    public static AlarmInfo recHeartbeatReport(byte[] fullData,AlarmInfo alarmInfo) {
        try {
        	final byte[] dataAfterCmdSeq = KhProtocolUtil.getDataField(fullData);
            // 告警点 1
            final byte indexFault1 = 0;
            {
                Double alarmStation = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault1, 1, DataAnalyseWayEnum.UInt8);
                alarmInfo.setAlarmStation(alarmStation.intValue());
            }
            // 告警开始时间 7
            final byte indexFault2 = indexFault1 + 1;
            {
                Calendar alarmStartTime = (Calendar) ProtocolDataGenerator.getCalendar(indexFault2, dataAfterCmdSeq);
                alarmInfo.setAlarmStartTime(alarmStartTime);
            }
            // 告警结束时间 7
            final byte indexFault3 = indexFault2 + 7;
            {
                Calendar alarmStopTime = (Calendar) ProtocolDataGenerator.getCalendar(indexFault3, dataAfterCmdSeq);
                alarmInfo.setAlarmStopTime(alarmStopTime);
            }
            // 是否影响充电 1
            final byte indexFault4 = indexFault3 + 7;;
            {
                Double isAffectCharge = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault4, 1, DataAnalyseWayEnum.UInt8);
                alarmInfo.setIsAffectCharge(isAffectCharge.intValue());
            }
            log.info("告警信息包上报(0x0f)");
            log.info("告警点 :" + alarmInfo.getAlarmStation());
            log.info("告警开始时间 :" + alarmInfo.getAlarmStartTime());
            log.info("告警结束时间 :" + alarmInfo.getAlarmStopTime());
            log.info("是否影响充电  :" + alarmInfo.getIsAffectCharge());
            return alarmInfo;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return alarmInfo;
    }

	@Override
	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
		AlarmInfo alarmInfo = new AlarmInfo();
		KhProtocolUtil.setProviderAndField(alarmInfo, fullData);
		return recHeartbeatReport(fullData,alarmInfo);
	}
    
}
