package com.gdcdgj.charging.gateway.platform.kh.execute.receive;

import com.gdcdgj.charging.api.vo.srv2gw.BalanceReissue;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.kh.protocol.KhProtocolUtil;
import com.gdcdgj.charging.gateway.platform.kh.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;

import lombok.extern.slf4j.Slf4j;

/**
 * 终端上传金额补发结果(0x9c)
 *
 * @author Changliang Tao
 * @date 2020/4/30 14:56
 * @since JDK 1.8
 */
@Slf4j
public class RecBalanceReissueCmdExecute implements BaseReceiveCmdExecute {
    
	/**
     * 接收心跳报文数据的执行方法
     *
     * @param fullData
     * @return
     * @throws Exception
     * @author ouxx
     */
    @Override
    public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
        BalanceReissue balanceReissue = new BalanceReissue();
        byte[] dataAfterCmdSeq = KhProtocolUtil.getDataField(fullData);
        // 用户卡号 20
        final int index1 = 0;
        {
        	String userNo = (String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index1, 20, DataAnalyseWayEnum.StrASCII);
        	balanceReissue.setUserNo(userNo);
        }
        // 更新结果 1
        final int index2 = index1 + 20;
        {
        	Double successSignal = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index2, 1, DataAnalyseWayEnum.UInt8);
        	balanceReissue.setSuccessSignal(successSignal.intValue());
        }
        log.info("终端上传金额补发结果(0x9c)");
        log.info("用户卡号 :{}",balanceReissue.getUserNo());
        log.info("更新结果 :{}",balanceReissue.getSuccessSignal());
        return balanceReissue;
    }
}