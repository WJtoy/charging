package com.gdcdgj.charging.gateway.platform.kh.execute.receive;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.HeartBeat;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.kh.protocol.KhProtocolUtil;
import com.gdcdgj.charging.gateway.platform.kh.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;

import lombok.extern.slf4j.Slf4j;

/**
 * 远端心跳包上报(0x02)
 * <p>接收充电桩发来的心跳包报文 </p>
 *
 * @author Changliang Tao
 * @date 2020/4/30 14:56
 * @since JDK 1.8
 */
@Slf4j
public class RecHeartbeatCmdExecute implements BaseReceiveCmdExecute {
    
	/**
     * 接收心跳报文数据的执行方法
     *
     * @param fullData
     * @return
     * @throws Exception
     * @author ouxx
     */
    @Override
    public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
        HeartBeat heartBeat = new HeartBeat();
        KhProtocolUtil.setProviderAndField(heartBeat, fullData);
        byte[] dataAfterConnectorNoInDataField = KhProtocolUtil.getDataField(fullData);
        //心跳序号 2
        Double heartBeatSeq = (Double) ProtocolDataGenerator.getOneData(dataAfterConnectorNoInDataField, 0, 2, DataAnalyseWayEnum.UInt16);
        heartBeat.setHeartBeatSeq(heartBeatSeq.intValue());
        log.info("远端心跳包上报(0x02)");
        log.info("心跳序号 :{}",heartBeat.getHeartBeatSeq());
        return heartBeat;
    }
}