package com.gdcdgj.charging.gateway.platform.kh.execute.receive;

import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.HistoryChargeRecord;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.kh.protocol.KhProtocolUtil;
import com.gdcdgj.charging.gateway.platform.kh.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;

import lombok.extern.slf4j.Slf4j;

/**
 * 充电桩上报历史充电记录信息(0x91,0x01)
 * <p>发送报文 </p>
 *
 * @author ydc
 * @since 2016-11-14 下午3:35:46
 */
@Slf4j
public class RecHistoryChargeRecordInfoReportCmd implements BaseReceiveCmdExecute{

    /**
     * 充电桩上报历史充电记录信息(0x0e)
     *
     * @param fullData
     * @return
     * @throws Exception
     * @author ouxx
     * @date 2016-11-3 下午1:50:21
     */
    public static HistoryChargeRecord recHeartbeatReport(byte[] fullData,HistoryChargeRecord info) {
    	DecimalFormat df = new DecimalFormat("#0.00");
    	
    	Map<Byte,Double> maps = new HashMap<>();
    	final int len1 = 1;
    	final int len2 = 2;
    	final int len4 = 4;
    	final int len7 = 7;
    	final int len8 = 8;
    	final int len20 = 20;
        try {
        	final byte[] dataAfterCmdSeq = KhProtocolUtil.getDataField(fullData);
        	// 充电方式 1
            final int index1 = 0;
            {
            	Double startType = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index1, len1, DataAnalyseWayEnum.UInt8);
            	info.setStartType(startType.intValue());
            }
            // 充电策略 1
            final int index2 = index1 + len1;
            {
            	Double chargePolicy = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index2, len1, DataAnalyseWayEnum.UInt8);
            	info.setChargePolicy(chargePolicy.byteValue());
            }
            // 充电卡类型 1
            final int index3 = index2 + len1;
            {
            	Double cardType = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index3, len1, DataAnalyseWayEnum.UInt8);
            	info.setCardType(cardType.intValue());
            }
            // 充电卡号 32
            final int index4 = index3 + len1;
            {
            	String chargeNo = (String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index4, len20, DataAnalyseWayEnum.StrASCII);
            	info.setChargeNo(chargeNo);
            }
            // 车VIN 17
            final int index5 = index4 + len20;
            {
            	String carVIN = (String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index5, 17, DataAnalyseWayEnum.StrASCII);
            	info.setCarVIN(carVIN);
            }
            // 充电前卡余额 4
            final int index6 = index5 + 17;
            {
            	Double brforeChargeMoney = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index6, len4, DataAnalyseWayEnum.UInt32);
            	info.setBrforeChargeMoney(Double.parseDouble(df.format(brforeChargeMoney)));
            }
            // 充电最高电压 2
            final int index7 = index6 + len4;
            {
            	Double maxVoltage = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index7, len2, DataAnalyseWayEnum.UInt16);
            	info.setMaxVoltage(Double.parseDouble(df.format(maxVoltage)));
            }
            // 充电最高电流 2
            final int index8 = index7 + len2;
            {
            	Double maxCurrent = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index8, len2, DataAnalyseWayEnum.UInt16);
            	info.setMaxCurrent(Double.parseDouble(df.format(maxCurrent)));
            }
            //充电时间长度 4
            final int index9 = index8 + len2;
            {
          	    Double chargeTimeLen = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index9, len4, DataAnalyseWayEnum.UInt32);
          	    info.setChargeTimeLen(chargeTimeLen.intValue());
            }
            // 本次充电金额 4
            final int index10 = index9 + len4;
            {
          	    Double chargeMoney = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index10, len4, DataAnalyseWayEnum.UInt32);
          	    info.setChargeMoney(chargeMoney);
            }
            // 本次充电电能 4
            final int index11 = index10 + len4;
            {
            	Double currentChargeCount = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index11, len4, DataAnalyseWayEnum.UInt32);
            	info.setCurrentChargeCount(Double.parseDouble(df.format(currentChargeCount)));
            }
            // 充电开始电能 4
            final int index12 = index11 + len4;
            {
            	Double startChargeQuality = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index12, len4, DataAnalyseWayEnum.UInt32);
            	info.setStartChargeQuality(Double.parseDouble(df.format(startChargeQuality)));
            }
            // 充电结束电能 4
            final int index13 = index12 + len4;
            {
            	Double stopChargeQuality = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index13, len4, DataAnalyseWayEnum.UInt32);
            	info.setStopChargeQuality(Double.parseDouble(df.format(stopChargeQuality)));
            }
            //开始SOC 1
	        final int index14 = index13 + len4;
	        {
	          	Double startSOC = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index14, len1, DataAnalyseWayEnum.UInt8);
	          	info.setStartSOC(startSOC.byteValue());
	        }
	        // 结束SOC 1
	        final int index15 = index14 + len1;
	        {
	          	Double stopSOC = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index15, len1, DataAnalyseWayEnum.UInt8);
	          	info.setStopSOC(stopSOC.byteValue());
	        }
	        // 是否付费 1
	        final int index16 = index15 + len1;
	        {
	          	Double isPayment = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index16, len1, DataAnalyseWayEnum.UInt8);
	          	info.setIsPayment(isPayment.intValue());
	        }
	        // 充电结束原因 1
	        final int index17 = index16 + len1;
	        {
	        	Double chargeStopCause = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index17, len1, DataAnalyseWayEnum.UInt8);
	        	info.setChargeStopCause(chargeStopCause.intValue());
	        }
            // 开始充电时间 8
            final int index18 = index17 + len1;
            {
            	Calendar startChargeTime = ProtocolDataGenerator.getCalendar(index18, dataAfterCmdSeq);
            	info.setStartChargeTime(startChargeTime);
            }
            // 结束充电时间 8
            final int index19 = index18 + len7;
            {
            	Calendar stopChargeTime = ProtocolDataGenerator.getCalendar(index19, dataAfterCmdSeq);
            	info.setStopChargeTime(stopChargeTime);
            }
            // 单体最高电压 2
            final int index20 = index19 + len7;
            {
            	Double sigalVoltage = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index20, len2, DataAnalyseWayEnum.UInt16);
            	info.setSigalVoltage(Double.parseDouble(df.format(sigalVoltage)));
            }
            // 单体最高电流 2
            final int index21 = index20 + len2;
            {
            	Double sigalCurrent = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index21, len2, DataAnalyseWayEnum.UInt16);
            	info.setSigalCurrent(Double.parseDouble(df.format(sigalCurrent)));
            }
            // 单体最高温度 2
            final int index22 = index21 + len2;
            {
            	Double sigalTemperature = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index22, len2, DataAnalyseWayEnum.UInt16);
            	info.setSigalTemperature(Double.parseDouble(df.format(sigalTemperature)));
            }
            // 充电流水号 4
            final int index23 = index22 + len2;
            {
            	Double serialNum = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index23, len4, DataAnalyseWayEnum.UInt32);
          		info.setSerialNum(serialNum.toString());
            }
            // 本地存储流水号 4
            final int index24 = index23 + len4;
            {
            	Double localSerialNo = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index24, len4, DataAnalyseWayEnum.UInt32);
          		info.setLocalSerialNo(localSerialNo.intValue());
            }
            // 服务费 4
            final int index25 = index24 + len4;
            {
            	Double servePrice = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index25, len4, DataAnalyseWayEnum.UInt32);
            	info.setServePrice(Double.parseDouble(df.format(servePrice)));
            }
            // 总费 4
            final int index26 = index25 + len4;
            {
            	Double totalPrice = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index26, len4, DataAnalyseWayEnum.UInt32);
            	info.setTotalPrice(Double.parseDouble(df.format(totalPrice)));
            }
            // 计费版本 10 
            final int index27 = index26 + len4;
            {
            	String voluationVersion = (String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index27, 10, DataAnalyseWayEnum.StrASCII);
            	info.setVoluationVersion(voluationVersion);
            }
            // 尖时电量 4
            final int index28 = index27 + 10;
            {
            	Double sharpQuality = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index28, len4, DataAnalyseWayEnum.UInt32);
            	info.setSharpQuality(Double.parseDouble(df.format(sharpQuality)));
            }
            // 峰时电量 4
            final int index29 = index28 + len4;
            {
            	Double peakQuality = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index29, len4, DataAnalyseWayEnum.UInt32);
            	info.setPeakQuality(Double.parseDouble(df.format(peakQuality)));
            }
            // 平时电量 4
            final int index30 = index29 + len4;
            {
            	Double normalQuality = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index30, len4, DataAnalyseWayEnum.UInt32);
            	info.setNormalQuality(Double.parseDouble(df.format(normalQuality)));
            }
            // 谷时电量 4
            final int index31 = index30 + len4;
            {
            	Double valleyQuality = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index31, len4, DataAnalyseWayEnum.UInt32);
            	info.setValleyQuality(Double.parseDouble(df.format(valleyQuality)));
            }
            // 尖时电费 4
            final int index32 = index31 + len4;
            {
            	Double sharpChargingPrice = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index32, len4, DataAnalyseWayEnum.UInt32);
            	info.setSharpChargingPrice(Double.parseDouble(df.format(sharpChargingPrice)));
            }
            // 峰时电费 4
            final int index33 = index32 + len4;
            {
            	Double peakChargingPrice = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index33, len4, DataAnalyseWayEnum.UInt32);
            	info.setPeakChargingPrice(Double.parseDouble(df.format(peakChargingPrice)));
            }
            // 平时电费 4
            final int index34 = index33 + len4;
            {
            	Double normalChargingPrice = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index34, len4, DataAnalyseWayEnum.UInt32);
            	info.setNormalChargingPrice(Double.parseDouble(df.format(normalChargingPrice)));
            }
            // 谷时电费 4
            final int index35 = index34 + len4;
            {
            	Double valleyChargingPrice = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index35, len4, DataAnalyseWayEnum.UInt32);
            	info.setValleyChargingPrice(Double.parseDouble(df.format(valleyChargingPrice)));
            }
            // 尖时服务费 4
            final int index36 = index35 + len4;
            {
            	Double sharpServicePrice = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index36, len4, DataAnalyseWayEnum.UInt32);
            	info.setSharpServicePrice(Double.parseDouble(df.format(sharpServicePrice)));
            }
            // 峰时服务费 4
            final int index37 = index36 + len4;
            {
            	Double peakServicePrice = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index37, len4, DataAnalyseWayEnum.UInt32);
            	info.setPeakServicePrice(Double.parseDouble(df.format(peakServicePrice)));
            }
            // 平时服务费 4
            final int index38 = index37 + len4;
            {
            	Double normalServicePrice = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index38, len4, DataAnalyseWayEnum.UInt32);
            	info.setNormalServicePrice(Double.parseDouble(df.format(normalServicePrice)));
            }
            // 谷时服务费 4
            final int index39 = index38 + len4;
            {
            	Double valleyServicePrice = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index39, len4, DataAnalyseWayEnum.UInt32);
            	info.setValleyServicePrice(Double.parseDouble(df.format(valleyServicePrice)));
            }
            log.info("充电桩上报历史充电记录信息(0x0e)");
//            log.info("充电桩编码 :" + info.getPileCode());
//            log.info("充电枪位置类型 :" + info.getLocationType());
//            log.info("充电枪号 :" + info.getConnectorNo());
//            log.info("充电卡号 :" + info.getChargeNo());
//            log.info("开始充电时间 :" + info.getStartChargeTime());
//            log.info("结束充电时间 :" + info.getStopChargeTime());
//            log.info("充电时间长度 :" + info.getChargeTimeLen());
//            log.info("开始SOC :" + info.getStartSOC());
//            log.info("结束SOC :" + info.getStopSOC());
//            log.info("充电结束原因 :" + info.getChargeStopCause());
//            log.info("本次充电电量 :" + info.getCurrentChargeCount());
//            log.info("本次充电金额 :" + info.getChargeMoney());
//            log.info("内部索引号 :" + info.getIndexNum());
//            log.info("充电策略 :" + info.getChargePolicy());
//            log.info("充电策略参数 :" + info.getChargePolicyParam());
//            log.info("车VIN :" + info.getCarVIN());
//            for (int i = 0; i < 48; i++) {
//           	 log.info("各时段充电电量 :" + info.getChargeCount().get((byte)i));
//			}
//            log.info("启动方式 :" + info.getStartType());
//            log.info("充电流水号 :" + info.getSerialNum());
            return info;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return info;
    }

	@Override
	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
		HistoryChargeRecord info = new HistoryChargeRecord();
		KhProtocolUtil.setProviderAndField(info, fullData);
		return recHeartbeatReport(fullData,info);
	}
}
