package com.gdcdgj.charging.gateway.platform.kh.execute.receive;

import java.util.HashMap;
import java.util.Map;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.ReadOrWriteData;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.platform.kh.protocol.KhProtocolUtil;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;

import lombok.extern.slf4j.Slf4j;

/**
 * 上传实时数据(0x0d)
 * 
 * @author ydc
 * @date 2020/6/1 17:23
 * @since JDK 1.8
 */
@Slf4j
public class RecMoudleInfoCmdExecute implements BaseReceiveCmdExecute {
   
	/**
     * 接收报文数据的执行方法
     *
     * @param fullData
     * @return
     * @throws Exception
     * @author ouxx
     * @date 2016-11-14 下午5:09:35
     */
    public DataBaseVo signInHandle(byte[] fullData,ReadOrWriteData readData) throws Exception {
    	byte[] dataAfterCmdSeq = KhProtocolUtil.getDataField(fullData);
    	
    	final int len1 = 1;
    	final int len2 = 2;
    	//数据单元个数 1
    	final int index0 = 0;
    	{
    		Double dataCount = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
					index0, len1, DataAnalyseWayEnum.UInt8);
    		readData.setDataCount(dataCount.intValue());
    	}
    	Integer count = readData.getDataCount();
    	//map 循环获取标识 长度 值
    	Map<Integer,Integer> dataSignalMap = new HashMap<>();
    	Map<Integer,Integer> dataLengthMap = new HashMap<>();
    	Map<Integer,Object> dataValueMap = new HashMap<>();
    	int index1 = index0 + len1;
    	for (int i = 1; i <= count; i++) {
    		//数据单元标识 2
    		{
    			Double data = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
    					index1, len2, DataAnalyseWayEnum.UInt16);
    			dataSignalMap.put(i, data.intValue());
        		readData.setDataSignalMap(dataSignalMap);
        		index1 += len2;
    		}
    		//数据单元长度 1
    		{
    			Double data = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
    					index1, len1, DataAnalyseWayEnum.UInt8);
    			dataLengthMap.put(i, data.intValue());
        		readData.setDataLengthMap(dataLengthMap);
        		index1 += len1;
    		}
    		//数据单元值 N
    		{
    			Integer valueLen = dataLengthMap.get(i);
    			Object data = (Object) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
    					index1, valueLen, DataAnalyseWayEnum.VarLength);
    			dataValueMap.put(i, data);
        		readData.setDataValueMap(dataValueMap);
        		index1 += valueLen;
    		}
    	}
		log.info("上传实时数据(0x0d)");
		log.info("数据单元个数 :{}",readData.getDataCount());
		for (int i = 1; i <= count; i++) {
			log.info("数据单元标识 :{}",readData.getDataSignalMap().get(i));
			log.info("数据单元长度 :{}",readData.getDataLengthMap().get(i));
			log.info("数据单元值 :{}",readData.getDataValueMap().get(i));
		}
		return readData;
    }

	@Override
	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
		ReadOrWriteData readData = new ReadOrWriteData();
		KhProtocolUtil.setProviderAndField(readData, fullData);
		return signInHandle(fullData,readData);
	}
}