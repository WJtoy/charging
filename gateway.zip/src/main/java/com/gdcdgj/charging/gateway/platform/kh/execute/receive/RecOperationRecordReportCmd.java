package com.gdcdgj.charging.gateway.platform.kh.execute.receive;


import java.util.Calendar;

import com.gdcdgj.charging.api.vo.srv2gw.AlarmInfo;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.OperationRecord;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.kh.protocol.KhProtocolUtil;
import com.gdcdgj.charging.gateway.platform.kh.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;

import lombok.extern.slf4j.Slf4j;

/**
 * 操作记录内容上报(0x10)
 * <p>发送报文 </p>
 *
 * @author ydc
 * @since 2016-11-14 下午3:35:46
 */
@Slf4j
public class RecOperationRecordReportCmd implements BaseReceiveCmdExecute{

    /**
     * 操作记录内容上报(0x10)
     *
     * @param fullData
     * @return
     * @throws Exception
     * @author ouxx
     * @date 2016-11-3 下午1:50:21
     */
    public static OperationRecord recHeartbeatReport(byte[] fullData,OperationRecord operationRecord) {
        try {
        	final byte[] dataAfterCmdSeq = KhProtocolUtil.getDataField(fullData);
            // 操作记录内容 4
            final byte index0 = 0;
            {
                Double operationContext = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index0, 4, DataAnalyseWayEnum.UInt32);
                operationRecord.setOperationContext(operationContext.intValue());
            }
            // 操作时间 7
            final byte index1 = index0 + 4;
            {
                Calendar operationTime = (Calendar) ProtocolDataGenerator.getCalendar(index1, dataAfterCmdSeq);
                operationRecord.setOperationTime(operationTime);
            }
            // 操作记录值 4
            final byte index2 = index1 + 7;
            {
                Double operationValue = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index2, 4, DataAnalyseWayEnum.UInt32);
                operationRecord.setOperationValue(operationValue.intValue());
            }
            log.info("操作记录内容上报(0x10)");
            log.info("操作记录内容 :" + operationRecord.getOperationContext());
            log.info("操作时间 :" + operationRecord.getOperationTime());
            log.info("操作记录值  :" + operationRecord.getOperationValue());
            return operationRecord;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return operationRecord;
    }

	@Override
	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
		OperationRecord operationRecord =new OperationRecord();
		KhProtocolUtil.setProviderAndField(operationRecord, fullData);
		return recHeartbeatReport(fullData,operationRecord);
	}
    
}
