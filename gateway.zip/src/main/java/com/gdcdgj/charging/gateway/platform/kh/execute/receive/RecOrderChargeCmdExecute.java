package com.gdcdgj.charging.gateway.platform.kh.execute.receive;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.OrderPileCtrl;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.platform.kh.protocol.KhProtocolUtil;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;

import lombok.extern.slf4j.Slf4j;

/**
 * 预约充电确认(0x89)
 * 
 * @author ydc
 * @date 2020/6/1 17:23
 * @since JDK 1.8
 */
@Slf4j
public class RecOrderChargeCmdExecute implements BaseReceiveCmdExecute {
   
	/**
     * 接收报文数据的执行方法
     *
     * @param fullData
     * @return
     * @throws Exception
     * @author ouxx
     * @date 2016-11-14 下午5:09:35
     */
    public DataBaseVo signInHandle(byte[] fullData,OrderPileCtrl orderPileCtrl) throws Exception {
    	byte[] dataAfterCmdSeq = KhProtocolUtil.getDataField(fullData);
    	
    	final int len1 = 1;
    	final int len20 = 20;
    	// 用户账号 20
    	final int index0 = 0;
    	{
    		String userNo = (String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
					index0, len20, DataAnalyseWayEnum.StrASCII);
    		orderPileCtrl.setUserNo(userNo);
    	}
    	// 预约操作 1
    	final int index1 = index0 + len20;
    	{
    		Double orderOperation = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
					index1, len1, DataAnalyseWayEnum.UInt8);
    		orderPileCtrl.setOrderOperation(orderOperation.intValue());
    	}
    	//成功标识 1
    	final int index2 = index1 + len1;
    	{
    		Double successSignal = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
					index2, len1, DataAnalyseWayEnum.UInt8);
    		orderPileCtrl.setSuccessSignal(successSignal.intValue());
    	}
		log.info("预约充电确认(0x89)");
		log.info("成功标识 :{}",orderPileCtrl.getSuccessSignal());
		log.info("预约操作 :{}",orderPileCtrl.getOrderOperation());
		log.info("用户账号 :{}",orderPileCtrl.getUserNo());
		return orderPileCtrl;
    }

	@Override
	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
		OrderPileCtrl orderPileCtrl = new OrderPileCtrl();
		KhProtocolUtil.setProviderAndField(orderPileCtrl, fullData);
		return signInHandle(fullData,orderPileCtrl);
	}
}