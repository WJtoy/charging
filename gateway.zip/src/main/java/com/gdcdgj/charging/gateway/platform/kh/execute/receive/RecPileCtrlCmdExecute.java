package com.gdcdgj.charging.gateway.platform.kh.execute.receive;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.PileCtrl;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.platform.kh.protocol.KhProtocolUtil;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;

import lombok.extern.slf4j.Slf4j;

/**
 * 启停充电确认(0x8a)
 * 
 * @author ydc
 * @date 2020/6/1 17:23
 * @since JDK 1.8
 */
@Slf4j
public class RecPileCtrlCmdExecute implements BaseReceiveCmdExecute {
   
	/**
     * 接收报文数据的执行方法
     *
     * @param fullData
     * @return
     * @throws Exception
     * @author ouxx
     * @date 2016-11-14 下午5:09:35
     */
    public DataBaseVo signInHandle(byte[] fullData,PileCtrl pileCtrl) throws Exception {
    	byte[] dataAfterCmdSeq = KhProtocolUtil.getDataField(fullData);
    	
    	final int len1 = 1;
    	final int len4 = 4;
    	final int len20 = 20;
    	// 用户账号 20
    	final int index0 = 0;
    	{
    		String userNo = (String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
					index0, len20, DataAnalyseWayEnum.StrASCII);
    		pileCtrl.setUserNo(userNo);
    	}
    	// 类型操作 1
    	final int index1 = index0 + len20;
    	{
    		Double operationType = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
					index1, len1, DataAnalyseWayEnum.UInt8);
    		pileCtrl.setOperationType(operationType.intValue());
    	}
    	// 充电流水号 4
    	final int index2 = index1 + len1;
    	{
    		Double serialNo = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
					index2, len4, DataAnalyseWayEnum.UInt32);
    		pileCtrl.setSerialNo(serialNo.toString());
    	}
    	// 确认标识 1
    	final int index3 = index2 + len4;
    	{
    		Double ResultCode = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
					index3, len1, DataAnalyseWayEnum.UInt8);
    		pileCtrl.setResultCode(ResultCode.intValue());
    	}
		log.info("启停充电确认(0x8a)");
		log.info("确认标识 :{}",pileCtrl.getResultCode());
		log.info("操作类型 :{}",pileCtrl.getOperationType());
		log.info("用户账号 :{}",pileCtrl.getUserNo());
		log.info("充电流水号 :{}",pileCtrl.getSerialNo());
		return pileCtrl;
    }

	@Override
	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
		PileCtrl pileCtrl = new PileCtrl();
		KhProtocolUtil.setProviderAndField(pileCtrl, fullData);
		return signInHandle(fullData,pileCtrl);
	}
}