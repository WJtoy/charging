package com.gdcdgj.charging.gateway.platform.kh.execute.receive;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.SignIn;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.platform.kh.protocol.KhProtocolUtil;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;

import lombok.extern.slf4j.Slf4j;

/**
 * 登陆
 * 
 * @author ydc
 * @date 2020/6/1 17:23
 * @since JDK 1.8
 */
@Slf4j
public class RecSignInCmdExecute implements BaseReceiveCmdExecute {
   
	/**
     * 接收报文数据的执行方法
     *
     * @param fullData
     * @return
     * @throws Exception
     * @author ouxx
     * @date 2016-11-14 下午5:09:35
     */
    public DataBaseVo signInHandle(byte[] fullData,SignIn signIn) throws Exception {
    	byte[] dataAfterCmdSeq = KhProtocolUtil.getDataField(fullData);
    	
    	final int len20 = 20;
    	final int len1 = 1;
    	
    	//总枪数
    	final int index0 = 0;
    	{
    		Double connectCount = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
					index0, len1, DataAnalyseWayEnum.UInt8);
			signIn.setConnectCount(connectCount.intValue());
    	}
		//父设备串号 20
		final int index1 = index0 + len1;
		{
			String pileCode = (String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
					index1, len20, DataAnalyseWayEnum.StrASCII);
			signIn.setPileCode(pileCode);
		}
		
		log.info("科华登录上报(0x01)");
		log.info("总枪数 ：{}",signIn.getConnectCount());
		log.info("父设备串号 :{}",signIn.getPileCode());
		return signIn;
    }

	@Override
	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
		SignIn signIn = new SignIn();
		KhProtocolUtil.setProviderAndField(signIn, fullData);
		return signInHandle(fullData,signIn);
	}
}