package com.gdcdgj.charging.gateway.platform.kh.execute.receive;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.TimeSyn;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.kh.protocol.KhProtocolUtil;
import com.gdcdgj.charging.gateway.platform.kh.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;


/**
 * 充电桩时间同步应答(0x9b)
	 * <p>充电桩收到中心监控系统 “充电桩时间同步”报文后，设置本地时钟时间，
	 * 以“充电桩时间同步应答“报文的格式，进行相关信息的上传应答
 * @author ouxx
 * @since 2016-11-14 下午6:04:07
 *
 */
public class RecTimeSynRespCmd implements BaseReceiveCmdExecute {

	@Override
	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
		TimeSyn timeSyn = new TimeSyn();
		KhProtocolUtil.setProviderAndField(timeSyn, fullData);
		return recTimeSynResp(fullData, timeSyn);
	}

	/**
	 * 充电桩时间同步应答(0x9b)
	 * <p>充电桩收到中心监控系统 “充电桩时间同步”报文后，设置本地时钟时间，
	 * 以“充电桩时间同步应答“报文的格式，进行相关信息的上传应答
	 * @param fullData
	 * @return
	 * @author ouxx
	 * @date 2016-11-11 下午3:19:22
	 */
	public static TimeSyn recTimeSynResp(byte[] fullData, TimeSyn timeSyn){
		byte[] dataAfterCmdSeq = KhProtocolUtil.getDataField(fullData);
		//获取时间
		timeSyn.setSuccessSignal(((Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, 0, 1, DataAnalyseWayEnum.UInt8)).intValue());
		return timeSyn;
	}
}
