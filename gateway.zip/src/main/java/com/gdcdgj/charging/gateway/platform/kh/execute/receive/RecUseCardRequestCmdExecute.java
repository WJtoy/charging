package com.gdcdgj.charging.gateway.platform.kh.execute.receive;

import com.gdcdgj.charging.api.vo.srv2gw.CardRequest;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.platform.kh.protocol.KhProtocolUtil;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;

import lombok.extern.slf4j.Slf4j;

/**
 * 桩上传刷卡请求(0x8c)
 * 
 * @author ydc
 * @date 2020/6/1 17:23
 * @since JDK 1.8
 */
@Slf4j
public class RecUseCardRequestCmdExecute implements BaseReceiveCmdExecute {
   
	/**
     * 接收报文数据的执行方法
     *
     * @param fullData
     * @return
     * @throws Exception
     * @author ouxx
     * @date 2016-11-14 下午5:09:35
     */
    public DataBaseVo signInHandle(byte[] fullData,CardRequest cardRequest) throws Exception {
    	byte[] dataAfterCmdSeq = KhProtocolUtil.getDataField(fullData);
    	
    	final int len1 = 1;
    	final int len16 = 16;
    	final int len20 = 20;
    	final int len32 = 32;
    	// 卡类型 1
    	final int index0 = 0;
    	{
    		Double cardType = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
					index0, len1, DataAnalyseWayEnum.UInt8);
    		cardRequest.setCardType(cardType.intValue());
    	}
    	// 用户账号 20
    	final int index1 = index0 +len1;
    	{
    		String userNo = (String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
					index1, len20, DataAnalyseWayEnum.StrASCII);
    		cardRequest.setUserNo(userNo);
    	}
    	// 用户密码 32
    	final int index2 = index1 + len20;
    	{
    		String password = (String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
					index2, len32, DataAnalyseWayEnum.StrASCII);
    		cardRequest.setPassword(password);
    	}
    	// 卡唯一id 16
    	final int index3 = index2 + len32;
    	{
    		String cardNo = (String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
					index3, len16, DataAnalyseWayEnum.StrASCII);
    		cardRequest.setCardNo(cardNo);
    	}
    	// 操作类型 16
    	final int index4 = index3 + len16;
    	{
    		Double operationType = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq,
					index4, len1, DataAnalyseWayEnum.UInt8);
    		cardRequest.setOperationType(operationType.intValue());
    	}
		log.info("桩上传刷卡请求(0x8c)");
		log.info("卡类型 :{}",cardRequest.getCardType());
		log.info("用户账号 :{}",cardRequest.getUserNo());
		log.info("用户密码 :{}",cardRequest.getPassword());
		log.info("卡唯一id :{}",cardRequest.getCardNo());
		log.info("操作类型 :{}",cardRequest.getOperationType());
		return cardRequest;
    }

	@Override
	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
		CardRequest cardRequest = new CardRequest();
		KhProtocolUtil.setProviderAndField(cardRequest, fullData);
		return signInHandle(fullData,cardRequest);
	}
}