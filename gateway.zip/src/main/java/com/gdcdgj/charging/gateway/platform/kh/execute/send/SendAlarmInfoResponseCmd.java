package com.gdcdgj.charging.gateway.platform.kh.execute.send;

import com.gdcdgj.charging.api.vo.srv2gw.AlarmInfo;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.kh.protocol.KhCmdEnum;
import com.gdcdgj.charging.gateway.platform.kh.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.platform.kw.protocol.KwCmdEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;

import lombok.extern.slf4j.Slf4j;

/**
 * 服务器告警信息应答(0x8f)
 * <p>发送告警信息上报应答</p>
 * @author ydc
 * @since
 *
 */
@Slf4j
public class SendAlarmInfoResponseCmd implements BaseSendCmdExecute {

	/**
	 * 服务器告警信息应答(0x8f)
	 * @param connectorNo
	 * @param memberId
	 * @param cmdSeq
	 * @param vo
	 */
	public byte[] generateSendDatas(int connectorNo, DataBaseVo vo) {
		AlarmInfo info = (AlarmInfo) vo;
		// 告警信息应答为4个空字节
		byte[] datas = new byte[9];
		//确认标识 1
		final int index0 = 0;
        {
        	info.setSuccessSignal(1);
            int response = info.getSuccessSignal() > 0 ? 1 : 0;
            byte[] data = DataAnalyzer.analyseCommandData(response, DataAnalyseWayEnum.UInt8);
            System.arraycopy(data, 0, datas,index0,1);
        }
        // 告警点 1
        final byte index1 = index0 + 1;
        {
        	byte[] data = DataAnalyzer.analyseCommandData(info.getAlarmStation(), DataAnalyseWayEnum.UInt8);
            System.arraycopy(data, 0, datas,index1,1);
        }
        // 告警开始时间 7
        final byte index2 = index1 + 1;
        {
        	byte[] data = ProtocolDataGenerator.calendar2ByteArray(info.getAlarmStartTime());
            System.arraycopy(data, 0, datas,index2,1);
        }
		log.info("服务器告警信息应答(0x8f)");
        log.info("数据长度 :" + (datas.length == 9 ? "正常" : "出错"));
		// 发送报文
		return ProtocolDataGenerator.sendOneData_KH(datas, KhCmdEnum.ALARM_RECORD_RESP,vo);
	}

	@Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		return generateSendDatas(dataVo.getConnectorNo(),dataVo);
	}

}
