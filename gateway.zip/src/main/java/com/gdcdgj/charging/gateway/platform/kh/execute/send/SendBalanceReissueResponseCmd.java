package com.gdcdgj.charging.gateway.platform.kh.execute.send;

import com.gdcdgj.charging.api.vo.srv2gw.AlarmInfo;
import com.gdcdgj.charging.api.vo.srv2gw.BalanceReissue;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.kh.protocol.KhCmdEnum;
import com.gdcdgj.charging.gateway.platform.kh.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.platform.kw.protocol.KwCmdEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;

import lombok.extern.slf4j.Slf4j;

/**
 * 服务器下发补发金额(0x1c)
 * 
 * @author ydc
 * @since
 *
 */
@Slf4j
public class SendBalanceReissueResponseCmd implements BaseSendCmdExecute {

	/**
	 * 服务器下发补发金额(0x1c)
	 * @param connectorNo
	 * @param memberId
	 * @param cmdSeq
	 * @param vo
	 */
	public byte[] generateSendDatas(int connectorNo, DataBaseVo vo) {
		BalanceReissue balanceReissue =new BalanceReissue();
		// 告警信息应答为4个空字节
		byte[] datas = new byte[24];
		// 用户卡号  20
		final int index0 = 0;
        {
            String userNo = balanceReissue.getUserNo() == null ? "" : balanceReissue.getUserNo();
            byte[] data = DataAnalyzer.analyseCommandData(userNo, DataAnalyseWayEnum.StrASCII);
            System.arraycopy(data, 0, datas,index0,20);
        }
        // 充电金额 fen 4
        final byte index1 = index0 + 20;
        {
        	byte[] data = DataAnalyzer.analyseCommandData(balanceReissue.getMoney(), DataAnalyseWayEnum.UInt32);
            System.arraycopy(data, 0, datas,index1,4);
        }
		log.info("服务器下发补发金额(0x1c)");
        log.info("数据长度 :" + (datas.length == 24 ? "正常" : "出错"));
		// 发送报文
		return ProtocolDataGenerator.sendOneData_KH(datas, KhCmdEnum.BALANCE_REISSUE_SET,vo);
	}

	@Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		return generateSendDatas(dataVo.getConnectorNo(),dataVo);
	}

}
