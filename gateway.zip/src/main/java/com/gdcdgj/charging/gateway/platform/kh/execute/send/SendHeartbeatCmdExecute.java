package com.gdcdgj.charging.gateway.platform.kh.execute.send;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.HeartBeat;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.kh.protocol.KhCmdEnum;
import com.gdcdgj.charging.gateway.platform.kh.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;

import lombok.extern.slf4j.Slf4j;

/**
 * 服务器系统心跳包应答(0x82)
 * <p>发送心跳包信息上报应答</p>
 *
 * @author Changliang Tao
 * @date 2020/4/30 16:14
 * @since JDK 1.8
 */
@Slf4j
public class SendHeartbeatCmdExecute implements BaseSendCmdExecute {
    
	/**
     * 对象拼接成报文
     *
     * @param dataBaseVo
     * @return byte[]
     * @throws
     * @author Changliang Tao
     * @date 2020/4/26 17:38
     */
    @Override
    public byte[] sendCmdExecute(DataBaseVo dataBaseVo) {
        HeartBeat heartBeat = (HeartBeat) dataBaseVo;
        byte[] datas = new byte[1];
        //确认标识
        heartBeat.setResponse(1);
        int response = heartBeat.getResponse()>0 ? 1 : 0;
        //序号确认
        datas = DataAnalyzer.analyseCommandData(response, DataAnalyseWayEnum.UInt8);
        log.info("服务器系统心跳包应答(0x82)");
        log.info("数据长度 :{}",datas.length);
        return ProtocolDataGenerator.sendOneData_KH(datas, KhCmdEnum.HEART_BEAT_REPORT_RESP,dataBaseVo);
    }
}