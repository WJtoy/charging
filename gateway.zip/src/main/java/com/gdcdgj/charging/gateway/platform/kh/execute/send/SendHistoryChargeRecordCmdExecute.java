package com.gdcdgj.charging.gateway.platform.kh.execute.send;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.HeartBeat;
import com.gdcdgj.charging.api.vo.srv2gw.HistoryChargeRecord;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.kh.protocol.KhCmdEnum;
import com.gdcdgj.charging.gateway.platform.kh.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;

import lombok.extern.slf4j.Slf4j;

/**
 * 平台下发历史记录确认(0x8e)
 *
 * @author Changliang Tao
 * @date 2020/4/30 16:14
 * @since JDK 1.8
 */
@Slf4j
public class SendHistoryChargeRecordCmdExecute implements BaseSendCmdExecute {
    
	/**
     * 对象拼接成报文
     *
     * @param dataBaseVo
     * @return byte[]
     * @throws
     * @author Changliang Tao
     * @date 2020/4/26 17:38
     */
    public byte[] generateSendDatas(DataBaseVo vo) {
    	HistoryChargeRecord info = (HistoryChargeRecord) vo;
        byte[] datas = new byte[1];
        final int index0 = 0;
        //确认标识 1
        {
        	info.setSuccessSignal(1);
            int response = info.getSuccessSignal() > 0 ? 1 : 0;
            byte[] data = DataAnalyzer.analyseCommandData(response, DataAnalyseWayEnum.UInt8);
            System.arraycopy(data, 0, datas,index0,1);
        }
        // 用户账号 20字节
     	final int index1 = index0 + 1;
     	{
     		byte[] cardNum = DataAnalyzer.analyseCommandData(info.getChargeNo(), DataAnalyseWayEnum.StrASCII);
     		byte[] dataPoxy = new byte[20];
     		System.arraycopy(cardNum, 0, dataPoxy,index0,cardNum.length);
     		System.arraycopy(dataPoxy, 0, datas,index1,dataPoxy.length);
     	}
     	// 充电流水号 4字节
     	final int index2 = index1 +20;
     	{
     		byte[] serialNo = DataAnalyzer.analyseCommandData(Integer.valueOf(info.getSerialNum()), DataAnalyseWayEnum.UInt32);
     		System.arraycopy(serialNo, 0, datas,index2,4);
     	}
     	// 充电放式 1
     	final int index3 = index2 +4;
     	{
     		byte[] startType = DataAnalyzer.analyseCommandData(info.getStartType(), DataAnalyseWayEnum.UInt8);
     		System.arraycopy(startType, 0, datas,index3,1);
     	}
        log.info("平台下发历史记录确认(0x8e)");
        log.info("数据长度 :{}",datas.length);
        return ProtocolDataGenerator.sendOneData_KH(datas, KhCmdEnum.CHARGING_RECORD_RESP,vo);
    }

	@Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		return generateSendDatas(dataVo);
	}
}