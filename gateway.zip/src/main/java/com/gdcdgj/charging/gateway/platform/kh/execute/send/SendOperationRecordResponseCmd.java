package com.gdcdgj.charging.gateway.platform.kh.execute.send;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.OperationRecord;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.kh.protocol.KhCmdEnum;
import com.gdcdgj.charging.gateway.platform.kh.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;

import lombok.extern.slf4j.Slf4j;

/**
 * 服务器操作记录应答(0x90)
 * <p>发送告警信息上报应答</p>
 * @author ydc
 * @since
 *
 */
@Slf4j
public class SendOperationRecordResponseCmd implements BaseSendCmdExecute {

	/**
	 * 服务器操作记录应答(0x90)
	 * @param connectorNo
	 * @param memberId
	 * @param cmdSeq
	 * @param vo
	 */
	public byte[] generateSendDatas(DataBaseVo vo) {
		OperationRecord operationRecord = (OperationRecord) vo;
		//确认标识 1
        //int response = operationRecord.getSuccessSignal() > 0 ? 1 : 0;
        int response = 1;
        byte[] datas = DataAnalyzer.analyseCommandData(response, DataAnalyseWayEnum.UInt8);
		log.info("服务器操作记录应答(0x90)");
        log.info("数据长度 :" + (datas.length == 1 ? "正常" : "出错"));
		// 发送报文
		return ProtocolDataGenerator.sendOneData_KH(datas, KhCmdEnum.OPERATION_RECORD_RESP,vo);
	}

	@Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		return generateSendDatas(dataVo);
	}
}
