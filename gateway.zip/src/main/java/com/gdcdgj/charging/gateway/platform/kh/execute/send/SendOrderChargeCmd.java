package com.gdcdgj.charging.gateway.platform.kh.execute.send;

import java.util.Calendar;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.OrderPileCtrl;
import com.gdcdgj.charging.api.vo.srv2gw.SignIn;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.kh.protocol.KhCmdEnum;
import com.gdcdgj.charging.gateway.platform.kh.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;

import lombok.extern.slf4j.Slf4j;

/**
 * 预约充电下发(0x09)
 * 
 * @author ydc
 * @since 2020/06/01
 */
@Slf4j
public class SendOrderChargeCmd implements BaseSendCmdExecute {

	/**
	 * 预约充电下发(0x09)
	 */
	public byte[] generateSendDatas(DataBaseVo vo) {
		OrderPileCtrl ctrl = (OrderPileCtrl) vo;
		//预约充电命令
		byte[] datas = new byte[69];
		final int len1 = 1;
		final int len4 = 4;
		final int len7 = 7;
		final int len17 = 17;
		final int len20 = 20;
		
		// 用户账号 20字节
		final int index0 = 0;
		{
			byte[] cardNum = DataAnalyzer.analyseCommandData(ctrl.getUserNo(), DataAnalyseWayEnum.StrASCII);
			byte[] dataPoxy = new byte[20];
			System.arraycopy(cardNum, 0, dataPoxy,index0,cardNum.length);
			System.arraycopy(dataPoxy, 0, datas,index0,len20);
		}
		// 充电流水号 4字节
		final int index1 = index0 +len20;
		{
			byte[] serialNo = DataAnalyzer.analyseCommandData(ctrl.getSerialNo(), DataAnalyseWayEnum.UInt32);
			System.arraycopy(serialNo, 0, datas,index1,len4);
		}
		// 预约操作(1-确认 2-取消) 1字节
		final int index2 = index1 +len4;
		{
			byte[] operation = DataAnalyzer.analyseCommandData(ctrl.getOrderOperation(), DataAnalyseWayEnum.UInt8);
			System.arraycopy(operation, 0, datas,index2,len1);
		}
		// 预约充电时间 7字节
		final int index3 = index2 +len1;
		{
			byte[] orderChargeTime = ProtocolDataGenerator.calendar2ByteArray(ctrl.getOrderChargeTime());
			System.arraycopy(orderChargeTime, 0, datas,index3,len7);
		}
		// y预约车牌号 20字节
		final int index4 = index3 + len7;
		{
			byte[] carLPN = DataAnalyzer.analyseCommandData(ctrl.getCarLPN(), DataAnalyseWayEnum.StrASCII);
			byte[] dataPoxy = new byte[20];
			System.arraycopy(carLPN, 0, dataPoxy,index0,carLPN.length);
			System.arraycopy(dataPoxy, 0, datas,index4,len20);
		}
		// 预约车VIN号 17字节
		final int index5 =index4 + len20;
		{
			byte[] carVIN = DataAnalyzer.analyseCommandData(ctrl.getCarVIN(), DataAnalyseWayEnum.StrASCII);
			byte[] dataPoxy = new byte[17];
			System.arraycopy(carVIN, 0, dataPoxy,index0,carVIN.length);
			System.arraycopy(dataPoxy, 0, datas,index5,len17);
		}
		log.info("预约充电下发(0x09)");
		log.info("数据长度  :{}",datas.length == 69 ? "正常" : "失败");
		return ProtocolDataGenerator.sendOneData_KH(datas, KhCmdEnum.ORDER_CHARGE_RESP, vo);
	}
	
	@Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		return generateSendDatas(dataVo);
	}
}
