package com.gdcdgj.charging.gateway.platform.kh.execute.send;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.PileCtrl;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.kh.protocol.KhCmdEnum;
import com.gdcdgj.charging.gateway.platform.kh.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;

import lombok.extern.slf4j.Slf4j;

/**
 * 启动停止控制充电下发(0x0a)
 * 
 * @author ydc
 * @since 2020/06/01
 */
@Slf4j
public class SendPileCtrlCmd implements BaseSendCmdExecute {

	/**
	 * 启动停止控制充电下发(0x0a)
	 */
	public byte[] generateSendDatas(DataBaseVo vo) {
		PileCtrl ctrl = (PileCtrl) vo;
		//启动停止控制充电
		byte[] datas = new byte[69];
		final int len1 = 1;
		final int len4 = 4;
		final int len2 = 2;
		final int len20 = 20;
		
		// 操作类型(1-启动认 2-停止) 1字节
		final int index0 = 0;
		{
			byte[] operation = DataAnalyzer.analyseCommandData(ctrl.getOperationType(), DataAnalyseWayEnum.UInt8);
			System.arraycopy(operation, 0, datas,index0,len1);
		}
		// 辅源电压0-默认 1-24V 1字节
		final int index1 = index0 +len1;
		{
			if (ctrl.getVoltage() == null) ctrl.setVoltage(0);
			byte[] voltage = DataAnalyzer.analyseCommandData(ctrl.getVoltage(), DataAnalyseWayEnum.UInt8);
			System.arraycopy(voltage, 0, datas,index1,len1);
		}
		// 充电策略 1字节
		final int index2 = index1 + len1;
		{
			if (ctrl.getChargePolicy() == null) ctrl.setChargePolicy(0);
			byte[] chargePolicy = DataAnalyzer.analyseCommandData(ctrl.getChargePolicy(), DataAnalyseWayEnum.UInt8);
			System.arraycopy(chargePolicy, 0, datas,index2,len1);
		}
		// 充电策略参数 4字节
		final int index3 =index2 + len1;
		{
			if (ctrl.getChargePolicyParam() == null) ctrl.setChargePolicyParam(0);
			byte[] chargePolicyParam = DataAnalyzer.analyseCommandData(ctrl.getChargePolicyParam(), DataAnalyseWayEnum.UInt32);
			System.arraycopy(chargePolicyParam, 0, datas,index3,len4);
		}
		// 用户账号 20字节
		final int index4 =index3 + len4;
		{
			if (ctrl.getUserNo() == null) ctrl.setUserNo("");
			byte[] userNo = DataAnalyzer.analyseCommandData(ctrl.getUserNo(), DataAnalyseWayEnum.StrASCII);
			byte[] dataproxy = new byte[20];
			System.arraycopy(userNo, 0, dataproxy,index0,userNo.length);
			System.arraycopy(dataproxy, 0, datas,index4,len20);
		}
		// 充电流水号 4字节
		final int index5 =index4 + len20;
		{
			if (ctrl.getSerialNo() == null) ctrl.setSerialNo("");
			byte[] serialNo = DataAnalyzer.analyseCommandData(Integer.valueOf(ctrl.getSerialNo()), DataAnalyseWayEnum.UInt32);
			System.arraycopy(serialNo, 0, datas,index5,len4);
		}
		// 余额 4字节
		final int index6 =index5 + len4;
		{
			if (ctrl.getBalance() == null) ctrl.setBalance(0.0);
			byte[] balance = DataAnalyzer.analyseCommandData(ctrl.getBalance(), DataAnalyseWayEnum.UInt32);
			System.arraycopy(balance, 0, datas,index6,len4);
		}
		//停止验证码 手机号后四位
		final int index7 =index6 + len4;
		{
			if (ctrl.getStopVolidate() == null) ctrl.setStopVolidate(0);
			byte[] stopVolidate = DataAnalyzer.analyseCommandData(ctrl.getBalance(), DataAnalyseWayEnum.UInt16);
			System.arraycopy(stopVolidate, 0, datas,index7,len2);
		}
		log.info("启动停止控制充电下发(0x0a)");
		log.info("数据长度  :{}",datas.length == 37 ? "正常" : "失败");
		return ProtocolDataGenerator.sendOneData_KH(datas, KhCmdEnum.ORDER_CHARGE_RESP, vo);
	}
	
	@Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		return generateSendDatas(dataVo);
	}
}
