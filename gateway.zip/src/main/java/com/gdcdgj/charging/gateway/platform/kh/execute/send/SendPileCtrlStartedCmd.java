package com.gdcdgj.charging.gateway.platform.kh.execute.send;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.PileCtrl;
import com.gdcdgj.charging.api.vo.srv2gw.PileStartedRst;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.kh.protocol.KhCmdEnum;
import com.gdcdgj.charging.gateway.platform.kh.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;

import lombok.extern.slf4j.Slf4j;

/**
 * 启动充电结果上传回复(0x8b)
 * 
 * @author ydc
 * @since 2020/06/01
 */
@Slf4j
public class SendPileCtrlStartedCmd implements BaseSendCmdExecute {

	/**
	 * 启动充电结果上传回复(0x8b)
	 * 
	 * @param vo
	 * @return
	 */
	public byte[] generateSendDatas(DataBaseVo vo) {
		PileStartedRst ctrl = (PileStartedRst) vo;
		//启动停止控制充电
		byte[] datas = new byte[24];
		final int len4 = 4;
		final int len20 = 20;
		
		// 用户账号 20字节
		final int index0 = 0;
		{
			if (ctrl.getUserNo() == null) ctrl.setUserNo("");
			byte[] userNo = DataAnalyzer.analyseCommandData(ctrl.getUserNo(), DataAnalyseWayEnum.StrASCII);
			byte[] dataproxy = new byte[20];
			System.arraycopy(userNo, 0, dataproxy,index0,userNo.length);
			System.arraycopy(dataproxy, 0, datas,index0,len20);
		}
		// 充电流水号 4字节
		final int index1 =index0 + len20;
		{
			if (ctrl.getSerialNo() == null) ctrl.setSerialNo(0);
			byte[] serialNo = DataAnalyzer.analyseCommandData(ctrl.getSerialNo(), DataAnalyseWayEnum.UInt32);
			System.arraycopy(serialNo, 0, datas,index1,len4);
		}
		log.info("启动充电结果上传回复(0x8b)");
		log.info("数据长度  :{}",datas.length == 24 ? "正常" : "失败");
		return ProtocolDataGenerator.sendOneData_KH(datas, KhCmdEnum.PILE_START_RESP, vo);
	}
	
	@Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		return generateSendDatas(dataVo);
	}
}
