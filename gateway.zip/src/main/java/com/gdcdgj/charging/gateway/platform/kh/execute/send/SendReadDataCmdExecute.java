package com.gdcdgj.charging.gateway.platform.kh.execute.send;

import java.util.Map;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.ReadOrWriteData;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.indexAndLen.H2T_ChargingRecordResponseIndexAndLen;
import com.gdcdgj.charging.gateway.platform.kh.protocol.KhCmdEnum;
import com.gdcdgj.charging.gateway.platform.kh.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;

import lombok.extern.slf4j.Slf4j;

/**
 * 平台下发读取终端数据(0x03)
 *
 * @author Changliang Tao
 * @date 2020/4/30 16:14
 * @since JDK 1.8
 */
@Slf4j
public class SendReadDataCmdExecute implements BaseSendCmdExecute {
    
	/**
     * 对象拼接成报文
     *
     * @param dataBaseVo
     * @return byte[]
     * @throws
     * @author Changliang Tao
     * @date 2020/4/26 17:38
     */
    @Override
    public byte[] sendCmdExecute(DataBaseVo dataBaseVo) {
        ReadOrWriteData readData = (ReadOrWriteData) dataBaseVo;
        Integer count = readData.getDataCount();
        final int len1 = 1;
        final int len2 = 2;
        byte[] datas = new byte[1 + 2*count];
        // 数据单元个数
        final int index0 = 0;
        {
			byte[] type = DataAnalyzer.analyseCommandData(count, DataAnalyseWayEnum.UInt8);
			System.arraycopy(type, 0, datas, index0 , len1);
		}
        // 数据单元标识
        Map<Integer,Integer> maps = readData.getDataSignalMap();
        int index1 = index0 + len1;
        for (int i = 1; i <= count; i++) {
            {
    			byte[] type = DataAnalyzer.analyseCommandData(maps.get(i), DataAnalyseWayEnum.UInt16);
    			System.arraycopy(type, 0, datas, index1 ,len2);
    			index1 += len2;
    		}
		}
        log.info("平台下发读取终端数据(0x03)");
        log.info("数据长度 :{}",datas.length);
        return ProtocolDataGenerator.sendOneData_KH(datas, KhCmdEnum.READ_DATA,dataBaseVo);
    }
}