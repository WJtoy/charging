package com.gdcdgj.charging.gateway.platform.kh.execute.send;

import java.util.Calendar;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.SignIn;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.kh.protocol.KhCmdEnum;
import com.gdcdgj.charging.gateway.platform.kh.protocol.ProtocolDataGenerator;

import lombok.extern.slf4j.Slf4j;

/**
 * 平台下发登录确认帧(0x81)
 * 
 * @author ydc
 * @since 2020/06/01
 */
@Slf4j
public class SendSignInCmd implements BaseSendCmdExecute {

	/**
	 * 平台下发登录确认帧(0x81)
	 */
	public byte[] generateSendDatas(DataBaseVo vo) {
		SignIn signIn = (SignIn) vo;
		//签到命令
		byte[] datas = new byte[8];
		final int len1 = 1;
		final int len7 = 7;
		
		// 确认表示 1字节
		final int index0 = 0;
		{
			//byte[] cardNum = DataAnalyzer.analyseCommandData(signIn.getCardNum(), DataAnalyseWayEnum.StrASCII);
			byte[] cardNum = new byte[] {0x01};
			System.arraycopy(cardNum, 0, datas,index0,len1);
		}
		// 登陆时间  7字节
		final int index1 = index0 + len1;
		{
			Calendar cal = Calendar.getInstance();
			byte[] type = ProtocolDataGenerator.calendar2ByteArray(cal);
			System.arraycopy(type, 0, datas, index1,len7);
		}
		log.info("平台下发登录确认帧(0x81)");
		log.info("数据长度  :{}",datas);
		return ProtocolDataGenerator.sendOneData_KH(datas, KhCmdEnum.SEND_SIGN_IN_RESP, vo);
	}
	
	@Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		return generateSendDatas(dataVo);
	}
}
