package com.gdcdgj.charging.gateway.platform.kh.execute.send;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.TimeSyn;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.kh.protocol.KhCmdEnum;
import com.gdcdgj.charging.gateway.platform.kh.protocol.ProtocolDataGenerator;

/**
 * 充电桩时间同步(0x1b)
 *
 * @author ouxx
 * @since 2016-11-15 上午8:30:58
 *
 */
public class SendTimeSynCmd implements BaseSendCmdExecute {

	public byte[] generateSendDatas(DataBaseVo vo) {
		TimeSyn timeSyn = (TimeSyn) vo;
		byte[] datas = ProtocolDataGenerator.calendar2ByteArray(timeSyn.getClock());
		return ProtocolDataGenerator.sendOneData_KH(datas, KhCmdEnum.DATE_ACK_SET,vo);
	}

	@Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		return generateSendDatas(dataVo);
	}
	
}
