package com.gdcdgj.charging.gateway.platform.kh.execute.send;

import java.util.Map;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.ReadOrWriteData;
import com.gdcdgj.charging.api.vo.srv2gw.UploadData;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.protocol.indexAndLen.H2T_ChargingRecordResponseIndexAndLen;
import com.gdcdgj.charging.gateway.platform.kh.protocol.KhCmdEnum;
import com.gdcdgj.charging.gateway.platform.kh.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;

import lombok.extern.slf4j.Slf4j;

/**
 * 后台应答确认信息(0x93)
 *
 * @author ydc
 * @date 2020/4/30 16:14
 * @since JDK 1.8
 */
@Slf4j
public class SendUploadDataCmdExecute implements BaseSendCmdExecute {
    
	/**
     * 对象拼接成报文
     *
     * @param dataBaseVo
     * @return byte[]
     * @throws
     * @author Changliang Tao
     * @date 2020/4/26 17:38
     */
    @Override
    public byte[] sendCmdExecute(DataBaseVo dataBaseVo) {
        UploadData uploadData = (UploadData) dataBaseVo;
        final int len1 = 1;
        byte[] datas = new byte[2];
        if(uploadData.getDataId() != null) uploadData.setSuccessSignal(1);
        // 帧id 1
        final int index0 = 0;
        {
			byte[] type = DataAnalyzer.analyseCommandData(uploadData.getDataId(), DataAnalyseWayEnum.UInt8);
			System.arraycopy(type, 0, datas, index0 , len1);
		}
        // 数据单元标识
        final int index1 = index0 + len1;
        {
			byte[] type = DataAnalyzer.analyseCommandData(uploadData.getSuccessSignal(), DataAnalyseWayEnum.UInt8);
			System.arraycopy(type, 0, datas, index1 , len1);
		}
        log.info("后台应答确认信息(0x93)");
        log.info("数据长度 :{}",datas.length);
        return ProtocolDataGenerator.sendOneData_KH(datas, KhCmdEnum.DATA_RESP,dataBaseVo);
    }
}