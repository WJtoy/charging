package com.gdcdgj.charging.gateway.platform.kh.execute.send;

import java.util.Calendar;

import com.gdcdgj.charging.api.vo.srv2gw.CardRequest;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.OrderPileCtrl;
import com.gdcdgj.charging.api.vo.srv2gw.SignIn;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.kh.protocol.KhCmdEnum;
import com.gdcdgj.charging.gateway.platform.kh.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;

import lombok.extern.slf4j.Slf4j;

/**
 * 刷卡请求确认(0x0c)
 * 
 * @author ydc
 * @since 2020/06/01
 */
@Slf4j
public class SendUseCardRquestCmd implements BaseSendCmdExecute {

	/**
	 * 刷卡请求确认(0x0c)
	 */
	public byte[] generateSendDatas(DataBaseVo vo) {
		CardRequest cardRequest = (CardRequest) vo;
		//刷卡请求命令
		byte[] datas = new byte[32];
		final int len1 = 1;
		final int len4 = 4;
		final int len20 = 20;

		// 用户账号 20字节
		final int index0 = 0;
		{
			byte[] cardNum = DataAnalyzer.analyseCommandData(cardRequest.getUserNo(), DataAnalyseWayEnum.StrASCII);
			byte[] dataPoxy = new byte[20];
			System.arraycopy(cardNum, 0, dataPoxy,index0,cardNum.length);
			System.arraycopy(dataPoxy, 0, datas,index0,len20);
		}
		// 卡类型 1字节
		final int index1 = index0 +len20;
		{
			byte[] cardType = DataAnalyzer.analyseCommandData(cardRequest.getCardType(), DataAnalyseWayEnum.UInt8);
			System.arraycopy(cardType, 0, datas,index1,len1);
		}
		// 卡内余额 4字节
		final int index2 = index1 +len1;
		{
			byte[] cardType = DataAnalyzer.analyseCommandData(cardRequest.getBalance().intValue(), DataAnalyseWayEnum.UInt32);
			System.arraycopy(cardType, 0, datas,index2,len4);
		}
		// 卡状态 1字节
		final int index3 = index2 +len4;
		{
			byte[] cardType = DataAnalyzer.analyseCommandData(cardRequest.getCardStatus(), DataAnalyseWayEnum.UInt8);
			System.arraycopy(cardType, 0, datas,index3,len1);
		}
		// 充电流水号 4字节
		final int index4 = index3 +len1;
		{
			byte[] cardType = DataAnalyzer.analyseCommandData(cardRequest.getSerialNo(), DataAnalyseWayEnum.UInt32);
			System.arraycopy(cardType, 0, datas,index4,len4);
		}
		// 停止验证码 2字节
		final int index5 = index4 +len4;
		{
			byte[] cardType = DataAnalyzer.analyseCommandData(cardRequest.getStopVolidate(), DataAnalyseWayEnum.UInt16);
			System.arraycopy(cardType, 0, datas,index5,2);
		}
		log.info("刷卡请求确认(0x0c)");
		log.info("数据长度  :{}",datas.length == 32 ? "正常" : "失败");
		return ProtocolDataGenerator.sendOneData_KH(datas, KhCmdEnum.ORDER_CHARGE_RESP, vo);
	}
	
	@Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		return generateSendDatas(dataVo);
	}
}
