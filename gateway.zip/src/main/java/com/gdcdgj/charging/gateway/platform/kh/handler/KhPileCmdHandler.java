package com.gdcdgj.charging.gateway.platform.kh.handler;


import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.gdcdgj.charging.api.constant.RabbitmqConstant;
import com.gdcdgj.charging.api.vo.srv2gw.ChargeRecordInfo;
import com.gdcdgj.charging.api.vo.srv2gw.ChargeTimeFrameInfo;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.HeartBeat;
import com.gdcdgj.charging.api.vo.srv2gw.ModuleChargingInfo;
import com.gdcdgj.charging.api.vo.srv2gw.PileCtrl;
import com.gdcdgj.charging.api.vo.srv2gw.PileStartedRst;
import com.gdcdgj.charging.api.vo.srv2gw.PlasticParamSet;
import com.gdcdgj.charging.api.vo.srv2gw.SetVoluationPolicy;
import com.gdcdgj.charging.api.vo.srv2gw.SignIn;
import com.gdcdgj.charging.api.vo.srv2gw.StateInfo;
import com.gdcdgj.charging.api.vo.srv2gw.StrParamSet;
import com.gdcdgj.charging.gateway.platform.PileCmdHandler;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecAccountInfoReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecAlarmInfoReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecChargeRecordInfoReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecChargeTimeInfoReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecHeartBeatReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecHistoryChargeRecordInfoReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecModuleInfoResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecPileCtrlStartRstReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecPileCtrlStopRstReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecPileStartedRstReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecPlasticParamRespReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecSetVoluationPolicyResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecSignInResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecStateInfoReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecStrParamRespReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendAccountInfoResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendAlarmInfoResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendChargeRecordInfoResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendChargeTimeInfoResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendHeartbeatReportResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendPileCtrlStartRstRespCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendPileCtrlStopRstRespCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendPileStartedRstRespCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendPlasticParamResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendSetVoluationPolicyRespCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendSignInResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendStateInfoResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendStrParamSetRespCmd;
import com.gdcdgj.charging.gateway.server.handler.ChannelSender;
import com.gdcdgj.charging.gateway.server.handler.H2TServer;

import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import lombok.extern.slf4j.Slf4j;

/**
 * 科华报文处理器
 *
 * @author ydc
 * @date 2020/4/30 14:41
 * @since JDK 1.8
 */
@Component
@Slf4j
public class KhPileCmdHandler implements PileCmdHandler {
	
	@Autowired
	private AmqpTemplate amqpTemplate;
	
    /**
     * 报文心跳处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/26 16:57
     */
    @Override
    public void heartbeatCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
    	// 心跳包上报
    }

    /**
     * 报文签到处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:36
     */
    @Override
    public void signInCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
    	//充电桩签到报文上报
    }
    
    /**
     * 充电桩充电信息上报模块信息处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:38
     */
    @Override
    public void moduleInfoCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
    	//充电桩充电信息上报模块信息
    }

    /**
     * 充电桩上报启动结果处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
    @Override
    public void startResultCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
    	//充电桩上报启动结果
    	log.info("充电桩上报启动结果响应完成\n");
    }
    /**
     * 充电桩开始启动处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
    @Override
    public void startCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
    	//充电桩充电启动命令应答
    }
    /**
     * 充电桩停止充电处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
    @Override
    public void stopCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
    	//充电桩充电停止命令应答
        log.info("充电完成服务器查询充电记录信息处理完成\n");
    }

    /**
     * 充电桩状态信息包上报处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
    
	@Override
	public void stateInfoCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		//充电桩状态信息报上报
		log.info("本次充电桩状态信息包上报处理完成\n");
	}
	/**
     * 充电桩字符型参数设置处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
    
	@Override
	public void strParamSetCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		//充电桩字符型参数设置命令应答
	}
	
	/**
     * 充电桩整型参数设置处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
	@Override
	public void plasticParamSetCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		//充电桩整型参数设置命令应答
	}
	
	/**
     * 充电桩24时电费计价策略设置处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
    
	@Override
	public void voluationPolicyCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		//充电桩24时电费计价策略设置命令应答
	}
	
	/**
     * 充电桩告警信息上报处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
    
	@Override
	public void alarmInfoCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		//充电桩告警信息上报
		log.info("充电桩告警信息上报处理完成\n");
	}
	
	/**
     * 充电桩账户信息上报处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
	
	@Override
	public void accountInfoCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		//充电桩账户信息上报
		log.info("充电桩账户信息上报查询应答处理完成\n");
	}

	/**
     * 充电桩应答服务器查询最近一次充电各时段信息处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
	
	@Override
	public void chargeTimeFrameInfoCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		//充电桩应答服务器查询最近一次充电各时段信息
	}
	
	/**
     * 充电桩上报充电记录信息处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
	
	@Override
	public void chargeRecordInfoCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		//充电桩上报充电记录信息
	}
	
	/**
     * 充电桩上报充历史充电记录信息处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
	
	@Override
	public void HistoryChargeRecordInfoCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		//充电桩上报充历史充电记录信息
	}

	@Override
	public void timeSyncCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		log.info("科旺时间同步在整形参数设置里，此处无作用");
	}

	@Override
	public void workParamCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		log.info("科旺工作参数设置应答");
	}

	@Override
	public void validAuthenCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		log.info("科旺合法用户认证应答");
	}

	@Override
	public void remoteUpgradeCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		log.info("科旺远程升级系统应答");
	}

	@Override
	public void serviceTypeCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		log.info("中心下发服务类型");
	}

	@Override
	public void BRMCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void ReportTypeCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		log.info("宜步通讯间隔设置");
	}

	/**
	 * 桩上报BCP报文
	 * 
	 * @param ctx
	 * @param fullData
	 * @throws Exception
	 * @author ydc
     * @date 2020/4/30 14:40
	 */
		
	@Override
	public void BCPCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		log.info("桩上报BCP报文");
	}
}
