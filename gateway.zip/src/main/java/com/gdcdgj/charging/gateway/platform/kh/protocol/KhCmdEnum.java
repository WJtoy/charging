package com.gdcdgj.charging.gateway.platform.kh.protocol;

import lombok.extern.slf4j.Slf4j;

/**
 * 服务端与充电桩通信的命令
 * 科华
 * @author ydc
 * @since 2016-11-1 下午6:37:21
 */
@Slf4j
public enum KhCmdEnum {
	
	/**
     * BMS相关的报文命令
     */
    // 充电桩在充电准备阶段上报BMS与车辆辨识报文BRM
    BRM_REC((byte) 0x02),
    // 平台收到“充电桩上报BRM”报文后，应答充电桩
    BRM_RESP((byte) 0x12),//18
    // 充电桩在充电准备阶段上报BCP
    BCP_REC((byte) 0x03),// OK
    // 平台收到“充电桩上报BCP”报文后，应答充电桩
    BCP_RESP((byte) 0x13),//19 // OK
    // 充电桩在参数配置阶段上报CML
    CML_REC((byte) 0x04),        // OK1
    // 平台收到“充电桩上报CML”报文后，应答充电桩
    CML_RESP((byte) 0x14),//20  // OK1
    // 充电桩在充电阶段上报BCL
    BCL_REC((byte) 0x25),//37 	// OK1
    // 充电桩在充电阶段上报BCS
    BCS_REC((byte) 0x26),//38	// OK1
    // 充电桩在充电阶段上报BSM
    BSM_REC((byte) 0x07),        // OK1
    // 充电桩在充电阶段上报BST
    BST_REC((byte) 0x08),        // OK1
    // 平台收到“充电桩上报BST”报文后，应答充电桩
    BST_RESP((byte) 0x18),//24 	// OK1
    // 充电桩在充电阶段上报CST
    CST_REC((byte) 0x79),//121	// OK1
    // 平台收到“充电桩上报CST”报文后，应答充电桩
    CST_RESP((byte) 0x19),//25 	// OK1
    // 充电桩在各阶段上报BEM
    BEM_REC((byte) 0x0A),//10	// OK1
    // 平台收到“充电桩上报BEM”报文后，应答充电桩
    BEM_RESP((byte) 0x1A),//26	// OK1
    // 充电桩在各阶段上报CEM
    CEM_REC((byte) 0x0B),//11 	// OK
    // 平台收到“充电桩上报CEM”报文后，应答充电桩
    CEM_RESP((byte) 0x1B),//27 	// OK


    TIME_SYN_SET((byte) 0x42),//充电桩时间同步  		
    TIME_SYN_RESP((byte) 0x52),//充电桩时间同步应答 	

    WORK_PARAM_SET((byte) 0x46),//充电桩工作参数设置 	
    WORK_PARAM_RESP((byte) 0x56),//充电桩工作参数设置应答  
    
    VOLUATION_POLICY_REPORT((byte) 0x85),//终端设备上传电费计价模型查询
    VOLUATION_POLICY_QUERY((byte) 0x05),//监控平台下发计费模型查询
    
    VOLUATION_POLICY_RESP((byte) 0x86),//终端设备上传电费计价模型确认
    VOLUATION_POLICY_SET((byte) 0x06),//监控平台下发计费模型设置
    
    READ_DATA_RESP((byte) 0x83),//终端设备上传终端数据   
    READ_DATA((byte) 0x03),//监控平台下发读取终端数据
    
    WRITE_DATA_RESP((byte) 0x84),//终端设备上传终端数据   
    WRITE_DATA((byte) 0x04),//监控平台下发读取终端数据
    
    HEART_BEAT_REPORT((byte) 0x02),//终端设备上传心跳帧	
    HEART_BEAT_REPORT_RESP((byte) 0x82),//监控平台下发心跳确认帧           

    SEND_SIGN_IN((byte) 0x01),//终端设备上传登录帧	
    SEND_SIGN_IN_RESP((byte) 0x81),//监控平台下发确认登录帧	
    
    PILE_CTRL_SET((byte) 0x05),//充电桩远程充电机控制设置	
    PILE_CTRL_RESP((byte) 0x15),//充电桩远程充电机控制应答	
    
    ORDER_CHARGE_REPORT((byte) 0x89),//终端设备上传预约充电确认
    ORDER_CHARGE_RESP((byte) 0x09),//监控平台下发预约充电
    
    PILE_START_REPORT((byte) 0x8a),//终端设备上传启停充电通知确认
    PILE_START_RESP((byte) 0x0a),//监控平台下发启停充电
    
    PILE_STARTED_REPORT((byte) 0x0b),//监控平台响应启停充电结果
    PILE_STARTED_RESP((byte) 0x8b),//终端设备上传启停充电结果通知确认

    CARD_REQUEST_REPORT((byte) 0x0c),//终端设备上传刷卡请求
    CARD_REQUEST_RESP((byte) 0x8c),//监控平台下发刷卡请求确认

    MODULE_INFO_REPORT((byte) 0x0d),//终端设备上传实时数据		
    MODULE_INFO_QUERY_RESP((byte) 0x8d),//平台响应上传实时数据

    CHARGING_RECORD_REPORT((byte) 0x0e),//终端上报充电记录命令	
    CHARGING_RECORD_RESP((byte) 0x8e),//监控平台应答充电记录上报	

    ALARM_RECORD_REPORT((byte) 0x0f),//终端设备上传历史告警数据	
    ALARM_RECORD_RESP((byte) 0x8f),//监控平台下发告警记录确认	

    OPERATION_RECORD_REPORT((byte) 0x10),//终端设备上传操作记录数据
    OPERATION_RECORD_RESP((byte) 0x90),//监控平台下发操作记录确认	

    FTP_UPDATE_SET((byte) 0x11),//FTP升级下发	
    FTP_UPDATE_RESP((byte) 0x91),//FTP升级应答

    FTP_UPDATE_RESULT_REPORT((byte) 0x12),//FTP升级结果
    FTP_UPDATE_RESULT_RESP((byte) 0x92),//FTP升级结果确认
	
	DATA_REPORT((byte) 0x13),//终端数据主动上传
    DATA_RESP((byte) 0x93),//主动上传数据确认
	
	DATE_ACK_SET((byte) 0x1b),//后台下发对时
    DATE_ACK_RESP((byte) 0x9b),//终端上传对时结果
    
    BALANCE_REISSUE_SET((byte) 0x1c),//金额补发下发
    BALANCE_REISSUE_RESP((byte) 0x9c),//上报补发结果
    
    VIN_START_REPORT((byte) 0x1d),//VIN码请求充电
    VIN_START_RESP((byte) 0x9d),//VIN码响应结果
    
    PASSWORD_START_REPORT((byte) 0x1e),//密码启动充电
    PASSWORD_START_RESP((byte) 0x9e),//响应结果
    
    TIMEFRAME_POLICY_SET((byte) 0x1f),//尖峰平谷计费规则下发
    TIMEFRAME_POLICY_RESP((byte) 0x9f),//回复结果

    TIMEFRAME_POLICY_QUERY((byte) 0x20),//尖峰平谷计费规则查询
    TIMEFRAME_POLICY_RESPS((byte) 0xa0),//响应结果
    
    REQUEST_POWER_REPORT((byte) 0x1e),//请求输出功率
    REQUEST_POWER_RESP((byte) 0x9e),//回复可以输出功率
    
	LIMIT_POWER_SET((byte) 0x22),//功率限制下发
	LIMIT_POWER_RESP((byte) 0xa2);//响应结果

    private byte cmd;

    private KhCmdEnum(byte cmd) {
        this.cmd = cmd;
    }

    public byte getValue() {
        return this.cmd;
    }

    public static KhCmdEnum valueOf(byte cmd) {
        KhCmdEnum tempEnum = null;
        for (KhCmdEnum en : KhCmdEnum.values()) {
            if (en.getValue() == cmd) {
                tempEnum = en;
                break;
            }
        }
        if (tempEnum == null) {
            log.error("Enum value not exist : " + cmd);
        }
        return tempEnum;
    }
}
