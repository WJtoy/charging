package com.gdcdgj.charging.gateway.platform.kh.protocol;


import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.gateway.enums.MsgProviderEnum;
import com.gdcdgj.charging.gateway.util.CRC16Util;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;
import com.gdcdgj.charging.gateway.util.MathConverterHelper;
import com.mysql.cj.log.Log;

import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;

/**
 * 科华 协议工具类 本协议中，所有协议中除去特别说明外，均是低位在前，高位在后， 通信数据报文采用二进制格式； 起始域：固定为 先0x4b、 后0x48；
 * 长度域：整帧总长度； 协议版本（版本域）：本次版本4.07( 0x97,0x01)； 序列号域：报文的流水号；设备类型：对应设备；设备串号：设备唯一序列号
 * 加密方式：0代表不加密； 功能码：即消息类型，代表不同功能要求；设备id：保留为0x00,0x01；数据域：具体的信息数据区域，不同的命令代码对应
 * 的内容不同； 校验和域：采用CRC16作为校验，校验区域为帧头到信息域；结束字节：保留以0x68表示；
 *
 * @author ydc
 * @since 
 */
@Slf4j
public class KhProtocolUtil {

    /**
     * 信息域
     *
     * @author ydc
     * @since 2020-6-1 下午
     */
    public static class DataField {
        public DataField(byte[] memberId, byte[] cmd) {
            this.memberId = memberId;
            this.cmd = cmd;
        }

        private byte[] memberId = new byte[2];// 用户ID，2字节
        private byte[] cmd = new byte[2];// 指令序号，2字节
        private List<Byte> data = new ArrayList<Byte>();// 其他数据，因无法预料数据长度，所以用List

        public byte[] getMemberId() {
            return memberId;
        }

        public void setMemberId(byte[] memberId) {
            this.memberId = memberId;
        }

        public byte[] getCmd() {
            return cmd;
        }

        public void setCmd(byte[] cmd) {
            this.cmd = cmd;
        }

        public List<Byte> getData() {
            return data;
        }

        public void setData(List<Byte> data) {
            this.data = data;
        }
    }

    // 第34个字节后开始是信息域
    private static final int DATA_FIELD_START_INDEX = 34;

    //private static final int EQUIPMENT_CODE_LEN = 8;// 桩编码数据占8字节

    private static final byte[] KH_START_FIELD = new byte[]{(byte) 0x4b, (byte) 0x48};// 起始域（帧头）
    private static byte[] KH_START_LENGTH = new byte[2];// 帧长
    private static byte[] KH_SERIAL_NO = new byte[2];// 序列号
    private static final byte[] KH_VERSION_FIELD = new byte[] {(byte) 0x97,0x01}; // 版本域
    

    /**
     * 校验接收到的数据
     *
     * @param fullData
     * @return
     * @author ouxx
     * @throws Exception 
     * @date 2017-2-10 上午9:42:49
     */
    public static boolean verifyRecData(byte[] fullData) throws Exception {
        // 起始域
        boolean matchHead = ((KH_START_FIELD[0] == fullData[0]) && (KH_START_FIELD[1] == fullData[1]));
        // 信息域
        boolean matchVersion = ((KH_VERSION_FIELD[0] == fullData[4]) && (KH_VERSION_FIELD[1] == fullData[5]));
        // 长度域
        KH_START_LENGTH = MathConverterHelper.getBytes(fullData.length);
        // 容错长度
        byte[] tolerantLen = MathConverterHelper.getBytes(fullData.length - 1);
        boolean matchLen = ((KH_START_LENGTH[0] == fullData[2]) && (KH_START_LENGTH[1] == fullData[3])
        		|| (tolerantLen[0] == fullData[2] && tolerantLen[1] == fullData[3]));
        
        return (matchHead && matchVersion && matchLen);
    }

    public static byte[] getFullDataBytes(byte cmdCode, byte serialField, byte[] dataField) throws Exception {
        byte[] datas8 = new byte[8];// 协议数组的前8个字节
        datas8[0] = KH_START_FIELD[0];
        datas8[1] = KH_START_FIELD[1];
        //长度域数值：包含从 起始域到校验和域 的所有字节数
        KH_START_LENGTH = MathConverterHelper.getBytes(getLength(dataField));
        datas8[2] = KH_START_LENGTH[0];
        datas8[3] = KH_START_LENGTH[1];
        // 信息域(版本域)
        datas8[4] = KH_VERSION_FIELD[0];
        datas8[5] = KH_VERSION_FIELD[1];
        // 序列号域
        datas8[6] = KH_SERIAL_NO[0];
        datas8[7] = KH_SERIAL_NO[1];
        try {
            // 把数据域的数组合并到前8个字节的数据后
            byte[] datasWithDataField = MathConverterHelper.byteMerger(datas8, dataField);
            // 添上最后的校验和，校验和域：CRC16
            return MathConverterHelper.byteMerger(datasWithDataField, getCheckSum(datasWithDataField));
        } catch (Exception e) {
        	log.error("KhProtocolUtil 122 数组合并报错 :{}",e);
        }
        return null;
    }
    /**
     * 获取功能码
     *
     * @param fullData
     * @return
     * @author ouxx
     * @date 2016-11-11 下午5:54:20
     */
    public static byte getCmdCode(byte[] fullData) {
        return fullData[30];
    }
    
    /**
     * 获取设备类型
     *
     * @param fullData
     * @return
     * @author ouxx
     * @date 2016-11-11 下午5:54:20
     */
    public static byte getEquipmentType(byte[] fullData) {
        return fullData[8];
    }
    /**
     * 获取设备id
     *
     * @param fullData
     * @return
     * @author ouxx
     * @date 2016-11-11 下午5:54:20
     */
    public static byte[] getEquipmentId(byte[] fullData) {
        return new byte[] {fullData[31],fullData[32]};
    }
    /**
     * 获取加密方式
     *
     * @param fullData
     * @return
     * @author ouxx
     * @date 2016-11-11 下午5:54:20
     */
    public static byte getEncryptType(byte[] fullData) {
        return fullData[29];
    }
    /**
     * 获取枪号
     *
     * @param fullData
     * @return
     * @author ouxx
     * @date 2016-11-11 下午5:54:20
     */
    public static byte getConnectorNo(byte[] fullData) {
        return fullData[33];
    }
    /**
     * 获取电桩编码
     *
     * @param fullData
     * @return
     * @author ouxx
     * @date 2016-11-11 下午5:54:20
     */
    public static byte[] getPileCode(byte[] fullData) {
        return getDataByIndexAndSize(fullData, 9, 20);
    }
    /**
     * 获取命令代码对应的枚举
     *
     * @param fullData
     * @return
     * @author ouxx
     * @date 2016-11-11 下午5:54:20
     */
    public static KhCmdEnum getCmdCodeEnum(byte[] fullData) {
        return KhCmdEnum.valueOf(getCmdCode(fullData));
    }

    /**
     * 获取长度域的值: 整帧长
     *
     * @param dataField
     * @return
     * @author ouxx
     * @date 2016-11-1 下午6:19:14
     */
    public static int getLength(byte[] dataField) {
        if (null != dataField) {
            return (34 + dataField.length + 3);
        } else {
            return 37;
        }
    }

    /**
     * 校验和域：用出CRC16校验 范围包含从帧头到信息域 2字节
     *
     * @param cmdCode
     * @param dataField
     * @return
     * @author ouxx
     * @date 2016-11-1 下午6:15:48
     */
    public static byte[] getCheckSum(byte[] dataField) {
    	int crc = CRC16Util.calcCrc16(dataField);
    	byte[] data = DataAnalyzer.analyseCommandData(crc, DataAnalyseWayEnum.UInt16);
    	try {
    		//拼接结束字节 0x68
			data = MathConverterHelper.byteMerger(data, new byte[] {0x68});
		} catch (Exception e) {
			log.error("KhProtocol 191 数组合并出错 ：{}",e);
		}
        return data;
    }
    
    /**
     * 给定起始下标获取数据域
     * @param fullData
     * @param index
     * @return
     * @author ouxx
     * @date 2016-11-3 上午11:22:21
     */
    private static byte[] getDataWithStartIndex(byte[] fullData, int index) {
        // 长度要减去3，因为最后还有检验和域和结尾字节
        int dataFieldLength = fullData.length -index - 3;
        return getDataByIndexAndSize(fullData, index, dataFieldLength);
    }

    /**
     * 获取数据域的数据
     *
     * @param fullData
     * @return
     * @author ouxx
     * @date 2016-11-1 下午6:03:27
     */
    public static byte[] getDataField(byte[] fullData) {
        return getDataWithStartIndex(fullData, DATA_FIELD_START_INDEX);
    }

    /**
     * 从datas截取数据片段，
     *
     * @param datas
     * @param startIndex
     * @param length
     * @return
     * @author ouxx
     * @date 2016-11-4 下午2:09:56
     */
    public static byte[] getDataByIndexAndSize(byte[] datas, int startIndex, int length) {
        byte[] data = new byte[length];
        if (1 == length) {
            data[0] = datas[startIndex];
            return data;
        }
        try {
            System.arraycopy(datas, startIndex, data, 0, length);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return data;
    }

    /**
     * 设置科华供应商、头信息
     * 
     * @param accountInfo
     */
    public static void setProviderAndField(DataBaseVo vo,byte[] fullData) {
    	//科华供应商 3
    	vo.setProviderId(MsgProviderEnum.KH_PROVIDER.getValue());
    	//设备类型
    	vo.setEquipmentType(getEquipmentType(fullData));
    	//设备id
    	vo.setEquipmentId(0001);
    	//加密方式
    	vo.setEncryptType(getEncryptType(fullData));
    	//枪口号
    	vo.setConnectorNo(getConnectorNo(fullData));
    	//电桩编码
    	DataAnalyzer analyzer = new DataAnalyzer();
        analyzer.setAnalyseWay(DataAnalyseWayEnum.StrASCII);
    	String pileCode = (String) DataAnalyzer.analyseAnalogData(analyzer, getPileCode(fullData));
    	vo.setPileCode(pileCode);
    }
}
