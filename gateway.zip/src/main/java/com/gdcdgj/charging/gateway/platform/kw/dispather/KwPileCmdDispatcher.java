package com.gdcdgj.charging.gateway.platform.kw.dispather;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.gdcdgj.charging.gateway.platform.kw.handler.KwPileCmdHandler;
import com.gdcdgj.charging.gateway.platform.kw.protocol.KwCmdEnum;
import com.gdcdgj.charging.gateway.platform.kw.protocol.KwProtocolUtil;

import io.netty.channel.ChannelHandlerContext;
import lombok.extern.slf4j.Slf4j;

/**
 * 科旺桩上报命令分发
 *
 * @author ydc
 * @date 2020/4/23
 * @since JDK 1.8
 */
@Slf4j
@Component
public class KwPileCmdDispatcher {

	// 科旺命令处理器
    @Autowired
    KwPileCmdHandler kwPileCmdHandler;

    /**
     * 科旺根据命令枚举分发不同命令处理
     *
     * @param
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/23
     */
    public void dispatcher(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
        // 报文验证
        if (!KwProtocolUtil.verifyRecData(fullData)) {
        	KwCmdEnum cmdEnums = KwProtocolUtil.getCmdCodeEnum(fullData);
            log.error("报文验证错误 数据长度：{},kw_cmdEnum:{}",fullData.length,cmdEnums);
            return;
        }
        // 获取命令代码枚举
        final KwCmdEnum cmdEnum = KwProtocolUtil.getCmdCodeEnum(fullData);
        log.info("kw_cmdEnum => {}", cmdEnum);
        switch (cmdEnum) {
            case HEART_BEAT_REPORT:
                // 心跳处理
            	log.info("进行心跳处理");
            	kwPileCmdHandler.heartbeatCmdHandle(ctx, fullData);
                break;
            case SEND_SIGN_IN_RESP:
                // 签到处理
            	log.info("进行签到处理");
            	kwPileCmdHandler.signInCmdHandle(ctx, fullData);
                break;
            case MODULE_INFO_QUERY_RESP:
                // 当前充电模块充电信息查询应答/上报
            	log.info("进行当前模块充电信息查询处理");
            	kwPileCmdHandler.moduleInfoCmdHandle(ctx, fullData);
                break;
            case PILE_STARTED_REPORT:
                // 充电桩启动成功后，向平台上报的命令
            	log.info("进行充电桩启动充电结果处理");
            	kwPileCmdHandler.startResultCmdHandle(ctx, fullData);
                break;
            case PILE_START_RESP:
            	// 充电桩开启充电
            	log.info("进行充电桩开启充电处理");
        		kwPileCmdHandler.startCmdHandle(ctx, fullData);
             	break;
            case PILE_STOP_RESP:
            	// 充电桩停止充电
            	log.info("进行充电桩停止充电处理");
        		kwPileCmdHandler.stopCmdHandle(ctx, fullData);
             	break;
            case STR_PARAM_RESP:
            	// 字符型参数设置
            	log.info("进行充电桩字符型参数设置处理");
            	kwPileCmdHandler.strParamSetCmdHandle(ctx, fullData);
            	break;
            case PLASTIC_PARAM_RESP:
            	// 整型参数设置
            	log.info("进行充电桩整型参数设置处理");
            	kwPileCmdHandler.plasticParamSetCmdHandle(ctx, fullData);
            	break;
            case SET_VOLUATION_POLICY_RESP:
            	// 24时电费计价策略
            	log.info("进行充电桩24时电费计价策略处理");
            	kwPileCmdHandler.voluationPolicyCmdHandle(ctx, fullData);
            	break;
            case STATE_INFO_REPORT_RESP:
            	// 状态信息包上报
            	log.info("进行充电桩状态信息包上报处理");
            	kwPileCmdHandler.stateInfoCmdHandle(ctx, fullData);
            	break;
            case ALARM_INFO_REPORT:
            	//告警信息上报
            	log.info("进行充电桩告警信息上报处理");
            	kwPileCmdHandler.alarmInfoCmdHandle(ctx, fullData);;
            	break;
            case ACCOUNT_INFO_QUERY_RESP:
            	//账户信息查询上报
            	log.info("进行充电桩账户信息查询上报处理");
            	kwPileCmdHandler.accountInfoCmdHandle(ctx, fullData);
            	break;
            case CHARGE_TIMEFRAME_INFO_RESP:
            	//充电桩应答服务器查询最近一次充电各时段信息
            	log.info("进行充电桩应答服务器查询最近一次充电各时段信息处理");
            	kwPileCmdHandler.chargeTimeFrameInfoCmdHandle(ctx, fullData);
            	break;
            case CHARGE_RECORD_INFO:
            	//充电桩上报充电记录信息
            	log.info("充电桩上报充电记录信息处理");
            	kwPileCmdHandler.chargeRecordInfoCmdHandle(ctx, fullData);
            	break;
            case HISTORY_CHARGE_RECORD_INFO:
            	//充电桩上报历史充电记录信息
            	log.info("充电桩上报历史充电记录信息处理");
            	kwPileCmdHandler.HistoryChargeRecordInfoCmdHandle(ctx, fullData);
            	break;
            default:
                log.info("其他");
                break;
        }
    }
}
