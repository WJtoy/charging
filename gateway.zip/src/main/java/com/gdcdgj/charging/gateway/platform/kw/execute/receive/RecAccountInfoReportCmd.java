/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.kw.execute.receive;


import com.gdcdgj.charging.api.vo.srv2gw.AccountInfo;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.kw.protocol.KwProtocolUtil;
import com.gdcdgj.charging.gateway.platform.kw.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;

import lombok.extern.slf4j.Slf4j;

/**
 * 用户查询报文（0xcc）
 * <p>发送报文 </p>
 *
 * @author ydc
 * @since 2016-11-14 下午3:35:46
 */
@Slf4j
public class RecAccountInfoReportCmd implements BaseReceiveCmdExecute{

    /**
     * 用户查询报文（0xcc）
     *
     * @param fullData
     * @return
     * @throws Exception
     * @author ouxx
     * @date 2016-11-3 下午1:50:21
     */
    public static AccountInfo recHeartbeatReport(byte[] fullData) {
    	AccountInfo accountInfo = new AccountInfo();
    	KwProtocolUtil.setProvider(accountInfo);
        try {
        	final byte[] dataAfterCmdSeq = KwProtocolUtil.getDataAfterCmdSeqInDataField(fullData);
        	// VinCode查询标识
            final byte index = 0;
            {
            	Double queryCode = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index, 2, DataAnalyseWayEnum.Int16);
            	accountInfo.setQueryCode(queryCode.intValue());
            }
        	// 充电桩编码 32
            final byte index1 = 4;
            {
            	String pileCode = (String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index1, 32, DataAnalyseWayEnum.StrASCII);
            	accountInfo.setPileCode(pileCode);
            }
            // 充电卡号
            final byte index2 = index1 + 32;
            {
                String chargeNo = (String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index2, 32, DataAnalyseWayEnum.StrASCII);
                accountInfo.setChargeNo(chargeNo);
            }
            // 充电卡余额
            final byte index3 = index2 + 32;
            {
                Double accountBalance = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index3, 4, DataAnalyseWayEnum.Int32);
                accountInfo.setAccountBalance(accountBalance.intValue());
            }
            // 充电卡黑白名单标志
            final byte index4 = index3 + 4;
            {
                Double blacklistSignal = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index4, 1, DataAnalyseWayEnum.Byte);
                accountInfo.setBlacklistSignal(blacklistSignal.byteValue());
            }
            // 充电卡密码
            final byte index5 = index4 + 1;
            {
                String chargeCheck = (String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index5, 32, DataAnalyseWayEnum.GB2312);
                accountInfo.setChargeCheck(chargeCheck);
            }
            log.info("用户查询报文(0xcc)");
            log.info("充电桩编码 :" + accountInfo.getPileCode());
            log.info("VinCode查询标识 :" + accountInfo.getQueryCode());
            log.info("充电卡号 :" + accountInfo.getChargeNo());
            log.info("充电卡余额 :" + accountInfo.getAccountBalance());
            log.info("充电卡黑白名单标志 :" + accountInfo.getBlacklistSignal());
            log.info("充电卡密码 :" + accountInfo.getChargeCheck());
            return accountInfo;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return accountInfo;
    }

	@Override
	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
		return recHeartbeatReport(fullData);
	}
}
