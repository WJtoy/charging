/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.kw.execute.receive;


import com.gdcdgj.charging.api.vo.srv2gw.AlarmInfo;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.kw.protocol.KwProtocolUtil;
import com.gdcdgj.charging.gateway.platform.kw.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;

import lombok.extern.slf4j.Slf4j;

/**
 * 告警信息包上报(0x6c)
 * <p>发送报文 </p>
 *
 * @author ydc
 * @since 2016-11-14 下午3:35:46
 */
@Slf4j
public class RecAlarmInfoReportCmd implements BaseReceiveCmdExecute{

    /**
     * 告警信息包上报(0x6c)
     *
     * @param fullData
     * @return
     * @throws Exception
     * @author ouxx
     * @date 2016-11-3 下午1:50:21
     */
    public static AlarmInfo recHeartbeatReport(byte[] fullData) {
    	AlarmInfo alarmInfo = new AlarmInfo();
    	KwProtocolUtil.setProvider(alarmInfo);
        try {
        	final byte[] dataAfterCmdSeq = KwProtocolUtil.getDataAfterCmdSeqInDataField(fullData);
        	// 充电桩编码 32
            final byte indexFault = 4;
            {
            	String pileCode = (String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault, 32, DataAnalyseWayEnum.StrASCII);
            	alarmInfo.setPileCode(pileCode);
            }
            // 告警信息 2
            final byte indexFault1 = 36;
            {
                String alarmInfos = (String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault1, 32, DataAnalyseWayEnum.StrASCII);
                alarmInfo.setAlarmInfo(alarmInfos);
            }
            log.info("告警信息包上报(0x6c) 后台无需应答");
            log.info("充电桩编码 :" + alarmInfo.getPileCode());
            log.info("告警信息 :" + alarmInfo.getAlarmInfo());
            return alarmInfo;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return alarmInfo;
    }

	@Override
	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
		return recHeartbeatReport(fullData);
	}
    
}
