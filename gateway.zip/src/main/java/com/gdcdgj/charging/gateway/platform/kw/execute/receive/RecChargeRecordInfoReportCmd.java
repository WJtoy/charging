/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.kw.execute.receive;


import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import com.gdcdgj.charging.api.vo.srv2gw.ChargeRecordInfo;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.kw.protocol.KwProtocolUtil;
import com.gdcdgj.charging.gateway.platform.kw.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;

import lombok.extern.slf4j.Slf4j;

/**
 * 充电桩上报充电记录信息(0xca)
 * <p>发送报文 </p>
 *
 * @author ydc
 * @since 2016-11-14 下午3:35:46
 */
@Slf4j
public class RecChargeRecordInfoReportCmd implements BaseReceiveCmdExecute{

    /**
     * 充电桩上报充电记录信息(0xca)
     *
     * @param fullData
     * @return
     * @throws Exception
     * @author ouxx
     * @date 2016-11-3 下午1:50:21
     */
    public static ChargeRecordInfo recHeartbeatReport(byte[] fullData) {
    	ChargeRecordInfo info = new ChargeRecordInfo();
    	KwProtocolUtil.setProvider(info);
    	DecimalFormat df = new DecimalFormat("#.00");
    	Map<Byte,Double> maps = new HashMap<>();
    	final int len1 = 1;
    	final int len2 = 2;
    	final int len4 = 4;
    	final int len8 = 8;
    	final int len32 = 32;
        try {
        	final byte[] dataAfterCmdSeq = KwProtocolUtil.getDataAfterCmdSeqInDataField(fullData);
        	// 充电桩编码 32
            final int index1 = len4;
            {
            	String pileCode = (String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index1, len32, DataAnalyseWayEnum.StrASCII);
            	info.setPileCode(pileCode);
            }
            // 充电枪位置类型 1
            final int index2 = index1 + len32;
            {
            	Double locationType = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index2, len1, DataAnalyseWayEnum.Byte);
            	info.setLocationType(locationType.intValue());
            }
            // 充电枪口 1
            final int index3 = index2 + len1;
            {
            	Double connectorNo = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index3, len1, DataAnalyseWayEnum.Byte);
            	info.setConnectorNo(connectorNo.intValue());
            }
            // 充电卡号 32
            final int index4 = index3 + len1;
            {
            	String chargeNo = (String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index4, len32, DataAnalyseWayEnum.StrASCII);
            	info.setChargeNo(chargeNo);
            }
            // 开始充电时间 8
            final int index5 = index4 + len32;
            {
            	Calendar startChargeTime = ProtocolDataGenerator.getCalendar(index5, dataAfterCmdSeq);
            	info.setStartChargeTime(startChargeTime);
            }
            // 结束充电时间 8
            final int index6 = index5 + len8;
            {
            	Calendar stopChargeTime = ProtocolDataGenerator.getCalendar(index6, dataAfterCmdSeq);
            	info.setStopChargeTime(stopChargeTime);
            }
            // 充电时间长度 4
            final int index7 = index6 + len8;
            {
            	Double chargeTimeLen = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index7, len4, DataAnalyseWayEnum.Int32);
            	info.setChargeTimeLen(chargeTimeLen.intValue());
            } 
            // 开始SOC 1
            final int index8 = index7 + len4;
            {
            	Double startSOC = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index8, len1, DataAnalyseWayEnum.Byte);
            	info.setStartSOC(startSOC.intValue());
            }
            // 结束SOC 1
            final int index9 = index8 + len1;
            {
            	Double stopSOC = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index9, len1, DataAnalyseWayEnum.Byte);
            	info.setStopSOC(stopSOC.intValue());
            }
            // 充电结束原因 4
            final int index10 = index9 + len1;
            {
            	Double chargeStopCause = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index10, len4, DataAnalyseWayEnum.Int32);
            	Integer chargeStopCauses =  getStopCause(chargeStopCause.intValue());
            	info.setChargeStopCause(chargeStopCauses);
            }
            // 本次充电电量 4
            final int index11 = index10 + len4;
            {
            	Double currentChargeCount = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index11, len4, DataAnalyseWayEnum.Int32);
            	info.setKwh(Double.parseDouble(df.format(currentChargeCount*0.01)));
            }
            // 充电前电表读数 4
            final int index12 = index11 + len4;
            {
            	Double beforeAmmeterNum = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index12, len4, DataAnalyseWayEnum.Int32);
            	info.setBeforeAmmeterNum(Double.parseDouble(df.format(beforeAmmeterNum*0.01)));
            }
        	// 充电后电表读数 4
            final int index13 = index12 + len4;
            {
            	Double afterAmmeterNum = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index13, len4, DataAnalyseWayEnum.Int32);
            	info.setAfterAmmeterNum(Double.parseDouble(df.format(afterAmmeterNum*0.01)));
            }
            // 本次充电金额 4
            final int index14 = index13 + len4;
            {
            	Double chargeMoney = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index14, len4, DataAnalyseWayEnum.Int32);
            	info.setChargeMoney(chargeMoney.intValue());
            }
            // 内部索引号 4
            final int index15 = index14 + len4;
            {
            	Double indexNum = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index15, len4, DataAnalyseWayEnum.Int32);
            	info.setIndexNum(indexNum.intValue());
            }
            // 充电前卡余额 4
            final int index16 = index15 + len4;
            {
            	Double brforeChargeMoney = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index16, len4, DataAnalyseWayEnum.Int32);
            	info.setBrforeChargeMoney(brforeChargeMoney.intValue());
            }
            // 充电策略 1
            final int index17 = index16 + len4 + 9;
            {
            	Double chargePolicy = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index17, len1, DataAnalyseWayEnum.Byte);
            	info.setChargePolicy(chargePolicy.intValue());
            }
            // 充电策略参数 4
            final int index18 = index17 + len1;
            {
            	Double chargePolicyParam = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index18, len4, DataAnalyseWayEnum.Int32);
            	info.setChargePolicyParam(chargePolicyParam.intValue());
            }
            // 车VIN 17
            final int index19 = index18 + len4;
            {
            	String carVIN = (String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index19, 17, DataAnalyseWayEnum.StrASCII);
            	info.setCarVIN(carVIN);
            }
            //各时段充电电量 48 * 2
            int index20 = index19 + 17 + 8;
            {
            	for (int i = 0; i < 48; i++) {
            		Double power = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index20, len2, DataAnalyseWayEnum.Int16);
                	maps.put((byte)i, Double.parseDouble(df.format(power*0.01)));
            		index20 += len2;
				}
            	info.setChargeCount(maps);
            }
            // 启动方式 1
            final int index21 = index20;
            {
            	Double startType = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index21, len1, DataAnalyseWayEnum.Byte);
            	info.setStartType(startType.intValue());
            }
            // 充电流水号 32
            final int index22 = index21 + len1;
            {
            	String serialNum = (String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index22, len32, DataAnalyseWayEnum.StrASCII);
            	info.setSerialNum(serialNum);
            }
            // 充电服务费 4
            final int index23 = index22 + len32;
            {
            	Double chargeFee = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index23, len4, DataAnalyseWayEnum.Int32);
            	info.setChargeFee(Double.parseDouble(df.format(chargeFee*0.01)));
            }
            log.info("充电桩上报充电记录信息(0xca)");
            log.info("充电桩编码 :" + info.getPileCode());
            log.info("充电枪位置类型 :" + info.getLocationType());
            log.info("充电枪号 :" + info.getConnectorNo());
            log.info("充电卡号 :" + info.getChargeNo());
            log.info("开始充电时间 :" + info.getStartChargeTime());
            log.info("结束充电时间 :" + info.getStopChargeTime());
            log.info("充电时间长度 :" + info.getChargeTimeLen());
            log.info("开始SOC :" + info.getStartSOC());
            log.info("结束SOC :" + info.getStopSOC());
            log.info("充电结束原因 :" + info.getChargeStopCause());
            log.info("本次充电电量 :" + info.getKwh());
            log.info("充电前电表读数 :" + info.getBeforeAmmeterNum());
            log.info("充电后电表读数 :" + info.getAfterAmmeterNum());
            log.info("本次充电金额 :" + info.getChargeMoney());
            log.info("内部索引号 :" + info.getIndexNum());
            log.info("充电策略 :" + info.getChargePolicy());
            log.info("充电策略参数 :" + info.getChargePolicyParam());
            log.info("车VIN :" + info.getCarVIN());
            for (int i = 0; i < 48; i++) {
           	 log.info("各时段充电电量 :" + info.getChargeCount().get((byte)i));
			}
            log.info("启动方式 :" + info.getStartType());
            log.info("充电流水号 :" + info.getSerialNum());
            log.info("充电服务费 :" + info.getChargeFee());
            return info;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return info;
    }

	@Override
	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
		return recHeartbeatReport(fullData);
	}
	private static Integer getStopCause(Integer a) {
		if(a == 0 || a == 101015 || a == 316) return 3;//充满结束
		if(a == 200 || a == 21) return 0;//客户端结束 用户结束
		if(a == 311) return 2;//后台结束
		if(a== 302) return 1;//紧急停止
		//余额不足
		log.info("结束原因  :{}",a);
		return 5;//异常结束
	}
}
