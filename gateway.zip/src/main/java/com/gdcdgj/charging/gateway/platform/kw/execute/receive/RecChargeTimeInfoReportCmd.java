/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.kw.execute.receive;


import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import com.gdcdgj.charging.api.vo.srv2gw.ChargeTimeFrameInfo;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.kw.protocol.KwProtocolUtil;
import com.gdcdgj.charging.gateway.platform.kw.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;

import lombok.extern.slf4j.Slf4j;

/**
 * 充电桩应答服务器查询最近一次充电各时段信息(0x72)
 * <p>发送报文 </p>
 *
 * @author ydc
 * @since 2016-11-14 下午3:35:46
 */
@Slf4j
public class RecChargeTimeInfoReportCmd implements BaseReceiveCmdExecute{

    /**
     * 充电桩应答服务器查询最近一次充电各时段信息(0x72)
     *
     * @param fullData
     * @return
     * @throws Exception
     * @author ouxx
     * @date 2016-11-3 下午1:50:21
     */
    public static ChargeTimeFrameInfo recHeartbeatReport(byte[] fullData) {
    	ChargeTimeFrameInfo info = new ChargeTimeFrameInfo();
    	KwProtocolUtil.setProvider(info);
    	DecimalFormat df = new DecimalFormat("#.00");
    	Map<Byte,Double> maps = new HashMap<>();
        try {
        	final byte[] dataAfterCmdSeq = KwProtocolUtil.getDataAfterCmdSeqInDataField(fullData);
        	// 充电桩编码 32
            final byte index1 = 4;
            {
            	String pileCode = (String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index1, 32, DataAnalyseWayEnum.StrASCII);
            	info.setPileCode(pileCode);
            }
            // 充电枪号 1
            final byte index2 = index1 + 32;
            {
            	Double connectorNo = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index2, 1, DataAnalyseWayEnum.Byte);
            	info.setConnectorNo(connectorNo.byteValue());
            }
            // 工作状态 1
            final byte index3 = index2 + 1;
            {
            	Double workState = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index3, 1, DataAnalyseWayEnum.Byte);
            	info.setWorkState(workState.byteValue());
            }
            // 开始充电时间 8
            final byte index4 = index3 + 1;
            {
            	Calendar startChargeTime = ProtocolDataGenerator.getCalendar(index4, dataAfterCmdSeq);
            	info.setStartChargeTime(startChargeTime);
            }
            //各时段充电电量 48 * 2
            int index5 = index4 + 8;
            {
            	for (int i = 0; i < 48; i++) {
            		Double power = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index5, 2, DataAnalyseWayEnum.Int16);
                	maps.put((byte) index5, Double.parseDouble(df.format(power)));
            		index5 += 2;
				}
            	info.setTimeFrame(maps);
            }
            log.info("充电桩应答服务器查询最近一次充电各时段信息(0x72)");
            log.info("充电桩编码 :" + info.getPileCode());
            log.info("充电枪号 :" + info.getConnectorNo());
            log.info("工作状态 :" + info.getWorkState());
            log.info("开始充电时间 :" + info.getStartChargeTime());
            for (int i = 0; i < 48; i++) {
            	 log.info("各时段充电电量 :" + info.getTimeFrame().get((byte)i));
			}
            return info;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return info;
    }

	@Override
	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
		return recHeartbeatReport(fullData);
	}
    
}
