/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.kw.execute.receive;


import java.util.HashMap;
import java.util.Map;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.HeartBeat;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.kw.protocol.KwProtocolUtil;
import com.gdcdgj.charging.gateway.platform.kw.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;

import lombok.extern.slf4j.Slf4j;

/**
 * 远端心跳包上报(0x66)
 * <p>心跳包发送报文 </p>
 *
 * @author ydc
 * @since 2016-11-14 下午3:35:46
 */
@Slf4j
public class RecHeartBeatReportCmd implements BaseReceiveCmdExecute{

    private static RecHeartBeatReportCmd recHeartBeatReportCmd = null;

    public static synchronized RecHeartBeatReportCmd getInstance() {
        if (recHeartBeatReportCmd == null) {
            recHeartBeatReportCmd = new RecHeartBeatReportCmd();
        }
        return recHeartBeatReportCmd;
    }

    /**
     * 远端心跳包上报(0x66)
     *
     * @param fullData
     * @return
     * @throws Exception
     * @author ouxx
     * @date 2016-11-3 下午1:50:21
     */
    public static HeartBeat recHeartbeatReport(byte[] fullData) {
    	HeartBeat heartBeat = new HeartBeat();
    	KwProtocolUtil.setProvider(heartBeat);
        try {
        	
        	final byte[] dataAfterCmdSeq = KwProtocolUtil.getDataAfterCmdSeqInDataField(fullData);
        	// 充电桩编码 32
            final byte indexFault = 4;
            {
            	String pileCode = (String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault, 32, DataAnalyseWayEnum.StrASCII);
                heartBeat.setPileCode(pileCode);
            }
            // 心跳序号 2
            final byte indexFault1 = 36;
            {
                Double heartBeatSeq = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault1, 2, DataAnalyseWayEnum.Int16);
                heartBeat.setHeartBeatSeq(heartBeatSeq.intValue());
            }
            // 各枪状态 16
            final byte indexFault2 = 38;
            {
            	Map<Integer,Integer> maps = new HashMap<>();
                	Double connectorState = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault2, 1, DataAnalyseWayEnum.Byte);
                	Integer a = connectorState.intValue();
                	for (int j = 1; j <= 8; j++) {
                		int res = ProtocolDataGenerator.isIntNumberNBitONEInBinary(a, j) ? 1 : 0;
                		maps.put(j, res);
					}
                heartBeat.setConnectorState(maps);
            }
            log.info("远端心跳包上报(0x66)");
            log.info("充电桩编码 :" + heartBeat.getPileCode());
            log.info("心跳序号 :" + heartBeat.getHeartBeatSeq());
            for (int i = 1; i <= heartBeat.getConnectorState().size(); i++) {
            	log.info("枪连接状态 ："+  (heartBeat.getConnectorState().get(i)== 0 ? "未插枪" : "已插枪"));
			}
            return heartBeat;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return heartBeat;
    }

	@Override
	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
		return recHeartbeatReport(fullData);
	}
}
