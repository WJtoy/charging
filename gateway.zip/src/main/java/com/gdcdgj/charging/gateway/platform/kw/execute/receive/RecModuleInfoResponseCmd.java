/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.kw.execute.receive;


import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.ModuleChargingInfo;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.kw.protocol.KwProtocolUtil;
import com.gdcdgj.charging.gateway.platform.kw.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.Map;

/**
 * 当前充电模块充电信息查询应答/上报(0x70)
 *
 * @author ydc
 * @since 2016-11-14 下午4:17:23
 */
@Slf4j
public class RecModuleInfoResponseCmd implements BaseReceiveCmdExecute{


    private static RecModuleInfoResponseCmd recModuleInfoResponseCmd = null;

    public static synchronized RecModuleInfoResponseCmd getInstance() {
        if (recModuleInfoResponseCmd == null) {
            recModuleInfoResponseCmd = new RecModuleInfoResponseCmd();
        }
        return recModuleInfoResponseCmd;
    }

    /**
     * 当前充电模块充电信息查询应答/上报(0x70)
     *
     * @param fullData
     * @param info
     * @return
     * @throws Exception
     * @author ouxx
     * @date 2016-11-14 下午4:19:21
     */
    public static ModuleChargingInfo recModuleInfoResponse(byte[] fullData) throws Exception {
    	ModuleChargingInfo info = new ModuleChargingInfo();
    	KwProtocolUtil.setProvider(info);
        final byte[] dataAfterCmdSeq = KwProtocolUtil.getDataAfterCmdSeqInDataField(fullData);

        //长度，字节数
        final int len1 = 1;
        final int len2 = 2;
        final int len4 = 4;
        final int len32 = 32;
        //1字节
        final DataAnalyseWayEnum analyseWay1 = DataAnalyseWayEnum.Byte;

        //充电桩编码  32字节
        final byte indexFault = 4;
        final byte lenFault = len32;
        {
            String pileCode = (String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault, lenFault, DataAnalyseWayEnum.StrASCII);
            info.setPileCode(pileCode);
        }
        //上报方式 1
        final byte index0 = lenFault + indexFault;
        {
            Double reportType = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index0, len1, analyseWay1);
            info.setReportType(reportType.byteValue());
        }
        //模块数量 1
        final byte index1 = index0 + len1;
        {
            Double connectorCnt = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index1, len1, analyseWay1);
            info.setConnectorCnt(connectorCnt.byteValue());
        }
        //模块类型 1
        final byte index2 = index1 + len1;
        {
            Double moudleType = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index2, len1, analyseWay1);
            info.setMoudleType(moudleType.byteValue());
        }
        //模块一AC版本  Map<充电枪位置, AC版本>
        Map<Byte, Integer> ACMap = new HashMap<Byte, Integer>();
        //模块一DC版本  Map<充电枪位置, DC版本>
        Map<Byte, Integer> DCMap = new HashMap<Byte, Integer>();
        //充电枪位置N充电类型  Map<充电枪位置, 类型>
        Map<Byte, Byte> connectorStateMap = new HashMap<Byte, Byte>();
     	//充电枪位置N电压  Map<充电枪位置, 电压>
        Map<Byte, Double> currentMap = new HashMap<Byte, Double>();
        //充电枪位置N充电电流  Map<充电枪位置, 电流>
        Map<Byte, Double> voltageMap = new HashMap<Byte, Double>();
        //充电枪位置N充电告警  Map<充电枪位置, 告警>
        Map<Byte, Integer> alarmMap = new HashMap<Byte, Integer>();
        //获取模块总数量
        int moudleCount = info.getConnectorCnt();
        for (int i = 1; i <= moudleCount; i++) {
        	//充电枪位置AC版本
            int index3 = index2 + len1;
            {
                Double typeMaps = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index3, len2, DataAnalyseWayEnum.Int16);
                ACMap.put((byte) i, typeMaps.intValue());
                info.setACVersionMap(ACMap);
                index3 += i*13;
            }
            //充电枪位置AC版本
            int index4 = index2 + len1 +len2;
            {
                Double typeMaps = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index4, len2, DataAnalyseWayEnum.Int16);
                DCMap.put((byte) i, typeMaps.intValue());
                info.setDCVersionMap(DCMap);
                index4 += i*13;
            }
            //充电枪位置状态
            int index5 = index2 + len4 + len1;
            {
                Double typeMaps = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index5, len1, DataAnalyseWayEnum.Byte);
                connectorStateMap.put((byte) i, typeMaps.byteValue());
                info.setConnectedStateMap(connectorStateMap);
                index5 += i*13;
            }
            //充电枪位置电压
            int index6 = index2 + len4 + len2;
            {
                Double typeMaps = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index6, len2, DataAnalyseWayEnum.Int16);
                currentMap.put((byte) i, typeMaps);
                info.setCurrentMap(currentMap);
                index6 += i*13;
            }
            //充电枪位置电流
            int index7 = index2 + len4 + len4;
            {
                Double typeMaps = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index7, len2, DataAnalyseWayEnum.Int16);
                voltageMap.put((byte) i, typeMaps);
                info.setVoltageMap(voltageMap);
                index7 += i*13;
            }
            //充电枪位置电流
            int index8 = index2 + len4 + len4 +len4;
            {
                Double typeMaps = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index8, len4, DataAnalyseWayEnum.Int32);
                alarmMap.put((byte) i, typeMaps.intValue());
                info.setAlarmMap(alarmMap);
                index8 += i*13;
            }
		}
        log.info("当前充电模块充电信息查询应答/上报(0x70)");
        return info;
    }

	@Override
	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
		return recModuleInfoResponse(fullData);
	}
}
