/*
 *
 */
package com.gdcdgj.charging.gateway.platform.kw.execute.receive;


import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.PileCtrl;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.kw.protocol.KwProtocolUtil;
import com.gdcdgj.charging.gateway.platform.kw.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;

import lombok.extern.slf4j.Slf4j;

/**
 * 充电桩对后台下发的充电桩开启充电控制应答(0x08)
 * 
 * @author ydc
 * @since 2017-3-1 下午8:09:07
 *
 */
@Slf4j
public class RecPileCtrlStartRstReportCmd implements BaseReceiveCmdExecute{

	public static PileCtrl recPileCtrlStartRstReport(byte[] fullData) throws Exception{
		PileCtrl pileCtrlStart = new PileCtrl();
		KwProtocolUtil.setProvider(pileCtrlStart);
		final byte[] dataAfterCmdSeq = KwProtocolUtil.getDataAfterCmdSeqInDataField(fullData);
		
		// 长度，字节数
        final int len1 = 1;
        final int len4 = 4;
        final int len32 = 32;

        // 1字节
        final DataAnalyseWayEnum analyseWay1 = DataAnalyseWayEnum.Byte;
        // 4字节
        final DataAnalyseWayEnum analyseWay3 = DataAnalyseWayEnum.UInt32;
        // 充电桩编码 32
        final byte indexFault = 4;
        {
            String pileCode = (String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault, len32, DataAnalyseWayEnum.StrASCII);
            pileCtrlStart.setPileCode(pileCode);
        }
        // 充电枪口 1
        final byte index0 = indexFault + len32;
        {
            Double connectorNo = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index0, len1, analyseWay1);
            pileCtrlStart.setConnectorNo(connectorNo.byteValue());
        }
        // 命令执行结果 4
        final byte index1 = index0 + len1;
        {
        	Double resultCode = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index1, len4, analyseWay3);
        	int res = (resultCode==0) ? 1 : 2;
        	pileCtrlStart.setResultCode(res);
        }
        // 充电流水号 4
        final byte index2 = index1 + len4;
        {
        	String serialNo = (String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index2, len4, DataAnalyseWayEnum.GB2312);
            pileCtrlStart.setSerialNo(serialNo.toString());
        }
        log.info("充电桩对后台下发的充电桩开启充电控制应答(0x08)");
        log.info("充电桩编码 :" + pileCtrlStart.getPileCode());
        log.info("充电枪口 :" + pileCtrlStart.getConnectorNo() + "号枪");
        log.info("命令执行结果 :" + (pileCtrlStart.getResultCode()==1 ? "成功" : "失败"));
		return pileCtrlStart;
	}

	@Override
	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
		return recPileCtrlStartRstReport(fullData);
	}

}
