/*
 *
 */
package com.gdcdgj.charging.gateway.platform.kw.execute.receive;


import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.PileCtrl;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.kw.protocol.KwProtocolUtil;
import com.gdcdgj.charging.gateway.platform.kw.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;

import lombok.extern.slf4j.Slf4j;

/**
 * 充电桩对后台下发的充电桩停止充电控制命令应答(0x06)
 * 
 * @author ydc
 * @since 2017-3-1 下午8:09:07
 *
 */
@Slf4j
public class RecPileCtrlStopRstReportCmd implements BaseReceiveCmdExecute{

	public static PileCtrl recPileCtrlStartRstReport(byte[] fullData) throws Exception{
		PileCtrl pileCtrlStop = new PileCtrl();
		KwProtocolUtil.setProvider(pileCtrlStop);
		final byte[] dataAfterCmdSeq = KwProtocolUtil.getDataAfterCmdSeqInDataField(fullData);
		
		// 长度，字节数
        final int len1 = 1;
        final int len4 = 4;
        final int len32 = 32;

        //充电桩编码 32
        final byte indexFault = 4;
        {
            String pileCode = (String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault, len32, DataAnalyseWayEnum.StrASCII);
            pileCtrlStop.setPileCode(pileCode);
        }
        // 充电枪口 1
        final byte index0 = indexFault + len32;
        {
            Double connectorNo = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index0, len1, DataAnalyseWayEnum.Byte);
            pileCtrlStop.setConnectorNo(connectorNo.byteValue());
        }
        // 命令起始标志  4
        final byte index1 = index0 + len1;
        {
            Double originAddr = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index1, len4, DataAnalyseWayEnum.Int32);
            pileCtrlStop.setOriginAddr(originAddr.intValue());
        }
        // 命令个数  1
        final byte index2 = index1 + len4;
        {
        	Double connectorCount = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index2, len1, DataAnalyseWayEnum.Byte);
            pileCtrlStop.setConnectorCount(connectorCount.byteValue());
        }
        // 命令执行结果 1
        final byte index3 = index2 + len1;
        {
        	Double resultCode = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index3, len1, DataAnalyseWayEnum.Byte);
        	pileCtrlStop.setResultCode(resultCode.intValue());
        }
        log.info("充电桩对后台下发的充电桩停止充电控制命令应答(0x06)");
        log.info("充电桩编码 :" + pileCtrlStop.getPileCode());
        log.info("充电枪口 :" + pileCtrlStop.getConnectorNo() + "号枪");
        log.info("命令起始标志 :" + pileCtrlStop.getOriginAddr());
        log.info("命令个数 :" + pileCtrlStop.getConnectorCount());
        log.info("命令执行结果 :" + (pileCtrlStop.getResultCode()==0 ? "成功" : "失败"));
		return pileCtrlStop;
	}

	@Override
	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
		return recPileCtrlStartRstReport(fullData);
	}

}
