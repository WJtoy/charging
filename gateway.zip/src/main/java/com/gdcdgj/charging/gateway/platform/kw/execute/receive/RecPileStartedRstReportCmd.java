/*
 *
 */
package com.gdcdgj.charging.gateway.platform.kw.execute.receive;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.PileStartedRst;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.kw.protocol.KwProtocolUtil;
import com.gdcdgj.charging.gateway.platform.kw.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;

import lombok.extern.slf4j.Slf4j;

/**
 * 充电桩启动成功后，向平台上报的命令0X6e
 * @author ydc
 * @since 2017-3-1 下午8:09:07
 *
 */
@Slf4j
public class RecPileStartedRstReportCmd implements BaseReceiveCmdExecute{

	public static PileStartedRst recPileStartedRstReport(byte[] fullData) throws Exception{
		PileStartedRst startedRst = new PileStartedRst();
		KwProtocolUtil.setProvider(startedRst);
		final byte[] dataAfterCmdSeq = KwProtocolUtil.getDataAfterCmdSeqInDataField(fullData);
    	// 充电桩编码 32
        final byte index1 = 4;
        {
        	String pileCode = (String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index1, 32, DataAnalyseWayEnum.StrASCII);
        	startedRst.setPileCode(pileCode);
        }
        // 充电枪号 1
        final byte index2 = index1 + 32;
        {
        	Double connectorNo = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index2, 1, DataAnalyseWayEnum.Byte);
        	startedRst.setConnectorNo(connectorNo.byteValue());
        }
        //启动结果 2
        final byte index3 = index2 + 1;
        {
        	Integer result = (Integer) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index3, 4, DataAnalyseWayEnum.Int32);
        	result = (result==0) ? 1 : 2;
        	startedRst.setResult(result);
        }
        log.info("充电桩启动结果上报(0x6e)");
        log.info("充电桩编码 :" + startedRst.getPileCode());
        log.info("充电枪口 :" + startedRst.getConnectorNo() + "号枪");
        log.info("命令执行结果 :" + (startedRst.getResult()==1 ? "成功" : "失败"));
		return startedRst;
	}

	@Override
	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
		return recPileStartedRstReport(fullData);
	}
}
