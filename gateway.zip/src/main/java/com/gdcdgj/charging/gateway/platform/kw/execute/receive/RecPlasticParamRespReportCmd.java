/*
 *
 */
package com.gdcdgj.charging.gateway.platform.kw.execute.receive;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.PlasticParamSet;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.kw.protocol.KwProtocolUtil;
import com.gdcdgj.charging.gateway.platform.kw.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;

import lombok.extern.slf4j.Slf4j;

/**
 * 充电桩整型参数设置应答(0x02)
 * 
 * @author ydc
 * @since 2017-3-1 下午8:09:07
 *
 */
@Slf4j
public class RecPlasticParamRespReportCmd implements BaseReceiveCmdExecute {

	public static PlasticParamSet recPlasticParamRespReport(byte[] fullData) throws Exception{
		PlasticParamSet plasticParamSet = new PlasticParamSet();
		KwProtocolUtil.setProvider(plasticParamSet);
		final byte[] dataAfterCmdSeq = KwProtocolUtil.getDataAfterCmdSeqInDataField(fullData);
		
		// 长度，字节数
        final int len1 = 1;
        final int len4 = 4;
        final int len32 = 32;

        // 充电桩编码 32
        final byte indexFault = len4;
        {
        	String pileCode = (String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault, len32, DataAnalyseWayEnum.StrASCII);
        	plasticParamSet.setPileCode(pileCode);
        }
        // 参数类型 1
        final byte index0 = indexFault + len32;
        {
            Double paramType = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index0, len1, DataAnalyseWayEnum.Byte);
            plasticParamSet.setParamType(paramType.byteValue());
        }
        // 设置查询参数/起始地址
        final byte index1 = index0 + len1;
        {
        	Double originAddr = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index1, len4, DataAnalyseWayEnum.Int32);
        	plasticParamSet.setOriginAddr(originAddr.intValue());
        }
        // 设置/查询个数
        final byte index2 = index1 + len4;
        {
        	Double paramCount = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index2, len1, DataAnalyseWayEnum.Byte);
        	plasticParamSet.setParamCount(paramCount.byteValue());
        }
        // 设置/查询结果
        final byte index3 = index2 + len1;
        {
        	Double resultCode = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index3, len1, DataAnalyseWayEnum.Byte);
        	plasticParamSet.setResultCode(resultCode.byteValue());
        }
        // 设置参数信息
        final byte index4 = index3 + len1;
        {
        	if(dataAfterCmdSeq.length-index4 > 0) {
        		 Double value = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index4, dataAfterCmdSeq.length-index4, DataAnalyseWayEnum.Int32);
                 plasticParamSet.setValue(value.intValue());
        	}
        }
        log.info("充电桩整型参数设置应答(0x02)");
        log.info("充电桩编码 :" + plasticParamSet.getPileCode());
        log.info("参数类型 :" + plasticParamSet.getParamType());
        log.info("参数/起始地址 :" + ((plasticParamSet.getOriginAddr()==2) ? "同步充电桩时间" : plasticParamSet.getOriginAddr()+""));
        log.info("设置/查询个数 :" + plasticParamSet.getParamCount());
        log.info("设置/查询结果 :" + (plasticParamSet.getResultCode()==0 ? "成功" : "失败"));
        log.info("参数信息 :" + plasticParamSet.getValue());
		return plasticParamSet;
	}

	@Override
	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
		return recPlasticParamRespReport(fullData);
	}

}
