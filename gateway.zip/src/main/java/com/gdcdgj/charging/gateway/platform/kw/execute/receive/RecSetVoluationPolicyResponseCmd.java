/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.kw.execute.receive;


import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.SetVoluationPolicy;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.kw.protocol.KwProtocolUtil;
import com.gdcdgj.charging.gateway.platform.kw.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;

import lombok.extern.slf4j.Slf4j;

/**
 * 充电桩应答后台设置24时电费计价策略信息(0x50 0x04)
 *
 * @author ydc
 * @since 2016-11-14 下午4:17:23
 */
@Slf4j
public class RecSetVoluationPolicyResponseCmd implements BaseReceiveCmdExecute{

    /**
     * 充电桩应答后台设置24时电费计价策略信息(0x50 0x04)
     *
     * @param fullData
     * @param info
     * @return
     * @throws Exception
     * @author ouxx
     * @date 2016-11-14 下午4:19:21
     */
    public static SetVoluationPolicy recModuleInfoResponse(byte[] fullData) throws Exception {
    	SetVoluationPolicy info = new SetVoluationPolicy();
    	KwProtocolUtil.setProvider(info);
        final byte[] dataAfterCmdSeq = KwProtocolUtil.getDataAfterCmdSeqInDataField(fullData);
        // 执行结果通报
        Double resultCode = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, 0, 1, DataAnalyseWayEnum.Byte);
        info.setResultCode(resultCode.byteValue());
        log.info("充电桩应答后台设置24时电费计价策略信息(0x50 0x04)");
        log.info("执行结果 :" + (info.getResultCode()==0 ? "成功" : "失败"));
        return info;
    }

	@Override
	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
		return recModuleInfoResponse(fullData);
	}
}
