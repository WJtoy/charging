package com.gdcdgj.charging.gateway.platform.kw.execute.receive;


import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.Date;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.SignIn;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.kw.protocol.KwProtocolUtil;
import com.gdcdgj.charging.gateway.platform.kw.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;

import lombok.extern.slf4j.Slf4j;

/**
 * 中心系统签到应答中心系统查询签到(0x6a)
 * @author ydc
 * @date 2020/4/14 18:08
 * @since JDK 1.8
 */
@Slf4j
public class RecSignInResponseCmd implements BaseReceiveCmdExecute{

    /**
     * 中心系统查询签到应答/上报(0x6a)
     * 充电桩签到上报报文是用于传送充电桩工作状态的数据消息格式
     *
     * @param fullData
     * @param signIn
     * @return
     * @throws Exception
     * @author ouxx
     * @date 2016-11-14 下午3:52:43
     */
    public static SignIn recSignInResponse(byte[] fullData) throws Exception {
    	SignIn signIn = new SignIn();
    	KwProtocolUtil.setProvider(signIn);
    	DecimalFormat df = new DecimalFormat("#0.00");
        final byte[] dataAfterCmdSeq = KwProtocolUtil.getDataAfterCmdSeqInDataField(fullData);
        final int len1 = 1;
        final int len2 = 2;
        final int len4 = 4;
        final int len32 = 32;
        //充电桩编码
        final int index0 = 4;
        String equipmentCode = (String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index0, len32, DataAnalyseWayEnum.StrASCII);
        signIn.setPileCode(equipmentCode);
        //标志（是否加密）
        final int index1 = index0 + len32;
        Double encrypt = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index1, len1, DataAnalyseWayEnum.Byte);
        signIn.setSignal(encrypt.byteValue());

        //系统软件版本
        final int index2 = index1 + len1;
        Double version = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index2, len4, DataAnalyseWayEnum.Int32);
        signIn.setVersion(Double.parseDouble(df.format(version)));

        //存版本号字符串(因为传来的是大端模式，所以要颠倒顺序)
        // tcl: 该处是不是为小端模式才要颠倒顺序
        StringBuffer versionStr = new StringBuffer("");
        for (int i = index2; i < index2 + len4; ++i) {
            versionStr.append(dataAfterCmdSeq[i] + ".");
        }
        signIn.setVersionStr(versionStr.substring(0, versionStr.length() - 1));

        //启动次数
        final int index3 = index2 + len4 + len2;
        Double bootTimes = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index3, len4, DataAnalyseWayEnum.Int32);
        signIn.setBootTimes(bootTimes.longValue());

        //签到间隔时间
        final int index4 = index3 + len4 + len1;
        Double intervalTime = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index4, len2, DataAnalyseWayEnum.Int16);
        signIn.setIntervalTime(intervalTime.longValue());

        //充电枪个数
        final int index5 = index4 + len2 + len1;
        Double connectCount = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index5, len1, DataAnalyseWayEnum.Byte);
        signIn.setConnectCount(connectCount.intValue());

        //充电记录数量
        final int index6 = index5 + len1 + len2;
        Double chargeCount = (Double)ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index6, len4, DataAnalyseWayEnum.Int32);
        signIn.setChargeCount(chargeCount.intValue());

        //当前充电桩系统时间
        // 时间默认为8个字节
        final int index7 = index6 + len4;
        Calendar currentTime = ProtocolDataGenerator.getCalendar(index7, dataAfterCmdSeq);
        signIn.setCurrentTime(currentTime);
        Calendar currentTimes = Calendar.getInstance(); 
        currentTimes.setTime(new Date());
        long millis = currentTime.getTime().getTime() - currentTimes.getTime().getTime();
        if(millis > 5000) {
        	//时间同步
        	log.info("启动将当前时间同步到桩");
        }
        signIn.setStartStopSingal((byte) 1);
        log.info("系统签到应答中心系统查询签到(0x6a)");
        log.info("充电桩编码 :" + signIn.getPileCode());
        log.info("加密标志 :" + (signIn.getSignal()==0 ? "不支持加密" : "加密"));
        log.info("系统软件版本 :" + signIn.getVersionStr());
        log.info("启动次数:" + signIn.getBootTimes());
        log.info("签到间隔时间 :" + signIn.getIntervalTime());
        log.info("充电枪个数:" + signIn.getConnectCount());
        log.info("充电记录数量:" + signIn.getChargeCount());
        log.info("当前充电桩系统时间:" + signIn.getCurrentTime().getTime());
        return signIn;
    }

	@Override
	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
		return recSignInResponse(fullData);
	}
}

