/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.kw.execute.receive;

import java.text.DecimalFormat;
import java.util.Calendar;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.StateInfo;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.kw.protocol.KwProtocolUtil;
import com.gdcdgj.charging.gateway.platform.kw.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;

import lombok.extern.slf4j.Slf4j;

/**
 * 状态信息报上报(0x68)
 * <p>信息包发送报文 </p>
 *
 * @author ydc
 * @since 2016-11-14 下午3:35:46
 */
@Slf4j
public class RecStateInfoReportCmd implements BaseReceiveCmdExecute{

    private static RecStateInfoReportCmd recHeartBeatReportCmd = null;

    public static synchronized RecStateInfoReportCmd getInstance() {
        if (recHeartBeatReportCmd == null) {
            recHeartBeatReportCmd = new RecStateInfoReportCmd();
        }
        return recHeartBeatReportCmd;
    }

    /**
     * 远端信息包上报(0x68)
     *
     * @param fullData
     * @return
     * @throws Exception
     * @author ouxx
     * @date 2016-11-3 下午1:50:21
     */
    public static StateInfo recHeartbeatReport(byte[] fullData) {
    	StateInfo stateInfo = new StateInfo();
    	KwProtocolUtil.setProvider(stateInfo);
    	DecimalFormat df = new DecimalFormat("#0.00");
    	
    	final int len1 =1;
    	final int len2 =2;
    	final int len4 =4;
    	final int len32 =32;
        try {
        	final byte[] dataAfterCmdSeq = KwProtocolUtil.getDataAfterCmdSeqInDataField(fullData);
        	// 充电桩编码 32
            final byte indexFault = len4;
            {
            	String pileCode = (String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault, len32, DataAnalyseWayEnum.StrASCII);
            	stateInfo.setPileCode(pileCode);
            }
            // 充电枪数量 1
            final byte indexFault1 = indexFault + len32;
            {
                Double connectorCount = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault1, len1, DataAnalyseWayEnum.Byte);
                stateInfo.setConnectorCount(connectorCount.byteValue());
            }
            // 充电口号 1
            final byte indexFault2 = indexFault1 + len1;
            {
                Double chargeConnectorNo = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault2, len1, DataAnalyseWayEnum.Byte);
                stateInfo.setConnectorNo(chargeConnectorNo.byteValue());
            }
            // 充电枪类型 1
            final byte indexFault3 = indexFault2 + len1;
            {
                Double connectorType = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault3, len1, DataAnalyseWayEnum.Byte);
                stateInfo.setConnectorType(connectorType.byteValue());
            }
            // 工作状态 1
            final byte indexFault4 = indexFault3 + len1;
            {
                Double workState = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault4, len1, DataAnalyseWayEnum.Byte);
                stateInfo.setWorkState(workState.byteValue());
            }
            // 当前SOC% 1
            final byte indexFault5 = indexFault4 + len1;
            {
                Double currentSOC = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault5, len1, DataAnalyseWayEnum.Byte);
                stateInfo.setCurrentSOC(currentSOC.byteValue());
            }
            // 当前告警信息 4
            final byte indexFault6 = indexFault5 + len1;
            {
                Double alarmCode = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault6, len4, DataAnalyseWayEnum.Int32);
                stateInfo.setAlarmCode(alarmCode.intValue());
            }
            // 车连接状态 1
            final byte indexFault7 = indexFault6 + len4;
            {
                Double carConntectState = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault7, len1, DataAnalyseWayEnum.Byte);
                stateInfo.setCarConnectState(carConntectState.byteValue());
            }
            // 充电累计充电费用 4
            final byte indexFault8 = indexFault7 + len1;
            {
                Double chargeCost = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault8, len4, DataAnalyseWayEnum.Int32);
                stateInfo.setChargeCost(chargeCost.intValue());
            }
            // 直流充电电压 2
            final byte indexFault9 = indexFault8 + len4 + len4 + len4;
            {
                Double dCChargePressure = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault9, len2, DataAnalyseWayEnum.Int16);
                stateInfo.setDCChargePressure(Double.parseDouble(df.format(dCChargePressure*0.01)));
            }
            // 直流充电电流 2
            final byte indexFault10 = indexFault9 + len2;
            {
                Double dCChargeElectric = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault10, len2, DataAnalyseWayEnum.Int16);
                stateInfo.setDCChargeElectric(Double.parseDouble(df.format(dCChargeElectric*0.01)));
            }
            // BMS需求电压 2
            final byte indexFault11 = indexFault10 + len2;
            {
                Double bMSPressure = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault11, len2, DataAnalyseWayEnum.Int16);
                stateInfo.setBMSPressure(bMSPressure.intValue());
            }
            // BMS需求电流 2
            final byte indexFault12 = indexFault11 + len2;
            {
                Double bMSElectric = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault12, len2, DataAnalyseWayEnum.Int16);
                stateInfo.setBMSElectric(bMSElectric.intValue());
            }
            // BMS充电模式 2
            final byte indexFault13 = indexFault12 + len2;
            {
                Double bMSChargeType = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault13, len1, DataAnalyseWayEnum.Byte);
                stateInfo.setBMSChargeType(bMSChargeType.byteValue());
            }
            // 交流A相充电电压 2
            final byte indexFault14 = indexFault13 + len1;
            {
                Double aCChargePressure = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault14, len2, DataAnalyseWayEnum.Int16);
                stateInfo.setACChargePressure(aCChargePressure.intValue());
            }
            // 交流B相充电电压 2
            final byte indexFault15 = indexFault14 + len2;
            {
                Double aCChargePressure = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault15, len2, DataAnalyseWayEnum.Int16);
                stateInfo.setACChargePressure1(aCChargePressure.intValue());
            }
            // 交流C相充电电压 2
            final byte indexFault16 = indexFault15 + len2;
            {
                Double aCChargePressure = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault16, len2, DataAnalyseWayEnum.Int16);
                stateInfo.setACChargePressure2(aCChargePressure.intValue());
            }
            // 交流A相充电电流 2
            final byte indexFault17 = indexFault16 + len2;
            {
                Double aCChargeElectric = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault17, len2, DataAnalyseWayEnum.Int16);
                stateInfo.setACChargeElectric(aCChargeElectric.intValue());
            }
            // 交流B相充电电流 2
            final byte indexFault18 = indexFault17 + len2;
            {
                Double aCChargeElectric = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault18, len2, DataAnalyseWayEnum.Int16);
                stateInfo.setACChargeElectric1(aCChargeElectric.intValue());
            }
            // 交流C相充电电流 2
            final byte indexFault19 = indexFault18 + len2;
            {
                Double aCChargeElectric = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault19, len2, DataAnalyseWayEnum.Int16);
                stateInfo.setACChargeElectric2(aCChargeElectric.intValue());
            }
            // 剩余充电时间 2
            final byte indexFault20 = indexFault19 + len2;
            {
                Double residueChargeTime = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault20, len2, DataAnalyseWayEnum.Int16);
                stateInfo.setResidueChargeTime(residueChargeTime.intValue());
            }
            // 充电时长 4
            final byte indexFault21 = indexFault20 + len2;
            {
                Double chargeTime = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault21, len4, DataAnalyseWayEnum.Int32);
                stateInfo.setChargeTime(chargeTime.intValue());
            }
            // 本次充电累计电量 4
            final byte indexFault22 = indexFault21 + len4;
            {
                Double chargePowerCount = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault22, len4, DataAnalyseWayEnum.Int32);
                stateInfo.setChargePowerCount(Double.parseDouble(df.format(chargePowerCount*0.01)));
            }
            //当前电表读数
            final byte indexFault222 = indexFault22 + len4;
            {
                Double currentQuliety = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault222, len4, DataAnalyseWayEnum.Int32);
                stateInfo.setCurrentQuliety(Double.parseDouble(df.format(currentQuliety*0.01)));
            }
            // 充电启动方式 1
            final byte indexFault23 = indexFault22 + len4 + len4 + len4;
            {
                Double startType = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault2, len1, DataAnalyseWayEnum.Byte);
                stateInfo.setStartType(startType.byteValue());
            }
            // 充电预约卡号 32
            final byte indexFault24 = indexFault23 + len1 + len2 + len4;
            {
                String chargeNo = (String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault24, len32, DataAnalyseWayEnum.StrASCII);
                stateInfo.setChargeNo(chargeNo);
            }
            // 预约开始充电时间 8
            final int indexFault25 = indexFault24 + len1 + len32;
            {
            	Calendar beginChargeTime = ProtocolDataGenerator.getCalendar(indexFault25, dataAfterCmdSeq);
            	stateInfo.setBeginChargeTime(beginChargeTime);
            }
            // 充电功率 8
            final int indexFault26 = indexFault25 + 16;
            {
            	Double chargePower = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault26, len4, DataAnalyseWayEnum.Int32);
            	stateInfo.setChargePower(Double.parseDouble(df.format(chargePower)));
            }
            log.info("远端信息包上报(0x68)");
            log.info("充电桩编码 :" + stateInfo.getPileCode());
            log.info("充电枪数量 :" + stateInfo.getConnectorCount());
            log.info("充电口号 :" + stateInfo.getConnectorNo());
            log.info("充电枪类型 :" + stateInfo.getConnectorType());
            log.info("工作状态 :" + stateInfo.getWorkState());
            log.info("当前SOC% :" + stateInfo.getCurrentSOC());
            log.info("当前告警信息 :" + (stateInfo.getAlarmCode()==0 ? "无告警" : stateInfo.getAlarmCode()));
            log.info("车连接状态 :" + stateInfo.getCarConnectState());
            log.info("充电累计充电费用 :" + stateInfo.getChargeCost());
            log.info("直流充电电压 :" + stateInfo.getDCChargePressure());
            log.info("直流充电电流 :" + stateInfo.getDCChargeElectric());
            log.info("BMS需求电压 :" + stateInfo.getBMSPressure());
            log.info("BMS需求电流 :" + stateInfo.getBMSElectric());
            log.info("BMS充电模式 :" + stateInfo.getBMSChargeType());
            log.info("交流A相充电电压 :" + stateInfo.getACChargePressure());
            log.info("交流B相充电电压 :" + stateInfo.getACChargePressure1());
            log.info("交流C相充电电压 :" + stateInfo.getACChargePressure2());
            log.info("交流A相充电电流 :" + stateInfo.getACChargeElectric());
            log.info("交流B相充电电流 :" + stateInfo.getACChargeElectric1());
            log.info("交流C相充电电流 :" + stateInfo.getACChargeElectric2());
            log.info("剩余充电时间 :" + stateInfo.getResidueChargeTime());
            log.info("本次充电累计电量 :" + stateInfo.getChargePowerCount());
            log.info("当前电表读数 :" + stateInfo.getCurrentQuliety());
            log.info("充电启动方式 :" + stateInfo.getStartType());
            log.info("剩余充电时间 :" + stateInfo.getResidueChargeTime());
            log.info("充电预约卡号 :" + stateInfo.getChargeNo());
            log.info("预约开始充电时间 :" + stateInfo.getBeginChargeTime().getTime());
            log.info("充电功率 :" + stateInfo.getChargePower());
            return stateInfo;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return stateInfo;
    }

	@Override
	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
		return recHeartbeatReport(fullData);
	}
}
