/*
 *
 */
package com.gdcdgj.charging.gateway.platform.kw.execute.receive;


import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.StrParamSet;
import com.gdcdgj.charging.gateway.platform.BaseReceiveCmdExecute;
import com.gdcdgj.charging.gateway.platform.kw.protocol.KwProtocolUtil;
import com.gdcdgj.charging.gateway.platform.kw.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;

import lombok.extern.slf4j.Slf4j;

/**
 * 充电桩字符型参数设置应答(0x04)
 * 
 * @author ydc
 * @since 2017-3-1 下午8:09:07
 *
 */
@Slf4j
public class RecStrParamRespReportCmd implements BaseReceiveCmdExecute{

	public static StrParamSet recStrParamRespReport(byte[] fullData) throws Exception{
		StrParamSet strParamSet = new StrParamSet();
		KwProtocolUtil.setProvider(strParamSet);
		final byte[] dataAfterCmdSeq = KwProtocolUtil.getDataAfterCmdSeqInDataField(fullData);
		
		// 长度，字节数
        final int len1 = 1;
        final int len4 = 4;
        final int len32 = 32;

        // 充电桩编码 32
        final byte indexFault = 4;
        {
        	String pileCode = (String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, indexFault, len32, DataAnalyseWayEnum.StrASCII);
        	strParamSet.setPileCode(pileCode);
        }
        // 参数类型 1
        final byte index0 = indexFault + len32;
        {
            Double paramType = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index0, len1, DataAnalyseWayEnum.Byte);
            strParamSet.setParamType(paramType.byteValue());
        }
        // 设置查询参数/起始地址
        final byte index1 = index0 + len1;
        {
        	Double originAddr = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index1, len4, DataAnalyseWayEnum.Int32);
            strParamSet.setOriginAddr(originAddr.intValue());
        }
        // 设置/查询结果
        final byte index2 = index1 + len4;
        {
        	Double resultCode = (Double) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index2, len1, DataAnalyseWayEnum.Byte);
        	strParamSet.setResultCode(resultCode.byteValue());
        }
        // 设置参数信息
        if(strParamSet.getParamType() == 1) {
        	 final byte index3 = index2 + len1;
             {
             	String value = (String) ProtocolDataGenerator.getOneData(dataAfterCmdSeq, index3, dataAfterCmdSeq.length-index3, DataAnalyseWayEnum.StrASCII);
             	strParamSet.setValue(value);
             }
        }
        log.info("充电桩字符型参数设置应答(0x04)");
        log.info("充电桩编码 :" + strParamSet.getPileCode());
        log.info("参数类型 :" + strParamSet.getParamType());
        log.info("参数/起始地址 :" + ((strParamSet.getOriginAddr()==2) ? "同步充电桩时间" : strParamSet.getOriginAddr()+""));
        log.info("查询结果 :" + (strParamSet.getResultCode()==0 ? "成功" : "失败"));
        log.info("参数信息 :" + strParamSet.getValue());
		return strParamSet;
	}

	@Override
	public DataBaseVo receiveCmdExecute(byte[] fullData) throws Exception {
		return recStrParamRespReport(fullData);
	}

}
