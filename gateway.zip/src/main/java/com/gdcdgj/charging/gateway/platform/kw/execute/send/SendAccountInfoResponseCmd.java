/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.kw.execute.send;


import com.gdcdgj.charging.api.vo.srv2gw.AccountInfo;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.kw.protocol.KwCmdEnum;
import com.gdcdgj.charging.gateway.platform.kw.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;

import lombok.extern.slf4j.Slf4j;

/**
 * 服务器应答账户查询信息(0xcb)
 * 
 * @author ydc
 * @since
 *
 */
@Slf4j
public class SendAccountInfoResponseCmd implements BaseSendCmdExecute {

	/**
	 * 服务器应答账户查询信息(0xcb)
	 * @param connectorNo
	 * @param memberId
	 * @param cmdSeq
	 * @param vo
	 */
	public byte[] generateSendDatas(int connectorNo, DataBaseVo vo) {
		AccountInfo accountInfo = (AccountInfo) vo;
		//初始定长
		final int len1 = 1;
		final int len2 = 2;
		final int len4 = 4;
		byte[] datas = new byte[114];
		final int index0 = 0;
		{
		//VinCode查询标识
			byte[] data = DataAnalyzer.analyseCommandData(accountInfo.getQueryCode(), DataAnalyseWayEnum.Int32);
			System.arraycopy(data, 0, datas, index0, len2);
		}
		{
		//预留
			byte[] data = new byte[2];
			System.arraycopy(data, 0, datas, len2, len2);
		}
		final int index1 = index0 + len4;
		{
		//响应码
			byte[] data = DataAnalyzer.analyseCommandData(accountInfo.getQueryCode(), DataAnalyseWayEnum.Int32);
			System.arraycopy(data, 0, datas, index1, len4);
		}
		final int index2 = index1 + len4;
		{
		//账户余额
			byte[] data = DataAnalyzer.analyseCommandData(accountInfo.getAccountBalance(), DataAnalyseWayEnum.Int32);
			System.arraycopy(data, 0, datas, index2, len4);
		}
		final int indexs = index2 + len4;
		{
		//预留
				byte[] data = new byte[2];
				System.arraycopy(data, 0, datas, indexs, len2);
		}
		final int index3 = index2 + len4 + len2;
		{
		//服务费率
			byte[] data = DataAnalyzer.analyseCommandData(accountInfo.getServeRate(), DataAnalyseWayEnum.Int16);
			System.arraycopy(data, 0, datas, index3, len2);
		}
		final int index4 = index3 + len2;
		{
		//充电密码验证
			byte[] data = new byte[1];
			//byte[] data = DataAnalyzer.analyseCommandData(accountInfo.getChargeSignal(), DataAnalyseWayEnum.Byte);
			System.arraycopy(data, 0, datas, index4, len1);
		}
		final int index5 = index4 + len1;
		{
		//验证VIN标志
			byte[] data = new byte[1];
			//byte[] data = DataAnalyzer.analyseCommandData(accountInfo.getVINSignal(), DataAnalyseWayEnum.Byte);
			System.arraycopy(data, 0, datas, index5, len1);
		}
		final int indexd = index5 + len1;
		{
		//预留
				byte[] data = new byte[2];
				System.arraycopy(data, 0, datas, indexd, len2);
		}
		final int index6 = index5 + 3;
		{
		//车辆VIN
			byte[] data = new byte[17];
			//byte[] data = DataAnalyzer.analyseCommandData(accountInfo.getCarVIN(), DataAnalyseWayEnum.StrASCII);
			System.arraycopy(data, 0, datas, index6, 17);
		}
		final int index7 = index6 + 17;
		{
		//服务费
			byte[] data = DataAnalyzer.analyseCommandData(accountInfo.getFee(), DataAnalyseWayEnum.Int32);
			System.arraycopy(data, 0, datas, index7, len4);
		}
		final int index8 = index7 + len4;
		{
		//充电卡号
			byte[] data1 = new byte[32];
			//byte[] data = DataAnalyzer.analyseCommandData(accountInfo.getChargeNo(), DataAnalyseWayEnum.StrASCII);
			//System.arraycopy(data, 0, data1, 0, accountInfo.getChargeNo().length());
			System.arraycopy(data1, 0, datas, index8, 32);
		}
		final int index9 = index8 + 32;
		{
		//充电订单号
			byte[] data1 = new byte[32];
			//byte[] data = DataAnalyzer.analyseCommandData(accountInfo.getChargeOrderNo(), DataAnalyseWayEnum.StrASCII);
			//System.arraycopy(data, 0, data1, 0, accountInfo.getChargeOrderNo().length());
			System.arraycopy(data1, 0, datas, index9, 32);
		}
		final int index10 = index9 + 32;
		{
		//充电订单号
			byte[] data = new byte[1];
			//byte[] data = DataAnalyzer.analyseCommandData(accountInfo.getFeeType(), DataAnalyseWayEnum.Byte);
			System.arraycopy(data, 0, datas, index10, len1);
		}
		final int index11 = index10 + len1;
		{
		//预留
			byte[] data = new byte[8];
			System.arraycopy(data, 0, datas, index11, 8);
		}
		log.info("服务器应答账户查询信息(0xcb)");
		log.info("生成数据 :" + (datas!=null ? "成功" : "失败"));
        log.info("数据长度 :" + ((datas.length == 114) ? "正常" : "出错"));
		// 发送报文
		return ProtocolDataGenerator.sendOneData_KW(connectorNo, datas, KwCmdEnum.ACCOUNT_INFO_QUERY);
	}

	@Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		byte[] datas = generateSendDatas(dataVo.getConnectorNo(),dataVo);
		return datas;
	}

}
