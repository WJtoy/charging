/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.kw.execute.send;


import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.HeartBeat;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.kw.protocol.KwCmdEnum;
import com.gdcdgj.charging.gateway.platform.kw.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;

import lombok.extern.slf4j.Slf4j;

/**
 * 服务器告警信息应答(0x6b)
 * <p>发送告警信息上报应答</p>
 * @author ydc
 * @since
 *
 */
@Slf4j
public class SendAlarmInfoResponseCmd implements BaseSendCmdExecute {

	/**
	 * 服务器告警信息应答(0x6b)
	 * @param connectorNo
	 * @param memberId
	 * @param cmdSeq
	 * @param vo
	 */
	public byte[] generateSendDatas(int connectorNo, DataBaseVo vo) {
		// 告警信息应答为4个空字节
		byte[] datas = new byte[4];
		log.info("服务器告警信息应答(0x6b)");
		log.info("生成数据 :" + (datas!=null ? "成功" : "失败"));
        log.info("数据长度 :" + (datas.length == 4 ? "正常" : "出错"));
		// 发送报文
		return ProtocolDataGenerator.sendOneData_KW(connectorNo, datas, KwCmdEnum.ALARM_INFO_RESPONSE);
	}

	@Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		byte[] datas = generateSendDatas(dataVo.getConnectorNo(),dataVo);
		return datas;
	}

}
