/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.kw.execute.send;


import com.gdcdgj.charging.api.vo.srv2gw.ChargeRecordInfo;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.kw.protocol.KwCmdEnum;
import com.gdcdgj.charging.gateway.platform.kw.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;

import lombok.extern.slf4j.Slf4j;

/**
 * 服务器应答充电桩上报充电信息报文(0xc9)
 * 
 * @author ydc
 * @since
 *
 */
@Slf4j
public class SendChargeRecordInfoResponseCmd implements BaseSendCmdExecute {

	/**
	 * 服务器应答充电桩上报充电信息报文(0xc9)
	 * @param connectorNo
	 * @param memberId
	 * @param cmdSeq
	 * @param vo
	 */
	public byte[] generateSendDatas(int connectorNo, DataBaseVo vo) {
		ChargeRecordInfo info = (ChargeRecordInfo) vo;
		//初始定长
		final int len1 = 1;
		final int len4 = 4;
		final int len32 = 32;
		byte[] datas = new byte[66];
		//充电口号
		final int index1 = len4;
		{
			byte[] data = DataAnalyzer.analyseCommandData((byte)info.getConnectorNo(), DataAnalyseWayEnum.Byte);
			System.arraycopy(data, 0, datas, index1, len1);
		}
		//充电卡号
		final int index2 = index1 + len1;
		{
			byte[] data1 = new byte[32];
//			byte[] data = DataAnalyzer.analyseCommandData(info.getChargeNo(), DataAnalyseWayEnum.StrASCII);
//			System.arraycopy(data, 0, data1, 0, data.length);
			System.arraycopy(data1, 0, datas, index2, len32);
		}
		//内部索引号
		final int index3 = index2 + len32;
		{
			byte[] data = DataAnalyzer.analyseCommandData(info.getIndexNum(), DataAnalyseWayEnum.Int32);
			System.arraycopy(data, 0, datas, index3, len4);
		}
		//字段有效标识
		final int index4 = index3 + len4;
		{
			byte[] data = DataAnalyzer.analyseCommandData((byte)info.getFieldSignal(), DataAnalyseWayEnum.Byte);
			System.arraycopy(data, 0, datas, index4, len1);
		}
		//充电优惠前金额
		final int index5 = index4 + len1;
		{
			byte[] data = new byte[4];
//			byte[] data = DataAnalyzer.analyseCommandData(info.getBeforeDiscountMoney(), DataAnalyseWayEnum.Byte);
			System.arraycopy(data, 0, datas, index5, len4);
		}
		//充电优惠后金额
		final int index6 = index5 + len4;
		{
			byte[] data = new byte[4];
//			byte[] data = DataAnalyzer.analyseCommandData(info.getDiscountMoney(), DataAnalyseWayEnum.Byte);
			System.arraycopy(data, 0, datas, index6, len4);
		}
		//充电实扣金额
		final int index7 = index6 + len4;
		{
			byte[] data = new byte[4];
//			byte[] data = DataAnalyzer.analyseCommandData(info.getActualMoney(), DataAnalyseWayEnum.Byte);
			System.arraycopy(data, 0, datas, index7, len4);
		}
		//用户余额
		final int index8 = index7 + len4;
		{
			byte[] data = new byte[] {0x00,(byte) 0xc8,0x00,0x00};
//			byte[] data = DataAnalyzer.analyseCommandData(info.getBalance(), DataAnalyseWayEnum.Byte);
			System.arraycopy(data, 0, datas, index8, len4);
		}
		//充电实扣电费
		final int index9 = index8 + len4;
		{
			byte[] data = new byte[] {0x00,0x2c,0x01,0x00};
//			byte[] data = DataAnalyzer.analyseCommandData(info.getActualPay(), DataAnalyseWayEnum.Byte);
			System.arraycopy(data, 0, datas, index9, len4);
		}
		//充电实扣服务费
		final int index10 = index9 + len4;
		{
			byte[] data = new byte[] {0x00,0x2c,0x01,0x00};
//			byte[] data = DataAnalyzer.analyseCommandData(info.getActualPayFee(), DataAnalyseWayEnum.Byte);
			System.arraycopy(data, 0, datas, index10, len4);
		}
		log.info("服务器应答充电桩上报充电信息报文(0xc9)");
		log.info("生成数据 :" + (datas!=null ? "成功" : "失败"));
        log.info("数据长度 :" + ((datas.length == 66) ? "正常" : "出错"));
		// 发送报文
		return ProtocolDataGenerator.sendOneData_KW(connectorNo, datas, KwCmdEnum.CHARGE_RECORD_INFO_RESP);
	}

	@Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		byte[] datas = generateSendDatas(dataVo.getConnectorNo(),dataVo);
		return datas;
	}
}
