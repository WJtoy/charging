/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.kw.execute.send;


import com.gdcdgj.charging.api.vo.srv2gw.ChargeTimeFrameInfo;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.kw.protocol.KwCmdEnum;
import com.gdcdgj.charging.gateway.platform.kw.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;

import lombok.extern.slf4j.Slf4j;

/**
 * 服务器查询最近一次充电各时段信息(0x71)
 * 
 * @author ydc
 * @since
 *
 */
@Slf4j
public class SendChargeTimeInfoResponseCmd implements BaseSendCmdExecute {

	/**
	 * 服务器查询最近一次充电各时段信息(0x71)
	 * @param connectorNo
	 * @param memberId
	 * @param cmdSeq
	 * @param vo
	 */
	public byte[] generateSendDatas(int connectorNo, DataBaseVo vo) {
		ChargeTimeFrameInfo info = (ChargeTimeFrameInfo) vo;
		//初始定长
		final int len1 = 1;
		final int len4 = 4;
		byte[] datas = new byte[6];
		//预留
		{
			byte[] data = new byte[4];
			System.arraycopy(data, 0, datas, 0, len4);
		}
		//充电口号
		final int index1 = len4;
		{
			byte[] data = new byte[] {0x01};
//			byte[] data = DataAnalyzer.analyseCommandData(info.getConnectorNo(), DataAnalyseWayEnum.Byte);
			System.arraycopy(data, 0, datas, index1, len1);
		}
		//标志
		final int index2 = index1 + len1;
		{
			byte[] data = new byte[]{0x01};
//			byte[] data = DataAnalyzer.analyseCommandData(info.getSignal(), DataAnalyseWayEnum.Byte);
			System.arraycopy(data, 0, datas, index2, len1);
		}
		log.info("服务器查询最近一次充电各时段信息(0x71)");
		log.info("生成数据 :" + (datas!=null ? "成功" : "失败"));
        log.info("数据长度 :" + ((datas.length == 6) ? "正常" : "出错"));
		// 发送报文
		return ProtocolDataGenerator.sendOneData_KW(connectorNo, datas, KwCmdEnum.CHARGE_TIMEFRAME_INFO);
	}

	@Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		byte[] datas = generateSendDatas(dataVo.getConnectorNo(),dataVo);
		return datas;
	}

}
