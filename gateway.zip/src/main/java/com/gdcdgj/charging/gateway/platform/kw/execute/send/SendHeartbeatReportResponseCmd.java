/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.kw.execute.send;


import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.HeartBeat;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.kw.protocol.KwCmdEnum;
import com.gdcdgj.charging.gateway.platform.kw.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;

import lombok.extern.slf4j.Slf4j;

/**
 * 服务器系统心跳包应答(0x65)
 * <p>发送心跳包信息上报应答</p>
 * @author ydc
 * @since
 *
 */
@Slf4j
public class SendHeartbeatReportResponseCmd implements BaseSendCmdExecute {

	/**
	 * 服务器系统心跳包应答(0x65)
	 * @param connectorNo
	 * @param memberId
	 * @param cmdSeq
	 * @param vo
	 */
	public byte[] generateSendDatas(int connectorNo, DataBaseVo vo) {
		HeartBeat heartBeat = (HeartBeat) vo;
		// 心跳应答为4+2字节
		final int len4 = 4;
		byte[] datas = new byte[6];
		byte[] data = new byte[] {0x02,0x00};
		if(null != heartBeat.getResponse()){
			// 拼出数据域
			data = DataAnalyzer.analyseCommandData(heartBeat.getResponse(), DataAnalyseWayEnum.CharReverse);
		}
		System.arraycopy(data, 0, datas, len4, 2);
		log.info("服务器系统心跳包应答(0x65)");
		log.info("生成数据 :" + (datas!=null ? "成功" : "失败"));
        log.info("数据长度 :" + (datas.length == 6 ? "正常" : "出错"));
		// 发送报文
		return ProtocolDataGenerator.sendOneData_KW(connectorNo, datas, KwCmdEnum.HEART_BEAT_REPORT_RESP);
	}

	@Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		byte[] datas = generateSendDatas(dataVo.getConnectorNo(),dataVo);
		return datas;
	}

}
