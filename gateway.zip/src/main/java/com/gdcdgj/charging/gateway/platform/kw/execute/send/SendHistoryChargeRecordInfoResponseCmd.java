/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.kw.execute.send;


import com.gdcdgj.charging.api.vo.srv2gw.ChargeRecordInfo;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.HistoryChargeRecord;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.kw.protocol.KwCmdEnum;
import com.gdcdgj.charging.gateway.platform.kw.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;

import lombok.extern.slf4j.Slf4j;

/**
 * 服务器应答充电桩上报历史充电记录信息报文(0x92,0x01)
 * 
 * @author ydc
 * @since
 *
 */
@Slf4j
public class SendHistoryChargeRecordInfoResponseCmd implements BaseSendCmdExecute {

	/**
	 * 服务器应答充电桩上报历史充电记录信息报文(0x92,0x01)
	 * @param connectorNo
	 * @param memberId
	 * @param cmdSeq
	 * @param vo
	 */
	public byte[] generateSendDatas(int connectorNo, DataBaseVo vo) {
		HistoryChargeRecord info = (HistoryChargeRecord) vo;
		//初始定长
		final int len4 = 4;
		byte[] datas = new byte[8];
		//查询记录起始索引
		final int index1 = len4;
		{
			byte[] data = new byte[4];
//			byte[] data = DataAnalyzer.analyseCommandData(info.getQueryCode(), DataAnalyseWayEnum.Byte);
			System.arraycopy(data, 0, datas, index1, len4);
		}
		
		log.info("服务器应答充电桩上报历史充电记录信息报文(0x92,0x01)");
		log.info("生成数据 :" + (datas!=null ? "成功" : "失败"));
        log.info("数据长度 :" + ((datas.length == 8) ? "正常" : "出错"));
		// 发送报文
		return ProtocolDataGenerator.sendOneData_KW(connectorNo, datas, KwCmdEnum.HISTORY_CHARGE_RECORD_INFO_RESP);
	}

	@Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		byte[] datas = generateSendDatas(dataVo.getConnectorNo(),dataVo);
		return datas;
	}

}
