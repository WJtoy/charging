/*
 *
 */
package com.gdcdgj.charging.gateway.platform.kw.execute.send;


import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.PileCtrl;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.kw.protocol.KwCmdEnum;
import com.gdcdgj.charging.gateway.platform.kw.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;

import lombok.extern.slf4j.Slf4j;

/**
 * 服务器下发启动充电控制命令(0x07)
 *
 * @author ydc
 * @since 2017-3-1 下午8:03:58
 */
@Slf4j
public class SendPileCtrlStartRstRespCmd implements BaseSendCmdExecute { 
	
	/**
	 * 充电桩启动 ,给出应答（0x07）
	 * @param connectorNo
	 * @param memberId
	 * @param cmdSeq
	 * @param vo
	 * @return
	 * @throws Exception 
	 * @throws
	 * @author Changliang Tao
	 * @date 2020/4/15 18:51
	 */
    public byte[] generateSendDatas(int connectorNo, DataBaseVo vo) {
        PileCtrl pileCtrlStart = (PileCtrl) vo;
        byte[] datas = new byte[112];
        // 数组copy定长
     	final int index0 = 0;
     	final int len1 = 1;
     	final int len4 = 4;
     	final int len8 = 8;
     	final int len32 = 32;
     	{	 
     	// 用户余额
     		byte[] balance = new byte[4] ;
//			byte[] balance = DataAnalyzer.analyseCommandData(pileCtrlStart.getBalance().intValue(), DataAnalyseWayEnum.Int32);
			System.arraycopy(balance, 0, datas, index0, len4);
		}
     	// 枪口
     	{
     		//byte[] connectorNos = new byte[] {0x02};
     		Double cnto = (double)pileCtrlStart.getConnectorNo();
     		byte[] connectorNos = DataAnalyzer.analyseCommandData(cnto.byteValue(), DataAnalyseWayEnum.Byte);
			System.arraycopy(connectorNos, 0, datas, 4, len1);
     	}
     	// 充电停止密码
     	{
     		byte[] chargeStopCheck = new byte[4];
     		//byte[] chargeStopCheck = DataAnalyzer.analyseCommandData(pileCtrlStart.getChargeStopCheck(), DataAnalyseWayEnum.Int32);
			System.arraycopy(chargeStopCheck, 0, datas, 5, len4);
     	}
     	// 充电生效类型 默认0-即时充电
     	{
     		byte[] chargeType = new byte[4];
     		//byte[] chargeType = DataAnalyzer.analyseCommandData(pileCtrlStart.getType(), DataAnalyseWayEnum.Int32);
			System.arraycopy(chargeType, 0, datas, 9, len4);
     	}
     	// 充电策略 默认0-充满为止
     	{
     		byte[] chargePolicy = new byte[4];
     		//byte[] chargePolicy = DataAnalyzer.analyseCommandData(pileCtrlStart.getChargePolicy(), DataAnalyseWayEnum.Int32);
			System.arraycopy(chargePolicy, 0, datas, 13, len4);
     	}
     	// 充电策略参数（时间、金额、电量单位） 采用默认设置
     	{
     		byte[] chargePolicyParam = new byte[4];
     		//byte[] chargePolicyParam = DataAnalyzer.analyseCommandData(pileCtrlStart.getChargePolicyParam(), DataAnalyseWayEnum.Int32);
			System.arraycopy(chargePolicyParam, 0, datas, 17, len4);
     	}
     	// 预约、定时启动时间
     	{
     		byte[] timerStartTime = new byte[8];
     		//byte[] timerStartTime = DataAnalyzer.analyseCommandData(pileCtrlStart.getTimerStartTime().toString(), DataAnalyseWayEnum.BCD16);
			System.arraycopy(timerStartTime, 0, datas, 21, len8);
     	}
     	{
     	// 预约超时时间
     		byte[] timeoutTime = new byte[1];
     		//byte[] timeoutTime = DataAnalyzer.analyseCommandData(pileCtrlStart.getTimeoutTime(), DataAnalyseWayEnum.Byte);
			System.arraycopy(timeoutTime, 0, datas, 29, len1);
     	}
     	// 用户卡号、用户识别号
     	{
     		byte[] userNos = new byte[32];
     		byte[] userNo = DataAnalyzer.analyseCommandData(pileCtrlStart.getUserNo(), DataAnalyseWayEnum.GB2312);
     		System.arraycopy(userNo, 0, userNos, 0, userNo.length);
			System.arraycopy(userNos, 0, datas, 30, len32);
     	}
     	// 断网充电标志 默认可充
     	{
            byte[] chargeSignal = new byte[] {0x01};
       		System.arraycopy(chargeSignal, 0, datas, 62, len1);
        }
        {
        // 离线可充电电量 采用默认
        	byte[] unlineCharge = new byte[] {(byte) 0xe8,0x03,0x00,0x00};
       		System.arraycopy(unlineCharge, 0, datas, 63, len4);
        }
        {
        // 流水号
            byte[] serialNo = new byte[32];
           	System.arraycopy(serialNo, 0, datas, 67, len32);
        }
        {
        // 服务费 不采用桩自带的费用计算
            byte[] fee = new byte[4];
            System.arraycopy(fee, 0, datas, 99, len4);
        }
        {
        // 服务类型
            byte[] serverType = new byte[1];
            System.arraycopy(serverType, 0, datas, 103, len1);
        }
        {
        // 预留
            byte[] reserved = new byte[8];
            System.arraycopy(reserved, 0, datas, 104, len8);
        }
        log.info("服务器下发启动充电控制命令(0x07)");
        log.info("生成数据 :" + (datas!=null ? "成功" : "失败"));
        log.info("数据长度 :" + (datas.length == 112 ? "正常" : "出错"));
        // 拼接报文
        return ProtocolDataGenerator.sendOneData_KW(connectorNo, datas, KwCmdEnum.PILE_STSRT_REPORT);
    }

	@Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		byte[] datas = generateSendDatas(dataVo.getConnectorNo(), dataVo);
		return datas;
	}
}
