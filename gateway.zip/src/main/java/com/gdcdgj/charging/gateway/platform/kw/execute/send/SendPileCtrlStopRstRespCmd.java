/*
 *
 */
package com.gdcdgj.charging.gateway.platform.kw.execute.send;



import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.PileCtrl;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.kw.protocol.KwCmdEnum;
import com.gdcdgj.charging.gateway.platform.kw.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;

import lombok.extern.slf4j.Slf4j;

/**
 * 服务器下发停止充电控制命令(0x05)
 *
 * @author ydc
 * @since 2017-3-1 下午8:03:58
 */
@Slf4j
public class SendPileCtrlStopRstRespCmd implements BaseSendCmdExecute {
	
	/**
	 * 充电桩停止充电 ,给出应答（0x05）
	 * @param connectorNo
	 * @param memberId
	 * @param cmdSeq
	 * @param vo
	 * @return
	 * @throws Exception 
	 * @throws
	 * @author Changliang Tao
	 * @date 2020/4/15 18:51
	 */
    public byte[] generateSendDatas(int connectorNo, DataBaseVo vo) {
        PileCtrl pileCtrl = (PileCtrl) vo;
        pileCtrl.setConnectorCount((byte)1);
        Byte count = pileCtrl.getConnectorCount();
        count = (null != count) ? count.byteValue() : 0;
        byte[] datas = new byte[12+count*4];
        // 数组copy定长
     	final int len1 = 1;
     	final int len2 = 2;
     	final int len4 = 4;
     	// 充电枪口
     	{	
//     		byte[] cntos = new byte[] {0x02};
     		Double cnto = (double)connectorNo;
     		byte[] cntos = DataAnalyzer.analyseCommandData(cnto.byteValue(), DataAnalyseWayEnum.Byte);
			System.arraycopy(cntos, 0, datas, 4, len1);
		}
     	// 起始命令地址
     	{
     		byte[] originAddr = new byte[] {0x02,0x00,0x00,0x00};
//     		byte[] originAddr = DataAnalyzer.analyseCommandData(pileCtrl.getOriginAddr(), DataAnalyseWayEnum.Int32);
     		System.arraycopy(originAddr, 0, datas, 5, len4);
     	}
     	// 命令个数
     	{
     		byte[] cmdNo = new byte[] {0x01};
//     		byte[] cmdNo = DataAnalyzer.analyseCommandData(pileCtrl.getConnectorCount(), DataAnalyseWayEnum.Byte);
			System.arraycopy(cmdNo, 0, datas, 9, len1);
     	}
     	// 命令参数长度
     	{
     		byte[] cmdLength = new byte[] {0x04,0x00};
//     		byte[] cmdLength = DataAnalyzer.analyseCommandData(pileCtrl.getValueLength(), DataAnalyseWayEnum.Int16);
			System.arraycopy(cmdLength, 0, datas, 10, len2);
     	}
     	// 命令参数
     	{
     		byte[] cmdParam = new byte[] {0x55,0x00,0x00,0x00};
     		System.arraycopy(cmdParam, 0, datas, 12, len4);
//     		Map<Byte,Integer> maps = pileCtrl.getValueMap();
//     		for (int i = 0; i < maps.size(); i++) {
//     			byte[] cmdParam = DataAnalyzer.analyseCommandData(maps.get((byte)i), DataAnalyseWayEnum.Int32);
//    			System.arraycopy(cmdParam, 0, datas, 12, len4);
//			}
     	}
        log.info("充电桩停止充电 ,给出应答（0x05）");
        log.info("生成数据 :" + (datas!=null ? "成功" : "失败"));
        log.info("数据长度 :" + (datas.length == (12+count*4) ? "正常" : "出错"));
        // 拼接报文
        return ProtocolDataGenerator.sendOneData_KW(connectorNo, datas, KwCmdEnum.PILE_STOP_REPORT);
    }

	@Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		byte[] datas = generateSendDatas(dataVo.getConnectorNo(),dataVo);
		return datas;
	}
}
