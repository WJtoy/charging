/*
 *
 */
package com.gdcdgj.charging.gateway.platform.kw.execute.send;



import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.PileStartedRst;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.kw.protocol.KwCmdEnum;
import com.gdcdgj.charging.gateway.platform.kw.protocol.ProtocolDataGenerator;

import lombok.extern.slf4j.Slf4j;

/**
 * 充电桩启动成功后，平台收到桩的0x6e上报后的应答0x6d
 *
 * @author ydc
 * @since 2017-3-1 下午8:03:58
 */
@Slf4j
public class SendPileStartedRstRespCmd implements BaseSendCmdExecute {
	
	/**
	 * 充电桩启动成功 ,给出应答（0x6d）
	 * @param connectorNo
	 * @param memberId
	 * @param cmdSeq
	 * @param vo
	 * @return
	 * @throws
	 * @author Changliang Tao
	 * @date 2020/4/15 18:51
	 */
    public byte[] generateSendDatas(int connectorNo, DataBaseVo vo) {
        PileStartedRst startedRst = (PileStartedRst) vo;
        byte[] datas = new byte[4];
        log.info("充电桩启动成功 ,给出应答（0x6d）");
        log.info("生成数据 :" + (datas!=null ? "成功" : "失败"));
        log.info("数据长度 :" + ((datas.length == 4) ? "正常" : "出错"));
        // 拼接报文
        return ProtocolDataGenerator.sendOneData_KW(connectorNo, datas, KwCmdEnum.PILE_STARTED_RESP);
    }

	@Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		byte[] datas = generateSendDatas(dataVo.getConnectorNo(),dataVo);
		return datas;
	}
}
