/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.kw.execute.send;


import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.PlasticParamSet;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.kw.protocol.KwCmdEnum;
import com.gdcdgj.charging.gateway.platform.kw.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;

import lombok.extern.slf4j.Slf4j;

/**
 * 服务器下发整形工作参数(0x01)
 * 
 * @author ydc
 * @since
 *
 */
@Slf4j
public class SendPlasticParamResponseCmd implements BaseSendCmdExecute {

	/**
	 * 服务器下发整形工作参数(0x01)
	 * @param connectorNo
	 * @param memberId
	 * @param cmdSeq
	 * @param vo
	 */
	public byte[] generateSendDatas(int connectorNo, DataBaseVo vo) {
		PlasticParamSet plasticParamSet = (PlasticParamSet) vo;
		final int count = plasticParamSet.getValLength();
		// 应答为12+count字节
		final int len1 = 1;
		final int len2 = 2;
		final int len4 = 4;
		byte[] datas = new byte[12+count];
		final int index = len4;
		{
			byte[] data = new byte[] {0x01};
//			byte[] data = DataAnalyzer.analyseCommandData(plasticParamSet.getParamType(), DataAnalyseWayEnum.Byte);
			System.arraycopy(data, 0, datas, index, len1);
		}
		final int index1 = index + len1;
		{
//			byte[] data = new byte[] {0x1b,0x00,0x00,0x00};
			byte[] data = DataAnalyzer.analyseCommandData(plasticParamSet.getOriginAddr(), DataAnalyseWayEnum.Int32);
			System.arraycopy(data, 0, datas, index1, len4);
		}
		final int index2 = index1 + len4;
		{
			byte[] data = new byte[] {0x01};
//			byte[] data = DataAnalyzer.analyseCommandData(plasticParamSet.getParamCount(), DataAnalyseWayEnum.Byte);
			System.arraycopy(data, 0, datas, index2, len1);
		}
		final int index3 = index2 + len1;
		{
			byte[] data = new byte[] {0x04,0x00};
//			byte[] data = DataAnalyzer.analyseCommandData(plasticParamSet.getValLength(), DataAnalyseWayEnum.Int16);
			System.arraycopy(data, 0, datas, index3, len2);
		}
		int index4 = index3 + len2;
		{
//			byte[] data = new byte[] {0x3c,0x00,0x00,0x00,0x5e,(byte) 0xaa,(byte) 0xf5,0x19,0x00,0x10,0x0c,0x01,0x00,0x00,0x00,0x00,0x00,0x01,0x17,0x00,0x00,0x00,0x01,0x04,0x00,0x0f,0x00,0x00,0x00};
			byte[] data = DataAnalyzer.analyseCommandData(plasticParamSet.getValue(), DataAnalyseWayEnum.Int32);
			System.arraycopy(data, 0, datas, index4, len4);
			
		}
		log.info("服务器下发整形工作参数(0x01)");
		log.info("生成数据 :" + (datas!=null ? "成功" : "失败"));
        log.info("数据长度 :" + (datas.length == (12+count) ? "正常" : "出错"));
		// 发送报文
		return ProtocolDataGenerator.sendOneData_KW(connectorNo, datas, KwCmdEnum.PLASTIC_PARAM_SET);
	}

	@Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		byte[] datas = generateSendDatas(dataVo.getConnectorNo(),dataVo);
		return datas;
	}

}
