/*
 *
 */
package com.gdcdgj.charging.gateway.platform.kw.execute.send;


import java.util.HashMap;
import java.util.Map;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.HeartBeat;
import com.gdcdgj.charging.api.vo.srv2gw.SetVoluationPolicy;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.kw.protocol.KwCmdEnum;
import com.gdcdgj.charging.gateway.platform.kw.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;

import lombok.extern.slf4j.Slf4j;

/**
 * 服务器设置电费计价策略信息(0x4f,0x04)
 *
 * @author ydc
 * @since 2017-3-1 下午8:03:58
 */
@Slf4j
public class SendSetVoluationPolicyRespCmd implements BaseSendCmdExecute {
	
	/**
	 * 服务器设置电费计价策略信息(0x4f,0x04)
	 * @param connectorNo
	 * @param memberId
	 * @param cmdSeq
	 * @param vo
	 * @return
	 * @throws Exception 
	 * @throws
	 * @author Changliang Tao
	 * @date 2020/4/15 18:51
	 */
    public byte[] generateSendDatas(int connectorNo, DataBaseVo vo) throws Exception {
        SetVoluationPolicy setVoluationPolicy = (SetVoluationPolicy) vo;
        byte[] datas = new byte[96];
        //开始小时map 十二段开始小时存储
        if(setVoluationPolicy.getBeginHourMap() == null) setVoluationPolicy.setBeginHourMap(new HashMap<Byte, Byte>());
        if(setVoluationPolicy.getBeginMinMap() == null) setVoluationPolicy.setBeginMinMap(new HashMap<Byte, Byte>());
        if(setVoluationPolicy.getEndHourMap() == null) setVoluationPolicy.setEndHourMap(new HashMap<Byte, Byte>());
        if(setVoluationPolicy.getEndMinMap() == null) setVoluationPolicy.setEndMinMap(new HashMap<Byte, Byte>());
        if(setVoluationPolicy.getRatesMap() == null) setVoluationPolicy.setRatesMap(new HashMap<Byte, Integer>());
        Map<Byte, Byte> beginHourMap = setVoluationPolicy.getBeginHourMap();
//      	Map<Byte, Byte> beginHourMap = new HashMap<>();
      	//开始分钟map 十二段开始分钟存储
      	Map<Byte, Byte> beginMinMap = setVoluationPolicy.getBeginMinMap();
//      	Map<Byte, Byte> beginMinMap = new HashMap<>();
      	//结束小时map 十二段结束小时存储
      	Map<Byte, Byte> endHourMap = setVoluationPolicy.getEndHourMap();
//      	Map<Byte, Byte> endHourMap = new HashMap<>();
      	//结束分钟map 十二段结束分钟存储
      	Map<Byte, Byte> endMinMap = setVoluationPolicy.getEndMinMap();
//      	Map<Byte, Byte> endMinMap = new HashMap<>();
      	//费率map 十二段费率存储
      	Map<Byte, Integer> ratesMap = setVoluationPolicy.getRatesMap();
//      	Map<Byte, Integer> ratesMap = new HashMap<>();
      	
      	//initMaps(beginHourMap,beginMinMap,endHourMap,endMinMap,ratesMap);
//      	boolean checkMap = checkMaps(beginHourMap,beginMinMap,endHourMap,endMinMap,ratesMap);
//      	if(!checkMap) log.error("数据设置有误！");
      	
        //map 开始小时循环处理
        {
        	for (int i = 0; i < beginHourMap.size(); i++) {
        		byte[] beginHourMaps = DataAnalyzer.analyseCommandData(beginHourMap.get((byte)i), DataAnalyseWayEnum.Byte);
        		System.arraycopy(beginHourMaps, 0, datas, 8*i, 1);
        	}
        }
        //map 开始分钟循环处理
        {
        	for (int i = 0; i < beginMinMap.size(); i++) {
        		byte[] beginMinMaps = DataAnalyzer.analyseCommandData(beginMinMap.get((byte)i), DataAnalyseWayEnum.Byte);
        		System.arraycopy(beginMinMaps, 0, datas, 8*i+1, 1);
        	}
        }
        //map 结束小时循环处理
        {
        	for (int i = 0; i < endHourMap.size(); i++) {
        		byte[] endHourMaps = DataAnalyzer.analyseCommandData(endHourMap.get((byte)i), DataAnalyseWayEnum.Byte);
        		System.arraycopy(endHourMaps, 0, datas, 8*i+2, 1);
        	}
        }
        //map 结束分钟循环处理
        {
        	for (int i = 0; i < endMinMap.size(); i++) {
        		byte[] endMinMaps = DataAnalyzer.analyseCommandData(endMinMap.get((byte)i), DataAnalyseWayEnum.Byte);
        		System.arraycopy(endMinMaps, 0, datas, 8*i+3, 1);
        	}
        }
        //map 计费费率循环处理
        {
        	int check = 1;
    		{
    			for (int i = 0; i < ratesMap.size();) {
    	    		byte[] ratesMaps = DataAnalyzer.analyseCommandData(ratesMap.get((byte)i), DataAnalyseWayEnum.Int32);
    	    		byte[] res = new byte[] {ratesMaps[check-1]};
    	    		System.arraycopy(res, 0, datas, 8*i+4+(check-1), 1);
    	    		i = (check == 4) ? ++i : i;
    	    		check = (check == 4) ?  1 : ++check;
    	    	}
    		}
        }
        log.info("服务器设置电费计价策略信息(0x4f,0x04)");
        log.info("生成数据 :" + (datas!=null ? "成功" : "失败"));
        log.info("数据长度 :" + ((datas.length == 96) ? "正常" : "出错"));
        // 拼接报文
        return ProtocolDataGenerator.sendOneData_KW(connectorNo, datas, KwCmdEnum.SET_VOLUATION_POLICY);
    }
    public void initMaps(Map<Byte, Byte> beginHourMap,Map<Byte, Byte> beginMinMap,Map<Byte, Byte> endHourMap,
    		Map<Byte, Byte> endMinMap,Map<Byte, Integer> ratesMap){
        beginHourMap.put((byte) 0, (byte)0);
        beginHourMap.put((byte) 1, (byte)8);
        beginHourMap.put((byte) 2, (byte)9);
        beginHourMap.put((byte) 3, (byte)12);
        beginHourMap.put((byte) 4, (byte)19);
        beginHourMap.put((byte) 5, (byte)22);
        beginHourMap.put((byte) 6, (byte)0);
        beginHourMap.put((byte) 7, (byte)0);
        beginHourMap.put((byte) 8, (byte)0);
        beginHourMap.put((byte) 9, (byte)0);
        beginHourMap.put((byte) 10, (byte)0);
        beginHourMap.put((byte) 11, (byte)0);
      	beginMinMap.put((byte) 0, (byte)0);
      	beginMinMap.put((byte) 1, (byte)0);
      	beginMinMap.put((byte) 2, (byte)0);
      	beginMinMap.put((byte) 3, (byte)0);
      	beginMinMap.put((byte) 4, (byte)0);
      	beginMinMap.put((byte) 5, (byte)0);
      	beginMinMap.put((byte) 6, (byte)0);
      	beginMinMap.put((byte) 7, (byte)0);
      	beginMinMap.put((byte) 8, (byte)0);
      	beginMinMap.put((byte) 9, (byte)0);
      	beginMinMap.put((byte) 10, (byte)0);
      	beginMinMap.put((byte) 11, (byte)0);
      	endHourMap.put((byte) 0, (byte)8);
      	endHourMap.put((byte) 1, (byte)9);
      	endHourMap.put((byte) 2, (byte)12);
      	endHourMap.put((byte) 3, (byte)19);
      	endHourMap.put((byte) 4, (byte)22);
      	endHourMap.put((byte) 5, (byte)24);
      	endHourMap.put((byte) 6, (byte)0);
      	endHourMap.put((byte) 7, (byte)0);
      	endHourMap.put((byte) 8, (byte)0);
      	endHourMap.put((byte) 9, (byte)0);
      	endHourMap.put((byte) 10, (byte)0);
      	endHourMap.put((byte) 11, (byte)0);
      	endMinMap.put((byte) 0, (byte)0);
      	endMinMap.put((byte) 1, (byte)0);
      	endMinMap.put((byte) 2, (byte)0);
      	endMinMap.put((byte) 3, (byte)0);
      	endMinMap.put((byte) 4, (byte)0);
      	endMinMap.put((byte) 5, (byte)0);
      	endMinMap.put((byte) 6, (byte)0);
      	endMinMap.put((byte) 7, (byte)0);
      	endMinMap.put((byte) 8, (byte)0);
      	endMinMap.put((byte) 9, (byte)0);
      	endMinMap.put((byte) 10, (byte)0);
      	endMinMap.put((byte) 11, (byte)0);
      	ratesMap.put((byte) 0, 34);
      	ratesMap.put((byte) 1, 64);
      	ratesMap.put((byte) 2, 104);
      	ratesMap.put((byte) 3, 64);
      	ratesMap.put((byte) 4, 104);
      	ratesMap.put((byte) 5, 64);
      	ratesMap.put((byte) 6, 0);
      	ratesMap.put((byte) 7, 0);
      	ratesMap.put((byte) 8, 0);
      	ratesMap.put((byte) 9, 0);
      	ratesMap.put((byte) 10, 0);
      	ratesMap.put((byte) 11, 0);
    }
	public boolean checkMaps(Map<Byte, Byte> beginHourMap,Map<Byte, Byte> beginMinMap,Map<Byte, Byte> endHourMap,
    		Map<Byte, Byte> endMinMap,Map<Byte, Integer> ratesMap) {
		boolean beginHourMaps = true;
		boolean endHourMaps = true;
		boolean beginMinMaps = true;
		boolean endMinMaps = true;
		boolean ratesMaps = true;
		for (int i = 0; i < beginHourMap.size(); i++) {
			beginHourMaps = beginHourMap.get((byte)i) <= 24;
		}
		for (int i = 0; i < endHourMap.size(); i++) {
			endHourMaps = endHourMap.get((byte)i) <= 24;
		}
		for (int i = 0; i < beginMinMap.size(); i++) {
			beginMinMaps = beginMinMap.get((byte)i) == 0 || beginMinMap.get((byte)i) == 30;
		}
		for (int i = 0; i < endMinMap.size(); i++) {
			endMinMaps = endMinMap.get((byte)i) == 0 || endMinMap.get((byte)i) == 30;
		}
		for (int i = 0; i < ratesMap.size(); i++) {
			ratesMaps = ratesMap.get((byte)i) < 9999;
		}
		return (beginHourMaps && endHourMaps && beginMinMaps && endMinMaps && ratesMaps);
	}
    @Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		byte[] datas = null;
		try {
			datas = generateSendDatas(dataVo.getConnectorNo(),dataVo);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return datas;
	}
}
