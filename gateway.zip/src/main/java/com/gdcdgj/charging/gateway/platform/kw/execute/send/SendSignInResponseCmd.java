/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.kw.execute.send;


import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.SignIn;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.kw.protocol.KwCmdEnum;
import com.gdcdgj.charging.gateway.platform.kw.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;

import lombok.extern.slf4j.Slf4j;

/**
 * 中心系统答复签到命令(0x69)
 *
 * @author ydc
 * @since 
 */
@Slf4j
public class SendSignInResponseCmd implements BaseSendCmdExecute {

	/**
	 * 中心系统答复签到命令(0x69)
	 * @param connectorNo
	 * @param memberId
	 * @param cmdSeq
	 * @param vo
	 */
    public byte[] generateSendDatas(int connectorNo, DataBaseVo vo) {
        SignIn signIn = (SignIn) vo;
        final int len = 0;
        final int len1 = 1;
        final int len4 = 4;
        final int len128 = 128;
        //服务器应答域长 143
        byte[] datas = new byte[143];
        //随机数应答
        final int index1 = len4;
        {
        	byte[] random = new byte[4];
            //充电桩8编码 32 个字节
            //equipmentCodeBytes = DataAnalyzer.analyseCommandData(signIn.getEquipmentCode(), DataAnalyseWayEnum.StrASCII);
            System.arraycopy(random, len, datas, index1, len4);
        }
        //登入验证
        final int index2 = index1 + len4;
        {
        	byte[] signInCheck = new byte[1];
            System.arraycopy(signInCheck, len, datas, index2, len1);
        }
        //加密标志
        final int index3 = index2 + len1;
        {
        	byte[] signal = new byte[1];
            System.arraycopy(signal, len, datas, index3, len1);
        }
        //公共模数
        final int index4 = index3 + len1;
        {
        	byte[] moudleCount;
            if(signIn.getMoudleCount() == null) {
            	moudleCount = new byte[len128];
            }else{
            	moudleCount = DataAnalyzer.analyseCommandData(signIn.getMoudleCount(), DataAnalyseWayEnum.GB2312);
            }
            System.arraycopy(moudleCount, len, datas, index4, len128);
        }
        //RSA公密
        final int index5 = index4 + len128;
        {
        	 byte[] RSA;
             if(signIn.getRSA() == 0) {
             	RSA = new byte[len4];
             }else {
             	RSA = DataAnalyzer.analyseCommandData(signIn.getRSA(), DataAnalyseWayEnum.Int32);
             }
             System.arraycopy(RSA, len, datas, index5, len4);
        }
        //启停用标志
        final int index6 = index5 + len4;
        {
        	byte[] startStopSignal = new byte[1];
            System.arraycopy(startStopSignal, len, datas, index6, len1);
        }
        log.info("中心系统答复签到命令(0x69)");
        log.info("生成数据 :" + (datas!=null ? "成功" : "失败"));
        log.info("数据长度 :" + ((datas.length == 143) ? "正常" : "出错"));
        // 报文
        return ProtocolDataGenerator.sendOneData_KW(connectorNo, datas, KwCmdEnum.SRV_SIGN_IN_RESP);
    }

	@Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		byte[] datas = generateSendDatas(dataVo.getConnectorNo(),dataVo);
		return datas;
	}
}
