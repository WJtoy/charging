/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.kw.execute.send;


import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.StateInfo;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.kw.protocol.KwCmdEnum;
import com.gdcdgj.charging.gateway.platform.kw.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;

import lombok.extern.slf4j.Slf4j;

/**
 * 服务器系统信息包应答(0x67)
 * <p>发送状态信息上报应答</p>
 * @author ydc
 * @since
 *
 */
@Slf4j
public class SendStateInfoResponseCmd implements BaseSendCmdExecute {

	/**
	 * 服务器系统信息包应答(0x67)
	 * @param connectorNo
	 * @param memberId
	 * @param cmdSeq
	 * @param vo
	 */
	public byte[] generateSendDatas(int connectorNo, DataBaseVo vo) {
		StateInfo stateInfo = (StateInfo) vo;
		// 4+2字节
		final int len4 = 4;
		final int len1  =1;
		byte[] datas = new byte[len4 + len1];
		byte[] data = new byte[] {0x01};
		if(stateInfo.getConnectorNo() >= 1){
			// 拼出数据域
			data = DataAnalyzer.analyseCommandData((byte)stateInfo.getConnectorNo(), DataAnalyseWayEnum.Byte);
		}
		System.arraycopy(data, 0, datas, len4, len1);
		log.info("服务器系统信息包应答(0x67)");
		log.info("生成数据 :" + (datas!=null ? "成功" : "失败"));
        log.info("数据长度 :" + (datas.length == 5 ? "正常" : "出错"));
		// 发送报文
		return ProtocolDataGenerator.sendOneData_KW(connectorNo, datas, KwCmdEnum.STATE_INFO_REPORT);
	}

	@Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		byte[] datas = generateSendDatas(dataVo.getConnectorNo(),dataVo);
		return datas;
	}

}
