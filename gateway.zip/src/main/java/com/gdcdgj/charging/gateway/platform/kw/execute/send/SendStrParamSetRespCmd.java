/*
 *
 */
package com.gdcdgj.charging.gateway.platform.kw.execute.send;


import java.util.Calendar;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.StrParamSet;
import com.gdcdgj.charging.gateway.platform.BaseSendCmdExecute;
import com.gdcdgj.charging.gateway.platform.kw.protocol.KwCmdEnum;
import com.gdcdgj.charging.gateway.platform.kw.protocol.ProtocolDataGenerator;
import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;

import lombok.extern.slf4j.Slf4j;

/**
 * 服务器下发充电桩字符型参数(0x03)
 *
 * @author ydc
 * @since 2017-3-1 下午8:03:58
 */
@Slf4j
public class SendStrParamSetRespCmd implements BaseSendCmdExecute {
	
	/**
	 * 服务器下发充电桩字符型参数(0x03)
	 * @param connectorNo
	 * @param memberId
	 * @param cmdSeq
	 * @param vo
	 * @return
	 * @throws Exception 
	 * @throws
	 * @author Changliang Tao
	 * @date 2020/4/15 18:51
	 */
	public byte[] generateSendDatas(int connectorNo,DataBaseVo vo) {
        StrParamSet strParamSet = (StrParamSet) vo;
        //字符型参数的长度
        Integer count = strParamSet.getValueLength();
        count = (null != count) ? count : 0;
        byte[] datas = new byte[11+count];
        // 数组copy定长
        final int len1 = 1;
     	final int len2 = 2;
     	final int len4 = 4;
     	{
     	//预留
     		byte[] reserved = new byte[4];
     		System.arraycopy(reserved, 0, datas, 0, len4);
     	}
        // 参数类型 1
        final byte indexFault = len4;
        {
        	byte[] paramType = new byte[] {0x01};
//        	byte[] paramType = DataAnalyzer.analyseCommandData(strParamSet.getParamType(), DataAnalyseWayEnum.Byte);
            System.arraycopy(paramType, 0, datas, indexFault, len1);
        }
        // 设置/查询参数 起始地址 4
        final byte index0 = indexFault + len1;
        {
        	byte[] originAddr = new byte[] {0x02,0x00,0x00,0x00};
//        	byte[] originAddr = DataAnalyzer.analyseCommandData(strParamSet.getOriginAddr(), DataAnalyseWayEnum.Int32);
            System.arraycopy(originAddr, 0, datas, index0, len4);
        }
        // 参数字节数 2
        final byte index1 = index0 + len4;
        {
        	byte[] valueLength = new byte[] {0x08,0x00};
//        	byte[] valueLength = DataAnalyzer.analyseCommandData(strParamSet.getValueLength(), DataAnalyseWayEnum.Int16);
            System.arraycopy(valueLength, 0, datas, index1, len2);
        }
        // 字符型参数数据 N
        	 final byte index2 = index1 + len2;
             {
            	byte[] value = null;
            	Calendar c = Calendar.getInstance();
//            	if(strParamSet.getValue() instanceof Calendar) {
            	if(c instanceof Calendar) {
            		//日期转数组处理
            		Calendar times = (Calendar) strParamSet.getValue();
            		value = new byte[8];
            		byte[] year = DataAnalyzer.analyseCommandData(times.YEAR, DataAnalyseWayEnum.Int16);
            		System.arraycopy(year, 0, value, 0, len2);
            		Double months = (double)times.MONTH;
            		byte[] month = DataAnalyzer.analyseCommandData(months.byteValue(), DataAnalyseWayEnum.Byte);
            		System.arraycopy(month, 0, value, len1, len1);
            		Double days = (double)times.DAY_OF_MONTH;
            		byte[] day = DataAnalyzer.analyseCommandData(days.byteValue(), DataAnalyseWayEnum.Byte);
            		System.arraycopy(day, 0, value, len2, len1);
            		Double hours = (double)times.HOUR;
            		byte[] hour = DataAnalyzer.analyseCommandData(hours.byteValue(), DataAnalyseWayEnum.Byte);
            		System.arraycopy(hour, 0, value, 3, len1);
            		Double mins = (double)times.MINUTE;
            		byte[] min = DataAnalyzer.analyseCommandData(mins.byteValue(), DataAnalyseWayEnum.Byte);
            		System.arraycopy(min, 0, value, len4, len1);
            		Double seconds = (double)times.SECOND;
            		byte[] second = DataAnalyzer.analyseCommandData(seconds.byteValue(), DataAnalyseWayEnum.Byte);
            		System.arraycopy(second, 0, value, 5, len1);
            		byte[] end = new byte[] {(byte) 0xff};
            		System.arraycopy(end, 0, value, 6, len1);
            	}else {
            		value = DataAnalyzer.analyseCommandData(strParamSet.getValue(), DataAnalyseWayEnum.StrASCII);
            	}
             	System.arraycopy(value, 0, datas, index2, count);
             }
        log.info("服务器下发充电桩字符型参数(0x03)");
        log.info("生成数据 :" + (datas!=null ? "成功" : "失败"));
        log.info("数据长度 :" + (datas.length == (11+count) ? "正常" : "出错"));
        // 拼接报文
        return ProtocolDataGenerator.sendOneData_KW(connectorNo, datas, KwCmdEnum.STR_PARAM_SET);
    }

	@Override
	public byte[] sendCmdExecute(DataBaseVo dataVo) {
		byte[] datas = generateSendDatas(dataVo.getConnectorNo(),dataVo);
		return datas;
	}
}
