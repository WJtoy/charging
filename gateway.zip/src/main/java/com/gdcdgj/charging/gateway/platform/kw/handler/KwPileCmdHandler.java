package com.gdcdgj.charging.gateway.platform.kw.handler;


import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.gdcdgj.charging.api.constant.RabbitmqConstant;
import com.gdcdgj.charging.api.vo.srv2gw.ChargeRecordInfo;
import com.gdcdgj.charging.api.vo.srv2gw.ChargeTimeFrameInfo;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.HeartBeat;
import com.gdcdgj.charging.api.vo.srv2gw.ModuleChargingInfo;
import com.gdcdgj.charging.api.vo.srv2gw.PileCtrl;
import com.gdcdgj.charging.api.vo.srv2gw.PileStartedRst;
import com.gdcdgj.charging.api.vo.srv2gw.PlasticParamSet;
import com.gdcdgj.charging.api.vo.srv2gw.SetVoluationPolicy;
import com.gdcdgj.charging.api.vo.srv2gw.SignIn;
import com.gdcdgj.charging.api.vo.srv2gw.StateInfo;
import com.gdcdgj.charging.api.vo.srv2gw.StrParamSet;
import com.gdcdgj.charging.gateway.platform.PileCmdHandler;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecAccountInfoReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecAlarmInfoReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecChargeRecordInfoReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecChargeTimeInfoReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecHeartBeatReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecHistoryChargeRecordInfoReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecModuleInfoResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecPileCtrlStartRstReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecPileCtrlStopRstReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecPileStartedRstReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecPlasticParamRespReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecSetVoluationPolicyResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecSignInResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecStateInfoReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecStrParamRespReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendAccountInfoResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendAlarmInfoResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendChargeRecordInfoResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendHeartbeatReportResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendPileStartedRstRespCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendPlasticParamResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendSetVoluationPolicyRespCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendSignInResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendStateInfoResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendStrParamSetRespCmd;
import com.gdcdgj.charging.gateway.server.handler.ChannelSender;
import com.gdcdgj.charging.gateway.server.handler.H2TServer;

import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import lombok.extern.slf4j.Slf4j;

/**
 * 科旺报文处理器
 *
 * @author ydc
 * @date 2020/4/30 14:41
 * @since JDK 1.8
 */
@Component
@Slf4j
public class KwPileCmdHandler implements PileCmdHandler {
	
	@Autowired
	private AmqpTemplate amqpTemplate;
	
	public boolean isStart = true;
	
    /**
     * 报文心跳处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/26 16:57
     */
    @Override
    public void heartbeatCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
    	// 心跳包上报
    	RecHeartBeatReportCmd recHeartBeatReportCmd = RecHeartBeatReportCmd.getInstance();
        // 接收报文后执行
    	HeartBeat heartBeat = (HeartBeat) recHeartBeatReportCmd.receiveCmdExecute(fullData);
        SendHeartbeatReportResponseCmd sendHeartbeatReportResponseCmd = new SendHeartbeatReportResponseCmd();
        byte[] datas = sendHeartbeatReportResponseCmd.sendCmdExecute(heartBeat);
        Channel chn = ctx.channel();
        ChannelSender.send(chn, datas);
        log.info("心跳包上报/应答完成\n");
        if(isStart) {
        	//心跳响应成功后服务器下发同步当前时间到桩
            SendStrParamSetRespCmd sendStrParamSetRespCmd = new  SendStrParamSetRespCmd();
            StrParamSet strParamSet = new StrParamSet();
            byte[] syncTime = sendStrParamSetRespCmd.sendCmdExecute(strParamSet);
            ChannelSender.send(chn, syncTime);
            log.info("服务器下发更新系统时间到桩处理完成\n");
            //后台服务器设置24时电费计价策略
            //SetVoluationPolicy setVoluationPolicy = new SetVoluationPolicy();
            //SendSetVoluationPolicyRespCmd sendSetVoluationPolicyRespCmd = new SendSetVoluationPolicyRespCmd();
            //byte[] policy = sendSetVoluationPolicyRespCmd.sendCmdExecute(setVoluationPolicy);
            //ChannelSender.send(chn, policy);
            //log.info("后台服务器设置24时电费计价策略处理完成\n");
            //服务器下发整形参数》服务费价格
            PlasticParamSet plasticParamSet = new PlasticParamSet();
            plasticParamSet.setOriginAddr(0x1b);
            plasticParamSet.setValue(0x3c);
            SendPlasticParamResponseCmd sendPlasticParamResponseCmd = new SendPlasticParamResponseCmd();
            byte[] plasticParam = sendPlasticParamResponseCmd.sendCmdExecute(plasticParamSet);
            ChannelSender.send(chn, plasticParam);
            log.info("服务器下发整形参数》服务费价格处理完成\n");
            //服务器下发整形参数》充电桩状态信息包上报周期
            PlasticParamSet plasticParamSet2 = new PlasticParamSet();
            plasticParamSet2.setOriginAddr(23);
            plasticParamSet2.setValue(15);
            byte[] plasticParam2 = sendPlasticParamResponseCmd.sendCmdExecute(plasticParamSet2);
            ChannelSender.send(chn, plasticParam2);
            log.info("服务器下发整形参数》充电桩状态信息包上报周期处理完成\n");
            isStart = false;
        }
    }

    /**
     * 报文签到处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:36
     */
    @Override
    public void signInCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
    	//充电桩签到报文上报
    	RecSignInResponseCmd recSignInResponseCmd = new RecSignInResponseCmd();
    	SignIn signIn = (SignIn) recSignInResponseCmd.receiveCmdExecute(fullData);
    	String tmpCode = signIn.getPileCode();
        log.info("保存equipmentCode和Channel========{}", tmpCode);
        H2TServer.saveChannel(tmpCode, ctx.channel());
        //后台应答充电桩签到上报
    	SendSignInResponseCmd sendSignInResponseCmd = new SendSignInResponseCmd();
    	byte[] datas = sendSignInResponseCmd.sendCmdExecute(signIn);
    	ChannelSender.send(ctx.channel(), datas);
    	amqpTemplate.convertAndSend(RabbitmqConstant.SIGN_IN_PILE_EXCHANGE, RabbitmqConstant.SIGN_IN_PILE_ROUTING_KEY, signIn);
    	log.info("报文签到处理完成\n");
    }
    
    /**
     * 充电桩充电信息上报模块信息处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:38
     */
    @Override
    public void moduleInfoCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
    	//充电桩充电信息上报模块信息
    	RecModuleInfoResponseCmd recModuleInfoResponseCmd = new RecModuleInfoResponseCmd();
    	ModuleChargingInfo moduleChargingInfo = (ModuleChargingInfo) recModuleInfoResponseCmd.receiveCmdExecute(fullData);
    	log.info("充电桩充电信息上报模块信息完成\n 有无故障：{}", moduleChargingInfo.getFaultCode() > 0 ? "有" : "无");
    }

    /**
     * 充电桩上报启动结果处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
    @Override
    public void startResultCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
    	//充电桩上报启动结果
    	RecPileStartedRstReportCmd recPileStartedRstReportCmd = new RecPileStartedRstReportCmd();
    	PileStartedRst pileStartedRst = (PileStartedRst) recPileStartedRstReportCmd.receiveCmdExecute(fullData);
    	//后台收到后给出响应
    	SendPileStartedRstRespCmd sendPileStartedRstRespCmd = new SendPileStartedRstRespCmd();
    	byte[] datas = sendPileStartedRstRespCmd.sendCmdExecute(pileStartedRst);
    	ChannelSender.send(H2TServer.getChannel(pileStartedRst.getPileCode()), datas);
    	log.info("充电桩上报启动结果响应完成\n");
    }
    /**
     * 充电桩开始启动处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
    @Override
    public void startCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
    	//充电桩充电启动命令应答
    	RecPileCtrlStartRstReportCmd recPileCtrlStartRstReportCmd = new RecPileCtrlStartRstReportCmd();
    	PileCtrl vo = (PileCtrl) recPileCtrlStartRstReportCmd.receiveCmdExecute(fullData);
    	log.info("充电桩启动充电命令应答完成");
    	//服务器下发整形参数》充电桩状态信息包上报周期 更改为3秒一次
        PlasticParamSet plasticParamSet = new PlasticParamSet();
        plasticParamSet.setOriginAddr(23);
        plasticParamSet.setValue(0x03);
        SendPlasticParamResponseCmd sendPlasticParamResponseCmd = new SendPlasticParamResponseCmd();
        byte[] plasticParam = sendPlasticParamResponseCmd.sendCmdExecute(plasticParamSet);
        ChannelSender.send(ctx.channel(), plasticParam);
        log.info("服务器下发整形参数》充电桩状态信息包上报周期更改完成\n");
        //下发启动结果到mQ
        PileStartedRst pileStartedRst = new PileStartedRst();
        pileStartedRst.setProviderId(1);
        pileStartedRst.setConnectorNo(vo.getConnectorNo());
        pileStartedRst.setPileCode(vo.getPileCode());
        pileStartedRst.setResult(vo.getResultCode());
        amqpTemplate.convertAndSend(RabbitmqConstant.STARTED_STATUS_EXCHANGE, RabbitmqConstant.STARTED_STATUS_ROUTING_KEY, pileStartedRst);
        log.info("下发启动结果到MQ 启动结果 {}",vo.getResultCode()==1 ? "成功" : "失败");
    }
    /**
     * 充电桩停止充电处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
    @Override
    public void stopCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
    	//充电桩充电停止命令应答
    	RecPileCtrlStopRstReportCmd recPileCtrlStopRstReportCmd = new RecPileCtrlStopRstReportCmd();
    	DataBaseVo vo = recPileCtrlStopRstReportCmd.receiveCmdExecute(fullData);
    	log.info("充电桩停止充电命令应答完成\n");
    	//服务器下发整形参数》充电桩状态信息包上报周期 更改为15秒一次
        PlasticParamSet plasticParamSet = new PlasticParamSet();
        plasticParamSet.setOriginAddr(23);
        plasticParamSet.setValue(15);
        SendPlasticParamResponseCmd sendPlasticParamResponseCmd = new SendPlasticParamResponseCmd();
        byte[] plasticParam = sendPlasticParamResponseCmd.sendCmdExecute(plasticParamSet);
        ChannelSender.send(H2TServer.getChannel(vo.getPileCode()), plasticParam);
        log.info("服务器下发整形参数》充电桩状态信息包上报周期更改完成\n");
    }

    /**
     * 充电桩状态信息包上报处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
    
	@Override
	public void stateInfoCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		//充电桩状态信息报上报
		RecStateInfoReportCmd recStateInfoReportCmd = new RecStateInfoReportCmd();
		StateInfo stateInfo = (StateInfo) recStateInfoReportCmd.receiveCmdExecute(fullData);
		SendStateInfoResponseCmd sendStateInfoResponseCmd = new SendStateInfoResponseCmd();
		byte[] datas = sendStateInfoResponseCmd.sendCmdExecute(stateInfo);
    	ChannelSender.send(H2TServer.getChannel(stateInfo.getPileCode()), datas);
    	amqpTemplate.convertAndSend(RabbitmqConstant.STATEINFO_STATUS_EXCHANGE, RabbitmqConstant.STATEINFO_STATUS_ROUTING_KEY, stateInfo);
		log.info("本次充电桩状态信息包上报处理完成 ：{}\n",stateInfo);
	}
	/**
     * 充电桩字符型参数设置处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
    
	@Override
	public void strParamSetCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		//充电桩字符型参数设置命令应答
		RecStrParamRespReportCmd recStrParamRespReportCmd = new RecStrParamRespReportCmd();
		StrParamSet strParamSet = (StrParamSet) recStrParamRespReportCmd.receiveCmdExecute(fullData);
		log.info("充电桩字符型参数设置处理完成  设置结果：{}" , strParamSet.getResultCode() > 0 ? "成功" : "失败");
	}
	
	/**
     * 充电桩整型参数设置处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
	@Override
	public void plasticParamSetCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		//充电桩整型参数设置命令应答
		RecPlasticParamRespReportCmd recPlasticParamRespReportCmd = new RecPlasticParamRespReportCmd();
		PlasticParamSet plasticParamSet = (PlasticParamSet) recPlasticParamRespReportCmd.receiveCmdExecute(fullData);
		log.info("充电桩整形参数设置应答处理完成 设置结果：{}" , plasticParamSet.getResultCode() > 0 ? "成功" : "失败");
	}
	
	/**
     * 充电桩24时电费计价策略设置处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
    
	@Override
	public void voluationPolicyCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		//充电桩24时电费计价策略设置命令应答
		RecSetVoluationPolicyResponseCmd recSetVoluationPolicyResponseCmd = new RecSetVoluationPolicyResponseCmd();
		SetVoluationPolicy setVoluationPolicy = (SetVoluationPolicy) recSetVoluationPolicyResponseCmd.receiveCmdExecute(fullData);
		log.info("充电桩24时电费计价策略设置应答处理完成\n 设置结果：{}" , setVoluationPolicy.getResultCode() > 0 ? "成功" : "失败"); 
	}
	
	/**
     * 充电桩告警信息上报处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
    
	@Override
	public void alarmInfoCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		//充电桩告警信息上报
		RecAlarmInfoReportCmd recAlarmInfoReportCmd = new RecAlarmInfoReportCmd();
		DataBaseVo vo = recAlarmInfoReportCmd.receiveCmdExecute(fullData);
		//后台给出告警信息上报响应
		SendAlarmInfoResponseCmd sendAlarmInfoResponseCmd = new SendAlarmInfoResponseCmd();
		byte[] datas = sendAlarmInfoResponseCmd.sendCmdExecute(vo);
		ChannelSender.send(H2TServer.getChannel(vo.getPileCode()), datas);
		//amqpTemplate.convertAndSend(RabbitmqConstant.SERVICE_TYPE_EXCHANGE, RabbitmqConstant.SERVICE_TYPE_ROUTING_KEY, vo);
		log.info("充电桩告警信息上报处理完成\n");
	}
	
	/**
     * 充电桩账户信息上报处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
	
	@Override
	public void accountInfoCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		//充电桩账户信息上报
		RecAccountInfoReportCmd recAccountInfoReportCmd = new RecAccountInfoReportCmd();
		DataBaseVo vo = recAccountInfoReportCmd.receiveCmdExecute(fullData);
		//服务器给出账户信息上报响应
		SendAccountInfoResponseCmd sendAccountInfoResponseCmd = new SendAccountInfoResponseCmd();
		byte[] datas = sendAccountInfoResponseCmd.sendCmdExecute(vo);
    	ChannelSender.send(H2TServer.getChannel(vo.getPileCode()), datas);
		log.info("充电桩账户信息上报查询应答处理完成\n");
	}

	/**
     * 充电桩应答服务器查询最近一次充电各时段信息处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
	
	@Override
	public void chargeTimeFrameInfoCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		//充电桩应答服务器查询最近一次充电各时段信息
		RecChargeTimeInfoReportCmd recChargeTimeInfoReportCmd = new RecChargeTimeInfoReportCmd();
		ChargeTimeFrameInfo chargeTimeFrameInfo = (ChargeTimeFrameInfo) recChargeTimeInfoReportCmd.receiveCmdExecute(fullData);
		log.info("充电桩应答服务器查询最近一次充电各时段信息上报处理完成\n 应答结果：{}" , chargeTimeFrameInfo);
	}
	
	/**
     * 充电桩上报充电记录信息处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
	
	@Override
	public void chargeRecordInfoCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		log.info("充电桩上报充电记录 长度 ：{}",fullData.length);
		//充电桩上报充电记录信息
		RecChargeRecordInfoReportCmd recChargeInfoReportCmd = new RecChargeRecordInfoReportCmd();
		ChargeRecordInfo chargeRecordInfo = (ChargeRecordInfo) recChargeInfoReportCmd.receiveCmdExecute(fullData);
		//服务器给出充电记录信息接收响应
		SendChargeRecordInfoResponseCmd sendChargeTimeInfoResponseCmd = new SendChargeRecordInfoResponseCmd();
		byte[] datas = sendChargeTimeInfoResponseCmd.sendCmdExecute(chargeRecordInfo);
    	ChannelSender.send(H2TServer.getChannel(chargeRecordInfo.getPileCode()), datas);
		log.info("充电桩上报充电记录信息处理完成 :{}\n",chargeRecordInfo);
		amqpTemplate.convertAndSend(RabbitmqConstant.CHARGEINFO_STATUS_EXCHANGE, RabbitmqConstant.CHARGEINFO_STATUS_ROUTING_KEY, chargeRecordInfo);
	}
	
	/**
     * 充电桩上报充历史充电记录信息处理
     *
     * @param ctx
     * @param fullData
     * @return
     * @throws
     * @author ydc
     * @date 2020/4/30 14:40
     */
	
	@Override
	public void HistoryChargeRecordInfoCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		//充电桩上报充历史充电记录信息
		RecHistoryChargeRecordInfoReportCmd recHistoryChargeRecordInfoReportCmd = new RecHistoryChargeRecordInfoReportCmd();
		DataBaseVo vo = recHistoryChargeRecordInfoReportCmd.receiveCmdExecute(fullData);
		log.info("充电桩上报充历史充电记录信息\n 上报结果：{}" , vo);
	}

	@Override
	public void timeSyncCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		log.info("科旺时间同步在整形参数设置里，此处无作用");
	}

	@Override
	public void workParamCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		log.info("科旺工作参数设置应答");
	}

	@Override
	public void validAuthenCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		log.info("科旺合法用户认证应答");
	}

	@Override
	public void remoteUpgradeCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		log.info("科旺远程升级系统应答");
	}

	@Override
	public void serviceTypeCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		log.info("中心下发服务类型");
	}

	@Override
	public void BRMCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void ReportTypeCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		log.info("宜步间隔上报设置");
	}
	
	/**
	 * 桩上报BCP报文
	 * 
	 * @param ctx
	 * @param fullData
	 * @throws Exception
	 * @author ydc
     * @date 2020/4/30 14:40
	 */
	
	@Override
	public void BCPCmdHandle(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
		log.info("桩上报BCP报文");
	}
}
