/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.kw.protocol;

import lombok.extern.slf4j.Slf4j;

/**
 * 服务端与充电桩通信的命令
 * 科旺
 * @author ydc
 * @since 2016-11-1 下午6:37:21
 */
@Slf4j
public enum KwCmdEnum {
    //后台:H
    //充电桩:T
    // H - T : 表示 H 发送给 T
    // T - H : 表示 T 发送给 H
    /**
     * BMS相关的报文命令
     */
	  //充电桩上报BMS信息
	  BMS_REC(new byte[] {0x2d,0x01}),
	  //服务器应答BMS上报信息
	  BMS_RESP(new byte[] {0x2e,0x01}),
	  //充电桩上报BMS信息
	  BMS_REC_A(new byte[] {0x2d,0x01}),
	  //服务器应答BMS上报信息
	  BMS_RESP_A(new byte[] {0x2e,0x01}),

	/**
	 * 服务器向充电桩设置/查询工作参数和命令
	 */
	//后台服务器下发充电柱整形工作参数
	  
    HEART_BEAT_REPORT(new byte[]{0x66,0x00}),//心跳包信息上报	T - H
    HEART_BEAT_REPORT_RESP(new byte[]{0x65,0x0}),//心跳包信息上报应答	H - T
    
    STATE_INFO_REPORT(new byte[]{0x67,0x0}), //状态信息包上报
    STATE_INFO_REPORT_RESP(new byte[]{0x68,0x0}),//状态信息包应答
    
    ALARM_INFO_REPORT(new byte[] {0x6c,0x00}),//充电桩告警信息报上报
    ALARM_INFO_RESPONSE(new byte[] {0x6b,0x00}),//暂时不用应答
    
    PLASTIC_PARAM_SET(new byte[]{0x01,0x00}),//服务器下发充电桩整形工作参数
    PLASTIC_PARAM_RESP(new byte[]{0x02,0x00}),//充电桩应答服务器整形参数设置
    
    STR_PARAM_SET(new byte[]{0x03,0x00}), //服务器下发充电桩字符型参数
    STR_PARAM_RESP(new byte[]{0x04,0x00}),//充电桩对字符型参数设置应答
    
    SEND_SIGN_IN_RESP(new byte[]{0x6a,0x00}),//中心系统查询签到应答/上报	T - H
    SRV_SIGN_IN_RESP(new byte[]{0x69,0x00}),//中心系统答复签到命令		H - T
    
    PILE_STSRT_REPORT(new byte[] {0x07,0x00}), //充电桩开启，向平台上报的命令
    PILE_START_RESP(new byte[] {0x08,0x00}),	  //充电桩开启，桩应答
    
    PILE_STARTED_REPORT(new byte[]{0x6e,0x00}),//充电桩启动成功后，向平台上报的命令			T - H
    PILE_STARTED_RESP(new byte[]{0x6d,0x00}),//充电桩启动成功后，平台收到桩的0x6d上报后的应答	H - T
    
    PILE_STOP_REPORT(new byte[]{0x05,0x00}),//充电桩停止充电，向平台上报的命令			T - H
    PILE_STOP_RESP(new byte[]{0x06,0x00}),//充电桩停止充电，桩应答	H - T
    
    CHARGE_TIMEFRAME_INFO(new byte[]{0x71,0x00}), //服务器查询最近一次充电各时段信息
    CHARGE_TIMEFRAME_INFO_RESP(new byte[]{0x72,0x00}),//充电桩应答服务器查询最近一次充电各时段信息
    
    MODULE_INFO_QUERY(new byte[]{0x6f,0x00}),//当前充电模块充电信息查询			H - T
    MODULE_INFO_QUERY_RESP(new byte[]{0x70,0x00}),//当前充电模块充电信息查询应答/上报	T - H

    SET_VOLUATION_POLICY(new byte[]{0x4f,0x04}),//服务器充电计价策略命令设置
    SET_VOLUATION_POLICY_RESP(new byte[]{0x50,0x04}),//充电计价策略命令应答
    
    CHARGE_RECORD_INFO(new byte[] {(byte) 0xca,0x00}),//充电桩上报充电记录信息
    CHARGE_RECORD_INFO_RESP(new byte[] {(byte) 0xc9,0x00}),//服务器应答充电桩上报充电信息报文
    
    HISTORY_CHARGE_RECORD_INFO(new byte[] {(byte) 0x91,0x01}),//充电桩上报历史充电记录信息
    HISTORY_CHARGE_RECORD_INFO_RESP(new byte[] {(byte) 0x92,0x01}),//服务器查询充电桩上报历史充电信息报文
    
    ACCOUNT_INFO_QUERY(new byte[]{(byte) 0xcb,0x00}), //服务器应答账户查询信息
    ACCOUNT_INFO_QUERY_RESP(new byte[]{(byte) 0xcc,0x00}),//充电桩上传用户账户查询报文
    
	CHARGE_VOLATILE(new byte[] {(byte) 0xcd,0x00}),//服务器应答充电密码验证报文
	CHARGE_VOLATILE_RESP(new byte[] {(byte) 0xce,0x00}),//充电桩上传用户密码验证报文
	
	FTP_UPDATE(new byte[] {(byte) 0xf5,0x03}),//服务器下发系统升级指令  		H - T
    FTP_UPDATE_RESP(new byte[] {(byte) 0xf6,0x03}),//充电器应答服务器下发升级命令  		T - H
	
	SIGNIN_VOLATILE(new byte[] {(byte) 0xb1,0x04}),//服务器对充电桩登入应答
	SIGNIN_VOLATILE_RESP(new byte[] {(byte) 0xb2,0x04});//充电桩密码登入报文

    private byte[] cmd;

    private KwCmdEnum(byte[] cmd) {
        this.cmd = cmd;
    }

    public byte[] getValue() {
        return this.cmd;
    }

    public static KwCmdEnum valueOf(byte[] cmd) {
        KwCmdEnum tempEnum = null;
        for (KwCmdEnum en : KwCmdEnum.values()) {
            if (en.getValue()[0] == cmd[0] && 
            		en.getValue()[1] == cmd[1]) {
                tempEnum = en;
                break;
            }
        }
        if (tempEnum == null) {
            log.error("Enum value not exist : " + cmd);
        }
        return tempEnum;
    }
    public static void main(String[] args) {
		System.err.println(valueOf(new byte[]{0x4f,0x04}));
	}
}
