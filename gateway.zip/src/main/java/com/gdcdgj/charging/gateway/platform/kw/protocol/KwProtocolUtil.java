/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.platform.kw.protocol;


import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.gateway.enums.MsgProviderEnum;
import com.gdcdgj.charging.gateway.util.MathConverterHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * 科旺 协议工具类 本协议中，所有协议中除去特别说明外，均是低位在前，高位在后， 通信数据报文采用二进制格式； 起始域：固定为 先0xAA、 后0xF5；
 * 长度域：包含从起始域到校验和域的整个报文长度； 信息域（版本域）：本次版本 0x03； 序列号域：报文的流水号； 命令代码：即消息类型，代表不同功能要求；
 * 数据域：具体的信息数据区域，不同的命令代码对应的内容不同； 校验和域：采用累计和计算校验值，计算范围包含从命令代码和数据域
 * 依照易充改写
 * @author ydc
 * @since 
 */
public class KwProtocolUtil {

    /**
     * 数据域
     *
     * @author ouxx
     * @since 2016-11-1 下午6:35:27
     */
    public static class DataField {
        public DataField(byte[] memberId, byte[] cmd) {
            this.memberId = memberId;
            this.cmd = cmd;
        }

        private byte[] memberId = new byte[2];// 用户ID，2字节
        private byte[] cmd = new byte[2];// 指令序号，2字节
        private List<Byte> data = new ArrayList<Byte>();// 其他数据，因无法预料数据长度，所以用List

        public byte[] getMemberId() {
            return memberId;
        }

        public void setMemberId(byte[] memberId) {
            this.memberId = memberId;
        }

        public byte[] getCmd() {
            return cmd;
        }

        public void setCmd(byte[] cmd) {
            this.cmd = cmd;
        }

        public List<Byte> getData() {
            return data;
        }

        public void setData(List<Byte> data) {
            this.data = data;
        }
    }

    // 第8个字节后开始是数据域
    private static final int DATA_FIELD_START_INDEX = 8;

    private static final int EQUIPMENT_CODE_LEN = 8;// 桩编码数据占8字节

    private static final byte[] KW_START_FIELD = new byte[]{(byte) 0xAA, (byte) 0xF5};// 起始域
    private static byte[] KW_START_LENGTH = new byte[2];// 长度域
    private static byte[] KW_START_CMD = new byte[2];// 命令代码
    private static final byte KW_VERSION_FIELD = 0x03; // 信息域(版本域)
    

    public static final int getEquipmentCodeLen() {
        return EQUIPMENT_CODE_LEN;
    }

    /**
     * 校验接收到的数据
     *
     * @param fullData
     * @return
     * @author ouxx
     * @throws Exception 
     * @date 2017-2-10 上午9:42:49
     */
    public static boolean verifyRecData(byte[] fullData) throws Exception {
        // 起始域
        boolean matchHead = ((KW_START_FIELD[0] == fullData[0]) && (KW_START_FIELD[1] == fullData[1]));
        // 信息域
        boolean matchVersion = (KW_VERSION_FIELD == fullData[4]);
        // 长度域
        KW_START_LENGTH = MathConverterHelper.getBytes(fullData.length);
        // 容错长度
        byte[] tolerantLen = MathConverterHelper.getBytes(fullData.length - 1);
        boolean matchLen = ((KW_START_LENGTH[0] == fullData[2]) && (KW_START_LENGTH[1] == fullData[3])
        		|| (tolerantLen[0] == fullData[2] && tolerantLen[1] == fullData[3]));
        return (matchHead && matchVersion && matchLen);
    }

    public static byte[] getFullDataBytes(byte[] cmdCode, byte serialField, byte[] dataField) throws Exception {
        byte[] datas8 = new byte[8];// 协议数组的前8个字节
        datas8[0] = KW_START_FIELD[0];
        datas8[1] = KW_START_FIELD[1];
        //长度域数值：包含从 起始域到校验和域 的所有字节数
        int c = getLength(dataField);
        KW_START_LENGTH = MathConverterHelper.getBytes(c);
        datas8[2] = KW_START_LENGTH[0];
        datas8[3] = KW_START_LENGTH[1];
        // 信息域(版本域)
        datas8[4] = KW_VERSION_FIELD;
        // 序列号域
        datas8[5] = serialField;
        // 命令代码
        KW_START_CMD = (byte[]) cmdCode;
        datas8[6] = KW_START_CMD[0];
        datas8[7] = KW_START_CMD[1];
        try {
            // 把数据域的数组合并到前8个字节的数据后
            byte[] datasWithDataField = MathConverterHelper.byteMerger(datas8, dataField);
            // 添上最后的校验和，校验和域：采用累计和计算校验值，计算范围包含从命令代码到数据域
            return MathConverterHelper.byteMerger(datasWithDataField, new byte[]{getCheckSum(cmdCode, dataField)});
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    /**
     * 获取命令代码
     *
     * @param fullData
     * @return
     * @author ouxx
     * @date 2016-11-11 下午5:54:20
     */
    public static byte[] getCmdCode(byte[] fullData) {
        return new byte[]{fullData[DATA_FIELD_START_INDEX - 2],fullData[DATA_FIELD_START_INDEX - 1]};
    }

    /**
     * 获取命令代码对应的枚举
     *
     * @param fullData
     * @return
     * @author ouxx
     * @date 2016-11-11 下午5:54:20
     */
    public static KwCmdEnum getCmdCodeEnum(byte[] fullData) {
        return KwCmdEnum.valueOf(getCmdCode(fullData));
    }

    /**
     * 获取长度域的值: 包含从 起始域到校验和域 的所有字节数
     *
     * @param dataField
     * @return
     * @author ouxx
     * @date 2016-11-1 下午6:19:14
     */
    public static int getLength(byte[] dataField) {
        if (null != dataField) {
            return (6 + 2 + dataField.length + 1);
        } else {
            return 9;
        }
    }

    /**
     * 校验和域：采用累计和计算校验值并取校验和的低8位，计算范围包含从命令代码到数据域
     *
     * @param cmdCode
     * @param dataField
     * @return
     * @author ouxx
     * @date 2016-11-1 下午6:15:48
     */
    public static byte getCheckSum(byte[] cmdCode, byte[] dataField) {
    	byte checkSum = cmdCode[0];
    	checkSum += cmdCode[1];
        for (byte b : dataField) {
        	checkSum +=  b;
        }
        return (byte) (checkSum&0xff);
    }

    /**
     * 给定起始下标获取数据域
     * @param fullData
     * @param index
     * @return
     * @author ouxx
     * @date 2016-11-3 上午11:22:21
     */
    private static byte[] getDataWithStartIndex(byte[] fullData, int index) {
        // 长度要减去1，因为最后还有检验和域
        int dataFieldLength = fullData.length -index - 1;
        return getDataByIndexAndSize(fullData, index, dataFieldLength);
    }

    /**
     * 获取数据域的数据
     *
     * @param fullData
     * @return
     * @author ouxx
     * @date 2016-11-1 下午6:03:27
     */
    public static byte[] getDataField(byte[] fullData) {
        return getDataWithStartIndex(fullData, DATA_FIELD_START_INDEX);
    }

    /**
     * 数据域中，在用户ID和指令序号之后的数据
     *
     * @param fullData
     * @return
     * @author ouxx
     * @date 2016-11-3 上午11:20:42
     */
    public static byte[] getDataAfterCmdSeqInDataField(byte[] fullData) {
        return getDataWithStartIndex(fullData, DATA_FIELD_START_INDEX);
    }

    /**
     * 从datas截取数据片段，
     *
     * @param datas
     * @param startIndex
     * @param length
     * @return
     * @author ouxx
     * @date 2016-11-4 下午2:09:56
     */
    public static byte[] getDataByIndexAndSize(byte[] datas, int startIndex, int length) {
        byte[] data = new byte[length];
        if (1 == length) {
            data[0] = datas[startIndex];
            return data;
        }
        try {
            System.arraycopy(datas, startIndex, data, 0, length);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return data;
    }

    /**
     * 设置科旺供应商
     * 
     * @param accountInfo
     */
    public static void setProvider(DataBaseVo vo) {
    	//科旺供应商 1
    	vo.setProviderId(MsgProviderEnum.KW_PROVIDER.getValue());
    }
}
