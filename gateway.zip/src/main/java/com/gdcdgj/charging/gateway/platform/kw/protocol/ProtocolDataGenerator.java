package com.gdcdgj.charging.gateway.platform.kw.protocol;

import com.gdcdgj.charging.gateway.util.DataAnalyseWayEnum;
import com.gdcdgj.charging.gateway.util.DataAnalyzer;
import com.gdcdgj.charging.gateway.util.MathConverterHelper;

import lombok.extern.slf4j.Slf4j;

import java.util.Calendar;

/**
 * 协议数据构造器
 *
 * @author ydc
 * @date 2020/4/24
 * @since JDK 1.8
 */
@Slf4j
public class ProtocolDataGenerator {
    /**
     * 序列号域的值
     * 序列号域：报文的流水号
     * 为了在网络链路不稳定时，如果报文重复发送，用序列号可以判断指令是否已经执行
     */
    private static byte serialField = 0;
    
    /**
     * 后台发送一个数据给充电桩 KW
     *
     * @param memberId
     * @param cmdSeq
     * @param datas
     * @param cmd
     * @return
     * @author ouxx
     * @date 2016-11-3 下午3:29:15
     */
    public static byte[] sendOneData_KW(int connectorNo, byte[] datas, KwCmdEnum cmd) {
        //序列号增1
        ++serialField;
        //拼接完整的报文
        try {
            return KwProtocolUtil.getFullDataBytes(cmd.getValue(), serialField,datas);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    /**
     * @param connectorNo
     * @param memberId
     * @param cmdSeq
     * @return
     * @throws
     * @author Changliang Tao
     * @date 2020/4/14 16:11
     */

    public static byte[] getMemberIdAndCmdSeqBytes(int connectorNo, int memberId) {
        byte[] memberIdBytes = DataAnalyzer.analyseCommandData(memberId, DataAnalyseWayEnum.Char);
        byte[] connectorNoBytes = DataAnalyzer.analyseCommandData(connectorNo, DataAnalyseWayEnum.Char);
        try {
            byte[] tmp = MathConverterHelper.byteMerger(memberIdBytes, connectorNoBytes);
            return tmp;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    /**
     * 后台接收来自充电桩的一个数据 KW
     *
     * @param requiredLength
     * @param fullData
     * @param analyseWay
     * @return
     * @throws Exception
     * @author ouxx
     * @date 2016-11-3 下午3:34:20
     */
    public static Object recOneData_KW(Integer requiredLength, byte[] fullData, DataAnalyseWayEnum analyseWay) throws Exception {
        DataAnalyzer analyzer = new DataAnalyzer();
        //解释方式，定字节数
        analyzer.setAnalyseWay(analyseWay);
        //从完整的返回数据中获取后台想要的数据，即  用户ID、指令序号后的数据
        byte[] resultBytes = KwProtocolUtil.getDataAfterCmdSeqInDataField(fullData);
        //根据解释方式analyseWay 解释数据
        return DataAnalyzer.analyseAnalogData(analyzer, resultBytes);
    }
    
    /**
     * 获取数据域 公用
     * @param dataAfterCmdSeq
     * @param index
     * @param len
     * @param analyseWay
     * @return
     * @throws
     * @author Changliang Tao
     * @date 2020/4/17 9:06
     */
    public static Object getOneData(final byte[] dataAfterCmdSeq, final int index, final int len, final DataAnalyseWayEnum analyseWay) {
        final byte[] bytes = KwProtocolUtil.getDataByIndexAndSize(dataAfterCmdSeq, index, len);
        final DataAnalyzer analyzer = new DataAnalyzer();
        analyzer.setAnalyseWay(analyseWay);
        return DataAnalyzer.analyseAnalogData(analyzer, bytes);
    }
    
    /**
     * 构建日期时间对象 公用
     * 默认为8个字节
     * @param index
     * @param dataAfterCmdSeq
     * @return
     * @author ouxx
     * @date 2016-11-7 上午9:49:29
     */
    public static Calendar getCalendar(final int index, final byte[] dataAfterCmdSeq) {
        //年份  2个字节
        final int indexYear = index;
        final int lenYear = 1;
        String year1 = (String) getOneData(dataAfterCmdSeq, indexYear, lenYear, DataAnalyseWayEnum.BCD16);
        String year2 = (String) getOneData(dataAfterCmdSeq, indexYear+1, lenYear, DataAnalyseWayEnum.BCD16);
        //月  1个字节
        final int indexMonth = indexYear + lenYear + lenYear;
        final int lenMonth = 1;
		// Double month = (Double) getOneData(dataAfterCmdSeq, indexMonth, lenMonth, DataAnalyseWayEnum.Byte);
        String month = (String) getOneData(dataAfterCmdSeq, indexMonth, lenMonth, DataAnalyseWayEnum.BCD16);
        //日  1个字节
        final int indexDay = indexMonth + lenMonth;
        final int lenDay = 1;
//		Double day = (Double) getOneData(dataAfterCmdSeq, indexDay, lenDay, DataAnalyseWayEnum.Byte);
        String day = (String) getOneData(dataAfterCmdSeq, indexDay, lenDay, DataAnalyseWayEnum.BCD16);
        //时  1个字节
        final int indexHour = indexDay + lenDay;
        final int lenHour = 1;
//		Double hour = (Double) getOneData(dataAfterCmdSeq, indexHour, lenHour, DataAnalyseWayEnum.Byte);
        String hour = (String) getOneData(dataAfterCmdSeq, indexHour, lenHour, DataAnalyseWayEnum.BCD16);
        hour = (hour.isEmpty()) ? "0" : hour;
        //分  1个字节
        final int indexMin = indexHour + lenHour;
        final int lenMin = 1;
//		Double min = (Double) getOneData(dataAfterCmdSeq, indexMin, lenMin, DataAnalyseWayEnum.Byte);
        String min = (String) getOneData(dataAfterCmdSeq, indexMin, lenMin, DataAnalyseWayEnum.BCD16);
        min = (min.isEmpty()) ? "0" : min;
        //秒  1个字节
        final int indexSecond = indexMin + lenMin;
        final int lenSecond = 1;
//		Double second = (Double) getOneData(dataAfterCmdSeq, indexSecond, lenSecond, DataAnalyseWayEnum.Byte);
        String second = (String) getOneData(dataAfterCmdSeq, indexSecond, lenSecond, DataAnalyseWayEnum.BCD16);
        second = (second.isEmpty()) ? "0" : second;
        Calendar cal = Calendar.getInstance();
//		cal.set(year.intValue(), month.intValue(), day.intValue(), hour.intValue(), min.intValue(), second.intValue());
        cal.set(Integer.parseInt(year1+year2), Integer.parseInt(month), Integer.parseInt(day), Integer.parseInt(hour), Integer.parseInt(min), Integer.parseInt(second));
        return cal;
    }
    
    /**
     * 根据数值获取n位bit为0或1
     * @param number
     * @param nbit
     * @return
     */
    public static boolean isIntNumberNBitONEInBinary(int number,int nbit){
        boolean result = false;            
        if((number%(Math.pow(2, nbit)))/(Math.pow(2, nbit-1)) >= 1.0){
                  result = true;
        }
        return result;
    }
}
