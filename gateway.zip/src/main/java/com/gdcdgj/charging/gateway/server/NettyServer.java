package com.gdcdgj.charging.gateway.server;


import com.gdcdgj.charging.gateway.config.NettyServerConfig;
import com.gdcdgj.charging.gateway.server.channel.BootNettyChannelInitializer;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.logging.LoggingHandler;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.annotation.PreDestroy;

/**
 * 服务端
 */
@Slf4j
@Component
public class NettyServer {

    /**
     * 创建bootstrap
     * // String s1 = new String(bytes, "gbk");
     */
    private ServerBootstrap serverBootstrap = new ServerBootstrap();
    /**
     * BOSS
     */
    private EventLoopGroup boss = new NioEventLoopGroup();
    /**
     * Worker
     */
    private EventLoopGroup work = new NioEventLoopGroup();

    // netty服务器配置类
    @Autowired
    private NettyServerConfig nettyServerConfig;
    // 通道初始化类
	@Autowired
    private BootNettyChannelInitializer bootNettyChannelInitializer;
	
    /**
     * 关闭服务器方法
     */
    @PreDestroy
    public void close() {
        log.info("关闭服务器....");
        //优雅退出
        boss.shutdownGracefully();
        work.shutdownGracefully();
    }

    /**
     * 开启服务
     *
     * @author Changliang Tao
     * @date 2020/4/11 13:36
     */
    public void start() {
        // 从配置文件中(application.yml)获取服务端监听端口号
        int port = nettyServerConfig.getPort();
        serverBootstrap.group(boss, work)
                .channel(NioServerSocketChannel.class)
                .option(ChannelOption.SO_BACKLOG, 100)
                // 设置日志等级
                .handler(new LoggingHandler(LogLevel.INFO));
        try {
            //设置事件处理
            serverBootstrap.childHandler(bootNettyChannelInitializer).childOption(ChannelOption.SO_KEEPALIVE, true);
            log.info("netty服务器在[{}]端口启动监听", port);
            //监听端口，等待绑定操作完成
            ChannelFuture f = serverBootstrap.bind(port).sync();
            //等待服务端监听端口关闭，才退出
            f.channel().closeFuture().sync();
        } catch (InterruptedException e) {
            log.info("[出现异常] 释放资源");
            boss.shutdownGracefully();
            work.shutdownGracefully();
        }
    }
    public static void main(String[] args) throws ParseException {// 1591340586471
    										// 1591340611162
		System.err.println(System.currentTimeMillis());
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		cal.setTime(df.parse("2020-06-05 14:55:00"));
		System.err.println(cal.getTime().getTime());
	}
}
