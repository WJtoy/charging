package com.gdcdgj.charging.gateway.server.channel;


import com.gdcdgj.charging.gateway.config.NettyServerConfig;
import com.gdcdgj.charging.gateway.server.handler.ServerChannelHandler;
import io.netty.channel.Channel;
import io.netty.channel.ChannelInitializer;
import io.netty.handler.codec.bytes.ByteArrayDecoder;
import io.netty.handler.codec.bytes.ByteArrayEncoder;
import io.netty.handler.timeout.IdleStateHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

/**
 * 通道初始化
 *
 * @author Changliang Tao
 * @date 2020/4/11 16:06
 * @since JDK 1.8
 */
@Component
public class BootNettyChannelInitializer<SocketChannel> extends ChannelInitializer<Channel> {
    // 通道适配器
    @Autowired
    private ServerChannelHandler serverChannelHandlerAdapter;
    // netty服务器配置信息
    @Autowired
    private NettyServerConfig nettyServerConfig;

    @Override
    protected void initChannel(Channel ch) throws Exception {
        //过滤编码
        ch.pipeline().addLast(new ByteArrayDecoder());
        ch.pipeline().addLast(new ByteArrayEncoder());

        // 添加心跳支持
        ch.pipeline().addLast(new IdleStateHandler(nettyServerConfig.getHeartBeatTimeOut(), 0, 0, TimeUnit.SECONDS));
        ch.pipeline().addLast(serverChannelHandlerAdapter);
    }
}
