package com.gdcdgj.charging.gateway.server.dispatcher;

import com.gdcdgj.charging.gateway.enums.MsgStartFieldEnum;
import com.gdcdgj.charging.gateway.platform.ib.dispatcher.IbPileCmdDispatcher;
import com.gdcdgj.charging.gateway.platform.kh.dispather.KhPileCmdDispatcher;
import com.gdcdgj.charging.gateway.platform.kw.dispather.KwPileCmdDispatcher;
import io.netty.channel.ChannelHandlerContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import java.util.Arrays;

import static com.gdcdgj.charging.gateway.enums.MsgStartFieldEnum.IB;
import static com.gdcdgj.charging.gateway.enums.MsgStartFieldEnum.KW;

/**
 * 请求分派
 *
 * @author Changliang Tao
 * @date 2020/4/13 14:45
 * @since JDK 1.8
 */
@Slf4j
@Component
public class RequestDispatcher {
    @Autowired
    IbPileCmdDispatcher ibPileCmdDispatcher;
    @Autowired
    KwPileCmdDispatcher kwPileCmdDispatcher;
    @Autowired
    KhPileCmdDispatcher khPileCmdDispatcher;

    /**
     * 根据不同平台不通起始域分发命令
     *
     * @param ctx ChannelHandlerContext
     * @return
     * @throws
     * @author Changliang Tao
     * @date 2020/4/13 14:53
     */
    public void dispatcher(ChannelHandlerContext ctx, byte[] fullData) throws Exception {
        if (dispatcherDataByStartField(fullData, IB)) {
            // 分发到宜步桩
            ibPileCmdDispatcher.dispatcher(ctx,fullData);
        } else if (dispatcherDataByStartField(fullData, KW)){
            // 分发到科旺
        	kwPileCmdDispatcher.dispatcher(ctx, fullData);
        }else if (dispatcherDataByStartField(fullData, KW)) {
        	//分发到科华
        	khPileCmdDispatcher.dispatcher(ctx, fullData);
        } else {
            log.error("该报文的数据起始域有误！");
            return;
        }
    }

    /**
     * 根据起始域判断属于哪一个平台桩
     * @param fullData
     * @param startFieldEnum
     * @return
     * @throws
     * @author Changliang Tao
     * @date 2020/4/14 8:37
     */
    private boolean dispatcherDataByStartField(byte[] fullData, MsgStartFieldEnum startFieldEnum) {
        return Arrays.equals(Arrays.copyOfRange(fullData, 0, 2), startFieldEnum.getValue());
    }
}
