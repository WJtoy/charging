package com.gdcdgj.charging.gateway.server.handler;


import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import lombok.extern.slf4j.Slf4j;

/**
 * 发送到充电桩
 *
 * @author Changliang Tao
 * @date 2020/4/14 15:17
 * @since JDK 1.8
 */
@Slf4j
public class ChannelSender {
    /**
     * 发送报文到桩
     *
     * @param chn
     * @param datas
     * @author ouxx
     * @date 2016-11-11 下午7:25:18
     */
    public synchronized static void send(Channel chn, byte[] datas) {
        try {
            if (chn != null && chn.isWritable()) {
                ByteBuf dataBuf = Unpooled.copiedBuffer(datas);
                chn.writeAndFlush(dataBuf);
            } else {
                throw new Exception("服务器发送数据给桩出错");
            }
        } catch (Exception e) {
            // todo 从redis获取桩编码
            log.error("服务器发送数据给桩出错:{}, 设备编码:{} ", e, H2TServer.channelPileMap.get(chn));
            return;
        }
    }
}
