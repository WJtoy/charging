package com.gdcdgj.charging.gateway.server.handler;

import io.netty.channel.Channel;
import lombok.extern.slf4j.Slf4j;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.springframework.util.CollectionUtils;

import com.gdcdgj.charging.gateway.platform.ib.protocol.CmdData;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbCmdEnum;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbProtocolUtil;
import com.gdcdgj.charging.gateway.platform.kw.protocol.KwCmdEnum;
import com.gdcdgj.charging.gateway.platform.kw.protocol.KwProtocolUtil;

/**
 * 充电桩: channel 和 pile
 *
 * @author Changliang Tao
 * @date 2020/4/18 10:56
 * @since JDK 1.8
 */
@Slf4j
public class H2TServer {
    // 桩编号，netty channel
    public static ConcurrentHashMap<String, Channel> pileChannelMap = new ConcurrentHashMap<String, Channel>();
    // netty channel, 桩编号
    public static ConcurrentHashMap<Channel, String> channelPileMap = new ConcurrentHashMap<Channel, String>();

    //可重入锁
    private static final ReentrantReadWriteLock reentrantLock = new ReentrantReadWriteLock();
    private static final Lock writeLock = reentrantLock.writeLock();
    //线程池
  	private static ScheduledThreadPoolExecutor scheduledExecutor = new ScheduledThreadPoolExecutor(4);
  	
    private static int PERIOD = 5000;//间隔为5秒
	private static final int SEND_TIMES_LIMIT = 5;//最多发5次
	
	//重发map<equipmentCode, Queue<发送的命令报文数据>>
  	private static ConcurrentHashMap<String, LinkedBlockingQueue<CmdData>> equipmentSendCmdMap = new ConcurrentHashMap<String, LinkedBlockingQueue<CmdData>>();
  	public static LinkedBlockingQueue<CmdData> getSendCmdQueue(String pileCode){
  		if(!equipmentSendCmdMap.isEmpty()){
  			return equipmentSendCmdMap.get(pileCode);
  		}
  		return null;
  	}
	
    public static void saveChannel(String pileCode, Channel channel) {
        boolean isLock = writeLock.tryLock();
        try {
            if (isLock) {
                putChannel2Map(pileCode, channel);
                putEquipmentCode2Map(pileCode, channel);
            }
        } finally {
            releaseWriteLock(isLock);
        }
    }
    public static Channel getChannel(String pileCode) {
		return pileChannelMap.get(pileCode);
    }
    private static void releaseWriteLock(boolean isLock) {
        if (isLock) {
            writeLock.unlock();
        }
    }
    public static void putChannel2Map(String pileCode, Channel channel) {
        //若pileChannelMap里没有key为pileCode的数据，才放进pileChannelMap
        if (!pileChannelMap.containsKey(pileCode) || null == pileChannelMap.get(pileCode)) {
            pileChannelMap.put(pileCode, channel);
            //启动超时重发线程
			log.info("pileChannelMap:{}=>{}",pileCode,channel);
			log.info("启动超时重发线程");
			scheduledExecutor.scheduleAtFixedRate(new PushThread(pileCode), PERIOD, PERIOD, TimeUnit.MILLISECONDS);
        }
    }
    public static void putEquipmentCode2Map(String pileCode, Channel chn) {
        if (!channelPileMap.containsKey(chn) || null == channelPileMap.get(chn)) {
            channelPileMap.put(chn, pileCode);
        }
    }
    public static String removePileChannel(Channel chn){
        String pileCode = null;
        boolean isLock = writeLock.tryLock();
        try{
            if(isLock){
                if(!pileChannelMap.isEmpty() && !channelPileMap.isEmpty() && null != channelPileMap.get(chn)){
                	pileCode = channelPileMap.remove(chn);
                    pileChannelMap.remove(pileCode);
                }
            }
        }finally{
            releaseWriteLock(isLock);
        }
        return pileCode;
    }
    
  	public static void putSendCmd2Queue(String pileCode, CmdData data){
  		boolean isLock = writeLock.tryLock();
  		try{
  			if(isLock){
  				LinkedBlockingQueue<CmdData> queue = equipmentSendCmdMap.get(pileCode);
  				//若本身没有pileCode对应的命令队列，则新建
  				if(CollectionUtils.isEmpty(queue)){
  					queue = new LinkedBlockingQueue<CmdData>();
  					//加进队列
  					queue.add(data);
  					//如果原先没有pileCode对应的队列，则要put进equipmentCmdMap
  					equipmentSendCmdMap.put(pileCode, queue);
  				}else{
  					//加进队列
  					queue.add(data);
  				}
  			}
  		}finally{
  			releaseWriteLock(isLock);
  		}
  	}
  	public static void removeQueue(String pileCode){
  		boolean isLock = writeLock.tryLock();
  		try{
  			if(!equipmentSendCmdMap.isEmpty()){
  				equipmentSendCmdMap.remove(pileCode);
  			}
  		}finally{
  			releaseWriteLock(isLock);
  		}
  	}

  	/**
  	 * 如果接收到应答数据，则移除数据重发队列中对应的数据
  	 */
  	public static void removeCmdInQueue(final CmdData cmdData, String pileCode){
  		boolean isLock = writeLock.tryLock();
  		try{
  			if(isLock){
  				if(cmdData.getCmdEnum() != null) {
  					LinkedBlockingQueue<CmdData> queue = getSendCmdQueue(pileCode);
  					if(!CollectionUtils.isEmpty(queue)){
  						CmdData sendData = queue.peek();
  						if(null != sendData){
  							IbCmdEnum sendCmd = sendData.getCmdEnum();
  							if(null != sendCmd){
  								log.warn("多线程中，收到来自 " + pileCode + " 的命令 " + sendCmd.name());
  								queue.poll();//出列
  							}
  						}
  					}
  				}else if(cmdData.getKwCmdEnum() != null) {
  					LinkedBlockingQueue<CmdData> queue = getSendCmdQueue(pileCode);
  					if(!CollectionUtils.isEmpty(queue)){
  						CmdData sendData = queue.peek();
  						if(null != sendData){
  							KwCmdEnum sendCmd = sendData.getKwCmdEnum();
  							if(null != sendCmd){
  								log.warn("多线程中，收到来自 " + pileCode + " 的命令 " + sendCmd.name());
  								queue.poll();//出列
  							}
  						}
  					}
  				}
  			}
  		}finally{
  			releaseWriteLock(isLock);
  		}

  	}
    
    /*
     * 超时重发桩数据的类
     */
    public static class PushThread implements Runnable {
    	
    	private String pileCode;
    	
    	public PushThread(String pileCode){
    		this.pileCode = pileCode;
    	}
    	public PushThread(){ }

    	@Override
    	public void run() {

    		boolean isLock = writeLock.tryLock();
    		try {
    			if(isLock){
    				//如果还没有桩连上来，则一直等，有桩连上时（pileChannelMap添加新元素），notifyAll
    				if(!H2TServer.pileChannelMap.isEmpty()){
    					//获取需要发送的命令队列
    					LinkedBlockingQueue<CmdData> cmdQueue = H2TServer.getSendCmdQueue(pileCode);
    					if(null != cmdQueue && !cmdQueue.isEmpty()){
    						CmdData cmdData = cmdQueue.element();//获取队列头
    						if(cmdData.getKwCmdEnum() != null) PERIOD = 10000;
    						//如果当前时间在上次发送的时间的5秒后，则重发
    						if( System.currentTimeMillis() - cmdData.getLastSendTime() >= PERIOD){
    							byte[] fullData = cmdData.getFullData();
    							if(null != fullData && 0 < fullData.length){
    								//已经发送了的次数
    								int sentNumOfTimes = cmdData.getSentNumOfTimes();
    								if(SEND_TIMES_LIMIT > sentNumOfTimes){
    									int times = sentNumOfTimes + 1;
    									log.warn("第 " + times + " 次向 " + pileCode + " 重发数据 "
    											+ IbProtocolUtil.getCmdCodeEnum(fullData).name()== null 
    											? IbProtocolUtil.getCmdCodeEnum(fullData).name()
    											: KwProtocolUtil.getCmdCodeEnum(fullData).name()
    											);
    									cmdQueue.element().setSentNumOfTimes(times);
    									cmdQueue.element().setLastSendTime(System.currentTimeMillis());
    									log.info("发送报文到桩");
    									ChannelSender.send(H2TServer.pileChannelMap.get(pileCode), fullData);
    								}else{
    									//发了5次都没收到应答数据，只移除命令队列中对应的命令
    									log.warn("桩" + pileCode + "没有应答");
    									H2TServer.removeQueue(pileCode);
    								}
    							}
    						}
    					}
    				}
    			}
    		} catch (Exception e) {
    			log.error("超时重发桩数据出错:" + Thread.currentThread().getName(), e);
    		} finally{
    			 releaseWriteLock(isLock);
    		}
    	}
    }
}
