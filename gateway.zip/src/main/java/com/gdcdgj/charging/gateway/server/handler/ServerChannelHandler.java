package com.gdcdgj.charging.gateway.server.handler;


import com.gdcdgj.charging.api.constant.RabbitmqConstant;
import com.gdcdgj.charging.api.vo.srv2gw.SignIn;
import com.gdcdgj.charging.gateway.config.NettyServerConfig;
import com.gdcdgj.charging.gateway.platform.kw.handler.KwPileCmdHandler;
import com.gdcdgj.charging.gateway.server.dispatcher.RequestDispatcher;
import io.netty.channel.ChannelHandler.*;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.handler.timeout.IdleState;
import io.netty.handler.timeout.IdleStateEvent;
import lombok.extern.slf4j.Slf4j;

import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.io.IOException;

import static com.gdcdgj.charging.gateway.server.handler.H2TServer.removePileChannel;

/**
 * 服务器处理类
 * io数据读写处理类
 */
@Slf4j
@Component
@Sharable
public class ServerChannelHandler extends ChannelInboundHandlerAdapter {
    // 失去连接次数
    private int lossConnectCount = 0;
    // netty服务器配置信息
    @Autowired
    private NettyServerConfig nettyServerConfig;
    // 充电桩请求分派
    @Autowired
    private RequestDispatcher requestDispatcher;
    @Autowired
	private AmqpTemplate amqp;

    /**
     * 从客户端收到新的数据时，这个方法会在收到消息时被调用
     *
     * @param ctx
     * @param msg
     */
    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        byte[] fullData = (byte[]) msg;
        requestDispatcher.dispatcher(ctx, fullData);
    }

    /**
     * 从客户端收到新的数据、读取完成时调用
     *
     * @param ctx
     */
    @Override
    public void channelReadComplete(ChannelHandlerContext ctx) throws Exception {
        super.channelReadComplete(ctx);
    }

    /**
     * 当出现 Throwable 对象才会被调用，即当 Netty 由于 IO 错误或者处理器在处理事件时抛出的异常时
     *
     * @param ctx
     * @param cause
     */
    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws IOException {
        log.error("{} -> [连接异常] {}通道异常，异常原因：{}", this.getClass().getName(), ctx.channel().id(), cause.getMessage());
        ctx.close();
    }

    /**
     * 客户端与服务端第一次建立连接时 执行
     *
     * @param ctx
     * @throws Exception
     */
    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception, IOException {
        log.info("客户端连接：" + ctx.channel().remoteAddress());
    }

    /**
     * 服务端当read超时, 会调用这个方法
     *
     * @param ctx
     * @param evt
     * @throws Exception
     */
    @Override
    public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception, IOException {
        log.info("{} -> [已经有15秒中没有接收到客户端的消息了]", this.getClass().getName());
        if (evt instanceof IdleStateEvent) {
            IdleStateEvent idleStateEvent = (IdleStateEvent) evt;
            if (idleStateEvent.state() == IdleState.READER_IDLE) {
                lossConnectCount++;
                if (lossConnectCount > nettyServerConfig.getLossConnectCount()) {
                    log.info("{} -> [释放不活跃通道] {}", this.getClass().getName(), ctx.channel().id());
                    // 失去连接次数置0
                    lossConnectCount = 0;
                    ctx.channel().close();
                }
            }
        } else {
            // 失去连接次数置0
            lossConnectCount = 0;
            super.userEventTriggered(ctx, evt);
        }
    }

    /**
     * 客户端与服务端 断连时 执行
     *
     * @param ctx
     * @return
     * @throws
     * @author Changliang Tao
     * @date 2020/4/14 13:58
     */

    @Override
    public void channelInactive(ChannelHandlerContext ctx) throws Exception {
        log.info("客户端断开：" + ctx.channel().remoteAddress());
        handleDisconnected(ctx);
        super.channelInactive(ctx);
    }

    /**
     * 断链处理
     */
    private void handleDisconnected(ChannelHandlerContext ctx) {
        try {
        	new KwPileCmdHandler().isStart = true;
            String equipmentCode = removePileChannel(ctx.channel());
            if (!StringUtils.isEmpty(equipmentCode)) {
                log.info("handleDisconnected--断连：" + equipmentCode);
            }
            //断链设置桩状态离线
            SignIn signIn = new SignIn();
            signIn.setPileCode(equipmentCode);
            signIn.setStartStopSingal((byte) 0);
            amqp.convertAndSend(RabbitmqConstant.SIGN_IN_PILE_EXCHANGE, RabbitmqConstant.SIGN_IN_PILE_ROUTING_KEY, signIn);
        } catch (Exception e) {
            log.error(e.getMessage());
        }
    }

}
