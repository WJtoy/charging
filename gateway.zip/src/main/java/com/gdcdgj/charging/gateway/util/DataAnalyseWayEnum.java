/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.util;

/**
 * 数据解析方式枚举
 * @author ouxx
 * @since 2016-11-2 上午11:06:59
 *
 */
public enum DataAnalyseWayEnum {

	Byte(0),//1个字节，8位
	Char(1),//解析为字符型，正常大小端--java中char型为16位无符号整形
	CharReverse (2),//解析为字节，反转大小端

	Int16 (5),//解析为带符号16位整型数，正常大小端--java中的short, 16位有符号整形
	Int16Reverse (6),//解析为带符号16位整形数，反转大小端

	Int32 (9),//解析为带符号32位整型数，正常大小端 0123
	Int32Swapped (10),//解析为带符号32位整型数，前16位与后16位调转 2301
	Int32ReverseByte (11),//解析为带符号32位整型数，前16位与后16位不调转，但每16位的前8位与后8位调转 1032
	Int32Reverse(12),//解析为带符号32位整型数，整个数组反转3210

	Int64 (15),//解析为带符号64位整型数，正常大小端--java中的long
	Int64Reverse (16),//解析为带符号64位整型数，反转大小端
	
	UInt8(18),//解析为无符号8位整型数，正常大小端--java中的char
	
	UInt16 (19),//解析为无符号16位整型数，正常大小端--java中的char
	UInt16Reverse (20),//解析为无符号16位整型数，反转大小端

	UInt32 (23),//解析为无符号32位整型数，正常大小端--java中的无符号long型
	UInt32Reverse (24),//解析为无符号32位整型数，反转大小端

	UInt64 (27),//解析为无符号64位整型数，正常大小端
	UInt64Reverse (28),//解析为无符号64位整型数，反转大小端

	Single (31),//解析为float类型数据，正常大小端
	SingleReverse (32),//解析为为float类型数据，反转大小端

	Double (35),//解析为double类型的数据
	DoubleReverse (36),//解析为double类型的数据，反转大小端

	StrASCII (39),//解析为ASCII编码的字符串
	StrUnicode (40),//解析为Unicode编码的字符串
	BCD16 (41),//解析为BDC编码的字符串
	UTF8 (42),//解析为UTF8编码的字符串
	GB2312(43),//GB2312 汉字编码方式

	VarLength(50),//解析不定长byte数组，返回BigInteger
	VarLengthReverse(51);//解析不定长byte数组，返回BigInteger，反转大小端

	private int value;
	private DataAnalyseWayEnum(int value){
		this.value=value;
	}

	public int getValue(){
		return value;
	}

	public static DataAnalyseWayEnum valueOf(int value) throws RuntimeException{
		DataAnalyseWayEnum tempEnum = null;
		for(DataAnalyseWayEnum en: DataAnalyseWayEnum.values()){
			if(en.value == value){
				tempEnum=en;
				break;
			}
		}
		if(tempEnum==null){
			throw new RuntimeException("Enum value not exist");
		}
		return tempEnum;
	}
}
