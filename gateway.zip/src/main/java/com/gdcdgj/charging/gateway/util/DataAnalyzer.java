package com.gdcdgj.charging.gateway.util;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.math.BigInteger;

/**
 * 数据分析器
 *
 * @author Changliang Tao
 * @date 2020/4/14 15:35
 * @since JDK 1.8
 */
@Slf4j
@Data
public class DataAnalyzer {
    // 数据解析方式枚举
    private DataAnalyseWayEnum analyseWay;
    // 数据解析方式枚举
    private DataCategory dataCategory;
    // 数据解析方式枚举
    private DataType dataType;
    // 偏移量
    private Offset offset;
    // 缩放因子
    private ZoomFactor zoomFactor;
    // 单位
    private Unit unit;


    /**
     * 转换命令数据 其他类型→byte[]类型
     *
     * @param value 待转换的数据
     * @return
     */
    public static byte[] analyseCommandData(Object value, DataAnalyseWayEnum analyseWay) {

        byte[] result = null;

        try {
            switch (analyseWay) {
                case Byte:
                    result = new byte[]{(Byte) value};
                    break;
                case Char:
                    result = MathConverterHelper.getBytes(((char) ((Integer) value).intValue()));
                    break;
                case CharReverse:
                    result = MathConverterHelper.getBytes(((char) ((Integer) value).intValue()));
                    char charValue = MathConverterHelper.toCharReverse(result, 0);
                    result = MathConverterHelper.getBytes(charValue);
                    break;

                case Int16:
                    result = MathConverterHelper.getBytes(((short) ((Integer) value).intValue()));
                    break;
                case Int16Reverse:
                    result = MathConverterHelper.getBytes(((short) ((Integer) value).intValue()));
                    short shortValue = MathConverterHelper.toInt16Reverse(result, 0);
                    result = MathConverterHelper.getBytes(shortValue);
                    break;

                case Int32:
                    result = MathConverterHelper.getBytes((Integer) value);
                    break;
                case Int32Swapped:
                    result = MathConverterHelper.getBytes(((Integer) value).intValue());
                    int intValue = MathConverterHelper.toInt32Swapped(result, 0);
                    result = MathConverterHelper.getBytes(intValue);
                    break;
                case Int32ReverseByte:
                    result = MathConverterHelper.getBytes(((Integer) value).intValue());
                    int intValue1 = MathConverterHelper.toInt32ReverseByte(result, 0);
                    result = MathConverterHelper.getBytes(intValue1);
                    break;
                case Int32Reverse:
                    result = MathConverterHelper.getBytes(((Integer) value).intValue());
                    int intValue2 = MathConverterHelper.toInt32Reverse(result, 0);
                    result = MathConverterHelper.getBytes(intValue2);
                    break;

                case Int64:
                    result = MathConverterHelper.getBytes(((Long) value).longValue());
                    break;
                case Int64Reverse:
                    result = MathConverterHelper.getBytes(((Long) value).longValue());
                    long longValue = MathConverterHelper.toInt64Reverse(result, 0);
                    result = MathConverterHelper.getBytes(longValue);
                    break;
                case UInt8:
                	result = MathConverterHelper.getBytes(((byte) ((Integer) value).intValue()));
                	break;
                case UInt16:
                    result = MathConverterHelper.getBytes(((char) ((Integer) value).intValue()));
                    break;
                case UInt16Reverse:
                    result = MathConverterHelper.getBytes(((char) ((Integer) value).intValue()));
                    char charValue1 = MathConverterHelper.toChar(result, 0);
                    result = MathConverterHelper.getBytes(charValue1);
                    break;

                case UInt32:
                    result = MathConverterHelper.getBytes(((Long) value).longValue());
                    break;
                case UInt32Reverse:
                    result = MathConverterHelper.getBytes(((Long) value).longValue());
                    long longValue2 = MathConverterHelper.toUInt32Reverse(result, 0);
                    result = MathConverterHelper.getBytes(longValue2);
                    break;

                // java中并无无符号64位整型数，以下功能待实现
                case UInt64:
                    break;
                case UInt64Reverse:
                    break;

                case Single:
                    result = MathConverterHelper.getBytes(((Float) value).floatValue());
                    break;
                case SingleReverse:
                    result = MathConverterHelper.getBytes(((Float) value).floatValue());
                    float floatValue = MathConverterHelper.toSingleReverse(result, 0);
                    result = MathConverterHelper.getBytes(floatValue);
                    break;

                case Double:
                    result = MathConverterHelper.getBytes(((Double) value).doubleValue());
                    break;

                case DoubleReverse:
                    result = MathConverterHelper.getBytes(((Double) value).doubleValue());
                    double doubleValue = MathConverterHelper.toDoubleReverse(result, 0);
                    result = MathConverterHelper.getBytes(doubleValue);
                    break;

                case StrASCII:
                    result = MathConverterHelper.getBytes((String) value, "ASCII");
                    break;

                case StrUnicode:
                    result = MathConverterHelper.getBytes((String) value, "Unicode");
                    break;

                case BCD16:
                    result = MathConverterHelper.getBytes((String) value, "CBCD");
                    break;
                case UTF8:
                    result = MathConverterHelper.getBytes((String) value, "UTF-8");
                    break;
                case GB2312:
                    result = MathConverterHelper.getBytes((String) value, "gb2312");
                    break;
                case VarLength:
                    result = MathConverterHelper.getVarLenDataBytes(value);
                    break;
                case VarLengthReverse:
                    result = MathConverterHelper.getVarLenDataBytes(value);
                    BigInteger bigInt = MathConverterHelper.toVarLenDataReverse(result);
                    result = MathConverterHelper.getVarLenDataBytes(bigInt);
                    break;

                default:
                    break;
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return result;
    }

    /**
     * 依据数据类型对模拟量进行解析: byte[]类型→double类型
     *
     * @param oneAnalogData
     * @return
     */
    public static Object analyseAnalogData(DataAnalyzer analyzer, byte... oneAnalogData) {

        Object result = null;

        double doubleResult = 0.0;// 所有非字符串模拟量数值转化为double型

        double zoomFactor = 1.0;
        if (null != analyzer.getZoomFactor()) {
            zoomFactor = analyzer.getZoomFactor().getValue();
        }
        int offset = 0;
        if (null != analyzer.getOffset()) {
            offset = analyzer.getOffset().getValue();
        }

        try {

            switch (analyzer.getAnalyseWay()) {
                case Byte:
                    result = oneAnalogData[0] * zoomFactor + offset;
                    break;
                case Char:
                    char tempChar = MathConverterHelper.toChar(oneAnalogData, 0);
                    result = tempChar * zoomFactor + offset;
                    break;

                case CharReverse:
                    char tempCharReverse = MathConverterHelper.toCharReverse(oneAnalogData, 0);
                    result = tempCharReverse * zoomFactor + offset;
                    break;

                case Int16:
                    short tempInt16 = MathConverterHelper.toInt16(oneAnalogData, 0);
                    result = tempInt16 * zoomFactor + offset;
                    break;

                case Int16Reverse:
                    short tempInt16Reverse = MathConverterHelper.toInt16Reverse(oneAnalogData, 0);
                    result = tempInt16Reverse * zoomFactor + offset;
                    break;

                case Int32:
                    int tempInt32 = MathConverterHelper.toInt32(oneAnalogData, 0);
                    result = tempInt32 * zoomFactor + offset;
                    break;

                case Int32Swapped:
                    int tempInt32Swapped = MathConverterHelper.toInt32Swapped(oneAnalogData, 0);
                    result = tempInt32Swapped * zoomFactor + offset;
                    break;

                case Int32ReverseByte:
                    int tempInt32ReverseByte = MathConverterHelper.toInt32ReverseByte(oneAnalogData, 0);
                    result = tempInt32ReverseByte * zoomFactor + offset;
                    break;

                case Int32Reverse:
                    int tempInt32Reverse = MathConverterHelper.toInt32Reverse(oneAnalogData, 0);
                    result = tempInt32Reverse * zoomFactor + offset;
                    break;

                case Int64:
                    long tempInt64 = MathConverterHelper.toInt64(oneAnalogData, 0);
                    result = tempInt64 * zoomFactor + offset;
                    break;

                case Int64Reverse:
                    long tempInt64Reverse = MathConverterHelper.toInt64Reverse(oneAnalogData, 0);
                    result = tempInt64Reverse * zoomFactor + offset;
                    break;
                    
                case UInt8:
                	int tempUInt8 = MathConverterHelper.toUInt8(oneAnalogData, 0);
                	result = tempUInt8 * zoomFactor + offset;
                	break;
                	
                case UInt16:
                    int tempUInt16 = MathConverterHelper.toUInt16(oneAnalogData, 0);
                    result = tempUInt16 * zoomFactor + offset;
                    break;

                case UInt16Reverse:
                    int tempUInt16Reverse = MathConverterHelper.toUInt16Reverse(oneAnalogData, 0);
                    result = tempUInt16Reverse * zoomFactor + offset;
                    break;

                case UInt32:
                    long tempUInt32 = MathConverterHelper.toUInt32(oneAnalogData, 0);
                    result = tempUInt32 * zoomFactor + offset;
                    break;

                case UInt32Reverse:
                    long tempUInt32Reverse = MathConverterHelper.toUInt32Reverse(oneAnalogData, 0);
                    result = tempUInt32Reverse * zoomFactor + offset;
                    break;

                case UInt64:
                    doubleResult = (Double) MathConverterHelper.toUInt64(oneAnalogData, 0);
                    doubleResult = doubleResult * zoomFactor + offset;
                    result = doubleResult;
                    break;

                case UInt64Reverse:
                    result = MathConverterHelper.toUInt64Reverse(oneAnalogData, 0);
                    result = Long.parseLong(result.toString()) * zoomFactor + offset;
                    break;

                case Single:
                    float tempSingle = MathConverterHelper.toSingle(oneAnalogData, 0);
                    result = tempSingle * zoomFactor + offset;
                    break;

                case SingleReverse:
                    float tempSingleReverse = MathConverterHelper.toSingleReverse(oneAnalogData, 0);
                    result = tempSingleReverse * zoomFactor + offset;
                    break;

                case Double:
                    double tempDouble = MathConverterHelper.toDouble(oneAnalogData, 0);
                    result = tempDouble * zoomFactor + offset;
                    break;

                case DoubleReverse:
                    double tempDoubleReverse = MathConverterHelper.toDoubleReverse(oneAnalogData, 0);
                    result = tempDoubleReverse * zoomFactor + offset;
                    break;

                case StrASCII:
                    String tempStrASCII = MathConverterHelper.toASCIIString(oneAnalogData, 0);
                    result = tempStrASCII;
                    break;

                case StrUnicode:
                    String tempStrUnicode = MathConverterHelper.toUnicodeString(oneAnalogData, 0);
                    result = tempStrUnicode;
                    break;

                case BCD16:
                    String tempBCD16 = MathConverterHelper.toCBCDString(oneAnalogData);
                    result = tempBCD16;
                    break;

                case UTF8:
                    String tempUTF8 = MathConverterHelper.toUTF8String(oneAnalogData);
                    result = tempUTF8;
                    break;

                case GB2312:
                    result = MathConverterHelper.toGB2312String(oneAnalogData, 0);
                    break;

                case VarLength:
                    result = MathConverterHelper.toVarLenData(oneAnalogData);
                    break;
                case VarLengthReverse:
                    result = MathConverterHelper.toVarLenDataReverse(oneAnalogData);
                    break;
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }
        // 若是Decimal类型，保留小数点后两位
        if (null != analyzer.getDataType()) {
            if (analyzer.getDataType().equals(DataType.Decimal)) {
                result = Double.parseDouble(new java.text.DecimalFormat("0.00").format(result));
            } else if (analyzer.getDataType().equals(DataType.Integer)) {// 若是Integer类型
                result = Integer.parseInt(new java.text.DecimalFormat("0").format(result));
            }
        }

        return result;
    }
    public static void main(String[] args) {
		try {
			byte[] result = MathConverterHelper.getBytes(((char) ((Integer) 1).intValue()));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
