/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.util;

/**
 * 数据类型：电压、电流、容量、温度等， 嵌套枚举
 * @author ouxx
 * @since 2016-11-2 上午11:08:38
 *
 */
public enum DataCategory {

	Voltage(DataAnalyseWayEnum.UInt16Reverse),//电压
	Current(DataAnalyseWayEnum.UInt16Reverse),//电流
	SingleVol(DataAnalyseWayEnum.UInt16Reverse),//单体电池电压
	Quantity(DataAnalyseWayEnum.UInt16Reverse),//容量/电量
	Soc(DataAnalyseWayEnum.CharReverse),//电池SOC Uint8
	Temperature(DataAnalyseWayEnum.Byte),//温度  int8
	Kwh(DataAnalyseWayEnum.UInt32Reverse),//电度
	Power(DataAnalyseWayEnum.UInt16Reverse);//功率

	private DataAnalyseWayEnum value;
	private DataCategory(DataAnalyseWayEnum value){
		this.value = value;
	}
	public DataAnalyseWayEnum getValue(){
		return this.value;
	}
}
