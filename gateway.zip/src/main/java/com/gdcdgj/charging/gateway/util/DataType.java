/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.util;

/**
 * 数据类型: 整型、小数、字符串等等
 *
 * @author ouxx
 * @since 2016-11-2 上午11:12:47
 */
public enum DataType {
    Decimal(10),
    Integer(20),
    String(30),
    Enum(40);

    private int value;

    private DataType(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    public static DataType valueOf(int value) throws RuntimeException {
        DataType tempEnum = null;
        for (DataType en : DataType.values()) {
            if (en.value == value) {
                tempEnum = en;
                break;
            }
        }
        if (tempEnum == null) {
            throw new RuntimeException("Enum value not exist");
        }
        return tempEnum;
    }
}
