package com.gdcdgj.charging.gateway.util;

import java.math.BigInteger;
import java.nio.charset.Charset;
import java.util.Calendar;

/**
 * 数据类型转换辅助类
 *
 * @author ouxx
 * @since 2016-11-1 上午9:56:54
 *
 */
public class MathConverterHelper {

	public static byte[] getBytes(boolean value) throws Exception {
		return new byte[] { (value ? ((byte) 1) : ((byte) 0)) };
	}

	public static byte[] getBytes(short data) throws Exception {
		byte[] bytes = new byte[2];
		bytes[0] = (byte) (data & 0xff);
		bytes[1] = (byte) ((data & 0xff00) >> 8);
		return bytes;
	}

	public static byte[] getBytesReverse(short data) throws Exception {
		byte[] bytes = new byte[2];
		bytes[0] = (byte) ((data & 0xff00) >> 8);
		bytes[1] = (byte) (data & 0xff);
		return bytes;
	}

	public static byte[] getBytes(char data) throws Exception {
		byte[] bytes = new byte[2];
		bytes[0] = (byte) (data & 0xff);
		bytes[1] = (byte) ((data & 0xff00) >> 8);
		return bytes;
	}

	public static byte[] getBytes(int data) throws Exception {
		byte[] bytes = new byte[4];
		bytes[0] = (byte) (data & 0xff);
		bytes[1] = (byte) ((data & 0xff00) >> 8);
		bytes[2] = (byte) ((data & 0xff0000) >> 16);
		bytes[3] = (byte) ((data & 0xff000000) >> 24);
		return bytes;
	}

	public static byte[] getBytes(long data) throws Exception {
		byte[] bytes = new byte[8];
		bytes[0] = (byte) (data & 0xff);
		bytes[1] = (byte) ((data >> 8) & 0xff);
		bytes[2] = (byte) ((data >> 16) & 0xff);
		bytes[3] = (byte) ((data >> 24) & 0xff);
		bytes[4] = (byte) ((data >> 32) & 0xff);
		bytes[5] = (byte) ((data >> 40) & 0xff);
		bytes[6] = (byte) ((data >> 48) & 0xff);
		bytes[7] = (byte) ((data >> 56) & 0xff);
		return bytes;
	}

	public static byte[] getBytes(float data) throws Exception {
		int intBits = Float.floatToIntBits(data);
		return getBytes(intBits);
	}

	public static byte[] getBytes(double data) throws Exception {
		long intBits = Double.doubleToLongBits(data);
		return getBytes(intBits);
	}

	/**
	 * 获得字符串的ASCII码数组
	 *
	 * @param value
	 * @param charsetName
	 * @return
	 */
	public static byte[] getBytes(String value, String charsetName) throws Exception {
		// 压缩BCD码
		if ("CBCD".equals(charsetName.toUpperCase())) {

			return getBytesFromCBCD(value);
		}
		return value.getBytes(Charset.forName(charsetName));
	}

	/**
	 * BigInteger转化为byte[]
	 * @param value
	 * @return
	 * @author ouxx
	 * @date 2016-11-5 下午1:46:11
	 */
	public static byte[] getVarLenDataBytes(Object value) throws Exception {
		if(value instanceof BigInteger) {
			return ((BigInteger)value).toByteArray();
		}
		return null;
	}

	/**
	 * BigInteger转化为byte[]，限定数组长度
	 * @param value
	 * @return
	 * @author ouxx
	 * @date 2016-11-5 下午1:46:11
	 */
	public static byte[] getVarLenDataBytes(Object value, int len) throws Exception {
		byte[] datas = new byte[len];
		if(value instanceof BigInteger) {
			System.arraycopy(((BigInteger)value).toByteArray(), 0, datas, 0, len);
		}
		return datas;
	}

	/**
	 * 获取压缩BCD码的byte[]
	 *
	 * @param bcdCode
	 * @return
	 */
	private static byte[] getBytesFromCBCD(String bcdCode) throws Exception {

		int len = bcdCode.length();
		byte[] result = null;

		if (len % 2 != 0) {
			bcdCode = "0" + bcdCode;
			result = new byte[len / 2 + 1];
		} else {
			result = new byte[len / 2];
		}

		char[] hex = bcdCode.toCharArray();

		for (int i = 0, pos = 0; i < bcdCode.length() / 2; i++) {

			result[i] = (byte) ((hex[pos] - 0x30) << 4 | (hex[pos + 1] - 0x30));
			pos += 2;
		}

		return result;
	}

	/**
	 * 将byte[]数组中的第index元素转化为boolean型
	 *
	 * @para value
	 *
	 * @para index
	 */
	public static boolean toBoolean(byte[] value, int index) throws Exception {
		return value[index] != 0;
	}

	public static char toChar(byte[] value, int index) throws Exception {
		return (char) (value[0 + index] & 0xFF<< 0 | value[1 + index]& 0xFF << 8);

	}

	public static char toCharReverse(byte[] value, int index) throws Exception {
		return (char) (value[0 + index]& 0xff << 8 | value[1 + index]& 0xff << 0);
	}

	/**
	 * 小端模式下将value数组数值还原为short型数值
	 * <p>
	 *
	 * 本函数功能理解示例：
	 * <p>
	 * short data = 0x1234;
	 * <p>
	 * byte[] value = new byte[]{0x34,
	 * 0x12};//小端模式下value数组成员分布，低字节0x34在前，高字节0x12在后
	 * <p>
	 * short result = ToInt16(value, 0);//调用函数
	 * <p>
	 * Assert(result == data);
	 * <p>
	 *
	 * @param value
	 * @param index
	 * @return
	 */
	public static short toInt8(byte[] value, int index) throws Exception {
		return (byte) ((value[index] & 0xFF) << 0 | (value[index] & 0xFF) << 8);
	}
	
	public static short toInt16(byte[] value, int index) throws Exception {
		return (short) ((value[0 + index] & 0xFF) << 0 | (value[1 + index] & 0xFF) << 8);
	}

	public static short toInt16Reverse(byte[] value, int index) throws Exception {
		return (short) ((value[1 + index] & 0xFF) << 0 | (value[0 + index] & 0xFF) << 8);
	}

	/**
	 * byte[] to int32
	 *
	 * @param value
	 * @param index
	 * @return
	 */
	public static int toInt32(byte[] value, int index) throws Exception {
		return ((value[0 + index] & 0xFF) << 0 | (value[1 + index] & 0xFF) << 8 | (value[2 + index] & 0xFF) << 16 | (value[3 + index] & 0xFF) << 24);
	}

	/**
	 * int32 swapped eg: 0x12345678 → 0x56781234
	 *
	 * @param value
	 * @param index
	 * @return
	 */
	public static int toInt32Swapped(byte[] value, int index) throws Exception {
		return ((value[1 + index] & 0xFF) << 24 | (value[0 + index] & 0xFF) << 16 | (value[3 + index] & 0xFF) << 8 | (value[2 + index] & 0xFF) << 0);
	}

	/**
	 * int32 reverse eg: 0x12345678 → 0x78563412
	 *
	 * @param value
	 * @param index
	 * @return
	 */
	public static int toInt32Reverse(byte[] value, int index) throws Exception {
		return ((value[0 + index] & 0xFF) << 24 | (value[1 + index] & 0xFF) << 16 | (value[2 + index] & 0xFF) << 8 | (value[3 + index] & 0xFF) << 0);
	}

	/**
	 * int32 reverse per word eg: 0x12345678 → 0x34127856
	 *
	 * @param value
	 * @param index
	 * @return
	 */
	public static int toInt32ReverseByte(byte[] value, int index) throws Exception {
		return ((value[2 + index] & 0xFF) << 24 | (value[3 + index] & 0xFF) << 16 | (value[0 + index] & 0xFF) << 8 | (value[1 + index] & 0xFF) << 0);
	}

	/**
	 * 翻转数组
	 *
	 * @param value
	 *            要翻转的数组
	 * @param left
	 *            指定起始元素位置
	 * @param right
	 *            指定结束元素位置
	 */
	public static void reverse(byte[] value, int left, int right) throws Exception {

		if (left >= right)
			return;

		byte temp;
		temp = value[left];
		value[left] = value[right];
		value[right] = temp;
		reverse(value, ++left, --right);
	}

	public static long toInt64(byte[] value, int index) throws Exception {
		return ((long) (value[0 + index] & 0xFF) << 0 | (long) (value[1 + index] & 0xFF) << 8
				| (long) (value[2 + index] & 0xFF) << 16 | (long) (value[3 + index] & 0xFF) << 24
				| (long) (value[4 + index] & 0xFF) << 32 | (long) (value[5 + index] & 0xFF) << 40
				| (long) (value[6 + index] & 0xFF) << 48 | (long) (value[7 + index] & 0xFF) << 56);
	}

	public static long toInt64Reverse(byte[] value, int index) throws Exception {
		return ((long) (value[0 + index] & 0xFF) << 56 | (long) (value[1 + index] & 0xFF) << 48
				| (long) (value[2 + index] & 0xFF) << 40 | (long) (value[3 + index] & 0xFF) << 32
				| (long) (value[4 + index] & 0xFF) << 24 | (long) (value[5 + index] & 0xFF) << 16
				| (long) (value[6 + index] & 0xFF) << 8 | (long) (value[7 + index] & 0xFF) << 0);
	}

	/**
	 * 转化为无符号0..65535的32位整数 注：java中无unsigned short类型,故返回型为int
	 *
	 * @param value
	 * @param index
	 * @return
	 */
	public static int toUInt8(byte[] value, int index) throws Exception {
		return toInt8(value, index) & 0xFF;
	}
	
	public static int toUInt16(byte[] value, int index) throws Exception {
		return toInt16(value, index) & 0xFFFF;
	}

	public static int toUInt16Reverse(byte[] value, int index) throws Exception {
		return toInt16Reverse(value, index) & 0xFFFF;
	}

	public static long toUInt32(byte[] value, int index) throws Exception {
		return toInt32(value, index) & 0xFFFFFFFF;
	}

	public static long toUInt32Reverse(byte[] value, int index) throws Exception {
		// return toInt32Reverse(value, index) & 0xFFFF;
		return toInt32Reverse(value, index) & 0xFFFFFFFF;
	}

	/**
	 * byte[] 转化为64位无符号数据 注：
	 * ToUInt32返回值可以用64位的long标志，但ToUint64的返回值找不到合适的数据类型表示(java中long为最大类型
	 * )，故用Object代替
	 *
	 * @param value
	 * @param index
	 * @return 返回Object型64位无符号数据
	 */
	public static Object toUInt64(byte[] value, int index) throws Exception {
		return toInt64(value, 0) & 0xFFFFFFFF;
	}

	public static Object toUInt64Reverse(byte[] value, int index) throws Exception {
		return toInt64Reverse(value, 0) & 0xFFFFFFFF;
	}

	/**
	 * 不定长数据
	 * byte[]转化为BigInteger
	 * @param value
	 * @return
	 * @author ouxx
	 * @date 2016-11-5 上午11:07:32
	 */
	public static BigInteger toVarLenData(byte[] value) throws Exception {
		return new BigInteger(value);
	}

	/**
	 * 反转不定长数据
	 * byte[]转化为BigInteger
	 * @param value
	 * @return
	 * @author ouxx
	 * @date 2016-11-5 上午11:07:32
	 */
	public static BigInteger toVarLenDataReverse(byte[] value) throws Exception {
		int length = value.length;
		byte[] reverseBytes = new byte[length];
		for(int i = 0; i < length; ++i) {
			reverseBytes[i] = (byte) (value[length - i - 1] & 0xFF);
		}
		return new BigInteger(reverseBytes);
	}



	public static void main(String[] args) throws Exception {
		byte[] b = new byte[]{0x1, 0x2, 0x3, 0x1, 0x2, 0x3
				, 0x1, 0x2, 0x3, 0x1, 0x2, 0x3, 0x1, 0x2, 0x3, 0x1, 0x2, 0x3};

		System.out.println(toVarLenData(b).toString(16));
		System.out.println(toVarLenDataReverse(b).toString(16));

		getVarLenDataBytes(BigInteger.valueOf(0x10203), 8);
	}

	/**
	 * float normal
	 *
	 * @param value
	 * @param index
	 * @return
	 */
	public static float toSingle(byte[] value, int index) throws Exception {
		int intValue = toInt32(value, 0);
		return Float.intBitsToFloat(intValue);
	}

	/**
	 * float swapped
	 *
	 * @param value
	 * @param index
	 * @return
	 */
	public static float toSingleSwapped(byte[] value, int index) throws Exception {
		int intValue = toInt32Swapped(value, 0);
		return Float.intBitsToFloat(intValue);
	}

	/**
	 * float reverse
	 *
	 * @param value
	 * @param index
	 * @return
	 */
	public static float toSingleReverse(byte[] value, int index) throws Exception {
		int intValue = toInt32Reverse(value, 0);
		return Float.intBitsToFloat(intValue);
	}

	/**
	 * double normal
	 *
	 * @param value
	 * @param index
	 * @return
	 */
	public static double toDouble(byte[] value, int index) throws Exception {
		long longValue = toInt64(value, index);
		return Double.longBitsToDouble(longValue);
	}

	/**
	 * double Reverse
	 *
	 * @param value
	 * @param index
	 * @return
	 */
	public static double toDoubleReverse(byte[] value, int index) throws Exception {
		long longValue = toInt64Reverse(value, index);
		return Double.longBitsToDouble(longValue);
	}

	public static String toUTF8String(byte[] value) throws Exception {
		return new String(value, Charset.forName("UTF-8")).trim();
	}

	/**
	 * 把字节数组转换为Unicode编码字符串数组
	 *
	 * @param value
	 * @param index
	 * @return
	 */
	public static String toUnicodeString(byte[] value, int index) throws Exception {
		return new String(value, index, value.length - index, Charset.forName("Unicode")).trim();
	}

	public static String toString(byte[] value, int index, int length) throws Exception {
		return new String(value, index, length);
	}

	/**
	 * 把字节数组转换为ASCII编码字符串数组
	 *
	 * @param value
	 * @param index
	 * @return
	 */
	public static String toASCIIString(byte[] value, int index) throws Exception {
		return new String(value, index, value.length - index, Charset.forName("ASCII")).trim();
	}

	/**
	 * 转换为特定编码的字符串
	 * @param value
	 * @param index
	 * @param charset  特定编码
	 * @return
	 * @author ouxx
	 * @date 2016-11-5 下午3:06:43
	 */
	@SuppressWarnings("unused")
	private static String toCharsetString(byte[] value, int index, String charset) throws Exception {
		return new String(value, index, value.length - index, Charset.forName(charset)).trim();
	}

	/**
	 * 转换为GB2312
	 * @param value
	 * @param index
	 * @return
	 * @author ouxx
	 * @date 2016-11-5 下午3:08:55
	 */
	public static String toGB2312String(byte[] value, int index) throws Exception {
		return new String(value, index, value.length - index, Charset.forName("gb2312")).trim();
	}

	/**
	 * 把BCD码 转换为时间（GF8000）
	 *
	 * @param BCD
	 * @return
	 */
	public static Calendar BCDtoDate(byte[] BCD) throws Exception {
		Calendar cal = Calendar.getInstance();

		cal.set(Calendar.YEAR, BCD2INT(BCD[0]));
		cal.set(Calendar.MONTH, BCD2INT(BCD[1]) - 1);
		cal.set(Calendar.DAY_OF_MONTH, BCD2INT(BCD[2]) - 1);
		cal.set(Calendar.HOUR_OF_DAY, BCD2INT(BCD[3]));
		cal.set(Calendar.MINUTE, BCD2INT(BCD[4]));
		cal.set(Calendar.SECOND, BCD2INT(BCD[5]));

		return cal;
	}

	private static int BCD2INT(byte BCD) throws Exception {
		return ((int) (BCD >> 4) * 10 + (BCD & 0x0F));
	}

	/**
	 * 把字节数组转换成BCD编码的字符 如果是非法BCD码，则返回0；
	 *
	 * @param value
	 */
	public static String toCBCDString(byte[] value) throws Exception {
		return cbcd2String(value);
	}

	/**
	 * 压缩BCD码转换为String
	 *
	 * @param value
	 * @return
	 */
	public static String cbcd2String(byte[] value) throws Exception {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < value.length; i++) {
			int h = ((value[i] & 0xff) >> 4) + 48;
			sb.append((char) h);
			int l = (value[i] & 0x0f) + 48;
			sb.append((char) l);
		}
		return sb.toString().replaceAll("^(0+)", "");// 去掉行首的0
	}

	/**
	 * java 合并两个byte数组
	 *
	 * @param byte_1
	 * @param byte_2
	 * @return 合并后的数组
	 */
	public static byte[] byteMerger(byte[] byte_1, byte[] byte_2) throws Exception {
		if (null == byte_2) {
			return byte_1;
		}

		byte[] byte_3 = null;
		if (null != byte_1) {
			byte_3 = new byte[byte_1.length + byte_2.length];
			System.arraycopy(byte_1, 0, byte_3, 0, byte_1.length);
			System.arraycopy(byte_2, 0, byte_3, byte_1.length, byte_2.length);
		} else {
			return byte_2;
//			byte_3 = new byte[byte_2.length];
//			System.arraycopy(byte_2, 0, byte_3, 0, byte_2.length);
		}

		return byte_3;
	}

	/**
	 * 把任意长度的byte数组转为long
	 * @param value
	 * @return
	 * @throws Exception
	 * @author ouxx
	 * @date 2017-4-28 下午2:50:47
	 */
	public static long toLongByAnyLen(byte[] value) throws Exception {
//		((value[0 + index] & 0xFF) << 0 | (value[1 + index] & 0xFF) << 8 | (value[2 + index] & 0xFF) << 16 | (value[3 + index] & 0xFF) << 24)
		int len = value.length;
		long result = 0;
		for(int i = 0; i < len; ++i){
			result |= (value[i] & 0xFF) << (i * 8);
		}
		return result;
	}


	// /**
	// * 测试用main函数
	// * @param args
	// */
	// public static void main(String[] args) throws Exception {
	//
	// String debugRecordFile = "D:\\testMathConverterHelper.txt";
	// FileOperateHelper.deleteFile(debugRecordFile);
	//
	// String emptyLine = " ";//空行
	//
	// System.out.println("开始测试...");
	// FileOperateHelper.writeToFileWithoutTimestamp("开始测试...",
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp(emptyLine,
	// debugRecordFile);//空一行
	//
	//
	// String strParam, strResult;//十六进制字符串
	//
	// //ToChar
	// FileOperateHelper.writeToFileWithoutTimestamp("---------ToChar",
	// debugRecordFile);
	//
	// char param1 = 0x1234;
	// char result1 = toChar(getBytes(param1), 0);
	//
	// strParam = Integer.toHexString(param1);
	// strResult = Integer.toHexString(result1);
	// FileOperateHelper.writeToFileWithoutTimestamp("输入：" + "0x" + strParam,
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp("输出：" + "0x" + strResult,
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp((strResult.equals(strParam))
	// ? "success" : "failure", debugRecordFile);
	//
	// FileOperateHelper.writeToFileWithoutTimestamp("---------ToChar",
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp(emptyLine,
	// debugRecordFile);//空一行
	//
	// //ToCharReverse
	// FileOperateHelper.writeToFileWithoutTimestamp("---------ToCharReverse",
	// debugRecordFile);
	//
	// char param2 = 0x1234;
	// char result2 = toCharReverse(getBytes(param2), 0);
	//
	// strParam = Integer.toHexString(param2);
	// strResult = Integer.toHexString(result2);
	// FileOperateHelper.writeToFileWithoutTimestamp("输入：" + "0x" + strParam,
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp("输出：" + "0x" + strResult,
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp(strResult.equals("3412") ?
	// "success" : "failure", debugRecordFile);
	//
	// FileOperateHelper.writeToFileWithoutTimestamp("---------ToCharReverse",
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp(emptyLine,
	// debugRecordFile);//空一行
	//
	// //ToInt16
	// FileOperateHelper.writeToFileWithoutTimestamp("---------ToInt16",
	// debugRecordFile);
	//
	// short param3 = 0x1234;
	// short result3 = toInt16(getBytes(param3), 0);
	//
	// strParam = Integer.toHexString(param3);
	// strResult = Integer.toHexString(result3);
	// FileOperateHelper.writeToFileWithoutTimestamp("输入：" + "0x" + strParam,
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp("输出：" + "0x" + strResult,
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp(strResult.equals("1234") ?
	// "success" : "failure", debugRecordFile);
	//
	// FileOperateHelper.writeToFileWithoutTimestamp("---------ToInt16",
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp(emptyLine,
	// debugRecordFile);//空一行
	//
	// //ToInt16Reverse
	// FileOperateHelper.writeToFileWithoutTimestamp("---------ToInt16Reverse",
	// debugRecordFile);
	//
	// short param4 = 0x1234;
	// short result4 = toInt16Reverse(getBytes(param4), 0);
	//
	// strParam = Integer.toHexString(param4);
	// strResult = Integer.toHexString(result4);
	// FileOperateHelper.writeToFileWithoutTimestamp("输入：" + "0x" + strParam,
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp("输出：" + "0x" + strResult,
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp(strResult.equals("3412") ?
	// "success" : "failure", debugRecordFile);
	//
	// FileOperateHelper.writeToFileWithoutTimestamp("---------ToInt16Reverse",
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp(emptyLine,
	// debugRecordFile);//空一行
	//
	// //ToInt32
	// FileOperateHelper.writeToFileWithoutTimestamp("---------ToInt32",
	// debugRecordFile);
	//
	// int param5 = 0x12345678;
	// int result5 = toInt32(getBytes(param5), 0);
	//
	// strParam = Integer.toHexString(param5);
	// strResult = Integer.toHexString(result5);
	// FileOperateHelper.writeToFileWithoutTimestamp("输入：" + "0x" + strParam,
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp("输出：" + "0x" + strResult,
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp(strResult.equals("12345678")
	// ? "success" : "failure", debugRecordFile);
	//
	// FileOperateHelper.writeToFileWithoutTimestamp("---------ToInt32",
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp(emptyLine,
	// debugRecordFile);//空一行
	//
	// //ToInt32Swapped
	// FileOperateHelper.writeToFileWithoutTimestamp("---------ToInt32Swapped",
	// debugRecordFile);
	//
	// int param6 = 0x12345678;
	// int result6 = toInt32Swapped(getBytes(param6), 0);
	//
	// strParam = Integer.toHexString(param6);
	// strResult = Integer.toHexString(result6);
	// FileOperateHelper.writeToFileWithoutTimestamp("输入：" + "0x" + strParam,
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp("输出：" + "0x" + strResult,
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp(strResult.equals("56781234")
	// ? "success" : "failure", debugRecordFile);
	//
	// FileOperateHelper.writeToFileWithoutTimestamp("---------ToInt32Swapped",
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp(emptyLine,
	// debugRecordFile);//空一行
	//
	// //ToInt32ReverseByte
	// FileOperateHelper.writeToFileWithoutTimestamp("---------ToInt32ReverseByte",
	// debugRecordFile);
	//
	// int param7 = 0x12345678;
	// int result7 = toInt32ReverseByte(getBytes(param7), 0);
	//
	// strParam = Integer.toHexString(param7);
	// strResult = Integer.toHexString(result7);
	// FileOperateHelper.writeToFileWithoutTimestamp("输入：" + "0x" + strParam,
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp("输出：" + "0x" + strResult,
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp(strResult.equals("34127856")
	// ? "success" : "failure", debugRecordFile);
	//
	// FileOperateHelper.writeToFileWithoutTimestamp("---------ToInt32ReverseByte",
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp(emptyLine,
	// debugRecordFile);//空一行
	//
	// //ToInt32Reverse
	// FileOperateHelper.writeToFileWithoutTimestamp("---------ToInt32Reverse",
	// debugRecordFile);
	//
	// int param8 = 0x12345678;
	// int result8 = toInt32Reverse(getBytes(param8), 0);
	//
	// strParam = Integer.toHexString(param8);
	// strResult = Integer.toHexString(result8);
	// FileOperateHelper.writeToFileWithoutTimestamp("输入：" + "0x" + strParam,
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp("输出：" + "0x" + strResult,
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp(strResult.equals("78563412")
	// ? "success" : "failure", debugRecordFile);
	//
	// FileOperateHelper.writeToFileWithoutTimestamp("---------ToInt32Reverse",
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp(emptyLine,
	// debugRecordFile);//空一行
	//
	// //ToInt64(byte[], int)
	// FileOperateHelper.writeToFileWithoutTimestamp("---------ToInt64(byte[], int)",
	// debugRecordFile);
	//
	// long param9 = 0xf1020304050607f8L;
	// long result9 = toInt64(getBytes(param9), 0);
	//
	// strParam = Long.toHexString(param9);
	// strResult = Long.toHexString(result9);
	// FileOperateHelper.writeToFileWithoutTimestamp("输入：" + "0x" + strParam,
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp("输出：" + "0x" + strResult,
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp(strResult.equals("f1020304050607f8")
	// ? "success" : "failure", debugRecordFile);
	//
	// FileOperateHelper.writeToFileWithoutTimestamp("---------ToInt64(byte[], int)",
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp(emptyLine,
	// debugRecordFile);//空一行
	//
	// //ToInt64Reverse(byte[], int)
	// FileOperateHelper.writeToFileWithoutTimestamp("---------ToInt64Reverse(byte[], int)",
	// debugRecordFile);
	//
	// long param10 = 0xf1020304050607f8L;
	// long result10 = toInt64Reverse(getBytes(param10), 0);
	//
	// strParam = Long.toHexString(param10);
	// strResult = Long.toHexString(result10);
	// FileOperateHelper.writeToFileWithoutTimestamp("输入：" + "0x" + strParam,
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp("输出：" + "0x" + strResult,
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp(strResult.equals("f8070605040302f1")
	// ? "success" : "failure", debugRecordFile);
	//
	// FileOperateHelper.writeToFileWithoutTimestamp("---------ToInt64Reverse(byte[], int)",
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp(emptyLine,
	// debugRecordFile);//空一行
	//
	// //ToSingle(byte[], int)
	// FileOperateHelper.writeToFileWithoutTimestamp("---------toSingle(byte[], int)",
	// debugRecordFile);
	//
	// float param11 = 1.23456f;
	// float result11 = toSingle(getBytes(param11), 0);
	//
	// FileOperateHelper.writeToFileWithoutTimestamp("输入：" + param11,
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp("输出：" + result11,
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp((result11 == param11) ?
	// "success" : "failure", debugRecordFile);
	//
	// FileOperateHelper.writeToFileWithoutTimestamp("---------toSingle(byte[], int)",
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp(emptyLine,
	// debugRecordFile);//空一行
	//
	// //toSingleSwapped(byte[], int)
	// FileOperateHelper.writeToFileWithoutTimestamp("---------toSingleSwapped(byte[], int)",
	// debugRecordFile);
	//
	// float param111 = 1.23456f;
	// float result111 = toSingleSwapped(getBytes(param111), 0);
	// result111 = toSingleSwapped(getBytes(result111), 0);
	//
	// FileOperateHelper.writeToFileWithoutTimestamp("输入：" + param111,
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp("输出：" + result111,
	// debugRecordFile);
	//
	//
	// FileOperateHelper.writeToFileWithoutTimestamp((result111 == param111) ?
	// "success" : "failure", debugRecordFile);
	// //由于Swapped了两次，故结果应与输入相等
	// FileOperateHelper.writeToFileWithoutTimestamp("---------toSingleSwapped(byte[], int)",
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp(emptyLine,
	// debugRecordFile);//空一行
	//
	// //toSingleReverse(byte[], int)
	// FileOperateHelper.writeToFileWithoutTimestamp("---------toSingleReverse(byte[], int)",
	// debugRecordFile);
	//
	// float param1111 = 1.23456f;
	// float result1111 = toSingleReverse(getBytes(param1111), 0);
	// result1111 = toSingleReverse(getBytes(result1111), 0);
	//
	// FileOperateHelper.writeToFileWithoutTimestamp("输入：" + param1111,
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp("翻转两次后输出：" + result1111,
	// debugRecordFile);
	// //由于Reverse了两次，故结果应与输入相等
	// FileOperateHelper.writeToFileWithoutTimestamp((result1111 == param1111) ?
	// "success" : "failure", debugRecordFile);
	//
	// FileOperateHelper.writeToFileWithoutTimestamp("---------toSingleReverse(byte[], int)",
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp(emptyLine,
	// debugRecordFile);//空一行
	//
	// //toDouble(byte[], int)
	// FileOperateHelper.writeToFileWithoutTimestamp("---------toDouble(byte[], int)",
	// debugRecordFile);
	//
	// double param12 = 2.34567;
	// double result12 = toDouble(getBytes(param12), 0);
	//
	// FileOperateHelper.writeToFileWithoutTimestamp("输入：" + param12,
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp("输出：" + result12,
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp((result12 == param12) ?
	// "success" : "failure", debugRecordFile);
	//
	// FileOperateHelper.writeToFileWithoutTimestamp("---------toDouble(byte[], int)",
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp(emptyLine,
	// debugRecordFile);//空一行
	//
	// //toASCIIString(byte[], int)
	// FileOperateHelper.writeToFileWithoutTimestamp("---------toASCIIString(byte[], int)",
	// debugRecordFile);
	//
	// String param13 = "ascii test";
	// String result13 = toASCIIString(getBytes(param13, "ASCII"), 0);
	//
	// FileOperateHelper.writeToFileWithoutTimestamp("输入：" + param13,
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp("输出：" + result13,
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp(result13.equals(param13) ?
	// "success" : "failure", debugRecordFile);
	//
	// FileOperateHelper.writeToFileWithoutTimestamp("---------toASCIIString(byte[], int)",
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp(emptyLine,
	// debugRecordFile);//空一行
	//
	// //toUnicodeString(byte[], int)
	// FileOperateHelper.writeToFileWithoutTimestamp("---------toUnicodeString(byte[], int)",
	// debugRecordFile);
	//
	// String param14 = "unicode test";
	// String result14 = toUnicodeString(getBytes(param14, "Unicode"), 0);
	//
	// FileOperateHelper.writeToFileWithoutTimestamp("输入：" + param14,
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp("输出：" + result14,
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp(result14.equals(param14) ?
	// "success" : "failure", debugRecordFile);
	//
	// FileOperateHelper.writeToFileWithoutTimestamp("---------toUnicodeString(byte[], int)",
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp(emptyLine,
	// debugRecordFile);//空一行
	//
	//
	// //toBCD16String(byte[], int)
	// FileOperateHelper.writeToFileWithoutTimestamp("---------toBCD16String(byte[], int)",
	// debugRecordFile);
	//
	// String param15 = "12345678";
	// String result15 = toCBCDString(getBytes(param15, "CBCD"));
	//
	// FileOperateHelper.writeToFileWithoutTimestamp("输入：" + param15,
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp("输出：" + result15,
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp(result15.equals(param15) ?
	// "success" : "failure", debugRecordFile);
	//
	// FileOperateHelper.writeToFileWithoutTimestamp("---------toBCD16String(byte[], int)",
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp(emptyLine,
	// debugRecordFile);//空一行
	//
	// //toUTF8String(byte[], int)
	// FileOperateHelper.writeToFileWithoutTimestamp("---------toUTF8String(byte[], int)",
	// debugRecordFile);
	//
	// String param16 = "12345678";
	// String result16 = toUTF8String(getBytes(param16, "UTF8"));
	//
	// FileOperateHelper.writeToFileWithoutTimestamp("输入：" + param16,
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp("输出：" + result16,
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp(result16.equals(param16) ?
	// "success" : "failure", debugRecordFile);
	//
	// FileOperateHelper.writeToFileWithoutTimestamp("---------toUTF8String(byte[], int)",
	// debugRecordFile);
	// FileOperateHelper.writeToFileWithoutTimestamp(emptyLine,
	// debugRecordFile);//空一行
	//
	// FileOperateHelper.writeToFileWithoutTimestamp("测试结束！",
	// debugRecordFile);//空一行
	//
	// System.out.println("测试结束!");
	// }
}
