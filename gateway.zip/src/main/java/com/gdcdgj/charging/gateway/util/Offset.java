/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.util;

/**
 * 偏移量
 * @author ouxx
 * @since 2016-11-2 上午11:09:52
 *
 */
public enum Offset {

	BCP_CURR_LIMIT(-400),//BCP 最高允许充电电流
//	Voltage(0),//电压
//	Current(0),//电流
//	SingleVol(0),//单体电池电压
//	Quantity(0),//容量/电量
//	Soc(0),//电池SOC
	Temperature(-50);//温度
//	Kwh(0),//电度
//	Power(0);//功率

	private int offset;
	private Offset(int offset){
		this.offset = offset;
	}
	public int getValue(){
		return this.offset;
	}
}
