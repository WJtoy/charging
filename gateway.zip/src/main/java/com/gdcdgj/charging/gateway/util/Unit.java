/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.util;

/**
 * 单位
 * @author ouxx
 * @since 2016-11-2 上午11:12:04
 *
 */
public enum Unit {

	Voltage("V"),//电压
	Current("A"),//电流
	SingleVol("V"),//单体电池电压
	Quantity("AH"),//容量/电量
	Soc("%"),//电池SOC
	Temperature("℃"),//温度
	Kwh("kwh"),//电度
	Power("kw");//功率

	private String unit;
	private Unit(String unit){
		this.unit = unit;
	}
	public String getValue(){
		return this.unit;
	}
}
