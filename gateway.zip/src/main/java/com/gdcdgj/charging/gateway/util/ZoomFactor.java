/*
 * Copyright 2015 guobang zaixian science technology CO., LTD. All rights reserved.
 * distributed with this file and available online at
 * http://www.gob123.com/
 */
package com.gdcdgj.charging.gateway.util;

/**
 * 缩放因子
 * @author ouxx
 * @since 2016-11-2 上午11:10:44
 *
 */
public enum ZoomFactor {
	BRM_AH(0.1),//BRM报文中,动力电池额定容量
	BCP_BATTERY_CELL_VOL_LIMIT(0.01),//BCP 单体动力电池最高允许充电电压
	BCP_TOTAL_KWH(0.1),//动力蓄电池标称总能量
	BCP_SOC(0.1),//整车动力蓄电池荷电状态

	NoZoom(1.0), //不缩放

	Voltage(0.1),//电压
	Current(0.1),//电流
	SingleVol(0.01),//单体电池电压
	Quantity(1.0),//容量/电量
	Soc(1.0),//电池SOC
	Temperature(1.0),//温度
	Kwh(0.01),//电度
	Power(0.1);//功率



	private double factor;
	private ZoomFactor(double factor){
		this.factor = factor;
	}
	public double getValue(){
		return this.factor;
	}
}
