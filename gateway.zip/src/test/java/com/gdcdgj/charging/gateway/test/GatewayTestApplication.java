package com.gdcdgj.charging.gateway.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author Changliang Tao
 * @date 2020/4/17 10:10
 * @since JDK 1.8
 */
@SpringBootApplication
public class GatewayTestApplication{

    public static void main(String[] args) {
        SpringApplication.run(GatewayTestApplication.class, args);
    }
}
