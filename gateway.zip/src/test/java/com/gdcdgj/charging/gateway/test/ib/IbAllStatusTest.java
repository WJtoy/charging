package com.gdcdgj.charging.gateway.test.ib;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.gdcdgj.charging.api.constant.RabbitmqConstant;
import com.gdcdgj.charging.api.vo.srv2gw.StateInfo;
import com.gdcdgj.charging.gateway.platform.ib.execute.receive.RecPileAllStatusResponseCmd;
import com.gdcdgj.charging.gateway.platform.ib.execute.send.SendPileAllStatusQueryCmd;
import com.gdcdgj.charging.gateway.test.GatewayTestApplication;

import lombok.extern.slf4j.Slf4j;

/**
 * 宜步状态信息包处理测试 cmd = 0x21
 * 
 * @author ydc
 * @since 2020 05/25 下午
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {GatewayTestApplication.class})
@Slf4j
public class IbAllStatusTest {
	
	@Autowired
	AmqpTemplate amqpTemplate;
	
	@Test
	public void stateInfoCmdHandle() throws Exception {
		//总状态信息包
		byte[] fullData = new byte[] {0x59,0x43,0x10,0x32,0x31,0x00,0x00,0x00,0x00,0x00,0x00,0x01,0x15,0x15,0x02,0x04,0x00,0x00,(byte) 0xff,(byte) 0xff,0x04,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x01,(byte) 0xff,(byte) 0xff,(byte) 0xff,(byte) 0xff,0x02,0x02,0x07,(byte) 0x95};
		log.info("充电桩上报总状态信息包");
		log.info("棱 ：{}",fullData.length-7);
		RecPileAllStatusResponseCmd recPileAllStatusResponseCmd = new RecPileAllStatusResponseCmd();
		StateInfo stateInfo = (StateInfo) recPileAllStatusResponseCmd.receiveCmdExecute(fullData);
//		StateInfo stateInfo = new StateInfo();
//		stateInfo.setACChargeElectric(0);
//		stateInfo.setProviderId(0);
//        stateInfo.setWorkState((byte) 2);
//        stateInfo.setChargeTime(1000);
//        stateInfo.setChargePowerCount(10.0);
//        stateInfo.setCurrentSOC((byte) 97);
//        stateInfo.setCurrentQuliety(366.0);
//        stateInfo.setDCChargeElectric(100.0);
//        stateInfo.setDCChargePressure(100.0);
//        stateInfo.setResidueChargeTime(6);
//        stateInfo.setChargePower(1.1);
//        stateInfo.setConnectorCount((byte) 2);
		SendPileAllStatusQueryCmd allStatusQueryCmd = new SendPileAllStatusQueryCmd();
		byte[] datas = allStatusQueryCmd.sendCmdExecute(stateInfo);
		//ChannelSender.send(ctx.channel(), datas);
		//stateInfo.setPileCode(H2TServer.channelPileMap.get(ctx.channel()));
		log.info("充电桩上报总状态信息包完成 :{}",datas);
	}
}
