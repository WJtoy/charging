package com.gdcdgj.charging.gateway.test.ib;

import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.gdcdgj.charging.api.constant.RabbitmqConstant;
import com.gdcdgj.charging.api.vo.srv2gw.ChargeRecordInfo;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.ModuleChargingInfo;
import com.gdcdgj.charging.api.vo.srv2gw.PileCtrl;
import com.gdcdgj.charging.api.vo.srv2gw.PileStartedRst;
import com.gdcdgj.charging.api.vo.srv2gw.SignIn;
import com.gdcdgj.charging.api.vo.srv2gw.StateInfo;
import com.gdcdgj.charging.api.vo.srv2gw.TimeSyn;
import com.gdcdgj.charging.gateway.platform.ib.execute.receive.RecChargingRecordReportCmd;
import com.gdcdgj.charging.gateway.platform.ib.execute.receive.RecHeartbeatCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.execute.receive.RecModuleInfoResponseCmd;
import com.gdcdgj.charging.gateway.platform.ib.execute.receive.RecPileAllStatusResponseCmd;
import com.gdcdgj.charging.gateway.platform.ib.execute.receive.RecPileCtrlResponseCmd;
import com.gdcdgj.charging.gateway.platform.ib.execute.receive.RecSignInCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.execute.send.SendChargingRecordResponseCmd;
import com.gdcdgj.charging.gateway.platform.ib.execute.send.SendHeartbeatCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.execute.send.SendPileAllStatusQueryCmd;
import com.gdcdgj.charging.gateway.platform.ib.execute.send.SendSignInCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.execute.send.SendTimeSynCmd;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbProtocolUtil;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecSignInResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendSignInResponseCmd;
import com.gdcdgj.charging.gateway.server.handler.ChannelSender;
import com.gdcdgj.charging.gateway.server.handler.H2TServer;
import com.gdcdgj.charging.gateway.test.GatewayTestApplication;
import com.rabbitmq.client.AMQP;

import lombok.extern.slf4j.Slf4j;

/**
 * 宜步充电桩上报充电记录处理测试 cmd = 0x78
 * 
 * @author ydc
 * @since 2020 05/25 下午
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {GatewayTestApplication.class})
@Slf4j
public class IbChargeRecordInfoTest {
	
	@Autowired
	AmqpTemplate amqpTemplate;
	
	@Test
	public void chargeRecordInfoCmdHandle() throws Exception {
		
//		//充电记录信息测试
//		byte[] fullData = new byte[] {89,67,(byte) 140,16,(byte) 209,120,19,0,0,0,2
//				,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
//				,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,105,98,95,116,106,121,121,
//				49,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,32,32,32,32,32,
//				32,32,32,0,0,0,0,0,0,84,0,0,0,4,0,0,2,(byte) 228,7,5,28,18,58,2,(byte)
//				255,(byte) 228,7,5,28,18,59,26,(byte) 255,(byte) 228,7,5,28,18,59,33,
//				(byte) 255,(byte) 247,58,27,0,(byte) 247,58,27,0,31};
		byte[] fulldata = new byte[] {89,67,(byte) 0x8c,16,(byte) 217,120,19,0,0,0,2,
				0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
				,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,105,98,95,116,106,121,121,49
				,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,32,32,32,32,32,
				32,32,32,0,0,0,0,0,0,84,0,0,0,4,0,0,2,(byte) 228,7,5,28,18,58,2,
				(byte) 255,(byte) 228,7,5,28,18,59,26,(byte) 255,(byte) 228,7,5,28,
				19,0,36,(byte) 255,(byte) 247,58,27,0,(byte) 247,58,27,0,(byte) 232,95,95};
		IbProtocolUtil.verifyRecData(fulldata);
		
		log.info("充电桩上报充电记录命令(0x78)");
		RecChargingRecordReportCmd cmd = new RecChargingRecordReportCmd();
//		ChargeRecordInfo chargeRecordInfo = new ChargeRecordInfo();
//		chargeRecordInfo.setMemberId(0);
//		chargeRecordInfo.setCmdSeq(222);
//		chargeRecordInfo.setConnectorNo(1);
//		chargeRecordInfo.setLocationType(1);
//		chargeRecordInfo.setChargeNo("123321");
//		chargeRecordInfo.setSerialNum("12345678");
//		chargeRecordInfo.setPileCode("ib_tjyy3");
//		chargeRecordInfo.setCarVIN("0");
//		chargeRecordInfo.setCarLpn("0");
//		chargeRecordInfo.setStartSOC(0);
//		chargeRecordInfo.setStopSOC(100);
//		chargeRecordInfo.setCurrentChargeCount(100.0);
//		chargeRecordInfo.setChargeTimeLen(50000);
//		chargeRecordInfo.setChargePolicy(4);
//		chargeRecordInfo.setChargePolicyParam(0);
//		chargeRecordInfo.setChargeStopCause(1);
//		Calendar cal = Calendar.getInstance();
//		chargeRecordInfo.setStartChargeTime(cal);
//		chargeRecordInfo.setStopChargeTime(cal);
//		chargeRecordInfo.setTradeDate(cal);
//		chargeRecordInfo.setBeforeAmmeterNum(1234.0);
//		chargeRecordInfo.setAfterAmmeterNum(1233.0);
		ChargeRecordInfo chargeRecordInfo = (ChargeRecordInfo) cmd.receiveCmdExecute(fulldata);
		SendChargingRecordResponseCmd sendCmd = new SendChargingRecordResponseCmd();
		byte[] datas = sendCmd.sendCmdExecute(chargeRecordInfo);
		//ChannelSender.send(ctx.channel(), datas);
		amqpTemplate.convertAndSend(RabbitmqConstant.CHARGEINFO_STATUS_EXCHANGE, RabbitmqConstant.CHARGEINFO_STATUS_ROUTING_KEY, chargeRecordInfo);
		log.info("发送充电记录到MQ body :{}",chargeRecordInfo);
		log.info("充电桩上报充电记录命令应答完成 :{}",datas);
	}
}
