package com.gdcdgj.charging.gateway.test.ib;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.gdcdgj.charging.api.constant.RabbitmqConstant;
import com.gdcdgj.charging.api.vo.srv2gw.CommunicationMode;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.StateInfo;
import com.gdcdgj.charging.gateway.platform.ib.execute.receive.RecCommunicationModeResponseCmd;
import com.gdcdgj.charging.gateway.platform.ib.execute.receive.RecPileAllStatusResponseCmd;
import com.gdcdgj.charging.gateway.platform.ib.execute.send.SendCommunicationModeCmd;
import com.gdcdgj.charging.gateway.platform.ib.execute.send.SendPileAllStatusQueryCmd;
import com.gdcdgj.charging.gateway.test.GatewayTestApplication;

import lombok.extern.slf4j.Slf4j;

/**
 * 宜步状态信息包处理测试 cmd = 0x21
 * 
 * @author ydc
 * @since 2020 05/25 下午
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {GatewayTestApplication.class})
@Slf4j
public class IbCommunatyTest {
	
	@Autowired
	AmqpTemplate amqpTemplate;
	
	@Test
	public void stateInfoCmdHandle() throws Exception {
		//总状态信息包
		byte[] fullData = new byte[] {0x59,0x43,0x0b,0x10,0x05,0x57,0x00,0x00,0x00,0x00,0x00,0x00,0x02,0x0f,0x07};
		log.info("棱 ：{}",fullData.length-7);
		RecCommunicationModeResponseCmd cmd = new RecCommunicationModeResponseCmd();
		CommunicationMode receiveCmdExecute = (CommunicationMode) cmd.receiveCmdExecute(fullData);
		
		SendCommunicationModeCmd cmd2 = new SendCommunicationModeCmd();
		byte[] sendCmdExecute = cmd2.sendCmdExecute(receiveCmdExecute);
		log.info("间隔发送 ：{}",sendCmdExecute);
		log.info("充电桩上报总状态信息包完成  设置间隔:{}",receiveCmdExecute.getReportInterval());
		
	}
}
