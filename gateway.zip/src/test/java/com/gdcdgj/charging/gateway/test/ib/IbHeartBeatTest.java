package com.gdcdgj.charging.gateway.test.ib;


import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.gateway.platform.ib.execute.receive.RecHeartbeatCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.execute.send.SendHeartbeatCmdExecute;
import com.gdcdgj.charging.gateway.test.GatewayTestApplication;

import lombok.extern.slf4j.Slf4j;

/**
 * 宜步心跳处理测试 cmd = 0x58
 * 
 * @author ydc
 * @since 2020 05/25 下午
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {GatewayTestApplication.class})
@Slf4j
public class IbHeartBeatTest {
	
	@Test
	public void heartbeatCmdHandle() throws Exception {
		byte[] fullData = new byte[] {0x59,0x43,0x0b,0x10,0x02,0x58,0x00,0x00,(byte) 0xde,
				0x00,0x01,0x00,(byte) 0x85,0x00,(byte) 0xbc};
		log.info("心跳包上报(0x58)");
		// 接收报文后执行
		RecHeartbeatCmdExecute recHeartbeatCmdExecute = new RecHeartbeatCmdExecute();
		DataBaseVo dataBaseVo = recHeartbeatCmdExecute.receiveCmdExecute(fullData);
		// 心跳包应答
		SendHeartbeatCmdExecute sendHeartbeatCmdExecute = new SendHeartbeatCmdExecute();
		byte[] bytes = sendHeartbeatCmdExecute.sendCmdExecute(dataBaseVo);
		// 后台返回应答
		//ChannelSender.send(ctx.channel(),bytes);
		log.info("心跳包上报应答完成\n :{}",bytes);
	}
}
