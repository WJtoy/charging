package com.gdcdgj.charging.gateway.test.ib;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.gdcdgj.charging.api.constant.RabbitmqConstant;
import com.gdcdgj.charging.api.vo.srv2gw.ModuleChargingInfo;
import com.gdcdgj.charging.gateway.platform.ib.execute.receive.RecModuleInfoResponseCmd;
import com.gdcdgj.charging.gateway.test.GatewayTestApplication;

import lombok.extern.slf4j.Slf4j;

/**
 * 宜步充电模块充电信息处理测试 cmd = 0x33
 * 
 * @author ydc
 * @since 2020 05/25 下午
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {GatewayTestApplication.class})
@Slf4j
public class IbMoudleInfoTest {
	
	@Autowired
	AmqpTemplate amqpTemplate;
	
	@Test
	public void moduleInfoCmdHandle() throws Exception {
		byte[] fullData = new byte[] {0x59,0x43,0x38,0x10,0x03,0x33,0x00,0x00,(byte) 0xde,
				0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x02,0x02,0x00,0x00,0x00,0x00,0x00,
				0x00,0x00,0x00,0x00,0x30,0x32,0x07,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
				0x01,0x02,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,(byte) 0xca,0x33
				,0x08,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,(byte) 0x86};
		log.info("当前充电模块充电信息查询应答(0x33)");
    	RecModuleInfoResponseCmd recModuleInfoResponseCmd = new RecModuleInfoResponseCmd();
    	ModuleChargingInfo moduleChargingInfo = (ModuleChargingInfo) recModuleInfoResponseCmd.receiveCmdExecute(fullData);
    	//moduleChargingInfo.setPileCode(H2TServer.channelPileMap.get(ctx.channel()));
    	amqpTemplate.convertAndSend(RabbitmqConstant.MOUDLEINFO_STATUS_EXCHANGE, RabbitmqConstant.MOUDLEINFO_STATUS_ROUTING_KEY, moduleChargingInfo);
        log.info("发送当前充电模块信息到后台 body :{}",moduleChargingInfo);
    	log.info("当前充电模块充电信息查询应答处理完成(0x33) 查询结果 : {}\n" , moduleChargingInfo);
	}
}
