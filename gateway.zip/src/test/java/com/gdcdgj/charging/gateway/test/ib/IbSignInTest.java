package com.gdcdgj.charging.gateway.test.ib;

import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.gdcdgj.charging.api.constant.RabbitmqConstant;
import com.gdcdgj.charging.api.vo.srv2gw.SignIn;
import com.gdcdgj.charging.api.vo.srv2gw.TimeSyn;
import com.gdcdgj.charging.gateway.platform.ib.execute.receive.RecSignInCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.execute.send.SendSignInCmdExecute;
import com.gdcdgj.charging.gateway.platform.ib.execute.send.SendTimeSynCmd;
import com.gdcdgj.charging.gateway.platform.ib.protocol.IbProtocolUtil;
import com.gdcdgj.charging.gateway.test.GatewayTestApplication;

import lombok.extern.slf4j.Slf4j;

/**
 * 宜步签到处理测试 cmd = 0x10
 * 
 * @author ydc
 * @since 2020 05/25 下午
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {GatewayTestApplication.class})
@Slf4j
public class IbSignInTest {
	
	@Autowired
	private AmqpTemplate amqpTemplate;
	
	@Test
	public void signInCmdHandle() throws Exception {
		byte[] fullData = new byte[] {0x59,0x43,0x45,0x10,0x00,0x10,0x00,0x00,(byte) 0xde,
				0x00,0x01,0x00,0x69,0x62,0x5f,0x74,0x6a,0x79,0x79,0x33,0x53,0x54,0x4d,
				0x33,0x32,0x46,0x32,0x30,0x37,(byte) 0xbd,(byte) 0xbb,(byte) 0xc1,
				(byte) 0xf7,(byte) 0xb3,(byte) 0xe4,(byte) 0xb5,(byte) 0xe7,(byte) 0xd7
				,(byte) 0xae,(byte) 0xb5,(byte) 0xb4,0x00,0x00,0x00,0x59,0x00,0x00,0x00
				,0x03,0x00,0x00,0x00,(byte) 0xef,0x07,0x00,0x00,(byte) 0xe4,0x07,0x04,
				0x18,0x10,0x2b,0x36,(byte) 0xff,(byte) 0xe4,0x07,0x04,0x18,0x11,0x0e,
				0x15,(byte) 0xff,(byte) 0xa8};
		log.info("中心系统查询签到应答");
		IbProtocolUtil.verifyRecData(fullData);
        // 获取到设备上报签到信息,解析出设备编码equipmentCode
    	RecSignInCmdExecute recSignInCmdExecute = new RecSignInCmdExecute();
    	SignIn signIn = (SignIn) recSignInCmdExecute.receiveCmdExecute(fullData);
        // 存储equipmentCode、channel，以便推送
        String tmpCode = signIn.getPileCode();
        log.info("保存equipmentCode========{}", tmpCode);
        SendSignInCmdExecute sign = new SendSignInCmdExecute();
        byte[] bytes = sign.sendCmdExecute(signIn);
        //ChannelSender.send(ctx.channel(),bytes);
        //如果之前桩断连或故障，现在连上了，则激活充电桩，把桩编码为equipmentCode的桩下的所有枪的状态改为空闲
        amqpTemplate.convertAndSend(RabbitmqConstant.SIGN_IN_PILE_EXCHANGE, RabbitmqConstant.SIGN_IN_PILE_ROUTING_KEY, signIn);
        log.info("签到应答发送MQ body :{}",signIn);
        log.info("中心系统查询签到应答完成\n :{}",bytes);
        //更新桩程序的版本号
        log.info("签到完成后同步系统时间");
        SendTimeSynCmd recTimeSynRespCmd = new SendTimeSynCmd();
        TimeSyn timeSyns = new TimeSyn();
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        timeSyns.setClock(cal);
        byte[] timeSyn = recTimeSynRespCmd.sendCmdExecute(timeSyns);
        //ChannelSender.send(ctx.channel(),timeSyn);
        log.info("签到完成后同步时间处理完成\n :{}",timeSyn);
	}
}
