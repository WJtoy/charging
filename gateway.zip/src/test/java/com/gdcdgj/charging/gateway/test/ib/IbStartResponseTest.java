package com.gdcdgj.charging.gateway.test.ib;


import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.gdcdgj.charging.api.constant.RabbitmqConstant;
import com.gdcdgj.charging.api.vo.srv2gw.PileCtrl;
import com.gdcdgj.charging.api.vo.srv2gw.PileStartedRst;
import com.gdcdgj.charging.gateway.platform.ib.execute.receive.RecPileCtrlResponseCmd;
import com.gdcdgj.charging.gateway.test.GatewayTestApplication;

import lombok.extern.slf4j.Slf4j;

/**
 * 宜步启动-停止应答处理测试 cmd = 0x65
 * 
 * @author ydc
 * @since 2020 05/25 下午
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {GatewayTestApplication.class})
@Slf4j
public class IbStartResponseTest {
	
	@Autowired
	AmqpTemplate amqpTemplate;
	
	@Test
	public void startCmdHandle() throws Exception {
		byte[] fullData = new byte[] {0x59,0x43,0x11,0x10,0x16,0x65,0x00,0x00,(byte) 0xde,
				0x00,0x01,0x00,0x02,0x02,0x01,0x01,0x00,0x02,0x00,0x00,0x4c};
		log.info("启动-停止应答(0x65)");
		RecPileCtrlResponseCmd recPileCtrlResponseCmd = new RecPileCtrlResponseCmd();
		PileCtrl pileCtrl = (PileCtrl) recPileCtrlResponseCmd.receiveCmdExecute(fullData);
		log.info("启动-停止应答完成(0x65) 启停结果：{}\n" , pileCtrl.getParamType() == 2 ? "成功" : "失败");
		//下发启动结果到mQ
        PileStartedRst pileStartedRst = new PileStartedRst();
        pileStartedRst.setProviderId(1);
        pileStartedRst.setConnectorNo(pileCtrl.getConnectorNo());
        pileStartedRst.setPileCode(pileCtrl.getPileCode());
        int res = (pileCtrl.getValueMap().get((byte)1)==1 || pileCtrl.getValueMap().get((byte)2)==1) ? 1 : 2;
        pileStartedRst.setResult(res);
        amqpTemplate.convertAndSend(RabbitmqConstant.STARTED_STATUS_EXCHANGE, RabbitmqConstant.STARTED_STATUS_ROUTING_KEY, pileStartedRst);
        log.info("桩应答后 下发启动结果到mQ body :{}",pileStartedRst);
	}
}
