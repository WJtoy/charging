package com.gdcdgj.charging.gateway.test.ib;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.gdcdgj.charging.api.constant.RabbitmqConstant;
import com.gdcdgj.charging.api.vo.srv2gw.PileStartedRst;
import com.gdcdgj.charging.gateway.platform.ib.execute.receive.RecPileStartedRstReportCmd;
import com.gdcdgj.charging.gateway.platform.ib.execute.send.SendPileStartedRstRespCmd;
import com.gdcdgj.charging.gateway.test.GatewayTestApplication;

import lombok.extern.slf4j.Slf4j;

/**
 * 宜步启动结果应答处理测试 cmd = 0x06
 * 
 * @author ydc
 * @since 2020 05/25 下午
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {GatewayTestApplication.class})
@Slf4j
public class IbStartResultTest {
	
	@Autowired
	AmqpTemplate amqpTemplate;
	
	@Test
	public void startResultCmdHandle() throws Exception {
		byte[] fullData = new byte[] {0x59,0x43,0x3a,0x10,0x1c,0x06,0x00,0x00,(byte) 0xde,
				0x00,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
				0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
				0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
				0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x01,(byte) 0xe6};
		log.info("启动结果应答(0x06)");
    	RecPileStartedRstReportCmd recPileStartedRstReportCmd = new RecPileStartedRstReportCmd();
    	PileStartedRst pileStartedRst = (PileStartedRst) recPileStartedRstReportCmd.receiveCmdExecute(fullData);
    	SendPileStartedRstRespCmd sendPileStartedRstRespCmd = new SendPileStartedRstRespCmd();
    	byte[] datas = sendPileStartedRstRespCmd.sendCmdExecute(pileStartedRst);
    	//ChannelSender.send(ctx.channel(), datas);
    	//pileStartedRst.setPileCode(H2TServer.channelPileMap.get(ctx.channel()));
    	amqpTemplate.convertAndSend(RabbitmqConstant.STARTED_STATUS_EXCHANGE, RabbitmqConstant.STARTED_STATUS_ROUTING_KEY, pileStartedRst);
        log.info("启动结果应答结果发送到MQ body :{}",pileStartedRst);
    	log.info("启动结果应答处理完成(0x06) 最终启动结果 ：{}\n" , datas);
	}
}
