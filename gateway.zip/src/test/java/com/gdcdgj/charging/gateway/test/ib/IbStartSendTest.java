package com.gdcdgj.charging.gateway.test.ib;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.gdcdgj.charging.api.enums.MsgProviderEnum;
import com.gdcdgj.charging.api.vo.srv2gw.PileCtrl;
import com.gdcdgj.charging.api.vo.srv2gw.ServiceType;
import com.gdcdgj.charging.gateway.platform.ib.execute.send.SendPileCtrlWithoutOrdCmd;
import com.gdcdgj.charging.gateway.platform.ib.execute.send.SendSrvTypeResponseCmd;
import com.gdcdgj.charging.gateway.test.GatewayTestApplication;

import lombok.extern.slf4j.Slf4j;

/**
 * 宜步启动充电命令下发处理测试 cmd = 0x55
 * 
 * @author ydc
 * @since 2020 05/25 下午
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {GatewayTestApplication.class})
@Slf4j
public class IbStartSendTest {
	
	@Autowired
	AmqpTemplate amqpTemplate;
	
	@Test
	public void startCmdHandle() throws Exception {
		PileCtrl ctrlVo = new PileCtrl();
		//充电生效类型
		ctrlVo.setParamType((byte) 0);
        //模块数量 
		ctrlVo.setConnectorCount((byte)2);
        //用户识别号
		ctrlVo.setUserNo("0");
        //枪口号
		ctrlVo.setConnectorNo(1);
        /***宜步map***/
        //充电模块位置编号   Map<充电模块位置, 编号>
        Map<Byte, Byte> connectorNoMap = new HashMap<Byte, Byte>();
        connectorNoMap.put((byte)1, (byte)1);
        connectorNoMap.put((byte)2, (byte)2);
        //充电模块 控制参数值  Map<充电模块位置, 控制参数值>
        Map<Byte, Integer> valueMap = new HashMap<Byte, Integer>();
        valueMap.put((byte) 1, 0);
        valueMap.put((byte) 2, 1);
        ctrlVo.setConnectorNoMap(connectorNoMap);
        ctrlVo.setValueMap(valueMap);
        ctrlVo.setPileCode("ib_tyjj3");
        ctrlVo.setProviderId(2);
        ctrlVo.setParamType((byte) 2);
        ctrlVo.setCmdSeq(0);
//        ctrlVo.setPileCode("44192019122601002");
//        ctrlVo.setProviderId(1);
        ctrlVo.setConnectorNo(1);
		if(ctrlVo.getProviderId() == MsgProviderEnum.IB_PROVIDER.getValue()) {
			//宜步桩启动充电命令下发
	    	//启动前对获取应答中心充电服务类型
	    	log.info("中心充电服务类型下发");
	        SendSrvTypeResponseCmd cmd = new SendSrvTypeResponseCmd();
	        ServiceType serviceType = new ServiceType();
	        serviceType.setCardNum("");
	        //交易类型 默认使用0x20自然充满   0x01换电服务 0x10充电服务 0x30按时间 0x40安电量 暂不考虑这些
	        serviceType.setType((byte) 32);
	        serviceType.setConnectorNo(ctrlVo.getConnectorNo());
	        Calendar cal = Calendar.getInstance();
            serviceType.setTradeDate(cal);
	        byte[] data = cmd.sendCmdExecute(serviceType);
	        log.info("Data  的长度 ：{}",data.length-7);
	        log.info("中心充电服务类型下发 :{}",data);
	        //ChannelSender.send(channel, data);
	        SendPileCtrlWithoutOrdCmd send = new SendPileCtrlWithoutOrdCmd();
	        byte[] datas = send.sendCmdExecute(ctrlVo);
	        //ChannelSender.send(channel, datas);
	        log.info("启动宜步桩命令下发 :{}",datas);
	        log.info("DataS  的长度 ：{}",datas.length-7);
	        log.info("启动宜步桩命令下发完成 {}",ctrlVo.getParamType() == 2 ? ",电桩正在启动中..." : ",请在约定时间内充电");
		}
	}
}
