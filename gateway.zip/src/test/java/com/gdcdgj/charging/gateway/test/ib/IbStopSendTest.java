package com.gdcdgj.charging.gateway.test.ib;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.gdcdgj.charging.api.vo.srv2gw.PileCtrl;
import com.gdcdgj.charging.gateway.enums.MsgProviderEnum;
import com.gdcdgj.charging.gateway.platform.ib.execute.send.SendPileCtrlWithoutOrdCmd;
import com.gdcdgj.charging.gateway.test.GatewayTestApplication;

import lombok.extern.slf4j.Slf4j;

/**
 * 宜步停止充电命令下发处理测试 cmd = 0x55
 * 
 * @author ydc
 * @since 2020 05/25 下午
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {GatewayTestApplication.class})
@Slf4j
public class IbStopSendTest {
	
	@Autowired
	AmqpTemplate amqpTemplate;
	
	@Test
	public void startCmdHandle() throws Exception {
		PileCtrl ctrlVo = new PileCtrl();
		//充电生效类型
		ctrlVo.setParamType((byte) 0);
        //模块数量 
		ctrlVo.setConnectorCount((byte)2);
        //用户识别号
		ctrlVo.setUserNo("0");
        //枪口号
		ctrlVo.setConnectorNo(1);
        /***宜步map***/
        //充电模块位置编号   Map<充电模块位置, 编号>
        Map<Byte, Byte> connectorNoMap = new HashMap<Byte, Byte>();
        connectorNoMap.put((byte)1, (byte)1);
        connectorNoMap.put((byte)2, (byte)2);
        //充电模块 控制参数值  Map<充电模块位置, 控制参数值>
        Map<Byte, Integer> valueMap = new HashMap<Byte, Integer>();
        valueMap.put((byte) 1, 1);
        valueMap.put((byte) 2, 0);
        ctrlVo.setConnectorNoMap(connectorNoMap);
        ctrlVo.setValueMap(valueMap);
        ctrlVo.setPileCode("ib_tyjj3");
        ctrlVo.setProviderId(2);
//        ctrlVo.setPileCode("44192019122601002");
//        ctrlVo.setProviderId(1);
        ctrlVo.setConnectorNo(1);
		if(ctrlVo.getProviderId() == MsgProviderEnum.IB_PROVIDER.getValue()) {
			//宜步停止充电命令下发
       	 	SendPileCtrlWithoutOrdCmd send = new SendPileCtrlWithoutOrdCmd();
            log.info("停止宜步桩==》{}", ctrlVo);
            byte[] datas = send.sendCmdExecute(ctrlVo);
            //ChannelSender.send(channel, datas);
            log.info("停止宜步桩命令下发完成 :{}",datas);
		}
	}
}
