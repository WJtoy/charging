package com.gdcdgj.charging.gateway.test.ib;

import java.util.Date;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.gdcdgj.charging.api.vo.srv2gw.TimeSyn;
import com.gdcdgj.charging.gateway.platform.ib.execute.receive.RecTimeSynRespCmd;
import com.gdcdgj.charging.gateway.test.GatewayTestApplication;

import lombok.extern.slf4j.Slf4j;

/**
 * 宜步时间同步处理测试 cmd = 0x52
 * 
 * @author ydc
 * @since 2020 05/25 下午
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {GatewayTestApplication.class})
@Slf4j
public class IbTimeSyncTest {
	
	@Autowired
	AmqpTemplate amqpTemplate;
	
	@Test
	public void timeSyncCmdHandle() throws Exception {
		//总状态信息包暂无测试数据
		byte[] fullData = new byte[] {0x59,0x43,0x16,0x10,(byte) 0x01,0x52,0x00,0x00,
				(byte) 0xde,0x00,0x01,0x00,0x69,0x62,
				0x5f,0x74,0x6a,0x79,0x79,0x33,0x20,0x20,0x05,0x26,0x08,0x53,0x05,(byte) 0xff,0x3c};
		System.err.println(fullData.length-7);
		log.info("充电桩时间同步应答(0x52)");
		RecTimeSynRespCmd recTimeSynRespCmd = new RecTimeSynRespCmd();
		TimeSyn timeSyn = (TimeSyn) recTimeSynRespCmd.receiveCmdExecute(fullData);
		long res = timeSyn.getClock().getTime().getTime()-new Date().getTime();
		log.info("充电桩时间同步应答完成(0x52) 同步结果 ：{}\n", res > 5000 ? "失败" : "成功");
	}
}
