package com.gdcdgj.charging.gateway.test.ib;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.gdcdgj.charging.api.vo.srv2gw.WorkParam;
import com.gdcdgj.charging.gateway.platform.ib.execute.receive.RecWorkParamResponseCmd;
import com.gdcdgj.charging.gateway.platform.ib.execute.send.SendWorkParamCmd;
import com.gdcdgj.charging.gateway.test.GatewayTestApplication;

import lombok.extern.slf4j.Slf4j;

/**
 * 宜步工作参数处理测试 cmd = 0x56
 * 
 * @author ydc
 * @since 2020 05/25 下午
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {GatewayTestApplication.class})
@Slf4j
public class IbWorkParamTest {
	
	@Autowired
	AmqpTemplate amqpTemplate;
	
	@Test
	public void timeSyncCmdHandle() throws Exception {
		//总状态信息包暂无测试数据
		byte[] fullData = new byte[] {0x59,0x43,0x16,0x10,(byte) 0x1b,0x56,0x00,0x00,
				(byte) 0xde,0x00,0x01,0x00,0x00,0x00,0x00,0x00,0x3c};
		log.info("工作参数应答处理(0x56)");
		RecWorkParamResponseCmd recWorkParamResponseCmd = new RecWorkParamResponseCmd(); 
		WorkParam workParam = (WorkParam) recWorkParamResponseCmd.receiveCmdExecute(fullData);
		log.info("工作参数应答处理完成(0x56) 设置结果：{}\n" , workParam.getSettingRst() == 0 ? "成功" : "失败");
		SendWorkParamCmd cmd = new SendWorkParamCmd();
		WorkParam w = new WorkParam();
		w.setPileCode("ib_tyjj3");
		w.setType((byte) 0);
		w.setBatteryType((byte) 0);
		w.setConnectorCnt((byte) 2);
		w.setSrvIp("102.10.10.110");
		w.setSrvPort(8899);
		byte[] datas = cmd.sendCmdExecute(w);
		log.info("工作参数设置处理完成 :：{}",datas);
	}
}
