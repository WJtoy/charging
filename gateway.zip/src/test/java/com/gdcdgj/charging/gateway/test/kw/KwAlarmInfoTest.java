package com.gdcdgj.charging.gateway.test.kw;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.gdcdgj.charging.api.constant.RabbitmqConstant;
import com.gdcdgj.charging.api.vo.srv2gw.ChargeRecordInfo;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.HeartBeat;
import com.gdcdgj.charging.api.vo.srv2gw.PileCtrl;
import com.gdcdgj.charging.api.vo.srv2gw.PileStartedRst;
import com.gdcdgj.charging.api.vo.srv2gw.PlasticParamSet;
import com.gdcdgj.charging.api.vo.srv2gw.SetVoluationPolicy;
import com.gdcdgj.charging.api.vo.srv2gw.SignIn;
import com.gdcdgj.charging.api.vo.srv2gw.StateInfo;
import com.gdcdgj.charging.api.vo.srv2gw.StrParamSet;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecAlarmInfoReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecHeartBeatReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecPileCtrlStartRstReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecPileCtrlStopRstReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecPileStartedRstReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecSignInResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecStateInfoReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendAlarmInfoResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendChargeRecordInfoResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendHeartbeatReportResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendPileStartedRstRespCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendPlasticParamResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendSetVoluationPolicyRespCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendSignInResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendStateInfoResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendStrParamSetRespCmd;
import com.gdcdgj.charging.gateway.server.handler.ChannelSender;
import com.gdcdgj.charging.gateway.server.handler.H2TServer;
import com.gdcdgj.charging.gateway.test.GatewayTestApplication;

import io.netty.channel.ChannelHandlerContext;
import lombok.extern.slf4j.Slf4j;

/**
 * 科旺告警信息上报处理测试 cmd = 108、107
 * 
 * @author ydc
 * @since 2020 05/25 上午
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {GatewayTestApplication.class})
@Slf4j
public class KwAlarmInfoTest {
	
	@Autowired
	AmqpTemplate amqpTemplate;
	
	@Test
	public void alarmInfoCmdHandle() throws Exception {
		byte[] fullData =new byte[] {(byte) 0xaa,(byte) 0xf5,0x4d,0x00,0x03,0x6c,0x00,
				0x00,0x00,0x00,0x00,0x34,0x34,0x31,0x39,0x32,0x30,0x31,0x39,0x31,0x32,
				0x32,0x36,0x30,0x31,0x30,0x30,0x32,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
				0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
				0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
				0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,(byte) 0xc8};
		//充电桩告警信息上报
		RecAlarmInfoReportCmd recAlarmInfoReportCmd = new RecAlarmInfoReportCmd();
		DataBaseVo vo = recAlarmInfoReportCmd.receiveCmdExecute(fullData);
		//后台给出告警信息上报响应
		SendAlarmInfoResponseCmd sendAlarmInfoResponseCmd = new SendAlarmInfoResponseCmd();
		byte[] datas = sendAlarmInfoResponseCmd.sendCmdExecute(vo);
		//ChannelSender.send(H2TServer.getChannel(vo.getPileCode()), datas);
		//amqpTemplate.convertAndSend(RabbitmqConstant.SERVICE_TYPE_EXCHANGE, RabbitmqConstant.SERVICE_TYPE_ROUTING_KEY, vo);
		log.info("充电桩告警信息上报处理完成\n :{}",datas);
	}
}
