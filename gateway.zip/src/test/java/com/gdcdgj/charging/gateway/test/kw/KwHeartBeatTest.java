package com.gdcdgj.charging.gateway.test.kw;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.gdcdgj.charging.api.vo.srv2gw.HeartBeat;
import com.gdcdgj.charging.api.vo.srv2gw.PlasticParamSet;
import com.gdcdgj.charging.api.vo.srv2gw.SetVoluationPolicy;
import com.gdcdgj.charging.api.vo.srv2gw.StrParamSet;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecHeartBeatReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendHeartbeatReportResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendPlasticParamResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendSetVoluationPolicyRespCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendStrParamSetRespCmd;
import com.gdcdgj.charging.gateway.test.GatewayTestApplication;

import lombok.extern.slf4j.Slf4j;

/**
 * 科旺心跳处理测试 cmd = 102
 * 24时计价策略命令下发
 * 24服务费设置命令下发
 * 15秒周期上报状态信息
 * @author ydc
 * @since 2020 05/25 上午
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {GatewayTestApplication.class})
@Slf4j
public class KwHeartBeatTest {
	
	//科旺桩在心跳完成发送一次设置命令
	private boolean isStart = true;
	
	@Test
	public void heartbeatCmdHandle() throws Exception {
		//科旺桩发送心跳报文 模拟 cmd = 102
		byte[] fullData = new byte[] {(byte) 0xaa,(byte) 0xf5,0x3f,0x00,0x03,(byte) 0x9c,0x66
				,0x00,0x00,0x00,0x00,0x00,0x34,0x34,0x31,0x39,0x32,0x30,0x31,0x39,0x31,0x32,
				0x32,0x36,0x30,0x31,0x30,0x30,0x32,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
				0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
				0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,(byte) 0xc3};
    	// 心跳包上报
    	RecHeartBeatReportCmd recHeartBeatReportCmd = RecHeartBeatReportCmd.getInstance();
        // 接收报文后执行
    	HeartBeat heartBeat = (HeartBeat) recHeartBeatReportCmd.receiveCmdExecute(fullData);
        SendHeartbeatReportResponseCmd sendHeartbeatReportResponseCmd = new SendHeartbeatReportResponseCmd();
        byte[] datas = sendHeartbeatReportResponseCmd.sendCmdExecute(heartBeat);
        log.info("心跳包上报/应答完成\n :{}",datas);
        if(isStart) {
        	//心跳响应成功后服务器下发同步当前时间到桩
            SendStrParamSetRespCmd sendStrParamSetRespCmd = new  SendStrParamSetRespCmd();
            StrParamSet strParamSet = new StrParamSet();
            byte[] syncTime = sendStrParamSetRespCmd.sendCmdExecute(strParamSet);
            //ChannelSender.send(chn, syncTime);
            log.info("服务器下发更新系统时间到桩处理完成\n :{}",syncTime);
            //后台服务器设置24时电费计价策略
            SetVoluationPolicy setVoluationPolicy = new SetVoluationPolicy();
            SendSetVoluationPolicyRespCmd sendSetVoluationPolicyRespCmd = new SendSetVoluationPolicyRespCmd();
            byte[] policy = sendSetVoluationPolicyRespCmd.sendCmdExecute(setVoluationPolicy);
            //ChannelSender.send(chn, policy);
            log.info("后台服务器设置24时电费计价策略处理完成\n :{}",policy);
            //服务器下发整形参数》服务费价格
            PlasticParamSet plasticParamSet = new PlasticParamSet();
            plasticParamSet.setOriginAddr(0x1b);
            plasticParamSet.setValue(0x3c);
            SendPlasticParamResponseCmd sendPlasticParamResponseCmd = new SendPlasticParamResponseCmd();
            byte[] plasticParam = sendPlasticParamResponseCmd.sendCmdExecute(plasticParamSet);
            //ChannelSender.send(chn, plasticParam);
            log.info("服务器下发整形参数》服务费价格处理完成\n :{}",plasticParam);
            //服务器下发整形参数》充电桩状态信息包上报周期
            PlasticParamSet plasticParamSet2 = new PlasticParamSet();
            plasticParamSet2.setOriginAddr(23);
            plasticParamSet2.setValue(15);
            byte[] plasticParam2 = sendPlasticParamResponseCmd.sendCmdExecute(plasticParamSet2);
            //ChannelSender.send(chn, plasticParam2);
            log.info("服务器下发整形参数》充电桩状态信息包上报周期处理完成\n :{}",plasticParam2);
            isStart = false;
        }
    }
	
}
