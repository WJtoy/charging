package com.gdcdgj.charging.gateway.test.kw;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.gdcdgj.charging.api.constant.RabbitmqConstant;
import com.gdcdgj.charging.api.vo.srv2gw.ChargeRecordInfo;
import com.gdcdgj.charging.api.vo.srv2gw.ChargeTimeFrameInfo;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.HistoryChargeRecord;
import com.gdcdgj.charging.api.vo.srv2gw.StrParamSet;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecChargeRecordInfoReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecChargeTimeInfoReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecHistoryChargeRecordInfoReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecStrParamRespReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendChargeRecordInfoResponseCmd;
import com.gdcdgj.charging.gateway.server.handler.ChannelSender;
import com.gdcdgj.charging.gateway.server.handler.H2TServer;
import com.gdcdgj.charging.gateway.test.GatewayTestApplication;

import lombok.extern.slf4j.Slf4j;

/**
 * 科旺充电桩上报充电记录信息处理测试 cmd = 201、202
 * 
 * @author ydc
 * @since 2020 05/25 上午
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {GatewayTestApplication.class})
@Slf4j
public class KwHistoryChargeRecordInfoTest {
	
	@Test
	public void HistoryChargeRecordInfoCmdHandle() throws Exception {
		//暂无测试数据
		byte[] fullData =new byte[] {};
		//充电桩上报充历史充电记录信息
		RecHistoryChargeRecordInfoReportCmd recHistoryChargeRecordInfoReportCmd = new RecHistoryChargeRecordInfoReportCmd();
		//HistoryChargeRecord historyChargeRecord = (HistoryChargeRecord) recHistoryChargeRecordInfoReportCmd.receiveCmdExecute(fullData);
		//log.info("充电桩上报充历史充电记录信息\n 上报结果：{}" ,historyChargeRecord );
	}
}
