package com.gdcdgj.charging.gateway.test.kw;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecModuleInfoResponseCmd;
import com.gdcdgj.charging.gateway.test.GatewayTestApplication;

import lombok.extern.slf4j.Slf4j;

/**
 * 科旺充电信息上报、应答处理测试 cmd = 112
 * 
 * @author ydc
 * @since 2020 05/25 上午
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {GatewayTestApplication.class})
@Slf4j
public class KwMoudleInfoTest {
	
	@Test
	public void moduleInfoCmdHandle() throws Exception {
		//暂无数据
		byte[] fullData = new byte[] {};
		//充电桩充电信息上报模块信息
    	RecModuleInfoResponseCmd recModuleInfoResponseCmd = new RecModuleInfoResponseCmd();
    	//ModuleChargingInfo moduleChargingInfo = (ModuleChargingInfo) recModuleInfoResponseCmd.receiveCmdExecute(fullData);
    	log.info("充电桩充电信息上报模块信息完成\n ");
    }
	
}
