package com.gdcdgj.charging.gateway.test.kw;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.gdcdgj.charging.api.vo.srv2gw.ChargeRecordInfo;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.PileCtrl;
import com.gdcdgj.charging.api.vo.srv2gw.PlasticParamSet;
import com.gdcdgj.charging.api.vo.srv2gw.StrParamSet;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecPileCtrlStopRstReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecPlasticParamRespReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecStrParamRespReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendChargeRecordInfoResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendPlasticParamResponseCmd;
import com.gdcdgj.charging.gateway.test.GatewayTestApplication;

import lombok.extern.slf4j.Slf4j;

/**
 * 科旺整形参数处理测试 cmd = 2
 * 
 * @author ydc
 * @since 2020 05/25 上午
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {GatewayTestApplication.class})
@Slf4j
public class KwPlasticParamSetTest {
	
	@Test
	public void plasticParamSetCmdHandle() throws Exception {
		byte[] fullData =new byte[] {(byte) 0xaa,(byte) 0xf5,0x34,0x00,0x03,(byte) 0x9a,
				0x02,0x00,0x00,0x00,0x00,0x01,0x34,0x34,0x31,0x39,0x32,0x30,0x31,0x39,
				0x31,0x32,0x32,0x36,0x30,0x31,0x30,0x30,0x32,0x00,0x00,0x00,0x00,0x00,
				0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x01,0x1b,0x00,0x00,
				0x00,0x01,0x00,0x7c};
		byte[] fullData1 =new byte[] {(byte) 0xaa,(byte) 0xf5,0x34,0x00,0x03,(byte) 0x9a,
				0x02,0x00,0x00,0x00,0x00,0x01,0x34,0x34,0x31,0x39,0x32,0x30,0x31,0x39,
				0x31,0x32,0x32,0x36,0x30,0x31,0x30,0x30,0x32,0x00,0x00,0x00,0x00,0x00,
				0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x01,0x17,0x00,0x00,
				0x00,0x01,0x00,0x7c};
		//充电桩整型参数设置命令应答
		RecPlasticParamRespReportCmd recPlasticParamRespReportCmd = new RecPlasticParamRespReportCmd();
		PlasticParamSet plasticParamSet = (PlasticParamSet) recPlasticParamRespReportCmd.receiveCmdExecute(fullData1);
		log.info("充电桩整形参数设置应答处理完成\n 设置结果：{}" , plasticParamSet);
	}
}
