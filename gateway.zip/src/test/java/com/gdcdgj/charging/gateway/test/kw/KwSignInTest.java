package com.gdcdgj.charging.gateway.test.kw;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.gdcdgj.charging.api.constant.RabbitmqConstant;
import com.gdcdgj.charging.api.vo.srv2gw.SignIn;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecSignInResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendSignInResponseCmd;
import com.gdcdgj.charging.gateway.test.GatewayTestApplication;

import lombok.extern.slf4j.Slf4j;

/**
 * 科旺签到处理测试 cmd = 106
 * 
 * @author ydc
 * @since 2020 05/25 上午
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {GatewayTestApplication.class})
@Slf4j
public class KwSignInTest {
	
	@Autowired
	private AmqpTemplate amqpTemplate;
	
	@Test
	public void signInCmdHandle() throws Exception {
		byte[] fullData = new byte[] {(byte) 0xaa,(byte) 0xf5,0x6d,0x00,0x03,(byte) 0x97,0x6a,
				0x00,0x00,0x00,0x00,0x00,0x00,0x34,0x34,0x31,0x39,0x32,0x30,0x31,0x39,0x31,
				0x32,0x32,0x36,0x30,0x31,0x30,0x30,0x32,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
				0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
				0x00,0x00,0x00,0x00,0x02,0x3c,0x00,0x00,0x02,0x01,0x03,0x00,0x74,0x00,0x00,
				0x20,0x20,0x04,0x26,0x12,0x07,0x53,(byte) 0xff,0x00,0x00,0x00,0x00,0x00
				,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
				0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x1d,0x00,0x00,0x00,0x00,0x00,0x03};
    	//充电桩签到报文上报
    	RecSignInResponseCmd recSignInResponseCmd = new RecSignInResponseCmd();
    	SignIn signIn = (SignIn) recSignInResponseCmd.receiveCmdExecute(fullData);
    	String tmpCode = signIn.getPileCode();
        log.info("保存equipmentCode和Channel========{}", tmpCode);
        //H2TServer.saveChannel(tmpCode, ctx.channel());
        //后台应答充电桩签到上报
    	SendSignInResponseCmd sendSignInResponseCmd = new SendSignInResponseCmd();
    	byte[] datas = sendSignInResponseCmd.sendCmdExecute(signIn);
    	//ChannelSender.send(ctx.channel(), datas);
    	amqpTemplate.convertAndSend(RabbitmqConstant.SIGN_IN_PILE_EXCHANGE, RabbitmqConstant.SIGN_IN_PILE_ROUTING_KEY, signIn);
    	log.info("签到报文发送MQ成功 -》body :{}\n",signIn);
    	log.info("报文签到处理完成\n :{}",datas);
    }
	
}
