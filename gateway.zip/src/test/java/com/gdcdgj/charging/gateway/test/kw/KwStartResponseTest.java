package com.gdcdgj.charging.gateway.test.kw;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.gdcdgj.charging.api.constant.RabbitmqConstant;
import com.gdcdgj.charging.api.vo.srv2gw.PileCtrl;
import com.gdcdgj.charging.api.vo.srv2gw.PileStartedRst;
import com.gdcdgj.charging.api.vo.srv2gw.PlasticParamSet;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecPileCtrlStartRstReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendPlasticParamResponseCmd;
import com.gdcdgj.charging.gateway.test.GatewayTestApplication;

import lombok.extern.slf4j.Slf4j;

/**
 * 科旺启动应答处理测试 cmd = 8
 * 
 * @author ydc
 * @since 2020 05/25 上午
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {GatewayTestApplication.class})
@Slf4j
public class KwStartResponseTest {
	
	@Autowired
	AmqpTemplate amqpTemplate;
	
	@Test
	public void startCmdHandle() throws Exception {
		byte[] fullData =new byte[] {(byte) 0xaa,(byte) 0xf5,0x52,0x00,0x03,(byte) 0xdb,0x08,
				0x00,0x00,0x00,0x00,0x00,0x34,0x34,0x31,0x39,0x32,0x30,0x31,0x39,0x31,0x32,
				0x32,0x36,0x30,0x31,0x30,0x30,0x32,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
				0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x01,0x00,0x00,0x00,0x00,0x00,0x34,0x38,
				0x32,0x30,0x30,0x34,0x32,0x36,0x31,0x36,0x32,0x37,0x33,0x36,0x31,0x30,0x36,
				0x4a,0x4a,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
				0x00,0x3f};
		//充电桩充电启动命令应答
    	RecPileCtrlStartRstReportCmd recPileCtrlStartRstReportCmd = new RecPileCtrlStartRstReportCmd();
    	PileCtrl vo = (PileCtrl) recPileCtrlStartRstReportCmd.receiveCmdExecute(fullData);
    	log.info("充电桩启动充电命令应答完成 :{}",vo);
    	//服务器下发整形参数》充电桩状态信息包上报周期 更改为3秒一次
        PlasticParamSet plasticParamSet = new PlasticParamSet();
        plasticParamSet.setOriginAddr(23);
        plasticParamSet.setValue(0x03);
        SendPlasticParamResponseCmd sendPlasticParamResponseCmd = new SendPlasticParamResponseCmd();
        byte[] plasticParam = sendPlasticParamResponseCmd.sendCmdExecute(plasticParamSet);
        //ChannelSender.send(H2TServer.getChannel(vo.getPileCode()), plasticParam);
        log.info("服务器下发整形参数》充电桩状态信息包上报周期更改完成\n :{}",plasticParam);
        //下发启动结果到mQ
        PileStartedRst pileStartedRst = new PileStartedRst();
        pileStartedRst.setProviderId(1);
        pileStartedRst.setConnectorNo(vo.getConnectorNo());
        pileStartedRst.setPileCode(vo.getPileCode());
        pileStartedRst.setResult(vo.getResultCode());
        amqpTemplate.convertAndSend(RabbitmqConstant.STARTED_STATUS_EXCHANGE, RabbitmqConstant.STARTED_STATUS_ROUTING_KEY, pileStartedRst);
        log.info("下发启动结果到mQ body:{}\n",pileStartedRst);
        log.info("下发启动结果到MQ 启动结果 {}",vo.getResultCode()==1 ? "成功" : "失败");
    }
	
}
