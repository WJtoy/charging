package com.gdcdgj.charging.gateway.test.kw;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.gdcdgj.charging.gateway.platform.ib.execute.receive.RecPileStartedRstReportCmd;
import com.gdcdgj.charging.gateway.platform.ib.execute.send.SendPileStartedRstRespCmd;
import com.gdcdgj.charging.gateway.test.GatewayTestApplication;

import lombok.extern.slf4j.Slf4j;

/**
 * 科旺启动结果处理测试 cmd = 110
 * 
 * @author ydc
 * @since 2020 05/25 上午
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {GatewayTestApplication.class})
@Slf4j
public class KwStartResultTest {
	
	@Test
	public void startResultCmdHandle() throws Exception {
		//暂无数据 启动结果科旺在0x08应答
		byte[] fullData = new byte[] {};
		//充电桩上报启动结果
    	RecPileStartedRstReportCmd recPileStartedRstReportCmd = new RecPileStartedRstReportCmd();
    	//PileStartedRst pileStartedRst = (PileStartedRst) recPileStartedRstReportCmd.receiveCmdExecute(fullData);
    	//后台收到后给出响应
    	SendPileStartedRstRespCmd sendPileStartedRstRespCmd = new SendPileStartedRstRespCmd();
    	//byte[] datas = sendPileStartedRstRespCmd.sendCmdExecute(pileStartedRst);
    	//ChannelSender.send(H2TServer.getChannel(pileStartedRst.getPileCode()), datas);
    	log.info("充电桩上报启动结果响应完成\n");
    }
	
}
