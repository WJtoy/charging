package com.gdcdgj.charging.gateway.test.kw;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.gdcdgj.charging.api.constant.RabbitmqConstant;
import com.gdcdgj.charging.api.vo.srv2gw.ChargeRecordInfo;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.HeartBeat;
import com.gdcdgj.charging.api.vo.srv2gw.PileCtrl;
import com.gdcdgj.charging.api.vo.srv2gw.PileStartedRst;
import com.gdcdgj.charging.api.vo.srv2gw.PlasticParamSet;
import com.gdcdgj.charging.api.vo.srv2gw.SetVoluationPolicy;
import com.gdcdgj.charging.api.vo.srv2gw.SignIn;
import com.gdcdgj.charging.api.vo.srv2gw.StateInfo;
import com.gdcdgj.charging.api.vo.srv2gw.StrParamSet;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecHeartBeatReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecPileCtrlStartRstReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecPileCtrlStopRstReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecPileStartedRstReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecSignInResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecStateInfoReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendChargeRecordInfoResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendHeartbeatReportResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendPileStartedRstRespCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendPlasticParamResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendSetVoluationPolicyRespCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendSignInResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendStateInfoResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendStrParamSetRespCmd;
import com.gdcdgj.charging.gateway.server.handler.ChannelSender;
import com.gdcdgj.charging.gateway.server.handler.H2TServer;
import com.gdcdgj.charging.gateway.test.GatewayTestApplication;

import io.netty.channel.ChannelHandlerContext;
import lombok.extern.slf4j.Slf4j;

/**
 * 科旺状态信息上报处理测试 cmd = 104
 * 
 * @author ydc
 * @since 2020 05/25 上午
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {GatewayTestApplication.class})
@Slf4j
public class KwStateInfoTest {
	
	@Autowired
	AmqpTemplate amqpTemplate;
	
	@Test
	public void stateInfoCmdHandle() throws Exception {
		byte[] fullData =new byte[] {(byte) 0xaa,(byte) 0xf5,(byte) 0xc8,0x00,0x03,(byte) 0x9d,0x68,
				0x00,0x00,0x00,0x00,0x00,0x34,0x34,0x31,0x39,0x32,0x30,0x31,0x39,0x31,0x32,0x32,
				0x36,0x30,0x31,0x30,0x30,0x32,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
				0x00,0x00,0x00,0x00,0x00,0x02,0x01,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
				0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
				0x00,0x00,0x00,0x02,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
				0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x61,0x50,0x02,0x00,0x00,0x00,
				0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
				0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
				0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x19,(byte) 0x90,0x01,0x01,0x00,
				0x00,0x00,(byte) 0xff,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
				0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x48,0x00,0x63,0x00,
				0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
				0x00,0x00,(byte) 0xd2};
		//充电桩状态信息报上报
		RecStateInfoReportCmd recStateInfoReportCmd = new RecStateInfoReportCmd();
		StateInfo stateInfo = (StateInfo) recStateInfoReportCmd.receiveCmdExecute(fullData);
		SendStateInfoResponseCmd sendStateInfoResponseCmd = new SendStateInfoResponseCmd();
		byte[] datas = sendStateInfoResponseCmd.sendCmdExecute(stateInfo);
		//ChannelSender.send(H2TServer.getChannel(stateInfo.getPileCode()), datas);
		amqpTemplate.convertAndSend(RabbitmqConstant.STATEINFO_STATUS_EXCHANGE, RabbitmqConstant.STATEINFO_STATUS_ROUTING_KEY, stateInfo);
		log.info("发送状态信息包到mq body:{}",stateInfo);
		log.info("本次充电桩状态信息包上报处理完成\n :{}",datas);
	}
}
