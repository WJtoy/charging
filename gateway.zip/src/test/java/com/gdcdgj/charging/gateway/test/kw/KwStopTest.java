package com.gdcdgj.charging.gateway.test.kw;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.gdcdgj.charging.api.vo.srv2gw.ChargeRecordInfo;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.PileCtrl;
import com.gdcdgj.charging.api.vo.srv2gw.PlasticParamSet;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecPileCtrlStopRstReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendChargeRecordInfoResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendPlasticParamResponseCmd;
import com.gdcdgj.charging.gateway.test.GatewayTestApplication;

import lombok.extern.slf4j.Slf4j;

/**
 * 科旺停止应答处理测试 cmd = 6
 * 
 * @author ydc
 * @since 2020 05/25 上午
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {GatewayTestApplication.class})
@Slf4j
public class KwStopTest {
	
	@Test
	public void stopCmdHandle() throws Exception {
		byte[] fullData =new byte[] {(byte) 0xaa,(byte) 0xf5,0x34,0x00,0x03,0x72,0x06,0x00,0x00,
				0x00,0x00,0x00,0x34,0x34,0x31,0x39,0x32,0x30,0x31,0x39,0x31,0x32,0x32,0x36,0x30,
				0x31,0x30,0x30,0x32,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
				0x00,0x00,0x00,0x02,0x02,0x00,0x00,0x00,0x01,0x00,0x67};
		//充电桩充电停止命令应答
    	RecPileCtrlStopRstReportCmd recPileCtrlStopRstReportCmd = new RecPileCtrlStopRstReportCmd();
    	DataBaseVo vo = recPileCtrlStopRstReportCmd.receiveCmdExecute(fullData);
    	PileCtrl pileCtrl = (PileCtrl) vo;
    	log.info("充电桩停止充电命令应答完成\n :{}",pileCtrl);
        if(pileCtrl.getResultCode() == 0) {
	    	//服务器下发整形参数》充电桩状态信息包上报周期 更改为15秒一次
	        PlasticParamSet plasticParamSet = new PlasticParamSet();
	        plasticParamSet.setOriginAddr(23);
	        plasticParamSet.setValue(15);
	        SendPlasticParamResponseCmd sendPlasticParamResponseCmd = new SendPlasticParamResponseCmd();
	        byte[] plasticParam = sendPlasticParamResponseCmd.sendCmdExecute(plasticParamSet);
	        //ChannelSender.send(H2TServer.getChannel(vo.getPileCode()), plasticParam);
	        log.info("服务器下发整形参数》充电桩状态信息包上报周期更改完成\n :{}",plasticParam);
	        //充电完成 充电桩下发充电记录信息
	        SendChargeRecordInfoResponseCmd sendChargeRecordInfoResponseCmd = new SendChargeRecordInfoResponseCmd();
	        ChargeRecordInfo ChargeRecordInfo = new ChargeRecordInfo();
	        byte[] chargeTimeInfos = sendChargeRecordInfoResponseCmd.sendCmdExecute(ChargeRecordInfo);
	        //ChannelSender.send(H2TServer.getChannel(vo.getPileCode()), chargeTimeInfos);
	        log.info("充电完成服务器查询充电记录信息处理完成\n :{}",chargeTimeInfos);
        }
	}
}
