package com.gdcdgj.charging.gateway.test.kw;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.gdcdgj.charging.api.vo.srv2gw.ChargeRecordInfo;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.PileCtrl;
import com.gdcdgj.charging.api.vo.srv2gw.PlasticParamSet;
import com.gdcdgj.charging.api.vo.srv2gw.SetVoluationPolicy;
import com.gdcdgj.charging.api.vo.srv2gw.StrParamSet;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecPileCtrlStopRstReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecPlasticParamRespReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecSetVoluationPolicyResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.receive.RecStrParamRespReportCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendChargeRecordInfoResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendPlasticParamResponseCmd;
import com.gdcdgj.charging.gateway.platform.kw.execute.send.SendSetVoluationPolicyRespCmd;
import com.gdcdgj.charging.gateway.test.GatewayTestApplication;

import lombok.extern.slf4j.Slf4j;

/**
 * 科旺服务器设置24小时电费计价策信息处理测试 cmd = 1104、1103
 * 
 * @author ydc
 * @since 2020 05/25 上午
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {GatewayTestApplication.class})
@Slf4j
public class KwVoluationPolicyTest {
	
	@Test
	public void voluationPolicyCmdHandle() throws Exception {
		byte[] fullData =new byte[] {(byte) 0xaa,(byte) 0xf5,0x6e,0x00,0x03,(byte) 0x99,0x50,0x04,0x00,0x54};
		//充电桩24时电费计价策略设置命令应答
		RecSetVoluationPolicyResponseCmd recSetVoluationPolicyResponseCmd = new RecSetVoluationPolicyResponseCmd();
		SetVoluationPolicy setVoluationPolicy = (SetVoluationPolicy) recSetVoluationPolicyResponseCmd.receiveCmdExecute(fullData);
		log.info("充电桩24时电费计价策略设置应答处理完成\n 应答结果：{}" , setVoluationPolicy); 
	}
	@Test
	public void voluationPolicyCmdHandle2() throws Exception {
		byte[] fullData =new byte[] {(byte) 0xaa,(byte) 0xf5,0x69,0x00,0x10,0x5a,0x4f,
				0x04,0x00,0x00,0x08,0x00,0x2b,0x00,0x00,0x00,0x08,0x00,0x00,0x74,0x00,
				0x40,0x00,0x00,0x00,0x00,0x74,0x00,0x0c,0x00,0x68,0x00,0x00,0x00,0x0c,
				0x00,0x13,0x00,0x40,0x00,0x00,0x00,0x13,0x00,0x16,0x00,0x68,0x00,0x00,
				0x00,0x16,0x00,0x18,0x00,0x40,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
				0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
				0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
				0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
				0x00,(byte) 0xa9};
		//充电桩24时电费计价策略设置命令下发
		SendSetVoluationPolicyRespCmd sendSetVoluationPolicyRespCmd = new SendSetVoluationPolicyRespCmd();
		//SetVoluationPolicy setVoluationPolicy = (SetVoluationPolicy) sendSetVoluationPolicyRespCmd.sendCmdExecute(dataVo)
		log.info("充电桩24时电费计价策略设置处理完成\n 设置参数：{}",fullData); 
	}
}
