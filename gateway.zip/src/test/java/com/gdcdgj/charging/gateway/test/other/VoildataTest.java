package com.gdcdgj.charging.gateway.test.other;

public class VoildataTest {
	public static void main(String[] args) {
		byte cmdCode = 0x55;
		byte[] dataField = new byte[] {0, 0, 0, 0, 1, 0, 2, 2, 1, 0, 0, 2, 1, 0};
		System.err.println(getCheckSum(cmdCode, dataField));//94
		System.err.println(0x61);
	}
	public static byte getCheckSum(byte cmdCode, byte... dataField) {
        byte checkSum = cmdCode;
        for (byte b : dataField) {
            checkSum = (byte) (checkSum+b);
        }
        return checkSum;
    }
}
