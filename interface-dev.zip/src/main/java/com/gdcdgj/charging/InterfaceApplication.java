package com.gdcdgj.charging;

import com.gdcdgj.charging.api.config.RedisConfig;
import org.apache.dubbo.config.spring.context.annotation.EnableDubbo;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;

/**
 * @author Changliang Tao
 * @date 2020/4/17 11:27
 * @since JDK 1.8
 */
@SpringBootApplication
@EnableDubbo
@Import(RedisConfig.class)
public class InterfaceApplication {
    public static void main(String[] args) {
        SpringApplication.run(InterfaceApplication.class, args);
    }
}
