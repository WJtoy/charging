package com.gdcdgj.charging.interceptor;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gdcdgj.charging.api.constant.ResultCode;
import com.gdcdgj.charging.api.util.RedisUtil;
import com.gdcdgj.charging.api.vo.CommonVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;

/**
 * 登录拦截器
 *
 * @author Changliang Tao
 * @date 2020/4/20 13:51
 * @since JDK 1.8
 */
@Slf4j
@Component
public class LoginInterceptor implements HandlerInterceptor {
    @Autowired
    RedisUtil redisUtil;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        // 从request获取token
        String token = request.getHeader("token");
        // 去redis里面查询token是否存在，如果不存在，返回错误信息，如果存在，返回true
        System.out.println(token);
        if (redisUtil.hasKey(token)) {
            return true;
        }
        log.error("访问 uri ===> {} 时， 用户token不存在",request.getRequestURI());
        PrintWriter printWriter= response.getWriter();
        CommonVo commonVo = new CommonVo(ResultCode.FAIL_CODE, "Check authrity has an exception.", "");
        response.setContentType("application/json;charset=utf-8");
        ObjectMapper objectMapper = new ObjectMapper();
        String value = objectMapper.writeValueAsString(commonVo);
        printWriter.print(value);
        printWriter.flush();
        printWriter.close();
        return  false;
    }
}
