package com.gdcdgj.charging.rest.charging;

import com.gdcdgj.charging.api.localService.charging.ChargingService;
import com.gdcdgj.charging.api.vo.CommonVo;
import com.gdcdgj.charging.rest.BaseController;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.Reference;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

/**
 * 扫码启动充电
 *
 * @author Changliang Tao
 * @date 2020/4/23 9:24
 * @since JDK 1.8
 */
@Slf4j
@Api
@RestController
@RequestMapping(value = "/api/charging")
public class ChargingController extends BaseController {
    @Reference(version = "1.0.0", check = false,timeout = 15000)
    private ChargingService chargingService;

    /**
     * 扫码充电
     *
     * @param
     * @return
     * @throws
     * @author Changliang Tao
     * @date 2020/4/20 14:29
     */
    @ApiOperation(value = "启动充电", notes = "根据二维码扫出枪编码启动充电桩")
    @PostMapping(value = "/start")
    public CommonVo start(@ApiParam("json字符串") @RequestBody String jsonText,
                                        HttpServletRequest request) throws Exception {
        // 从头部取出token,二维码即是枪编码
        String token = request.getHeader("token");
        Map<String, String> map = handleRequestParam(jsonText);
        String qrCode = map.get("cntr_code");//枪编码
        String scanTime = map.get("scan_time");
        String isSimulate = map.get("is_simulate");
        return chargingService.start(token, qrCode, scanTime,Integer.parseInt(isSimulate));
    }

    @ApiOperation(value = "结束充电",notes = "结束充电")
    @PostMapping("/stop")
    public CommonVo stop(@ApiParam("json字符串") @RequestBody String jsonText,
                         HttpServletRequest request){
        String token = request.getHeader("token");
        Map<String, String> map = handleRequestParam(jsonText);
        String cntr_code = map.get("cntr_code");
        String isSimulate = map.get("is_simulate");
        return chargingService.stop(token,cntr_code,Integer.parseInt(isSimulate));
    }


}
