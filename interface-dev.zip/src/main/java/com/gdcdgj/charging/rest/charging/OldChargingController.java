package com.gdcdgj.charging.rest.charging;

import com.gdcdgj.charging.api.localService.charging.ChargingService;
import com.gdcdgj.charging.api.localService.charging.OldChargingService;
import com.gdcdgj.charging.api.vo.CommonVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.apache.dubbo.config.annotation.Reference;
import org.springframework.web.bind.annotation.*;


/**
 * 充电相关
 */
@Api
@RestController
@RequestMapping(value = "/api/old/charging")
public class OldChargingController {

    @Reference(version = "1.0.0", check = false)
    private OldChargingService oldChargingService;


    /**
      * @Author: JianMei Chen
      * @Date: 2020/4/29
      * 根据会员Id来分页查询充电订单信息
     */
    @ApiOperation(value = "根据memberId来分页查询充电订单", notes = "分页查询订单（未支付和已支付）信息，包含站点名称，站点地址，充电枪接口类型")
    @GetMapping(value = "/queryChargingOrderList/{memberId:.+}/{page:.+}/{size:.+}")
    public CommonVo queryChargingOrderList(@ApiParam("会员编号") @PathVariable Integer memberId,
                                           @ApiParam("当前页数") @PathVariable Integer page,
                                           @ApiParam("当前记录数") @PathVariable Integer size) {
        return oldChargingService.queryChargingOrderList(memberId, page, size);
    }

    /**
      * @Author: JianMei Chen
      * @Date: 2020/4/29
      * 通过cityCode(行政区域编码)来查询充电站点信息
     */
    @ApiOperation(value = "根据cityCode(行政区域编码)来查询充电站点信息", notes = "根据cityCode来查询充电站点")
    @GetMapping(value = "/getStationList/{cityCode:.+}")
    public CommonVo getStationList(@ApiParam("行政区域编码") @PathVariable String cityCode) {
        return oldChargingService.getStationList(cityCode);
    }

    /**
    * @Description:  根据站点编号来获取快充枪数量，慢充枪数量，当前时间段的价格模板，营业时间
    * @Param: stationId 站点Id
    * @return:
    * @Author: JianMei Chen
    * @Date: 2020/4/22
    */
    @ApiOperation(value = "根据站点编号来获取快充枪数量，慢充枪数量，当前时间段的价格模板，营业时间", notes = "根据站点编号来获取快充枪数量，慢充枪数量，当前时间段的价格模板，营业时间")
    @GetMapping("/queryAllByStationId/{stationId:.+}")
    public CommonVo queryAllByStationId(@ApiParam("站点编号") @PathVariable Integer stationId) {
            return oldChargingService.queryAllByStationId(stationId);
    }

    /**
    * @Description: 根据站点编号来获取该站点所有价格模板列表
    * @param:
    * @return:
    * @Author: JianMei Chen
    * @Date: 2020/4/24
    */
    @ApiOperation(value = "根据站点编号来获取该站点所有价格模板列表")
    @GetMapping("/queryChargingPriceByStationId/{stationId:.+}")
    public CommonVo queryChargingPriceByStationId(@ApiParam("站点编号") @PathVariable Integer stationId){
        return oldChargingService.queryChargingPriceByStationId(stationId);
    }

    /**
     * 根据充电订单号查询充电订单
     *
     * @param orderNo
     * @return
     */
    @ApiOperation(value = "根据充电订单号查询充电订单", notes = "根据充电订单号查询充电订单")
    @GetMapping(value = "/getChargingByOrderNo/{orderNo:.+}")
    public CommonVo getChargingByOrderNo(@ApiParam("订单流水号") @PathVariable String orderNo) {
        return oldChargingService.getChargingByOrderNo(orderNo);
    }

    /**
     * 充电订单支付
     *
     * @param orderNo 订单号
     * @param payType 支付类型
     * @return
     */
    @ApiOperation(value = "支付", notes = "充电订单支付")
    @GetMapping(value = "/payChargingOrder/{orderNo:.+}/{payType}")
    public CommonVo payChargingOrder(@ApiParam("订单流水号") @PathVariable String orderNo,
                                     @ApiParam("支付方式") @PathVariable Integer payType,
                                     @ApiParam("会员编号") @PathVariable Integer memberId) {
        return oldChargingService.payChargingOrder(orderNo, payType,memberId);
    }
}
