package com.gdcdgj.charging.rest.order;

import com.gdcdgj.charging.api.localService.order.OrderService;
import com.gdcdgj.charging.api.vo.CommonVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.Reference;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

/**
 * @author JianMei Chen
 * @date 2020/05/09/11:31
 */
@RestController
@Api("订单模块")
@Slf4j
public class OrderController {

    @Reference
    private OrderService orderService;

    @ApiOperation("查询订单实时状态")
    @GetMapping("/api/order/{order_no}")
    public CommonVo order(@PathVariable @ApiParam("订单号") String order_no){
        log.info("订单号"+order_no);
        return orderService.order(order_no);
    }

    @ApiOperation("订单列表")
    @GetMapping("/api/order")
    public CommonVo orderList(@RequestParam(required = false) @ApiParam("充电状态") Integer charging_status,
                              @RequestParam(required = false) @ApiParam("支付状态") Integer payment_status,
                              HttpServletRequest request){
        String token = request.getHeader("token");
        return orderService.orderList(charging_status,payment_status,token);
    }

    @ApiOperation("获取订单评价标签")
    @GetMapping("/order/tags")
    public CommonVo orderTags(){
        return orderService.orderTags();
    }
}
