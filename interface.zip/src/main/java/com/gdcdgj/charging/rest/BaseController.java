package com.gdcdgj.charging.rest;

import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.servlet.http.HttpServletRequest;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * @Author: lw
 * @Date: 2019/5/29 15:27
 */
@Slf4j
public class BaseController {


    public Map<String,String> handleRequestParam(String jsonText){
        if(null == jsonText  || StringUtils.isBlank(jsonText)){
            return null;
        }else {
            Map<String, String> map = parseJSON(jsonText);
            if(CollectionUtils.isEmpty(map)){
                return null;
            }
            return map;
        }
    }

    protected Map<String, String> parseJSON(String jsonText){
        Map<String, String> paramData  = new HashMap<String, String>();
        JSONObject jsonObject = JSONObject.parseObject(jsonText);
        Set<String> set = jsonObject.keySet();
        Iterator<String> iter = set.iterator();
        while(iter.hasNext()){
            String key = iter.next();
            String value = jsonObject.getString(key);
            paramData.put(key, value);
        }
        return paramData;
    }
    protected Map<String, String> weixinParseParam(HttpServletRequest request) throws Exception {
        // 解析结果存储在HashMap
        Map<String, String> map = new HashMap<String, String>();
        InputStream inputStream = request.getInputStream();

        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        String FEATURE = null;
        try {
            FEATURE = "http://apache.org/xml/features/disallow-doctype-decl";
            dbf.setFeature(FEATURE, true);
            FEATURE = "http://xml.org/sax/features/external-general-entities";
            dbf.setFeature(FEATURE, false);
            FEATURE = "http://xml.org/sax/features/external-parameter-entities";
            dbf.setFeature(FEATURE, false);
            FEATURE = "http://apache.org/xml/features/nonvalidating/load-external-dtd";
            dbf.setFeature(FEATURE, false);
            dbf.setXIncludeAware(false);
            dbf.setExpandEntityReferences(false);
        } catch (ParserConfigurationException e) {
            log.error("ParserConfigurationException was thrown. The feature '" +
                    FEATURE + "' is probably not supported by your XML processor.");
        } catch (Exception e3) {
            log.error("Exception occurred, XXE may still possible: " + e3.getMessage());
        }
        DocumentBuilder safebuilder = dbf.newDocumentBuilder();
        Document document = safebuilder.parse(inputStream);
        document.getDocumentElement().normalize();
        NodeList nodeList = document.getDocumentElement().getChildNodes();
        int len = nodeList.getLength();
        for (int i = 0; i < len; ++i) {
            Node node = nodeList.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE) {
                Element element = (Element) node;
                map.put(element.getNodeName(), element.getTextContent());
            }
        }


        // 读取输入流
//		SAXReader reader = new SAXReader();
//		org.dom4j.Document document = reader.read(inputStream);
        // 得到xml根元素
//		org.dom4j.Element root = document.getRootElement();
//		// 得到根元素的所有子节点
//		List<org.dom4j.Element> elementList = root.elements();
//		// 遍历所有子节点
//		for (org.dom4j.Element e : elementList)
//			map.put(e.getName(), e.getText());

        // 释放资源
        inputStream.close();
        inputStream = null;

        return map;
    }
}
