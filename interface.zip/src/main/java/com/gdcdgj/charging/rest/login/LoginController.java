package com.gdcdgj.charging.rest.login;

import com.gdcdgj.charging.api.constant.RedisConstant;
import com.gdcdgj.charging.api.constant.ResultCode;
import com.gdcdgj.charging.api.entity.CustomerMember;
import com.gdcdgj.charging.api.localService.login.LoginService;
import com.gdcdgj.charging.api.util.RedisUtil;
import com.gdcdgj.charging.api.vo.CommonVo;
import com.gdcdgj.charging.rest.BaseController;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.Reference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * 登录api
 *
 * @author Changliang Tao
 * @date 2020/3/26 17:06
 * @since JDK 1.8
 */
@Slf4j
@Api
@RestController
public class LoginController extends BaseController {

    @Reference(version = "1.0.0", check = false)
    LoginService loginService;

    @Autowired
    RedisUtil redisUtil;

    /**
     * 登录
     *
     * @param
     * @return
     * @throws
     * @author Changliang Tao
     * @date 2020/4/20 14:29
     */
    @ApiOperation(value = "用户登录", notes = "根据手机号进行登录")
    @PostMapping(value = "/customer/login")
    public CommonVo login(@RequestBody @ApiParam("json字符串") String jsonString) {
        //将json字符串进行处理
        Map<String, String> map = handleRequestParam(jsonString);
        // 验证手机格式是否正确
        return loginService.login(map);
    }

    /**
     * 退出
     *
     * @param
     * @return
     * @throws
     * @author Changliang Tao
     * @date 2020/4/21 13:58
     */

    @ApiOperation(value = "用户退出", notes = "删除redis的Token")
    @PostMapping(value = "/customer/logout")
    public CommonVo logout(@RequestBody @ApiParam("json字符串") String jsonString) {
        Map<String, String> map = handleRequestParam(jsonString);
        String token=map.get("token");
        CustomerMember member = (CustomerMember) redisUtil.get(token);
        if (member != null) {
            redisUtil.del(token);
            redisUtil.del(RedisConstant.MEMBER_LOGIN_TOKEN + member.getPhone());
            return new CommonVo(null);
        }
        return new CommonVo(ResultCode.FAIL_CODE, "token错误", null);
    }
}
