package com.gdcdgj.charging.rest.member;

import com.gdcdgj.charging.api.localService.member.CustomerService;
import com.gdcdgj.charging.api.vo.CommonVo;
import com.gdcdgj.charging.rest.BaseController;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.models.auth.In;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.Reference;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

/**
 * @author JianMei Chen
 * @date 2020/05/08/8:37
 */
@RestController
@Slf4j
@Api
public class CustomerController extends BaseController {

    @Reference
    private CustomerService customerService;

    @ApiOperation("会员相关信息")
    @GetMapping("/api/customer/profile")
    public CommonVo profile(HttpServletRequest request){
        String token = request.getHeader("token");
        return customerService.profile(token);
    }

    @ApiOperation("会员支付充值后通知回调")
    @PostMapping("/customer/recharge/notify")
    public String rechargeNotify(@RequestBody @ApiParam("json字符串") String jsonText,
                               HttpServletRequest request){
        Map<String, String> map = handleRequestParam(jsonText);
        return customerService.rechargeNotify(map);
    }

    @ApiOperation("会员收藏站点集合")
    @GetMapping("/api/customer/collection_station")
    public CommonVo collectionStation(HttpServletRequest request,
                                      @ApiParam("当前页数") @RequestParam Integer page,
                                      @ApiParam("当前页数记录数") @RequestParam Integer pagesize){
        String token = request.getHeader("token");
        return customerService.collectionStation(token,page,pagesize);
    }

    @ApiOperation("会员收藏站点或者取消收藏站点")
    @PostMapping("/api/customer/collection/{station_id}/{type}")
    public CommonVo collection(@ApiParam("站点编号") @PathVariable Integer station_id
                               ,@ApiParam("标识符，1表示收藏，2表示取消收藏") @PathVariable Integer type,
                               HttpServletRequest request){
        String token = request.getHeader("token");
        return customerService.collection(station_id,type,token);
    }

    @ApiOperation("会员充值/退款记录")
    @GetMapping("/api/customer/money_record")
    public CommonVo moneyRecord(@RequestParam @ApiParam("类型，1表示充值，2表示退款") Integer type,
                                @RequestParam(defaultValue = "1") @ApiParam("当前页数") Integer page,
                                @RequestParam(defaultValue = "10") @ApiParam("当前页数记录数") Integer pagesize,
                                HttpServletRequest request){
        String token = request.getHeader("token");
        return customerService.moneyRecord(type,token,page,pagesize);
    }

    @ApiOperation("绑定车辆")
    @PostMapping("/api/customer/add_carnumber")
    public CommonVo addCarNumber(@ApiParam("车牌号") @RequestParam String carnumber,
                                 @ApiParam("是否为默认车牌号") @RequestParam Boolean is_default,
                                 HttpServletRequest request){
        String token = request.getHeader("token");
        return customerService.addCarNumber(token,carnumber,is_default);
    }

    @ApiOperation("设置车牌号为默认/删除")
    @PostMapping("/api/customer/alter")
    public CommonVo alterCarnumberInfo(@ApiParam("车辆编号") @RequestParam Integer id,
                                       @ApiParam("1表示设置默认，2表示删除车辆") @RequestParam Integer type,
                                       HttpServletRequest request){
        String token = request.getHeader("token");
        return customerService.alertCarnumberInfo(id,type,token);
    }

    @ApiOperation("编辑车辆")
    @PostMapping("/customer/edit_carnumber")
    public CommonVo editCarNumber(@ApiParam("车辆编号") @RequestParam Integer id,
                                  @ApiParam("车牌号") @RequestParam String carnumber,
                                  @ApiParam("是否为默认") @RequestParam Boolean is_default){
        return customerService.editCarNumber(id,carnumber,is_default);
    }

    @ApiOperation("显示所有会员车辆信息")
    @GetMapping("/api/customer/carnumber_list")
    public CommonVo carNumberList(HttpServletRequest request){
        String token = request.getHeader("token");
        return customerService.carNumberList(token);
    }

    @ApiOperation("支付")
    @PostMapping("/api/customer/pay")
    public CommonVo pay(@ApiParam("订单号") @RequestParam String order_no){
        return customerService.pay(order_no);
    }
}
