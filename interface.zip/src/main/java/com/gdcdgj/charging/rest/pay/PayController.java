package com.gdcdgj.charging.rest.pay;

import com.gdcdgj.charging.api.localService.pay.PayService;
import com.gdcdgj.charging.api.util.pay.wx.IpUtils;
import com.gdcdgj.charging.api.vo.CommonVo;
import com.gdcdgj.charging.rest.BaseController;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.Reference;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Context;
import java.io.PrintWriter;
import java.util.Map;

/**
 * @author JianMei Chen
 * @date 2020/04/28/14:25
 */
@Api
@Slf4j
@RestController
@RequestMapping("/api/pay")
public class PayController extends BaseController {

    @Reference
    private PayService payService;

    @ApiOperation(value = "会员充值",notes = "会员充值")
    @PostMapping("/preloadCharge/{memberId}/{payMethod}/{money}")
    public CommonVo preloadCharge(@RequestBody String jsonText,HttpServletRequest request){
        Map<String, String> map = handleRequestParam(jsonText);
        String ipAddr = IpUtils.getIpAddr(request);
        map.put("ip",ipAddr);
        return payService.preloadCharge(map);
    }

    @ApiOperation("会员预充值通莞回调")
    @PostMapping("/tg")
    public void tongguanNotify(@RequestBody String jsonText, HttpServletResponse response){
        PrintWriter out = null;
        try {
            out = response.getWriter();
            log.info("jsonText============>{}",jsonText);
            Map<String, String> map = handleRequestParam(jsonText);
            payService.tgChargeResult(map);
            out.write("SUCCESS");//回复通莞金服已经成功
            log.info("无论支付成功还是失败，都得回复通莞金服已经处理成功......");
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage(), e);
        } finally {
            if (out != null) {
                out.flush();
                out.close();
            }
        }
    }

    @ApiOperation("去通莞金服主动查询订单")
    @GetMapping("/orderQuery")
    public CommonVo orderQuery(@RequestBody String jsonText){
        Map<String, String> map = handleRequestParam(jsonText);
        return payService.orderQuery(map);
    }

    @ApiOperation("充电微信支付回调")
    @PostMapping("/wxpayChargingOrderPayNotify")
    public String wxpayChargingOrderPayNotify(@Context HttpServletRequest request, @Context  HttpServletResponse response) {
        //解析微信返回的数据
        try {
            Map<String, String> weixinResultMap = weixinParseParam(request);
            weixinResultMap.put("type","WX");
            payService.payChargingOrderCallBack(weixinResultMap);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "SUCCESS";
    }
}
