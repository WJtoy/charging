package com.gdcdgj.charging.rest.station;

import com.gdcdgj.charging.api.localService.station.StationService;
import com.gdcdgj.charging.api.vo.CommonVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.apache.dubbo.config.annotation.Reference;
import org.springframework.web.bind.annotation.*;

/**
 * @author JianMei Chen
 * @date 2020/05/06/13:50
 */
@Api
@RestController
public class StationController {

    @Reference
    private StationService stationService;

    @ApiOperation("查询站点列表")
    @GetMapping("/station")
    public CommonVo findStationListBySearch(@ApiParam("第几页") @RequestParam Integer page,
                                            @ApiParam("每页条目的数量") @RequestParam Integer pagesize,
                                            @ApiParam("过滤符合标签") @RequestParam(required = false) Integer tags,
                                            @ApiParam("纬度") @RequestParam Double latitude,
                                            @ApiParam("经度") @RequestParam Double longitude,
                                            @ApiParam("多少公里") @RequestParam Double distance,
                                            @ApiParam("模糊查询站点") @RequestParam(required = false) String name_like){
        return stationService.findStationList(page,pagesize,tags,latitude,longitude,distance,name_like);
    }

    @ApiOperation("查询站点标签")
    @GetMapping("/station/tags")
    public CommonVo findStationTags(){
        return stationService.findStationTags();
    }

    @ApiOperation("站点详情")
    @GetMapping("/station/{station_id}")
    public CommonVo stationDesc(@PathVariable @ApiParam("站点编号") Integer station_id){
        return stationService.stationDesc(station_id);
    }

    @ApiOperation("根据充电枪编码查站点Id")
    @GetMapping("/api/station/q_by_cntr/{cntr_code}")
    public CommonVo queryStationByCode(@PathVariable @ApiParam("枪编码")String cntr_code){
        return stationService.queryStationByCode(cntr_code);
    }

    @ApiOperation("站点评价标签")
    @GetMapping("/station/evaluate_tags")
    public CommonVo evaluateTags(){
        return stationService.evaluateTags();
    }
}
