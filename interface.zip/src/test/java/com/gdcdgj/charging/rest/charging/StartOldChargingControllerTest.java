package com.gdcdgj.charging.rest.charging;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.standaloneSetup;

import com.gdcdgj.charging.api.constant.RedisConstant;
import com.gdcdgj.charging.api.localService.charging.ChargingOrderService;
import com.gdcdgj.charging.api.localService.charging.ChargingService;
import com.gdcdgj.charging.api.localService.login.LoginService;
import com.gdcdgj.charging.api.util.RedisUtil;
import com.gdcdgj.charging.api.vo.CommonVo;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

/**
 * 扫码充电测试
 *
 * @author Changliang Tao
 * @date 2020/4/24 9:03
 * @since JDK 1.8
 */
@SpringBootTest
@AutoConfigureMockMvc
class StartOldChargingControllerTest {

    @Autowired
    MockMvc mockMvc;

    @Resource
    ChargingService chargingService;

    @Resource
    LoginService loginService;

    @Resource
    RedisUtil redisUtil;

    @Resource
    ChargingOrderService chargingOrderService;

    @Test
    void startChargingByScan() throws Exception {
        MockHttpServletRequestBuilder requestBuilder = post("/api/charging/startChargingByScan/20e2/2020-04-24 09:11:00")
                .header("token", "token:a5a7b48w1vsogfpnit1b29h5km2x8xn312ri52uafbwh0qqeibem74dyqbo7xq1l0x4yi76ruyd47au5p8o9ksebvq9l45k9n2tc");
        mockMvc.perform(requestBuilder)
                .andExpect(status().isOk())
                .andDo(print());
    }

    @Test
    public void startCharging() throws Exception{
        Map map = new HashMap();
        map.put("phone","13903904434");
        CommonVo commonVo = loginService.login(map);
        String token = (String) redisUtil.get(RedisConstant.MEMBER_LOGIN_TOKEN + "13903904434");

        chargingService.start(token,"002","2020-05-19",0);
    }







}
