package com.gdcdgj.charging.service.provider;

import com.baomidou.mybatisplus.extension.plugins.PaginationInterceptor;
import com.gdcdgj.charging.api.config.RedisConfig;
import com.gdcdgj.charging.service.provider.util.CustomProperties;
import org.apache.dubbo.config.spring.context.annotation.EnableDubbo;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;

/**
 * @author Changliang Tao
 * @date 2020/4/17 11:35
 * @since JDK 1.8
 */
@SpringBootApplication
@EnableDubbo
@Import(RedisConfig.class)
@MapperScan(value = "com.gdcdgj.charging.service.provider.mapper")
@EnableConfigurationProperties({CustomProperties.class})
public class ServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(ServiceApplication.class, args);
    }

    //配置分页插件
    @Bean
    public PaginationInterceptor paginationInterceptor(){
        return new PaginationInterceptor();
    }

}
