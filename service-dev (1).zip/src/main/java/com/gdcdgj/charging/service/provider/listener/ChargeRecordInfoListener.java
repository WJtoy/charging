package com.gdcdgj.charging.service.provider.listener;

import static com.gdcdgj.charging.api.constant.RabbitmqConstant.CHARGEINFO_STATUS_QUEUE;

import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.List;

import com.alibaba.fastjson.JSON;
import com.gdcdgj.charging.api.vo.order.PeakTemplateVo;
import com.gdcdgj.charging.service.provider.util.StringUtils;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.gdcdgj.charging.api.entity.CustomerChargingorder;
import com.gdcdgj.charging.api.enums.ChargingOrderStatusEnum;
import com.gdcdgj.charging.api.util.RedisUtil;
import com.gdcdgj.charging.api.vo.srv2gw.ChargeRecordInfo;
import com.gdcdgj.charging.service.provider.mapper.AssetsConnectorMapper;
import com.gdcdgj.charging.service.provider.mapper.CustomerChargingorderMapper;
import com.gdcdgj.charging.service.provider.mapper.CustomerChargingordertracksMapper;
import com.gdcdgj.charging.service.provider.mapper.CustomerMemberMapper;
import com.gdcdgj.charging.service.provider.service.AssetsChargingpileService;

import lombok.extern.slf4j.Slf4j;

/**
 * 监听桩桩充电结束后信息状态上报
 * 注： 
 *  科旺桩在充电时间隔实时上报充电记录
 *  宜步桩在一次充电结束后上报充电记录
 * @author ydc
 * @date 2020/4/18 15:00
 * @since JDK 1.8
 */
@Slf4j
@Component

public class ChargeRecordInfoListener {

	@Autowired
	AssetsChargingpileService chargingpileService;

	@Autowired
	RedisUtil redisUtil;

	@Autowired
	CustomerChargingorderMapper customerChargingorderMapper;

	@Autowired
	CustomerMemberMapper customerMemberMapper;

	@Autowired
	AssetsConnectorMapper assetsConnectorMapper;

	@Autowired
	CustomerChargingordertracksMapper customerChargingordertracksMapper;
	@Autowired
	AmqpTemplate amqpTemplate;

    @RabbitListener(queues = CHARGEINFO_STATUS_QUEUE)
    public void handlerMessage(ChargeRecordInfo chargeRecordInfo) throws UnsupportedEncodingException {
		this.onHandlerMessage(chargeRecordInfo);
    }
	public void onHandlerMessage(ChargeRecordInfo chargeRecordInfo){
		try {
			String code = chargeRecordInfo.getCode(chargeRecordInfo.getPileCode(), (int) chargeRecordInfo.getConnectorNo());
			//从redis中获取当前用户id
			int key = (int) redisUtil.get(code);
			//根据用户id和枪编码以及订单状态获取订单

			CustomerChargingorder order = null;
			CustomerChargingorder orderNew = new CustomerChargingorder();
			QueryWrapper<CustomerChargingorder> orderWrapper = new QueryWrapper<>();
			orderWrapper.eq("member_id", key);
			orderWrapper.eq("connector_code", code);
			if (chargeRecordInfo.getProviderId() == 1) {
				//科旺充电中发送充电信息包
				log.info("监听科旺发送充电信息包");
				orderWrapper.in("charging_status", ChargingOrderStatusEnum.CHARGING.getValue(), ChargingOrderStatusEnum.ENDING.getValue());
			} else if (chargeRecordInfo.getProviderId() == 2) {
				//宜步充电结束发送一次充电信息包
				log.info("监听宜步发送充电信息包");
				orderWrapper.in("charging_status", ChargingOrderStatusEnum.CHARGING.getValue(), ChargingOrderStatusEnum.ENDING.getValue());
			}
			order = customerChargingorderMapper.selectOne(orderWrapper);

			if (order != null) {
				log.info(orderNew.toString() + "-----------------》新状态");
				orderNew.setId(order.getId());
				orderNew.setStopTime(new Date());
				orderNew.setSocStart((double) chargeRecordInfo.getStartSOC());//起始soc
				orderNew.setSocEnd((double) chargeRecordInfo.getStopSOC());//结束SOC电量
				orderNew.setElectricStart(chargeRecordInfo.getBeforeAmmeterNum());//起始电表度数
				orderNew.setElectricEnd(chargeRecordInfo.getAfterAmmeterNum());//结束电表度数
				orderNew.setWarningCode(chargeRecordInfo.getFalutCode());
				orderNew.setTotalChargingQuantity(chargeRecordInfo.getKwh());    //充电量
				orderNew.setTotalChargingTime(chargeRecordInfo.getChargeTimeLen());    //充电长度
				orderNew.setChargingStatus(4);
				orderNew.setVinCode(chargeRecordInfo.getCarVIN());
				if (chargeRecordInfo.getChargeStopCause()==1){
					orderNew.setStopMethod(1);
				}else if (chargeRecordInfo.getChargeStopCause() == 5){
					orderNew.setStopMethod(5);
				}else if (chargeRecordInfo.getChargeStopCause() == 3){
					orderNew.setStopMethod(3);
				}
					if (order.getPriceUnit() != null) {
						List<PeakTemplateVo> json = JSON.parseArray(order.getPriceUnit(), PeakTemplateVo.class);
						Date date = new Date();
						//判断峰平谷时电量
						log.info("《--峰平谷是否为空--》峰平谷" + json.toString());
						for (PeakTemplateVo peakTemplateVo : json) {
							String now = date.getHours() + ":" + date.getMinutes();
							if (StringUtils.isInTime(peakTemplateVo.getStartTime() + "-" + peakTemplateVo.getEndTime(), now)) {
								log.info("峰平谷-------------------->");
								if (peakTemplateVo.getPnvType() == 1) {
									log.info("峰=》"+peakTemplateVo.getPnvType());
									orderNew.setPeaksChargingTime(chargeRecordInfo.getChargeTimeLen());	//时长
									orderNew.setPeaksChargingQuantity(chargeRecordInfo.getKwh());	//电量
									orderNew.setPeaksChargingPrice(chargeRecordInfo.getKwh() * peakTemplateVo.getChargingPrice());//峰时电费
									orderNew.setPeaksServicePrice(chargeRecordInfo.getKwh() * peakTemplateVo.getServicePrice());//服务费
								} else if (peakTemplateVo.getPnvType() == 2) {
									log.info("平=》"+peakTemplateVo.getPnvType());
									orderNew.setNormalChargingTime(chargeRecordInfo.getChargeTimeLen());//充电时长
									orderNew.setNormalChargingQuantity(chargeRecordInfo.getKwh());//充电电量
									orderNew.setNormalChargingPrice(chargeRecordInfo.getKwh() * peakTemplateVo.getChargingPrice());//平时电费
									orderNew.setNormalServicePrice(chargeRecordInfo.getKwh() * peakTemplateVo.getServicePrice());//平时服务费
								} else if (peakTemplateVo.getPnvType() == 3) {
									log.info("谷=》"+peakTemplateVo.getPnvType());
									orderNew.setValleysChargingTime(chargeRecordInfo.getChargeTimeLen());//充电时长
									orderNew.setValleysChargingQuantity(chargeRecordInfo.getKwh());//充电电量
									orderNew.setValleysChargingPrice(chargeRecordInfo.getKwh() * peakTemplateVo.getChargingPrice());//电费
									orderNew.setValleysServicePrice(chargeRecordInfo.getKwh() * peakTemplateVo.getServicePrice());//服务费
								}else{
									log.info("其他时段-》为平-》"+peakTemplateVo.getPnvType());
									orderNew.setNormalChargingTime(chargeRecordInfo.getChargeTimeLen());//充电时长
									orderNew.setNormalChargingQuantity(chargeRecordInfo.getKwh());//充电电量
									orderNew.setNormalChargingPrice(chargeRecordInfo.getKwh() * peakTemplateVo.getChargingPrice());//电费
									orderNew.setNormalServicePrice(chargeRecordInfo.getKwh() * peakTemplateVo.getServicePrice());//服务费
								}
							}
						}
						//总服务费
						Double serviceTotal = orderNew.getNormalServicePrice() + orderNew.getValleysServicePrice() + orderNew.getPeaksServicePrice();
						orderNew.setTotalServicePrice(serviceTotal);
						//总充电费
						Double chargingPriceTotal = orderNew.getNormalChargingPrice() + orderNew.getValleysChargingPrice() + orderNew.getPeaksChargingPrice();
						orderNew.setTotalChargingPrice(chargingPriceTotal);
						//总费用
						Double totalPriceUnit = serviceTotal + chargingPriceTotal;
						orderNew.setTotalPrice(totalPriceUnit);
					}
				}

				orderNew.setBillTime(new Date());
				customerChargingorderMapper.updateById(orderNew);
				if (redisUtil.hasKey(code)) redisUtil.del(code);
				log.info("桩编号==》  {}", chargeRecordInfo.getPileCode());
			}catch(Exception e){
				log.error("ChargeRecordInfoListener 监听桩发送充电记录包异常： {}", e);
			}
		}
}