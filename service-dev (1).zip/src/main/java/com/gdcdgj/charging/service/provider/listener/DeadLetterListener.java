package com.gdcdgj.charging.service.provider.listener;

import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

import java.io.UnsupportedEncodingException;

import static com.gdcdgj.charging.api.constant.RabbitmqConstant.DEAD_QUEUE_NAME;
import static com.gdcdgj.charging.api.constant.RabbitmqConstant.MESSAGE_TTL;

/**
 * 死信监听
 *
 * @author Changliang Tao
 * @date 2020/4/19 11:10
 * @since JDK 1.8
 */
@Slf4j
@Component
public class DeadLetterListener {
    @RabbitListener(queues = DEAD_QUEUE_NAME)
    public void handlerMessage(Object message) throws UnsupportedEncodingException {
        log.error("死信队列消息==> {}\n消息过期时间===> {} 秒", message, MESSAGE_TTL / 1000);
    }
}
