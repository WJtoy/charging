package com.gdcdgj.charging.service.provider.listener;

import static com.gdcdgj.charging.api.constant.RabbitmqConstant.MOUDLEINFO_STATUS_QUEUE;
import static com.gdcdgj.charging.api.enums.ChargingOrderStatusEnum.*;

import java.io.UnsupportedEncodingException;
import java.text.DecimalFormat;
import java.util.*;

import javax.annotation.Resource;

import com.gdcdgj.charging.api.entity.*;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.gdcdgj.charging.api.constant.RabbitmqConstant;
import com.gdcdgj.charging.api.enums.ChargingOrderStatusEnum;
import com.gdcdgj.charging.api.enums.ConnectorStatusEnum;
import com.gdcdgj.charging.api.enums.MsgProviderEnum;
import com.gdcdgj.charging.api.enums.PileCtrlParamType;
import com.gdcdgj.charging.api.util.RedisUtil;
import com.gdcdgj.charging.api.vo.order.PeakTemplateVo;
import com.gdcdgj.charging.api.vo.srv2gw.ModuleChargingInfo;
import com.gdcdgj.charging.api.vo.srv2gw.PileCtrl;
import com.gdcdgj.charging.service.provider.mapper.AssetsConnectorMapper;
import com.gdcdgj.charging.service.provider.mapper.CustomerChargingorderMapper;
import com.gdcdgj.charging.service.provider.mapper.CustomerChargingordertracksMapper;
import com.gdcdgj.charging.service.provider.mapper.CustomerMemberMapper;
import com.gdcdgj.charging.service.provider.service.AssetsChargingpileService;

import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;

/**
 * 监听桩桩充电结束后信息状态上报/宜步间隔上报
 *
 * @author ydc
 * @date 2020/4/18 15:00
 * @since JDK 1.8
 */
@Slf4j
@Component
public class MoubleInfoListener {

	@Autowired
	AssetsChargingpileService chargingpileService;
	@Autowired
	RedisUtil redisUtil;

	@Resource
	CustomerChargingorderMapper customerChargingorderMapper;

	@Resource
	CustomerMemberMapper customerMemberMapper;

	@Resource
	AssetsConnectorMapper assetsConnectorMapper;
	@Resource
	CustomerChargingordertracksMapper customerChargingordertracksMapper;

	@Resource
	AmqpTemplate amqpTemplate;
	
    @RabbitListener(queues = MOUDLEINFO_STATUS_QUEUE)
    public void handlerMessage(ModuleChargingInfo moduleChargingInfo) {
    	this.onHandlerMessage(moduleChargingInfo);

    }
    public void onHandlerMessage(ModuleChargingInfo moduleChargingInfo){
		//桩充电状态上报信息
		log.info("处理宜步桩充电状态上报信息");

		//修改表customer_chargingOrder 和 customer_chargingOrderTracks
		if(moduleChargingInfo.getProviderId() == MsgProviderEnum.IB_PROVIDER.getValue()) {

			//根据订单获取枪id  获取枪信息

			Iterator i = moduleChargingInfo.getStateMap().keySet().iterator();
			while (i.hasNext()) {
				String sno = i.next().toString();
				String code = moduleChargingInfo.getCode(moduleChargingInfo.getPileCode(),Integer.valueOf(sno));

				Byte connectedByte = moduleChargingInfo.getConnectedStateMap().get(Byte.valueOf(sno));	//枪的连接状态
				Byte stateByte = moduleChargingInfo.getStateMap().get(Byte.valueOf(sno));//充电位的状态

				log.info(moduleChargingInfo.getConnectedStateMap().toString()+"充电位的状态"+stateByte+"----->"+code+"i的值："+sno);

				//根据桩编码和枪获取用户id的键
				CustomerMember customerMember = null;
				CustomerChargingorder customerChargingorder = null;
				AssetsConnector assetsConnector = null;
				Integer totalAn = moduleChargingInfo.getAhMap().get(Byte.valueOf(sno));    //位置N本次累计充电Ah
				Double totalKw = moduleChargingInfo.getKwhMap().get(Byte.valueOf(sno))*0.01;    //位置N电表度数kwh

				Double totalCharging = moduleChargingInfo.getKwhTotalMap().get(Byte.valueOf(sno)).doubleValue();	//累计总充电量
				Double totalDate = moduleChargingInfo.getTimeMap().get(Byte.valueOf(sno)) * 60; //位置N本次累计充电时间
				Byte socByte = moduleChargingInfo.getSocNowMap().get(Byte.valueOf(sno));	//充电枪位置N当前充电SOC   Map<充电枪位置, soc>
				Byte socBegin = moduleChargingInfo.getSocBeginMap().get(Byte.valueOf(sno));	//起始soc电量
				Double current = moduleChargingInfo.getCurrentMap().get(Byte.valueOf(sno)); //电流
				Double voltage = moduleChargingInfo.getVoltageMap().get(Byte.valueOf(sno)); //电压
				Double leftTime = moduleChargingInfo.getRemainTimeMap().get(Byte.valueOf(sno)) * 60; //预计剩余时间

				if(redisUtil.hasKey(code)) {
					log.info(code+"用户<---------");
					//从redis中获取当前充电用户id
					int key = (int)redisUtil.get(code);
					//根据用户id获取用户信息
					customerMember = customerMemberMapper.selectById(key);
					//根据用户id和订单状态（充电中）获取用户正在充电的订单
					QueryWrapper<CustomerChargingorder> orderWrapper = new QueryWrapper<>();
					orderWrapper.eq("member_id", key);
					orderWrapper.in("charging_status", CHARGING.getValue(),ENDING.getValue());
					customerChargingorder = customerChargingorderMapper.selectOne(orderWrapper);
					//根据枪编码获取枪信息

					QueryWrapper<AssetsConnector> assetsConnectorQueryWrapper = new QueryWrapper<>();
					assetsConnectorQueryWrapper.eq("code",code);
					assetsConnector = assetsConnectorMapper.selectOne(assetsConnectorQueryWrapper);	//获取枪
					//创建订单追踪表
					CustomerChargingordertracks customerChargingordertracks = new CustomerChargingordertracks();
					if(stateByte == ConnectorStatusEnum.CONNECTOR_CHARGING.getValue()) {
						if (customerChargingorder != null){
						//钱包额度加信用额==wallet
						Double wallet = (customerMember.getWallet() == null ? 0 : customerMember.getWallet()) + customerMember.getCredit();
						Double totalPrice = customerChargingorder.getTotalPrice() == null ? 0 : customerChargingorder.getTotalPrice();
						//当前日期
						customerChargingordertracks.setOrderId(customerChargingorder.getId());
							if (wallet - 1.0d > totalPrice) {
							if (customerChargingorder.getPriceUnit() != null) {
								List<PeakTemplateVo> json = JSON.parseArray(customerChargingorder.getPriceUnit(), PeakTemplateVo.class);
								Date date = new Date();
								//判断峰平谷时电量
								log.info("《--峰平谷是否为空--》峰平谷" + json.toString());
								for (PeakTemplateVo peakTemplateVo : json) {
									String now = date.getHours() + ":" + date.getMinutes();

									if (com.gdcdgj.charging.service.provider.util.StringUtils.isInTime(peakTemplateVo.getStartTime() + "-" + peakTemplateVo.getEndTime(), now)) {
										log.info("轨迹峰平谷-------------------->");
										if (peakTemplateVo.getPnvType() == 1) {
											log.info("轨迹峰=》"+peakTemplateVo.getPnvType());
											customerChargingorder.setPeaksChargingTime(totalDate.intValue());	//时长
											customerChargingorder.setPeaksChargingQuantity(totalCharging);	//电量
											customerChargingorder.setPeaksChargingPrice(totalCharging * peakTemplateVo.getChargingPrice());//峰时电费
											customerChargingorder.setPeaksServicePrice(totalCharging * peakTemplateVo.getServicePrice());//服务费

										} else if (peakTemplateVo.getPnvType() == 2) {
											log.info("轨迹平=》"+peakTemplateVo.getPnvType());
											customerChargingorder.setNormalChargingTime(totalDate.intValue());//充电时长
											customerChargingorder.setNormalChargingQuantity(totalCharging);//充电电量
											customerChargingorder.setNormalChargingPrice(totalCharging * peakTemplateVo.getChargingPrice());//平时电费
											customerChargingorder.setNormalServicePrice(totalCharging * peakTemplateVo.getServicePrice());//平时服务费
										} else if (peakTemplateVo.getPnvType() == 3) {
											log.info("轨迹谷=》"+peakTemplateVo.getPnvType());
											customerChargingorder.setValleysChargingTime(totalDate.intValue());//充电时长
											customerChargingorder.setValleysChargingQuantity(totalCharging);//充电电量
											customerChargingorder.setValleysChargingPrice(totalCharging * peakTemplateVo.getChargingPrice());//电费
											customerChargingorder.setValleysServicePrice(totalCharging * peakTemplateVo.getServicePrice());//服务费
										}else{
											log.info("轨迹其他时段-》为平-》"+peakTemplateVo.getPnvType());
											customerChargingorder.setNormalChargingTime(totalDate.intValue());//充电时长
											customerChargingorder.setNormalChargingQuantity(totalCharging);//充电电量
											customerChargingorder.setNormalChargingPrice(totalCharging * peakTemplateVo.getChargingPrice());//电费
											customerChargingorder.setNormalServicePrice(totalCharging * peakTemplateVo.getServicePrice());//服务费
										}
									}
								}
								//总服务费
								Double serviceTotal = customerChargingorder.getNormalServicePrice() + customerChargingorder.getValleysServicePrice() + customerChargingorder.getPeaksServicePrice();
								customerChargingorder.setTotalServicePrice(serviceTotal);
								//总充电费
								Double chargingPriceTotal = customerChargingorder.getNormalChargingPrice() + customerChargingorder.getValleysChargingPrice() + customerChargingorder.getPeaksChargingPrice();
								customerChargingorder.setTotalChargingPrice(chargingPriceTotal);
								//总费用
								Double totalPriceUnit = serviceTotal + chargingPriceTotal;
								customerChargingorder.setTotalPrice(totalPriceUnit);

								DecimalFormat df = new DecimalFormat("#.000");

								//QueryWrapper<CustomerChargingorder> queryWrapper = new QueryWrapper();
//								queryWrapper.eq("id", customerChargingorder.getId());
								customerChargingorder.setTotalChargingTime(totalDate.intValue());
								customerChargingorder.setTotalChargingQuantity(totalCharging);
								customerChargingorder.setTotalChargingPrice(Double.valueOf(df.format(chargingPriceTotal)));
								customerChargingorder.setCurrent(current);
								customerChargingorder.setVoltage(voltage);
								customerChargingorder.setElectricEnd(totalKw);
								customerChargingorder.setTotalServicePrice(Double.valueOf(df.format(serviceTotal)));
								customerChargingorder.setTotalPrice(Double.valueOf(df.format(totalPriceUnit)));
								customerChargingorder.setSocStart(socBegin.doubleValue());
								customerChargingorder.setSocEnd(socByte.doubleValue());
								customerChargingorder.setWarningCode((int) moduleChargingInfo.getFaultCode());
								customerChargingorder.setLeftTime(leftTime.intValue());
//								customerChargingorderMapper.update(customerChargingorder, queryWrapper);
								customerChargingorderMapper.updateById(customerChargingorder);

								customerChargingordertracks.setAddTime(new Date());
								customerChargingordertracks.setTotalChargingTime(totalDate.intValue());	//总充电时长
								customerChargingordertracks.setTotalChargingQuantity(totalCharging.doubleValue());	//总充电电量
								customerChargingordertracks.setTotalPrice(totalPriceUnit);
								customerChargingordertracks.setTotalChargingPrice(chargingPriceTotal);	//总充电费
								customerChargingordertracks.setTotalServicePrice(serviceTotal);	//总服务费
								customerChargingordertracks.setTotalPrice(customerChargingordertracks.getTotalChargingPrice() + customerChargingordertracks.getTotalServicePrice());//总费用
								customerChargingordertracks.setSoc(Double.valueOf(socByte));	//当前SOC
								customerChargingordertracks.setElectric(totalKw);	//当前电表度数
								customerChargingordertracks.setRequireCurrent(current);	//需求电流
								customerChargingordertracks.setRequireVoltage(voltage);	//需求电压
								customerChargingordertracks.setCurrent(current);
								customerChargingordertracks.setVoltage(voltage);
								customerChargingordertracks.setLeftTime(leftTime.intValue()); //预计剩余时间
								customerChargingordertracks.setPower(current * voltage);
								//充电信息记录订单追踪表
								customerChargingordertracksMapper.insert(customerChargingordertracks);

								log.info("根据充电信息记录订单追踪表信息：{}", customerChargingordertracks == null ? "失败" : "成功");
								QueryWrapper<CustomerChargingordertracks> orderWrapperNews = new QueryWrapper<>();
								orderWrapperNews.eq("order_id",customerChargingorder.getId());
								List<CustomerChargingordertracks> customerChargingordertracksList = customerChargingordertracksMapper.selectList(orderWrapperNews);
									if (customerChargingordertracksList.size() > 3) {
										if (customerChargingordertracksList.get(customerChargingordertracksList.size()-2).getVoltage().intValue() == 0) {
											CustomerChargingorder customerChargingorderNews = new CustomerChargingorder();
											customerChargingorderNews.setId(customerChargingorder.getId());
											customerChargingorderNews.setChargingStatus(5);
											customerChargingorderNews.setStopMethod(5);
											customerChargingorderNews.setBillTime(new Date());
											customerChargingorderNews.setStopTime(new Date());
											customerChargingorderMapper.updateById(customerChargingorderNews);
										}
								}
								} else {
									log.error("计价标准未设置 出错");
								}
							}else {
									log.info("余额不足------------------->"+totalPrice);
									CustomerChargingorder customerChargingorderNews = new CustomerChargingorder();
									customerChargingorderNews.setId(customerChargingorder.getId());
									customerChargingorderNews.setChargingStatus(3);
									customerChargingorderNews.setStopMethod(4);
									customerChargingorderNews.setStopTime(new Date());
									customerChargingorderMapper.updateById(customerChargingorderNews);
									moduleChargingInfo.setConnectorNo(Integer.valueOf(sno));
									stopSendMq(moduleChargingInfo);
								}
						}
					}else if (stateByte == ConnectorStatusEnum.END_CHARGING.getValue() || stateByte == ConnectorStatusEnum.FREE.getValue()) {
						   log.info("结束状态---->"+stateByte+"---------------"+code);
							if (redisUtil.hasKey(code)) {
								int keyNew = (int)redisUtil.get(code);
								QueryWrapper<CustomerChargingorder> orderWrapperNew = new QueryWrapper<>();
								orderWrapperNew.eq("member_id", keyNew);
								orderWrapperNew.in("charging_status",CHARGING.getValue() ,ENDING.getValue());
								customerChargingorder = customerChargingorderMapper.selectOne(orderWrapperNew);
								if (customerChargingorder != null) {
									log.info("状态" + stateByte + "================" + code);
									generateFinalOrder(customerChargingorder, moduleChargingInfo);    //最终订单
									//充电结束 redis删除充电用户id缓存
								}else {
									if (connectedByte.intValue() == 0){
										QueryWrapper<CustomerChargingorder> orderWrapper1 = new QueryWrapper<>();
										orderWrapper1.eq("member_id", keyNew);
										orderWrapper1.in("charging_status",PREPARE_CHARGING.getValue(),CHARGING.getValue() ,ENDING.getValue());
										customerChargingorder = customerChargingorderMapper.selectOne(orderWrapper1);
										if(customerChargingorder != null) {
											customerChargingorder.setChargingStatus(4);
											customerChargingorder.setBillTime(new Date());
											customerChargingorder.setStopTime(new Date());
											customerChargingorderMapper.updateById(customerChargingorder);
										}
									}
								}
						}
					}
				}
				//根据枪编码获取枪信息
				QueryWrapper<AssetsConnector> mappers = new QueryWrapper<AssetsConnector>();
				mappers.eq("code", code);
				AssetsConnector assetsConnector2 = assetsConnectorMapper.selectOne(mappers);
				if (assetsConnector2 != null) {
					//工作状态
					assetsConnector2.setStatus(stateByte.intValue());
					//充电枪位置N连接状态   Map<充电枪位置, 连接状态>  0未连接，1已连接
					assetsConnector2.setConnectStatus(connectedByte.intValue()); // Map<充电枪位置, 连接状态>  0未连接，1已连接
					assetsConnectorMapper.updateById(assetsConnector2);
					//log.info("根据状态信息修改枪工作状态：{}和连接状态：{}", stateByte == 0 ? "空闲" : stateByte == 1 ? "准备充电" : "充电中", connectedByte == 0 ? "未连接" : "已连接");
				}
				//存在充电中的订单 做实时追踪
				log.info("宜步监听状态信息--桩编号_桩编码==》{}", code);
			}
		}
	}

	public void assetsConnectorStatus(ModuleChargingInfo moduleChargingInfo){
		if(moduleChargingInfo.getProviderId() == MsgProviderEnum.IB_PROVIDER.getValue()) {
			//根据订单获取枪id  获取枪信息
			Iterator i = moduleChargingInfo.getStateMap().keySet().iterator();
			while (i.hasNext()) {
				String sno = i.next().toString();
				String code = moduleChargingInfo.getCode(moduleChargingInfo.getPileCode(),Integer.valueOf(sno));
				Byte connectedByte = moduleChargingInfo.getConnectedStateMap().get(Byte.valueOf(sno));	//枪的连接状态
				Byte stateByte = moduleChargingInfo.getStateMap().get(Byte.valueOf(sno));//枪的状态
				//根据桩编码和枪获取用户id的键
				QueryWrapper<AssetsConnector> mappers = new QueryWrapper<AssetsConnector>();
				mappers.eq("code", code);
				AssetsConnector assetsConnector2 = assetsConnectorMapper.selectOne(mappers);
				if (assetsConnector2 != null) {
					//工作状态
					assetsConnector2.setStatus(stateByte.intValue());
					//充电枪位置N连接状态   Map<充电枪位置, 连接状态>  0未连接，1已连接
					assetsConnector2.setConnectStatus(connectedByte.intValue()); // Map<充电枪位置, 连接状态>  0未连接，1已连接
					assetsConnectorMapper.updateById(assetsConnector2);
					log.info("根据状态信息修改枪工作状态：{}和连接状态：{}", stateByte == 0 ? "空闲" : stateByte == 1 ? "准备充电" : "充电中", connectedByte == 0 ? "未连接" : "已连接");
				}
			}
		}
	}




	public void generateFinalOrder(CustomerChargingorder order,ModuleChargingInfo chargingInfo) {
		log.info("最终订单方法"+order.getId()+"-------------------->");

		if (order != null) {
			//如果此订单正在结速充电中，才能结束充电
			order.setStopTime(new Date());
			order.setSocStart((double) chargingInfo.getSocBeginMap().get((byte) 1));//起始SOC电量
			//更新订单信息
			customerChargingorderMapper.updateById(order);
			//更新充电枪状态
			AssetsConnector connector = new AssetsConnector();
			connector.setId(order.getConnectorId());
			connector.setStatus(ConnectorStatusEnum.FREE.getValue());
			assetsConnectorMapper.updateById(connector);
			//充电结束 删除本次订单跟进所需要的电量缓存
			if (redisUtil.hasKey("pnvTypeNew1" + order.getMemberId()) || redisUtil.hasKey("chargingNew1" + order.getMemberId())) {
				redisUtil.del("pnvTypeNew1" + order.getMemberId());
				redisUtil.del("chargingNew1" + order.getMemberId());
			}
			if (redisUtil.hasKey("pnvTypeNew1" + order.getMemberId()) || redisUtil.hasKey("chargingNew1" + order.getMemberId())) {
				redisUtil.del("pnvTypeNew2" + order.getMemberId());
				redisUtil.del("chargingNew2" + order.getMemberId());
			}
			if (redisUtil.hasKey("pnvTypeNew1" + order.getMemberId()) || redisUtil.hasKey("chargingNew1" + order.getMemberId())) {
				redisUtil.del("pnvTypeNew3" + order.getMemberId());
				redisUtil.del("chargingNew3" + order.getMemberId());
			}
		}

	}



		public void stopSendMq (ModuleChargingInfo moduleChargingInfo){
			//下发停止mq->
			PileCtrl ctrl = new PileCtrl();
			//接口个数和连接枪位置编码与现在表的是不是对应的
			ctrl.setProviderId(moduleChargingInfo.getProviderId());
			ctrl.setPileCode(moduleChargingInfo.getPileCode());//电桩编码
			ctrl.setParamType(PileCtrlParamType.PILE_START_STOP.getType());
			ctrl.setConnectorCount(moduleChargingInfo.getConnectorCnt());//接口个数--连接枪个数
			ctrl.setConnectorNo(moduleChargingInfo.getConnectorNo());//连接枪位置编码--枪口号(充电桩底层接口号)
			//充电模块位置编号   Map<充电模块位置, 编号>
			Map<Byte, Byte> connectorNoMap = new HashMap<Byte, Byte>();
			//充电模块 控制参数值  Map<充电模块位置, 控制参数值>
			Map<Byte, Integer> valueMap = new HashMap<Byte, Integer>();

			for (int i = 1; i <= moduleChargingInfo.getConnectorCnt(); ++i) {
				connectorNoMap.put((byte)i, (byte)i);//编号
				int value = 0;
				log.info("connector No：{}",moduleChargingInfo.getConnectorNo());
				//1:开启   2:关闭
				if(i == moduleChargingInfo.getConnectorNo()) {
					value = 2;
				}
				valueMap.put((byte)i, value);//启停充电
			}
			ctrl.setConnectorNoMap(connectorNoMap);
			ctrl.setValueMap(valueMap);

			amqpTemplate.convertAndSend(RabbitmqConstant.STOP_PILE_EXCHANGE, RabbitmqConstant.STOP_PILE_ROUTING_KEY, ctrl);
			log.info("发送控制桩停止指令到消息队列--------------------》宜步");
		}



}