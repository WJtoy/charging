package com.gdcdgj.charging.service.provider.listener;

import static com.gdcdgj.charging.api.constant.RabbitmqConstant.SIGN_IN_PILE_QUEUE;

import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.annotation.Resource;
import javax.print.DocFlavor.READER;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.gdcdgj.charging.api.entity.AssetsChargingpile;
import com.gdcdgj.charging.api.entity.AssetsConnector;
import com.gdcdgj.charging.api.util.RedisUtil;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.SignIn;
import com.gdcdgj.charging.service.provider.mapper.AssetsConnectorMapper;
import com.gdcdgj.charging.service.provider.service.AssetsChargingpileService;
import com.gdcdgj.charging.service.provider.serviceImpl.AssetsChargingpileServiceImpl;
import com.rabbitmq.client.AMQP.Basic.Get;

import lombok.extern.slf4j.Slf4j;

/**
 * 监听桩上报的签到信息
 *
 * @author ydc
 * @date 2020/4/18 15:00
 * @since JDK 1.8
 */
@Slf4j
@Component
public class SignInListener {
	
	@Autowired
    AssetsChargingpileService chargingpileService;
	@Autowired
	AssetsConnectorMapper assetsConnectorMapper;
	
    @RabbitListener(queues = SIGN_IN_PILE_QUEUE)
    public void handlerMessage(SignIn signIn) throws UnsupportedEncodingException {
    	this.onHandlerMessage(signIn);
    }

    public void onHandlerMessage(SignIn signIn){
		try {
			//收到签到上报，修改数据库
			if (signIn != null) {
				String code = signIn.getPileCode();
				QueryWrapper<AssetsChargingpile> updateWrapper=new QueryWrapper<>();
				updateWrapper.eq("code",code);
				AssetsChargingpile chargingpile = chargingpileService.getOne(updateWrapper);
				if(chargingpile != null) {
					if(signIn.getStartStopSingal().intValue() == 1) {
						//设置状态上线
						chargingpile.setIsOnline(true);
					}else {
						//设置状态离线
						chargingpile.setIsOnline(false);
					}
					chargingpileService.update(chargingpile,updateWrapper);
					log.info("桩编号==》{}", signIn.getPileCode());
				}
			}
		}catch (Exception e) {
			log.error("SignInListener 监听桩签到异常： {}",e);
		}
	}
}