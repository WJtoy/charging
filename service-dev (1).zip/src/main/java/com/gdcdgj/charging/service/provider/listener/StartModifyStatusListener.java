package com.gdcdgj.charging.service.provider.listener;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.gdcdgj.charging.api.entity.CustomerChargingorder;
import com.gdcdgj.charging.api.enums.ChargingOrderStatusEnum;
import com.gdcdgj.charging.service.provider.mapper.CustomerChargingorderMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.UnsupportedEncodingException;

import static com.gdcdgj.charging.api.constant.RabbitmqConstant.START_MODIFY_STATUS_QUEUE;

/**
 * @author JianMei Chen
 * @date 2020/05/15/19:16
 */
@Component
@Slf4j
public class StartModifyStatusListener {

    @Autowired
    private CustomerChargingorderMapper customerChargingorderMapper;

    @RabbitListener(queues = START_MODIFY_STATUS_QUEUE)
    public void handlerMessage(String orderNo) throws UnsupportedEncodingException {
        this.onHandlerMessage(orderNo);
    }
    public void onHandlerMessage(String orderNo) {
        log.info("订单号==》{}"+orderNo);
        //修改充电订单的充电状态
        QueryWrapper<CustomerChargingorder> orderWrapper=new QueryWrapper<>();
        orderWrapper.eq("order_no",orderNo);
        CustomerChargingorder order = customerChargingorderMapper.selectOne(orderWrapper);
        order.setChargingStatus(ChargingOrderStatusEnum.CHARGING.getValue());
        customerChargingorderMapper.updateById(order);
    }

}
