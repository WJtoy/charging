package com.gdcdgj.charging.service.provider.listener;

import static com.gdcdgj.charging.api.constant.RabbitmqConstant.STARTED_STATUS_QUEUE;
import static com.gdcdgj.charging.api.enums.ChargingOrderStatusEnum.CHARGING;
import static com.gdcdgj.charging.api.enums.ChargingOrderStatusEnum.START_FAIL;
import static com.gdcdgj.charging.api.enums.ConnectorStatusEnum.END_CHARGING;
import static com.gdcdgj.charging.api.enums.ConnectorStatusEnum.CONNECTOR_CHARGING;

import java.beans.Transient;
import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.commons.lang3.StringUtils;
import org.apache.zookeeper.Op.Check;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.gdcdgj.charging.api.entity.AssetsChargingpile;
import com.gdcdgj.charging.api.entity.AssetsConnector;
import com.gdcdgj.charging.api.entity.AssetsStations;
import com.gdcdgj.charging.api.entity.CustomerChargingorder;
import com.gdcdgj.charging.api.entity.CustomerChargingordertracks;
import com.gdcdgj.charging.api.entity.CustomerMember;
import com.gdcdgj.charging.api.entity.EmployeeCompany;
import com.gdcdgj.charging.api.enums.ChargingOrderStatusEnum;
import com.gdcdgj.charging.api.enums.ChargingOrderStopMethodEnum;
import com.gdcdgj.charging.api.enums.ConnectorStatusEnum;
import com.gdcdgj.charging.api.enums.PileCtrlParamType;
import com.gdcdgj.charging.api.util.RedisUtil;
import com.gdcdgj.charging.api.vo.CommonVo;
import com.gdcdgj.charging.api.vo.order.PeakTemplateVo;
import com.gdcdgj.charging.api.vo.srv2gw.ChargeRecordInfo;
import com.gdcdgj.charging.api.vo.srv2gw.PileCtrl;
import com.gdcdgj.charging.api.vo.srv2gw.PileStartedRst;
import com.gdcdgj.charging.api.vo.srv2gw.StateInfo;
import com.gdcdgj.charging.api.vo.station.PriceTemplateVo;
import com.gdcdgj.charging.service.provider.localServiceImpl.station.StationServiceImpl;
import com.gdcdgj.charging.service.provider.mapper.CustomerMemberMapper;
import com.gdcdgj.charging.service.provider.service.AssetsChargingpileService;
import com.gdcdgj.charging.service.provider.service.AssetsConnectorService;
import com.gdcdgj.charging.service.provider.service.AssetsStationsService;
import com.gdcdgj.charging.service.provider.service.CustomerChargingorderService;
import com.gdcdgj.charging.service.provider.service.EmployeeCompanyService;

import lombok.extern.slf4j.Slf4j;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

/**
 * 监听桩桩启动入库逻辑
 *
 * @author ydc
 * @date 2020/4/18 15:00
 * @since JDK 1.8
 */
@Slf4j
@Component
public class StartedListener {
	
	@Autowired
    AssetsChargingpileService chargingpileService;
	@Autowired
    CustomerChargingorderService chargingorderService;
	@Resource
    CustomerMemberMapper customerMemberMapper;
	@Autowired
    AssetsConnectorService connectorService;
	@Autowired
    AssetsStationsService stationsService;
    @Autowired
    EmployeeCompanyService companyService;
    @Autowired
    private RedisUtil redisUtil;
	
    @RabbitListener(queues = STARTED_STATUS_QUEUE)
    public void handlerMessage(PileStartedRst pileStartedRst) throws UnsupportedEncodingException {
    		this.onHandlerMessage(pileStartedRst);
    }

    @Transactional
    public void onHandlerMessage(PileStartedRst pileStartedRst){
        // 2. 如果没有，判断该会员是否有准备充电的订单
        // 1. 如果有，设置为启动失败,
    	if(pileStartedRst.getConnectorNo() != 0) {
    		AssetsChargingpile chargingpile = null;
            CustomerMember customerMember = null;
            CustomerChargingorder chargingorder = null;
            String code = pileStartedRst.getCode(pileStartedRst.getPileCode(), pileStartedRst.getConnectorNo());
            //从redis获取当前用户id
            try {
                int key = (int) redisUtil.get(code);
                //根据充电桩code获取充电桩信息
                QueryWrapper<AssetsChargingpile> queryWrapper = new QueryWrapper<>();
                queryWrapper.eq("code", pileStartedRst.getPileCode());
                chargingpile = chargingpileService.getOne(queryWrapper);
                //根据用户id获取用户信息
                customerMember = customerMemberMapper.selectById(key);

                //根据桩code获取枪
                QueryWrapper<AssetsConnector> connectorMapper = new QueryWrapper<>();
                connectorMapper.eq("code", code);
                AssetsConnector assetsConnector = connectorService.getOne(connectorMapper);
                //根据桩id和用户获取订单
                QueryWrapper<CustomerChargingorder> tracksWrapperNew = new QueryWrapper<>();
                tracksWrapperNew.eq("member_id", customerMember.getId());
                tracksWrapperNew.eq("charging_status",ChargingOrderStatusEnum.PREPARE_CHARGING.getValue());
                chargingorder = chargingorderService.getOne(tracksWrapperNew);
                if (chargingorder != null){
                    if(pileStartedRst.getResult() == 1) {       //1启动成功
                        chargingorder.setChargingStatus(CHARGING.getValue());
                        assetsConnector.setStatus(CONNECTOR_CHARGING.getValue());
                    }else {
                        chargingorder.setChargingStatus(START_FAIL.getValue());
                        assetsConnector.setStatus(END_CHARGING.getValue());
                        //删除用户
                        redisUtil.del(code);
                    }
                    chargingorder.setStartTime(new Date());
                    chargingorderService.updateById(chargingorder);
                    connectorService.updateById(assetsConnector);
                }
            } catch (Exception e) {
                log.error("StartedListener 监听异常 ：  {}",e);
            }
            log.info("桩编号==》{} 启动结果处理完成" ,pileStartedRst.getPileCode());
    	}
    }
}
