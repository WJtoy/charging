package com.gdcdgj.charging.service.provider.listener;

import static com.gdcdgj.charging.api.constant.RabbitmqConstant.STATEINFO_STATUS_QUEUE;
import static com.gdcdgj.charging.api.enums.ChargingOrderStatusEnum.*;

import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Map.Entry;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.gdcdgj.charging.api.constant.RabbitmqConstant;
import com.gdcdgj.charging.api.entity.*;
import com.gdcdgj.charging.api.enums.PileCtrlParamType;
import com.gdcdgj.charging.api.util.RedisUtil;
import com.gdcdgj.charging.api.vo.order.PeakTemplateVo;
import com.gdcdgj.charging.api.vo.srv2gw.PileCtrl;
import com.gdcdgj.charging.service.provider.mapper.AssetsConnectorMapper;
import com.gdcdgj.charging.service.provider.mapper.CustomerChargingorderMapper;
import com.gdcdgj.charging.service.provider.mapper.CustomerChargingordertracksMapper;
import com.gdcdgj.charging.service.provider.mapper.CustomerMemberMapper;
import com.gdcdgj.charging.service.provider.service.CustomerChargingorderService;
import org.apache.zookeeper.data.Stat;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.gdcdgj.charging.api.enums.ConnectorStatusEnum;
import com.gdcdgj.charging.api.enums.MsgProviderEnum;
import com.gdcdgj.charging.api.vo.srv2gw.DataBaseVo;
import com.gdcdgj.charging.api.vo.srv2gw.PileStartedRst;
import com.gdcdgj.charging.api.vo.srv2gw.StateInfo;
import com.gdcdgj.charging.service.provider.service.AssetsChargingpileService;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * 监听桩桩状态应答上报
 *
 * @author ydc
 * @date 2020/4/18 15:00
 * @since JDK 1.8
 */
@Slf4j
@Service
public class StateInfoListener {

	@Autowired
	AssetsChargingpileService chargingpileService;

	@Resource
	CustomerChargingorderService chargingorderService;

	@Resource
	CustomerChargingordertracksMapper customerChargingordertracksMapper;

	@Resource
	CustomerChargingorderMapper customerChargingorderMapper;

	@Resource
	CustomerMemberMapper customerMemberMapper;

	@Resource
	RedisUtil redisUtil;

	@Resource
	AssetsConnectorMapper assetsConnectorMapper;

	@Resource
	AmqpTemplate amqpTemplate;

    @RabbitListener(queues = STATEINFO_STATUS_QUEUE)
    public void handlerMessage(StateInfo stateInfo) throws UnsupportedEncodingException {

    	this.onHandlerMessage(stateInfo);

    }


    public void onHandlerMessage(StateInfo stateInfo){
		try {
			// 桩状态应答上报,修改数据库
			String code = stateInfo.getCode(stateInfo.getPileCode(),(int)stateInfo.getConnectorNo());
			if (stateInfo.getProviderId() == MsgProviderEnum.KW_PROVIDER.getValue()) {
				//科旺状态信息包上报处理
				QueryWrapper<AssetsConnector> assetsWrapper = new QueryWrapper<>();
				assetsWrapper.eq("code", code);
				assetsWrapper.eq("serial_no", stateInfo.getConnectorNo());
				AssetsConnector assetsConnector = assetsConnectorMapper.selectOne(assetsWrapper);
				//根据车连接状态判断是否已插枪
				if(stateInfo.getCarConnectState() == 0 || stateInfo.getCarConnectState() == 1) {
					assetsConnector.setConnectStatus(0);
				}else {
					assetsConnector.setConnectStatus(1);
				}

				//根据工作状态判断修改枪状态
				if ( stateInfo.getWorkState() == 1
						|| stateInfo.getWorkState() == 4
						|| stateInfo.getWorkState() == 5) {
					assetsConnector.setStatus(ConnectorStatusEnum.FREE.getValue());
					endChargingOrder(stateInfo);
				} else if (stateInfo.getWorkState() == 2) {
					assetsConnector.setStatus(ConnectorStatusEnum.CONNECTOR_CHARGING.getValue());
					//实时记录充电轨迹表
					setNewCustomerChargingordertracks(stateInfo);
				} else if ( stateInfo.getWorkState() == 0 || stateInfo.getWorkState() == 3) {		//工作状态等于3结束充电
					assetsConnector.setStatus(ConnectorStatusEnum.FREE.getValue());
					endChargingOrder(stateInfo);
				} else if (stateInfo.getWorkState() == 6) {
					assetsConnector.setStatus(ConnectorStatusEnum.SYSTEM_FAULT.getValue());
					endChargingOrder(stateInfo);
				}
				//根据工作状态更新数据库枪状态
				assetsConnectorMapper.updateById(assetsConnector);
			}
			log.info("桩编号==》{}", stateInfo.getPileCode());
		}catch(Exception e){
			log.error("StateInfoListener 监听科旺状态信息包出现异常 :{}",e);
		}
	}


	public void endChargingOrder(StateInfo stateInfo){
		String code = stateInfo.getCode(stateInfo.getPileCode(),(int) stateInfo.getConnectorNo());
		//从redis获取当前充电用户id
		if(redisUtil.get(code) != null) {
			//追踪表最后一次跟进以及生成最终订单
			int keyNew = (int)redisUtil.get(code);
			//todo 结束充电
			QueryWrapper<CustomerChargingorder> orderWrapperNew = new QueryWrapper<>();
			orderWrapperNew.eq("member_id", keyNew);
			orderWrapperNew.eq("charging_status", ENDING.getValue());
			CustomerChargingorder customerChargingorder = customerChargingorderMapper.selectOne(orderWrapperNew);
			generateFinalOrder(customerChargingorder.getId());
			//充电结束 删除当前充电用户id缓存
			redisUtil.del(code);
		}
	}



		public CustomerChargingordertracks setNewCustomerChargingordertracks (StateInfo stateInfo){
			CustomerChargingordertracks customerChargingordertracks = null;
			try {
				stateInfo.setChargePowerCount(stateInfo.getChargePowerCount());	//充电量
				stateInfo.setDCChargeElectric(stateInfo.getDCChargeElectric());	//电流
				stateInfo.setDCChargePressure(stateInfo.getDCChargePressure());	//电压
				String code = stateInfo.getCode(stateInfo.getPileCode(),stateInfo.getConnectorNo());
				//从redis -里获取当前充电用户id
				int key = (int) redisUtil.get(code);
				CustomerMember member = customerMemberMapper.selectById(key);
				QueryWrapper<CustomerChargingorder> orderWrapper = new QueryWrapper<>();
				orderWrapper.eq("member_id", key);
				orderWrapper.eq("charging_status", CHARGING.getValue());
				CustomerChargingorder chargingOrder = customerChargingorderMapper.selectOne(orderWrapper);
				if(chargingOrder != null) {
					log.info("断言订单---------------------------->"+chargingOrder.toString());
					customerChargingordertracks = new CustomerChargingordertracks();
					//钱包额度加信用额 -wallet
					Double wallet = (member.getWallet() == null ? 0 : member.getWallet())+member.getCredit();
					Double totalPrice = (chargingOrder.getTotalPrice()== null) ? 0.0 : chargingOrder.getTotalPrice();
					//根据memberID获取用户余额，费用超出累加额下发停止mq且计算出最终订单
					if (wallet - 1.0d > totalPrice) {

						Date date = new Date();
						customerChargingordertracks.setOrderId(chargingOrder.getId());
						customerChargingordertracks.setAddTime(date);

						if (chargingOrder.getPriceUnit() != null) {
							List<PeakTemplateVo> json =JSON.parseArray(chargingOrder.getPriceUnit(),PeakTemplateVo.class);
							//判断峰平谷时电量
							for (PeakTemplateVo peakTemplateVo : json) {
								String now = date.getHours() + ":" + date.getMinutes();
								if (isInTime(peakTemplateVo.getStartTime()+"-"+peakTemplateVo.getEndTime(), now)) {

									stateInfo.setChargePowerCount(stateInfo.getChargePowerCount());
									log.info("-------------------->");
									if (peakTemplateVo.getPnvType() == 1) {
										if (!redisUtil.hasKey("pnvType1"+chargingOrder.getId())) {
											redisUtil.set("pnvType1"+chargingOrder.getId(), stateInfo.getChargeTime());
											redisUtil.set("charging1"+chargingOrder.getId(), stateInfo.getChargePowerCount());
											chargingOrder.setPeaksChargingTime(stateInfo.getChargeTime());
										}
										chargingOrder.setPeaksChargingTime(stateInfo.getChargeTime() );//峰时充电时长 /*(int) redisUtil.get("pnvType1"+member.getId()))*/
										chargingOrder.setPeaksChargingQuantity(Double.valueOf(stateInfo.getChargePowerCount()) /*(Double) redisUtil.get("charging1"+member.getId())*/);//峰时充电电量
										chargingOrder.setPeaksChargingPrice(stateInfo.getChargePowerCount() * peakTemplateVo.getChargingPrice());//峰时电费
										chargingOrder.setPeaksServicePrice(stateInfo.getChargePowerCount() * peakTemplateVo.getServicePrice());//峰时服务费*/

									} else if (peakTemplateVo.getPnvType() == 2) {
										if (!redisUtil.hasKey("pnvType2"+chargingOrder.getId())) {
											redisUtil.set("pnvType2"+chargingOrder.getId(), stateInfo.getChargeTime());
											redisUtil.set("charging2"+chargingOrder.getId(), stateInfo.getChargePowerCount());
											chargingOrder.setNormalChargingTime(stateInfo.getChargeTime());
											chargingOrder.setNormalChargingQuantity(Double.valueOf(stateInfo.getChargePowerCount()));
										}

										chargingOrder.setNormalChargingTime((stateInfo.getChargeTime()));//平时充电时长
										chargingOrder.setNormalChargingQuantity(Double.valueOf(stateInfo.getChargePowerCount()));//平时充电电量
										chargingOrder.setNormalChargingPrice(stateInfo.getChargePowerCount() * peakTemplateVo.getChargingPrice());//平时电费
										chargingOrder.setNormalServicePrice(stateInfo.getChargePowerCount() * peakTemplateVo.getServicePrice());//平时服务费*/
									} else {
										if (!redisUtil.hasKey("pnvType3"+chargingOrder.getId())) {
											redisUtil.set("pnvType3"+chargingOrder.getId(), stateInfo.getChargePowerCount());
											redisUtil.set("charging3"+chargingOrder.getId(), stateInfo.getChargePowerCount());
											chargingOrder.setValleysChargingTime(stateInfo.getChargeTime());
										}
										chargingOrder.setValleysChargingTime((stateInfo.getChargeTime()));//谷时充电时长
										chargingOrder.setValleysChargingQuantity(Double.valueOf(stateInfo.getChargePowerCount()));//谷时充电电量
										chargingOrder.setValleysChargingPrice(stateInfo.getChargePowerCount() * peakTemplateVo.getChargingPrice());//谷时电费
										chargingOrder.setValleysServicePrice(stateInfo.getChargePowerCount() * peakTemplateVo.getServicePrice());//谷时服务费*/
									}
								}
							}
						}
						//总服务费
						Double serviceTotal = chargingOrder.getNormalServicePrice() + chargingOrder.getValleysServicePrice() + chargingOrder.getPeaksServicePrice();
						//总充电费
						Double chargingPriceTotal = chargingOrder.getNormalChargingPrice() + chargingOrder.getValleysChargingPrice() + chargingOrder.getPeaksChargingPrice();
						//总费用
						Double totalPriceUnit  = serviceTotal + chargingPriceTotal;

						customerChargingordertracks.setTotalChargingTime(stateInfo.getChargeTime().intValue());		//总充电时长
						customerChargingordertracks.setTotalChargingQuantity(Double.valueOf(stateInfo.getChargePowerCount()));		//总充电电量
						customerChargingordertracks.setTotalChargingPrice(chargingPriceTotal);		//总充电费
						customerChargingordertracks.setTotalServicePrice(serviceTotal);		//总服务费
						customerChargingordertracks.setTotalPrice(customerChargingordertracks.getTotalChargingPrice() + customerChargingordertracks.getTotalServicePrice());	//总费用
						customerChargingordertracks.setSoc(Double.valueOf(stateInfo.getCurrentSOC()));	//起始SOC
						customerChargingordertracks.setElectric((stateInfo.getCurrentQuliety()));	//当前电表度数
						customerChargingordertracks.setCurrent(stateInfo.getDCChargeElectric());//当前电流
						customerChargingordertracks.setVoltage(stateInfo.getDCChargePressure());	//当前电压
						customerChargingordertracks.setPower(stateInfo.getChargePower());		//充电功率
						customerChargingordertracks.setLeftTime(stateInfo.getResidueChargeTime()); 	//预计剩余时间min
						chargingOrder.setTotalChargingPrice(chargingPriceTotal);
						chargingOrder.setTotalServicePrice(serviceTotal);
						chargingOrder.setTotalPrice(totalPriceUnit);
						chargingOrder.setSocEnd(stateInfo.getCurrentSOC().doubleValue());
						chargingOrder.setTotalChargingQuantity(stateInfo.getChargePowerCount().doubleValue());
						chargingOrder.setTotalChargingTime(stateInfo.getChargeTime().intValue());
						chargingOrder.setWarningCode(stateInfo.getAlarmCode());
						chargingOrder.setCurrent(stateInfo.getDCChargeElectric());
						chargingOrder.setVoltage(stateInfo.getDCChargePressure());
						chargingOrder.setRequireVoltage(Double.valueOf(stateInfo.getBMSPressure()));
						chargingOrder.setRequireCurrent(Double.valueOf(stateInfo.getBMSElectric()));
						//插入追踪表
						customerChargingordertracksMapper.insert(customerChargingordertracks);
						//更新订单
						customerChargingorderMapper.updateById(chargingOrder);
					} else {
						//余额不足，生成最终订单
						stopSendMq(stateInfo);
						generateFinalOrder(chargingOrder.getId());
						if(redisUtil.hasKey(code)) {
							redisUtil.del(code);
						}
					}
				}
			}catch(Exception e) {
				log.error("customerChargingordertracks追踪异常 ：{}",e);
			}
			return customerChargingordertracks;
		}

		//生成最终订单
		public void generateFinalOrder (Integer chargingorder){
			QueryWrapper<CustomerChargingorder> orderWrapper = new QueryWrapper<>();
			orderWrapper.eq("id", chargingorder);
			CustomerChargingorder order = customerChargingorderMapper.selectOne(orderWrapper);
			if (order != null) {
				if(order.getChargingStatus() == ENDING.getValue()) {
					//如果此订单正在充电，才能结束充电
					order.setStopTime(new Date());
					order.setChargingStatus(END_CHARGING.getValue());
					customerChargingorderMapper.updateById(order);
					//更新充电枪状态
					AssetsConnector connector = new AssetsConnector();
					connector.setId(order.getConnectorId());
					connector.setStatus(ConnectorStatusEnum.FREE.getValue());
					assetsConnectorMapper.updateById(connector);
					if(redisUtil.hasKey("pnvType1"+order.getMemberId())
						|| redisUtil.hasKey("charging1"+order.getMemberId())) {
						redisUtil.del("pnvType1"+order.getMemberId());
						redisUtil.del("charging1"+order.getMemberId());
					}
					if(redisUtil.hasKey("pnvType2"+order.getMemberId())
							|| redisUtil.hasKey("charging2"+order.getMemberId())) {
						redisUtil.del("pnvType2"+order.getMemberId());
						redisUtil.del("charging2"+order.getMemberId());
					}
					if(redisUtil.hasKey("pnvType3"+order.getMemberId())
							|| redisUtil.hasKey("charging3"+order.getMemberId())) {
						redisUtil.del("pnvType3"+order.getMemberId());
						redisUtil.del("charging3"+order.getMemberId());
					}

				}
			}
		}

		public void stopSendMq (StateInfo stateInfo){
			try {
				//下发停止mq
	 			PileCtrl ctrl = new PileCtrl();
				//接口个数和连接枪位置编码与现在表的是不是对应的
	 			ctrl.setProviderId(stateInfo.getProviderId());
	 			ctrl.setPileCode(stateInfo.getPileCode());
				ctrl.setParamType(PileCtrlParamType.PILE_START_STOP.getType());
				ctrl.setConnectorCount(stateInfo.getConnectorCount());//接口个数--连接枪个数
				ctrl.setConnectorNo(stateInfo.getConnectorNo());//连接枪位置编码--枪口号(充电桩底层接口号)
				//充电模块位置编号   Map<充电模块位置, 编号>
				Map<Byte, Byte> connectorNoMap = new HashMap<Byte, Byte>();
				//充电模块 控制参数值  Map<充电模块位置, 控制参数值>
				Map<Byte, Integer> valueMap = new HashMap<Byte, Integer>();
				for (byte i = 1; i <= stateInfo.getConnectorCount(); ++i) {
					connectorNoMap.put(i, i);//编号
					int value = 0;
					if (i == stateInfo.getConnectorNo()) {
						//1:开启   2:关闭
						value = 2;
					}
					valueMap.put(i, value);//启停充电
				}
				ctrl.setConnectorNoMap(connectorNoMap);
				ctrl.setValueMap(valueMap);
				amqpTemplate.convertAndSend(RabbitmqConstant.STOP_PILE_EXCHANGE, RabbitmqConstant.STOP_PILE_ROUTING_KEY, ctrl);
			}catch(Exception e) {
				log.error("StateInfoListener 监听 下发停止命令stopSendMq 异常 ： {}",e);
			}
		}



		public static boolean isInTime(String sourceTime, String curTime) {
	        if (sourceTime == null || !sourceTime.contains("-") || !sourceTime.contains(":")) {
	            throw new IllegalArgumentException("Illegal Argument arg:" + sourceTime);
	        }
	        if (curTime == null || !curTime.contains(":")) {
	            throw new IllegalArgumentException("Illegal Argument arg:" + curTime);
	        }
	        String[] args = sourceTime.split("-");
	        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
	        try {
	            long now = sdf.parse(curTime).getTime();
	            long start = sdf.parse(args[0]).getTime();
	            long end = sdf.parse(args[1]).getTime();
	            if (args[1].equals("00:00")) {
	                args[1] = "24:00";
	            }
	            if (end < start) {
	                if (now >= end && now < start) {
	                    return false;
	                } else {
	                    return true;
	                }
	            } 
	            else {
	                if (now >= start && now < end) {
	                    return true;
	                } else {
	                    return false;
	                }
	            }
	        } catch (ParseException e) {
	            e.printStackTrace();
	            throw new IllegalArgumentException("Illegal Argument arg:" + sourceTime);
	        }
	 }





}