
package com.gdcdgj.charging.service.provider.listener;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.gdcdgj.charging.api.entity.AssetsChargingpile;
import com.gdcdgj.charging.api.entity.AssetsConnector;
import com.gdcdgj.charging.api.entity.CustomerChargingorder;
import com.gdcdgj.charging.api.entity.CustomerChargingordertracks;
import com.gdcdgj.charging.api.enums.ConnectorStatusEnum;
import com.gdcdgj.charging.api.localService.charging.ChargingOrderService;
import com.gdcdgj.charging.api.util.RedisUtil;
import com.gdcdgj.charging.api.vo.srv2gw.PileCtrl;
import com.gdcdgj.charging.service.provider.mapper.AssetsChargingpileMapper;
import com.gdcdgj.charging.service.provider.mapper.AssetsConnectorMapper;
import com.gdcdgj.charging.service.provider.mapper.CustomerChargingorderMapper;
import com.gdcdgj.charging.service.provider.mapper.CustomerChargingordertracksMapper;
import com.gdcdgj.charging.service.provider.service.CustomerChargingorderService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.List;

import static com.gdcdgj.charging.api.constant.RabbitmqConstant.STOP_PILE_QUEUE;
import static com.gdcdgj.charging.api.enums.ChargingOrderStatusEnum.*;


@Slf4j
@Component
public class StopChargingListener {

    @Resource
    private CustomerChargingorderService customerChargingorderService;

    @Resource
    private CustomerChargingorderMapper customerChargingorderMapper;

    @Resource
    private CustomerChargingordertracksMapper customerChargingordertracksMapper;

    @Resource
    private AssetsConnectorMapper assetsConnectorMapper;

    @Resource
    private AssetsChargingpileMapper assetsChargingpileMapper;
    @Resource
    RedisUtil redisUtil;

    @RabbitListener(queues = STOP_PILE_QUEUE)
    public void handlerMessage(PileCtrl pileCtrl) throws UnsupportedEncodingException {
        this.onHandlerMessage(pileCtrl);
    }

    public void onHandlerMessage(PileCtrl pileCtrl) {
        if (pileCtrl.getResultCode() != 0) {
            String connCode = pileCtrl.getCode(pileCtrl.getPileCode(), (int) pileCtrl.getConnectorNo());
            Integer memberId = (int) redisUtil.get(connCode);
            QueryWrapper<CustomerChargingorder> queryWrapper = new QueryWrapper<CustomerChargingorder>();
            queryWrapper.eq("connector_code", connCode);
            queryWrapper.eq("charging_status", ENDING.getValue());
            queryWrapper.eq("member_id", memberId);
            CustomerChargingorder customerChargingorder = customerChargingorderMapper.selectOne(queryWrapper);
            /*customerChargingorder.setChargingStatus(END_CHARGING.getValue());
            customerChargingorderMapper.updateById(customerChargingorder);*/

            if (customerChargingorder != null) {
                log.info("状态-------------->");
                generateFinalOrder(customerChargingorder.getId(), pileCtrl);
            }
           /* QueryWrapper<AssetsConnector> assetsConnectorQueryWrapper = new QueryWrapper<>();
            assetsConnectorQueryWrapper.eq("code",pileCtrl.getConnectorNo());
            AssetsConnector assetsConnector1 = assetsConnectorMapper.selectOne(assetsConnectorQueryWrapper);
            assetsConnector1.setConnectStatus(END_CHARGING.getValue());     //枪改为充电结束
            assetsConnectorMapper.updateById(assetsConnector1);
            // AssetsChargingpile assetsChargingpile = new AssetsChargingpile();
            QueryWrapper<AssetsChargingpile> assetsChargingpileQueryWrapper = new QueryWrapper<>();
            assetsChargingpileQueryWrapper.eq("code",pileCtrl.getPileCode());
            AssetsChargingpile assetsChargingpile1 =  assetsChargingpileMapper.selectOne(assetsChargingpileQueryWrapper);
            //assetsChargingpile1.setIsEnabled(false);       //桩关闭中
            assetsChargingpile1.setIsOnline(false);     //桩离线中
            assetsChargingpileMapper.updateById(assetsChargingpile1);*/
            if (redisUtil.hasKey(memberId.toString())) {
                redisUtil.del(memberId.toString());
            }
        }
    }


    public void generateFinalOrder(int chargingorder, PileCtrl pileCtrl) {
        QueryWrapper<CustomerChargingorder> orderWrapper = new QueryWrapper<>();
        orderWrapper.eq("id", chargingorder);
        CustomerChargingorder order = customerChargingorderMapper.selectOne(orderWrapper);

        if (order != null) {

            if (order.getChargingStatus() == ENDING.getValue()) {
                log.info("----------->"+order.getChargingStatus());
                order.setChargingStatus(4);
                order.setStopTime(new Date());
                //更新订单信息
                customerChargingorderMapper.updateById(order);

                //更新充电枪状态
                AssetsConnector connector = new AssetsConnector();
                connector.setId(order.getConnectorId());
                connector.setStatus(ConnectorStatusEnum.END_CHARGING.getValue());
                assetsConnectorMapper.updateById(connector);
                if (redisUtil.hasKey("pnvType1" + order.getMemberId()) || redisUtil.hasKey("pnvType2" + order.getMemberId()) ||
                        redisUtil.hasKey("pnvType3" + order.getMemberId()) || redisUtil.hasKey("charging1" + order.getMemberId()) ||
                        redisUtil.hasKey("charging2" + order.getMemberId()) || redisUtil.hasKey("charging3" + order.getMemberId())) {
                    redisUtil.del("pnvType1" + order.getMemberId());
                    redisUtil.del("pnvType2" + order.getMemberId());
                    redisUtil.del("pnvType3" + order.getMemberId());
                    redisUtil.del("charging1" + order.getMemberId());
                    redisUtil.del("charging2" + order.getMemberId());
                    redisUtil.del("charging3" + order.getMemberId());
                }
            }
        }
    }
}

