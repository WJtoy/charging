package com.gdcdgj.charging.service.provider.localServiceImpl.charging;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.gdcdgj.charging.api.constant.RabbitmqConstant;
import com.gdcdgj.charging.api.constant.RedisConstant;
import com.gdcdgj.charging.api.constant.ResultCode;
import com.gdcdgj.charging.api.entity.*;
import com.gdcdgj.charging.api.enums.*;
import com.gdcdgj.charging.api.localService.charging.ChargingService;
import com.gdcdgj.charging.api.util.DateTimeUtil;
import com.gdcdgj.charging.api.util.RedisUtil;
import com.gdcdgj.charging.api.vo.CommonVo;
import com.gdcdgj.charging.api.vo.order.FreeInfoVo;
import com.gdcdgj.charging.api.vo.order.PeakTemplateVo;
import com.gdcdgj.charging.api.vo.order.QuantityInfoVo;
import com.gdcdgj.charging.api.vo.srv2gw.PileCtrl;
import com.gdcdgj.charging.api.vo.station.PriceTemplateVo;
import com.gdcdgj.charging.service.provider.localServiceImpl.station.StationServiceImpl;
import com.gdcdgj.charging.service.provider.mapper.*;
import com.gdcdgj.charging.service.provider.service.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.dubbo.config.annotation.Service;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.gdcdgj.charging.api.enums.ChargingOrderStatusEnum.*;


/**
 * @author Changliang Tao
 * @date 2020/4/23 9:19
 * @since JDK 1.8
 */
@Slf4j
@Service(version = "1.0.0", timeout = 15000)
public class ChargingServiceImpl implements ChargingService {
    @Autowired
    AssetsConnectorService connectorService;//充电枪

    @Autowired
    AssetsChargingpileService chargingpileService;//桩

    @Autowired
    AssetsStationsService stationsService;//站点

    @Autowired
    EmployeeCompanyService companyService;
    @Autowired
    CustomerChargingorderService chargingorderService;
    @Autowired
    RedisUtil redisUtil;
    @Autowired
    CustomerMemberMapper customerMemberMapper;
    @Autowired
    AmqpTemplate amqpTemplate;

    @Autowired
    CustomerChargingorderMapper customerChargingorderMapper;

    @Autowired
    CustomerChargingordertracksMapper customerChargingordertracksMapper;

    @Autowired
    AssetsChargingpileMapper assetsChargingpileMapper;

    @Autowired
    AssetsConnectorMapper assetsConnectorMapper;

    @Autowired
    StationServiceImpl stationServiceImpl;

    @Autowired
    AssetsStationsMapper assetsStationsMapper;





    /**
     * qrCode即是枪编码，根据token获取会员信息
     * // 从redis中查询会员信息
     * // 在数据库查询是否存在该枪编码
     * // 1. 订单里面绑定了桩，和会员，一个订单一个桩，一个桩多个订单，一个会员多个订单
     * // 1. 在数据库查询，如果该桩为空闲
     * // 1. 判断该会员是否有正在充电、结束充电、未付费的订单
     * // 1. 如果有，直接返回
     * // 2. 如果没有，判断该会员是否有准备充电的订单
     * // 1. 如果有，设置为启动失败
     * // 
     * // 3. 设置服务类型，启动桩
     * // 2. 如果不为空闲，直接返回
     * // 桩的状态根据桩的模块信息上报来改，同时修改桩绑定的订单状态。
     *
     * @param token
     * @param qrCode
     * @return common vo
     * @throws
     * @author Changliang Tao
     * @date 2020/4/21 14:43
     */

    @Override
    @Transactional
    public CommonVo start(String token, String qrCode,String scanTime,Integer is_simulate) throws Exception {
        if (token==null && scanTime==null && is_simulate==null)
            return new CommonVo("请求参数为空！请严格输入所需的参数!!",null);
        // 在数据库查询是否存在该枪编码
        String code = qrCode;
        // 1. 订单里面绑定了桩，和会员，一个订单一个桩，一个桩多个订单，一个会员多个订单
        Date memberScanTime=null;
        if (scanTime != null){
            memberScanTime = DateTimeUtil.getFormatDateTime(scanTime);
        }
        // 判断充电设备的状态
        AssetsConnector connector = connectorService.getConnectorByCode(code);

        AssetsChargingpile chargingpile = chargingpileService.getById(connector.getPileId());

        AssetsStations station = assetsStationsMapper.selectById(chargingpile.getStationId());

        // 从redis中查询会员信息
        CustomerMember member = (CustomerMember) redisUtil.get(token);
        // 根据会员id到数据库查询最新的会员信息
        member = customerMemberMapper.selectById(member.getId());
        // 判断会员是否存在
        if (member == null) {
            log.info("会员不存在");
            return new CommonVo("会员不存在",null);
        }

        // 判断会员钱包余额加上信用余额是否大于零
        double money = member.getWallet() + member.getCredit();

        if (money <= 0) {
            log.info("会员余额不足，不能充电，请充值后再充电！===================================================="+money);
            return new CommonVo( "会员钱包余额不足",null);
        }
        // 1. 判断该会员是否有正在充电、结束充电、未付费的订单
        // 1. 如果有，直接返回
        //查询该会员是否有正在充电中的订单
        QueryWrapper<CustomerChargingorder> orderWrapper = new QueryWrapper<>();
        orderWrapper.eq("member_id", member.getId());
        orderWrapper.eq("charging_status", CHARGING.getValue());
        CustomerChargingorder chargingOrder = customerChargingorderMapper.selectOne(orderWrapper);
        if (chargingOrder!=null)
            return new CommonVo("已有正在充电订单",null);

        QueryWrapper<CustomerChargingorder> orderWrapperNew = new QueryWrapper<>();
        orderWrapperNew.eq("member_id", member.getId());
        orderWrapperNew.eq("charging_status", ENDING.getValue());
        CustomerChargingorder chargingOrderNew = customerChargingorderMapper.selectOne(orderWrapperNew);
        if (chargingOrderNew!=null)
            return new CommonVo("订单正在结束中",null);

        //查询该会员是否有未支付订单
        QueryWrapper<CustomerChargingorder> noPayWrapper=new QueryWrapper<>();
        noPayWrapper.eq("member_id",member.getId());
        noPayWrapper.eq("payment_status",ChargingOrderPayStatusEnum.NO_PAY.getValue());
        noPayWrapper.in("charging_status", END_CHARGING.getValue(),START_FAIL.getValue());
        noPayWrapper.gt("total_price",0);
        List<CustomerChargingorder> noPayOrderList = customerChargingorderMapper.selectList(noPayWrapper);
        if (noPayOrderList.size()> 0)
            return new CommonVo("有订单未支付 请先支付",null);

        //修改订单从准备充电为启动失败
        updateOrderStatusFromPrepareChargingToStartFail(member);

        if (is_simulate==1){//是模拟
            //生成订单
            CustomerChargingorder chargingorder = generateChargingOrder(member, connector, chargingpile);
            chargingorder.setScanTime(memberScanTime);
            chargingorder.setChargingStatus(CHARGING.getValue());
            customerChargingorderMapper.insert(chargingorder);
            //返回数据
            Map<String,Object> map=new HashMap<>();
            map.put("order_no",chargingorder.getOrderNo());
            return new CommonVo(map);
        }else {//真实环境
            if (connector == null) {
                log.info("二维码错误，该枪不存在");
                return new CommonVo("二维码错误请重试 或 换枪",null);
            }
            if (chargingpile == null)
                return new CommonVo("充电桩不存在！",null);
                CommonVo commonVo = checkEquipmentStatus(connector, chargingpile);
            if (commonVo.getstatus().equals("99")) return commonVo;

            if (station==null)
                return new CommonVo("站点不存在!",null);
            CommonVo vo = checkStationStatus(station);

            if (vo != null) {
                log.info("站没通过----");
                return vo;
            }

            // 判断会员的状态是否正常
                CommonVo memberStatus = checkMemberStatus(member);
            if (memberStatus != null) return memberStatus;


            //判断枪是否连接
            if(connector.getConnectStatus() == 0)
                return new CommonVo(ResultCode.FAIL_CODE,"未插枪","请检查枪是否已插好");

            //发送启动命令给桩
        	sendCmdToStart(connector, chargingpile, member);
        	//生成订单
        	CustomerChargingorder chargingorder = generateChargingOrder(member, connector, chargingpile);
            chargingorder.setScanTime(memberScanTime);
            customerChargingorderMapper.insert(chargingorder);
            //返回数据
            Map map = new HashMap<>();
            //redisUtil.set();
            map.put("order_no",chargingorder.getOrderNo());
            return new CommonVo(map);
        }
    }

    public CommonVo checkStationStatus(AssetsStations station){
        if (station.getStatus()==StationStatusEnum.UNKNOWN.getValue())
            return new CommonVo("99","该站点未初始化",null);
        if(station.getStatus()==StationStatusEnum.STOP.getValue())
            return new CommonVo("99","该站点停止营业了，请换个站点充电！",null);
        return null;
    }

    @Override
    @Transactional
    public CommonVo stop(String token, String qrCode,Integer isSimulate) {
        log.info("结束充电--------->");
        log.info(token+"------------------------------------------------------");

        if (token==null || qrCode==null || isSimulate==null)
            return new CommonVo("请求参数为空！！",null);
        CustomerMember member = (CustomerMember) redisUtil.get(token);
        if (member==null){
            return new CommonVo("会员不存在，token过期，请重新登录",null);
        }

        //防止redis没有实时更新member钱包金额信息
        member = customerMemberMapper.selectById(member.getId());
        redisUtil.set(token,member, RedisConstant.MEMBER_LOGIN_TOKEN_EXPIRE);
        //一个会员只有一个正在充电中并且枪唯一的订单
        QueryWrapper<CustomerChargingorder> wrapper = new QueryWrapper<>();
        wrapper.eq("connector_code",qrCode);
        wrapper.in("charging_status", CHARGING.getValue(),ENDING.getValue());
        wrapper.eq("member_id",member.getId());

        CustomerChargingorder order = customerChargingorderMapper.selectOne(wrapper);
        if (order!=null){
            if (isSimulate==0){//真实环境
                //修改订单的充电状态
                order.setChargingStatus(ENDING.getValue());
                order.setStopMethod(0);
                customerChargingorderMapper.updateById(order);
                AssetsChargingpile pile = assetsChargingpileMapper.selectById(order.getPileId());
                //通过订单的连接枪编号查询连接枪信息
                AssetsConnector assetsConnector = assetsConnectorMapper.selectById(order.getConnectorId());
                //给桩发送停止充电服务的命令
                sendCmdToStop(pile,assetsConnector);
                //修改订单表信息
                //generateFinalOrder(order.getId());  //插入总数据

            }else {//模拟结束充电
                QueryWrapper<CustomerChargingordertracks> trackWrapper=new QueryWrapper<>();
                log.info("订单编号："+order.getId());
                trackWrapper.eq("order_id",order.getId());
                trackWrapper.orderByAsc("add_time");
                List<CustomerChargingordertracks> tracks = customerChargingordertracksMapper.selectList(trackWrapper);
                if (tracks!=null && tracks.size()>0){
                    CustomerChargingordertracks track = tracks.get(tracks.size() - 1);
                    order.setTotalChargingPrice(track.getTotalChargingPrice());
                    order.setTotalServicePrice(track.getTotalServicePrice());
                    order.setTotalPrice(track.getTotalPrice());
                    //=================总费用计算start=============================================
                    CustomerChargingordertracks start = tracks.get(0);
                    String priceUnit = order.getPriceUnit();
                    SimpleDateFormat df=new SimpleDateFormat("HH:mm");
                    List<PeakTemplateVo> peakTemplateVos = JSONArray.parseArray(priceUnit, PeakTemplateVo.class);
                    List<FreeInfoVo> list=new ArrayList<>();
                    Date startAddTime = start.getAddTime();
                    startAddTime = formatYyMM(startAddTime);
                    Date endAddTime = formatYyMM(track.getAddTime());
                    FreeInfoVo vo=null;
                    try {
                        for (PeakTemplateVo peakTemplateVo : peakTemplateVos) {
                            diGui(peakTemplateVos,list,vo,df.parse(peakTemplateVo.getStartTime()),df.parse(peakTemplateVo.getEndTime()),startAddTime,endAddTime,order.getId(),track);
                            System.out.println(JSONObject.toJSONString(list));
                            break;
                        }
                        order.setPriceCalculation(JSONObject.toJSONString(list));
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    //=================总费用计算end=============================================
                }
                order.setChargingStatus(END_CHARGING.getValue());
                //修改订单表信息
                customerChargingorderMapper.updateById(order);
            }
            return new CommonVo(order.getOrderNo());
        }else {
            return new CommonVo(ResultCode.FAIL_CODE,"该订单不存在或者该订单已经结束，不在充电中范围内",null);
        }
    }

    private void diGui(List<PeakTemplateVo> vos,List<FreeInfoVo> list,FreeInfoVo vo,Date startTime,Date endTime,
                       Date compareDate,Date endAddTime,Integer orderId,CustomerChargingordertracks track){
        SimpleDateFormat df=new SimpleDateFormat("HH:mm");
        vo=new FreeInfoVo();
        Date addTime = track.getAddTime();
        int year = addTime.getYear()+1900;
        int month = addTime.getMonth() + 1;
        int date = addTime.getDate();
        String tyYmD=""+year+"-"+month+"-"+date+" ";
        System.out.println("开始时间："+df.format(startTime)+"，结束时间："+df.format(endTime)+",比较时间："+df.format(compareDate));
        try {
            if (df.format(endTime).equalsIgnoreCase("24:00")){
                endTime=df.parse("23:59");
            }
            if (tomorrowIsActivity(startTime,endTime,compareDate)
                    &&compare(endAddTime,endTime)){
                vo.setStartTime(df.format(startTime));
                if (df.format(endTime).equalsIgnoreCase("23:59")){
                    vo.setEndTime("24:00");
                }else{
                    vo.setEndTime(df.format(endTime));
                }
                Map<String,Object> map = new HashMap<>();
                map.put("orderId", orderId);
                log.info("统一年月日："+tyYmD);
                map.put("compareTime",tyYmD+(df.format(compareDate))+":59");
                QuantityInfoVo startQuantity = customerChargingordertracksMapper.findQuantity(map);
                map.put("compareTime",tyYmD+(df.format(endTime)+":59"));
                QuantityInfoVo endQuantity = customerChargingordertracksMapper.findQuantity(map);
                vo.setQuantity(endQuantity.getQuantity() - startQuantity.getQuantity());
                startTime = endTime;
                compareDate=endTime;
                for (PeakTemplateVo peakTemplateVo : vos) {
                    if (peakTemplateVo.getEndTime().equalsIgnoreCase(df.format(endTime))){
                        vo.setChargingPrice(peakTemplateVo.getChargingPrice());
                        vo.setServicePrice(peakTemplateVo.getServicePrice());
                    }
                    if (peakTemplateVo.getStartTime().equalsIgnoreCase(df.format(endTime))){
                        System.out.println("结束时间："+df.parse(vo.getEndTime()));
                        endTime=df.parse(peakTemplateVo.getEndTime());
                        break;
                    }
                }
                //修改startTime,endTime,compareTime值
                list.add(vo);
                vo=new FreeInfoVo();
                diGui(vos,list,vo,startTime,endTime,compareDate,endAddTime,orderId,track);
            }else {
                vo.setStartTime(df.format(startTime));
                vo.setEndTime(df.format(endAddTime));
                Map<String,Object> map=new HashMap<>();
                log.info("打印开始时间："+startTime+",比较时间："+compareDate+",结束时间："+endTime+"================>>>>>>>>");
                map.put("orderId", orderId);
                map.put("compareTime",tyYmD+(df.format(compareDate)+":59"));
                QuantityInfoVo startQuantity = customerChargingordertracksMapper.findQuantity(map);
                map.put("compareTime",tyYmD+(df.format(endAddTime)+":59"));
                QuantityInfoVo endQuantity = customerChargingordertracksMapper.findQuantity(map);
                log.info("结束电量："+endQuantity.getQuantity()+"开始电量："+startQuantity.getQuantity());
                vo.setQuantity(endQuantity.getQuantity()-startQuantity.getQuantity());
                for (PeakTemplateVo peakTemplateVo : vos) {
                    if (peakTemplateVo.getStartTime().equalsIgnoreCase(df.format(startTime))){
                        vo.setChargingPrice(peakTemplateVo.getChargingPrice());
                        vo.setServicePrice(peakTemplateVo.getServicePrice());
                        break;
                    }
                }
                list.add(vo);
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    private Date formatYyMM(Date startAddTime){
        SimpleDateFormat df=new SimpleDateFormat("HH:mm");
        int hours = startAddTime.getHours();
        String hoursStr="";
        if (hours<10){
            hoursStr="0"+hours;
        }else {
            hoursStr=hours+"";
        }
        System.out.println(hours);
        int minutes = startAddTime.getMinutes();
        Date startTime=null;
        try {
            log.info("打印时间："+hoursStr + ":" + minutes);
            String result=hoursStr + ":" + minutes;
            startTime = df.parse(result);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return startTime;
    }

    private boolean compare(Date a,Date b){
        if (a.getTime()>=b.getTime())
            return true;
        else
            return false;
    }

    private boolean tomorrowIsActivity(Date start,Date end,Date tomorrow){
        SimpleDateFormat df=new SimpleDateFormat("HH:mm");
        try {
            //当前时间
            Calendar nowTime=Calendar.getInstance();
            nowTime.setTime(df.parse(df.format(tomorrow)));
            //开始时间
            Calendar startTime=Calendar.getInstance();
            startTime.setTime(df.parse(df.format(start)));
            //结束时间
            Calendar endTime = Calendar.getInstance();
            endTime.setTime(df.parse(df.format(end)));
            if (df.format(tomorrow).equalsIgnoreCase(df.format(start))){
                return true;
            }
            //表示在指定时间范围内
            if (nowTime.after(startTime)&&nowTime.before(endTime)){
                return true;
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * 停止充电
     * @param pile
     * @param assetsConnector
     */
    private void sendCmdToStop(AssetsChargingpile pile,AssetsConnector assetsConnector){
    	PileCtrl ctrl=new PileCtrl();
        //接口个数和连接枪位置编码与现在表的是不是对应的
        ctrl.setParamType(PileCtrlParamType.PILE_START_STOP.getType());
        ctrl.setConnectorCount(pile.getConnectorNumber().byteValue()); //接口个数--连接枪个数
        ctrl.setConnectorNo(assetsConnector.getSerialNo().byteValue()); //连接枪位置编码--枪口号(充电桩底层接口号)
        //充电模块位置编号   Map<充电模块位置, 编号>
        Map<Byte, Byte> connectorNoMap = new HashMap<Byte, Byte>();
        //充电模块 控制参数值  Map<充电模块位置, 控制参数值>
        Map<Byte, Integer> valueMap = new HashMap<>();

        for (byte i = 1; i <= pile.getConnectorNumber().byteValue(); ++i) {
            connectorNoMap.put(i, i);//编号

            int value = 0;
            if (i == assetsConnector.getSerialNo().byteValue()) {
                //1:开启   2:关闭
                value = 2;
            }
            valueMap.put(i, value);//启停充电
        }
        ctrl.setConnectorNoMap(connectorNoMap);
        ctrl.setValueMap(valueMap);
        ctrl.setPileCode(pile.getCode());
        ctrl.setProviderId(pile.getProviderId());
        ctrl.setConnectorNo(assetsConnector.getSerialNo().byteValue());
        String code = ctrl.getCode(ctrl.getPileCode(), (int) ctrl.getConnectorNo());
        //STOP_PILE_EXCHANGE
        amqpTemplate.convertAndSend(RabbitmqConstant.STOP_PILE_EXCHANGE,RabbitmqConstant.STOP_PILE_ROUTING_KEY,ctrl);

        log.info("手动停止----》发送控制桩停止指令到消息队列");

    }

    /**
     * 判断桩是否在线
     * @param connector
     * @param chargingpile
     * @return
     */
    private CommonVo checkEquipmentStatus(AssetsConnector connector, AssetsChargingpile chargingpile) {
        // 查询桩是否在线
        if (!chargingpile.getIsOnline()) {
            log.info("充电桩离线");
            return new CommonVo("99","充电桩离线","充电桩离线");
        }
        // 查询桩是否启用
        if (!chargingpile.getIsEnabled())
            return new CommonVo("充电桩没有启动",null);
        // 1. 在数据库查询，如果该桩不为空闲
        if (connector.getStatus() != ConnectorStatusEnum.FREE.getValue()) {
            log.info("充电枪的状态为==》{}", ConnectorStatusEnum.valueOf(connector.getStatus()));
            return new CommonVo("99","充电枪已被占用","充电枪已被占用");
        }
         // 判断枪的连接状态
          if (connector.getConnectStatus() == ConnectorConnectStatusEnum.DISCONNECTED.getValue()) {
                log.info("充电枪与桩的连接状态为未连接");
                return new CommonVo("99","请检查充电枪是否已插好","请检查充电枪是否已插好");
            }

        return  new CommonVo(200);
    }


    /***
     * 充电枪开始充电并发送mq生成订单
     * @param connector
     * @param chargingpile
     * @param member
     */
    private void sendCmdToStart(AssetsConnector connector, AssetsChargingpile chargingpile, CustomerMember member) {
    	// 修改充电枪的状态为prepare charging
        connector.setStatus(PREPARE_CHARGING.getValue());
        int count = connectorService.updateConnectorStatusFromFreeToPrepareCharging(connector);

        //修改充电桩的状态为上线
        log.info("有 {} 根枪的状态从空闲改为准备充电", count);
        PileCtrl pileCtrlStart = new PileCtrl();
        //充电生效类型
        pileCtrlStart.setParamType(PileCtrlParamType.PILE_START_STOP.getType());
        //模块数量 
        pileCtrlStart.setConnectorCount(chargingpile.getConnectorNumber().byteValue());
        //用户识别号
        pileCtrlStart.setUserNo(member.getId().toString());
        //枪口号
        pileCtrlStart.setConnectorNo(connector.getSerialNo().byteValue());

        /***宜步map***/
        //充电模块位置编号   Map<充电模块位置, 编号>
        Map<Byte, Byte> connectorNoMap = new HashMap<Byte, Byte>();
        //充电模块 控制参数值  Map<充电模块位置, 控制参数值>
        Map<Byte, Integer> valueMap = new HashMap<Byte, Integer>();

        for (byte i = 1; i <= chargingpile.getConnectorNumber(); ++i) {
            connectorNoMap.put(i, i);//编号

            int value = 0;
            if (i == connector.getSerialNo().byteValue()) {
                //1:开启   2:关闭
                value = 1;
            }
            valueMap.put(i, value);//启停充电
        }
        pileCtrlStart.setConnectorNoMap(connectorNoMap);
        pileCtrlStart.setValueMap(valueMap);
        pileCtrlStart.setPileCode(chargingpile.getCode());
        pileCtrlStart.setMemberId(member.getId());

        pileCtrlStart.setProviderId(chargingpile.getProviderId());
        pileCtrlStart.setConnectorNo(connector.getSerialNo().byteValue());
        //redis +设置当前充电用户id        枪口号+桩编码  唯一用户id
        String key =  pileCtrlStart.getCode(chargingpile.getCode(),connector.getSerialNo());
        redisUtil.set(key,member.getId(),24*60*60);

        amqpTemplate.convertAndSend(RabbitmqConstant.START_PILE_EXCHANGE, RabbitmqConstant.START_PILE_ROUTING_KEY, pileCtrlStart);
        log.info("发送控制桩启动指令到消息队列");

    }

    @Transactional
    public CustomerChargingorder generateChargingOrder(CustomerMember member, AssetsConnector connector, AssetsChargingpile chargingpile) {
        // 查询站点，运营商
        AssetsStations stations = stationsService.getById(chargingpile.getStationId());
        EmployeeCompany company = companyService.getById(stations.getCompanyId());
        // 生成订单号,枪编码_组织机构代码+时间毫秒数+4位随机数
        String orderNo = connector.getCode() + "_" + generateOrderNo(company.getOrganizationCode());//订单号 = 枪编码 + 随机序列
        //计价标准
        CommonVo vo = stationServiceImpl.queryChargingPriceByStationId(stations.getId());
        List<PeakTemplateVo> list=new ArrayList<>();
        List<PriceTemplateVo> vos = (List<PriceTemplateVo>) vo.getdata();
        PeakTemplateVo basicVo = null;
        for (PriceTemplateVo priceTemplateVo : vos) {
            String period = priceTemplateVo.getPeriod();
            String[] split = period.split("-");
            basicVo=new PeakTemplateVo();
            basicVo.setStartTime(split[0]);
            basicVo.setEndTime(split[1]);
            basicVo.setChargingPrice(priceTemplateVo.getCharging_price());
            basicVo.setServicePrice(priceTemplateVo.getService_price());
            basicVo.setPnvType(priceTemplateVo.getPnv_type());
            list.add(basicVo);
        }
        // 订单实例
        CustomerChargingorder chargingorder = new CustomerChargingorder();
        chargingorder.setChargingStatus(PREPARE_CHARGING.getValue())
                .setOrderNo(orderNo)
                .setOrderTime(new Date())
                .setStartTime(new Date())
                .setPaymentStatus(ChargingOrderPayStatusEnum.NO_PAY.getValue())
                .setCityId(stations.getCityId())
                .setCityCode(stations.getCityCode())
                .setCompanyId(company.getId())
                .setConnectorId(connector.getId())
                .setConnectorCode(connector.getCode())
                .setMemberId(member.getId())
                .setMemberPhone(member.getPhone())
                .setPileId(chargingpile.getId())
                .setPileProviderId(chargingpile.getProviderId())
                .setStationId(stations.getId())
                .setPriceUnit(JSONObject.toJSONString(list));

        //customerChargingorderMapper.insert(chargingorder);
        return chargingorder;
    }

    private String generateOrderNo(String organizationCode) {
        organizationCode = StringUtils.isBlank(organizationCode) ? "" : organizationCode;
        String newOrganizationCode = organizationCode.replaceAll("-", "");//去掉机构代码中的"-"
        Calendar now = Calendar.getInstance();
        Random rand = new Random(now.getTimeInMillis());
        String randPart = String.format("%04d", rand.nextInt(10000));//随机数范围：[0, 9999]
        return newOrganizationCode + now.getTimeInMillis() + randPart;
    }

    @Transactional
    public void updateOrderStatusFromPrepareChargingToStartFail(CustomerMember member) {
        CustomerChargingorder chargingorder = chargingorderService.getPrepareChargingOrder(member.getId());
        log.info(member.getPhone()+">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + member.getId());

        // 1. 如果有，设置为启动失败
        if (chargingorder != null) {
            chargingorder.setChargingStatus(START_FAIL.getValue());
            int count = chargingorderService.updatePrepareChargingToStartFail(chargingorder);
            log.info("有[]笔订单启动失败", count);
        }
    }

    private CommonVo checkMemberStatus(CustomerMember member) {
        if (MemberStatusEnum.NORMAL.getValue() != member.getStatus()) {
            log.info("会员状态==》{}", MemberStatusEnum.valueOf(member.getStatus()));
            if (MemberStatusEnum.STOP_USE.getValue() == member.getStatus()) {
                return new CommonVo("会员已停用",null);
            }
            if (MemberStatusEnum.TEMPORARY_FREEZE.getValue() == member.getStatus()) {
                return new CommonVo("会员已临时冻结",null);
            }
            if (MemberStatusEnum.PERMANENT_FREEZE.getValue() == member.getStatus()) {
                return new CommonVo("会员已永久冻结",null);
            }
        }
        return null;
    }
}
