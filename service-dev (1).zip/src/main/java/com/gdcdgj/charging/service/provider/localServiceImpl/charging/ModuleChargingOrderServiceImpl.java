package com.gdcdgj.charging.service.provider.localServiceImpl.charging;

import com.alibaba.fastjson.JSONArray;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.gdcdgj.charging.api.constant.RabbitmqConstant;
import com.gdcdgj.charging.api.entity.AssetsConnector;
import com.gdcdgj.charging.api.entity.CustomerChargingorder;
import com.gdcdgj.charging.api.entity.CustomerChargingordertracks;
import com.gdcdgj.charging.api.entity.CustomerMember;
import com.gdcdgj.charging.api.enums.ConnectorStatusEnum;
import com.gdcdgj.charging.api.enums.PileCtrlParamType;
import com.gdcdgj.charging.api.util.RedisUtil;
import com.gdcdgj.charging.api.vo.order.PeakTemplateVo;
import com.gdcdgj.charging.api.vo.srv2gw.ModuleChargingInfo;
import com.gdcdgj.charging.api.vo.srv2gw.PileCtrl;
import com.gdcdgj.charging.service.provider.mapper.AssetsConnectorMapper;
import com.gdcdgj.charging.service.provider.mapper.CustomerChargingorderMapper;
import com.gdcdgj.charging.service.provider.mapper.CustomerChargingordertracksMapper;
import com.gdcdgj.charging.service.provider.mapper.CustomerMemberMapper;
import com.gdcdgj.charging.service.provider.service.AssetsChargingpileService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.gdcdgj.charging.api.enums.ChargingOrderStatusEnum.CHARGING;

/***
 * 宜步的数据测试
 */
@Slf4j
@Component
public class ModuleChargingOrderServiceImpl {
/*

    @Autowired
    AssetsChargingpileService chargingpileService;
    @Autowired
    RedisUtil redisUtil;

    @Resource
    CustomerChargingorderMapper customerChargingorderMapper;

    @Resource
    CustomerMemberMapper customerMemberMapper;

    @Resource
    AssetsConnectorMapper assetsConnectorMapper;
    @Resource
    CustomerChargingordertracksMapper customerChargingordertracksMapper;

    @Resource
    AmqpTemplate amqpTemplate;

    public void moduleChargingOrder(ModuleChargingInfo moduleChargingInfo){
        //桩充电状态上报信息
        //修改表customer_chargingOrder 和 customer_chargingOrderTracks
        CustomerMember member = customerMemberMapper.selectById(moduleChargingInfo.getMemberId());
        QueryWrapper<CustomerChargingorder> orderWrapper = new QueryWrapper<>();
        orderWrapper.eq("member_id", member.getId());
        orderWrapper.eq("charging_status", CHARGING.getValue());
        CustomerChargingorder chargingOrder = customerChargingorderMapper.selectOne(orderWrapper);
        //判断订单是否存在充电订单
        if (chargingOrder != null) {
            setNewCustomerChargingordertracks(moduleChargingInfo,chargingOrder,member);
        }
        log.info("桩编号==》{}", moduleChargingInfo.getPileCode());
    }

    */
/**
     * 记录充电轨迹表
     * 更新最终订单表
     * @param moduleChargingInfo
     * @return
     *//*

    public CustomerChargingordertracks setNewCustomerChargingordertracks(ModuleChargingInfo moduleChargingInfo, CustomerChargingorder chargingOrder, CustomerMember member) {
        //CustomerMember member = customerMemberMapper.selectById(moduleChargingInfo.getMemberId());
		*/
/*QueryWrapper<CustomerChargingorder> orderWrapper = new QueryWrapper<>();
		orderWrapper.eq("member_id", member.getId());
		orderWrapper.eq("charging_status", CHARGING.getValue());
		CustomerChargingorder chargingOrder = customerChargingorderMapper.selectOne(orderWrapper);*//*

        QueryWrapper<AssetsConnector> assetsConnectorQueryWrapper = new QueryWrapper<>();
        assetsConnectorQueryWrapper.eq("id",chargingOrder.getConnectorId());
        AssetsConnector assetsConnector = assetsConnectorMapper.selectOne(assetsConnectorQueryWrapper);	//获取枪
        AssetsConnector assetsConnectorNew = new AssetsConnector();
        assetsConnectorNew.setId(assetsConnector.getId());


        CustomerChargingordertracks customerChargingordertracks = new CustomerChargingordertracks();
        if (member.getWallet() > chargingOrder.getTotalPrice()) {

            Date date = new Date();
            customerChargingordertracks.setOrderId(chargingOrder.getId());
            customerChargingordertracks.setAddTime(date);

            if (chargingOrder.getPriceUnit() != null) {
                List<PeakTemplateVo> json = (List) JSONArray.parse(chargingOrder.getPriceUnit().toString());

                //判断峰平谷时电量
                for (PeakTemplateVo peakTemplateVo : json) {
                    if (peakTemplateVo.getStartTime().compareTo(date.getHours() + ":" + date.getMinutes()) < 0
                            && peakTemplateVo.getEndTime().compareTo(date.getHours() + ":" + date.getMinutes()) > 0) {
                        if (peakTemplateVo.getPnvType() == 1) {		//峰
                            for (int i=0; i < moduleChargingInfo.getStateMap().size(); i++) {

                                Integer totalAn = moduleChargingInfo.getAhMap().get(i);    //位置N本次累计充电Ah
                                Double totalKw = moduleChargingInfo.getKwhMap().get(i);    //位置N电表度数kwh
                                Integer totalDate = moduleChargingInfo.getTimeMap().get(i); //位置N本次累计充电时间
                                Integer minute = moduleChargingInfo.getRemainTimeMap().get(i);    //预估充满时间(分钟)  Map<充电枪位置, 分钟>
                                Byte socByte = moduleChargingInfo.getSocNowMap().get(i);	//充电枪位置N当前充电SOC   Map<充电枪位置, soc>
                                Byte connectedByte = moduleChargingInfo.getConnectedStateMap().get(i);	//充电枪位置N连接状态   Map<充电枪位置, 连接状态>  0未连接，1已连接
                                Byte stateByte = moduleChargingInfo.getStateMap().get(i);
                                Double current = moduleChargingInfo.getCurrentMap().get(i); //电流
                                Double voltage = moduleChargingInfo.getVoltageMap().get(i); //电压
                                Integer leftTime = moduleChargingInfo.getRemainTimeMap().get(i); //预计剩余时间
                                if (stateByte == 1) {
                                    if (redisUtil.get("pnvTypeNew1") == null) {
                                        redisUtil.set("pnvTypeNew1", totalAn);
                                        redisUtil.set("chargingNew1", totalDate);
                                    }
                                    assetsConnectorNew.setConnectStatus((int) connectedByte);
                                    assetsConnectorNew.setStatus((int) moduleChargingInfo.getStateMap().get(i));

                                    customerChargingordertracks.setPeaksChargingTime(totalDate - (Integer) redisUtil.get("chargingNew1"));//峰时充电时长
                                    customerChargingordertracks.setPeaksChargingQuantity((double) (totalAn - (Integer) redisUtil.get("pnvTypeNew1")));//峰时充电电量
                                    customerChargingordertracks.setPeaksChargingPrice(peakTemplateVo.getChargingPrice());//峰时电费
                                    customerChargingordertracks.setPeaksServicePrice(peakTemplateVo.getServicePrice());//峰时服务费

                                    Double serviceTotal = customerChargingordertracks.getNormalServicePrice()
                                            + customerChargingordertracks.getValleysServicePrice()
                                            + customerChargingordertracks.getPeaksServicePrice();
                                    Double chargingPriceTotal = customerChargingordertracks.getNormalChargingPrice()
                                            + customerChargingordertracks.getValleysChargingPrice()
                                            + customerChargingordertracks.getPeaksChargingPrice();
                                    Double totalCharing = customerChargingordertracks.getPeaksChargingQuantity()
                                            +customerChargingordertracks.getNormalChargingQuantity()
                                            +customerChargingordertracks.getValleysChargingQuantity();
                                    customerChargingordertracks.setTotalChargingTime(totalDate);//总充电时长
                                    customerChargingordertracks.setTotalChargingQuantity(totalCharing);//总充电电量
                                    customerChargingordertracks.setTotalChargingPrice(chargingPriceTotal);//总充电费
                                    customerChargingordertracks.setTotalServicePrice(serviceTotal);//总服务费
                                    customerChargingordertracks.setTotalPrice(customerChargingordertracks.getTotalChargingPrice() + customerChargingordertracks.getTotalServicePrice());//总费用
                                    customerChargingordertracks.setSoc(Double.valueOf(socByte));//当前SOC
                                    customerChargingordertracks.setElectric(totalKw);//当前电表度数
                                    customerChargingordertracks.setRequireCurrent(current);//当前电流
                                    customerChargingordertracks.setRequireVoltage(voltage);//当前电压
                                    customerChargingordertracks.setLeftTime(leftTime); //预计剩余时间
                                    customerChargingordertracksMapper.insert(customerChargingordertracks);
                                    assetsConnectorMapper.updateById(assetsConnectorNew);
                                    QueryWrapper<CustomerChargingorder> queryWrapper= new QueryWrapper();
                                    queryWrapper.eq("id",chargingOrder.getId());
                                    chargingOrder.setTotalPrice(customerChargingordertracks.getTotalPrice());
                                    customerChargingorderMapper.update(chargingOrder,queryWrapper);

                                }else if (stateByte == 2){
                                    generateFinalOrder(chargingOrder.getId(),moduleChargingInfo);	//最终订单
                                    stopSendMq(moduleChargingInfo);											//停mq
                                }
                            }
                        }else if (peakTemplateVo.getPnvType() == 2) {		//平

                            for (int i = 0; i < moduleChargingInfo.getStateMap().size(); i++) {

                                Integer totalAn = moduleChargingInfo.getAhMap().get(i);    //位置N本次累计充电Ah
                                Double totalKw = moduleChargingInfo.getKwhMap().get(i);    //位置N电表度数kwh
                                Integer totalDate = moduleChargingInfo.getTimeMap().get(i); //位置N本次累计充电时间
                                Integer minute = moduleChargingInfo.getRemainTimeMap().get(i);    //预估充满时间(分钟)  Map<充电枪位置, 分钟>
                                Byte socByte = moduleChargingInfo.getSocNowMap().get(i);	//充电枪位置N起始充电SOC   Map<充电枪位置, soc>
                                Byte connectedByte = moduleChargingInfo.getConnectedStateMap().get(i);	//充电枪位置N连接状态   Map<充电枪位置, 连接状态>  0未连接，1已连接
                                Byte stateByte = moduleChargingInfo.getStateMap().get(i);
                                Double current = moduleChargingInfo.getCurrentMap().get(i); //电流
                                Double voltage = moduleChargingInfo.getVoltageMap().get(i); //电压
                                Integer leftTime = moduleChargingInfo.getRemainTimeMap().get(i); //预计剩余时间
                                if (stateByte == 1) {
                                    if (redisUtil.get("pnvTypeNew2") == null) {
                                        redisUtil.set("pnvTypeNew2", totalAn);
                                        redisUtil.set("chargingNew2", totalDate);
                                    }
                                    customerChargingordertracks.setNormalChargingTime(totalDate - (Integer) redisUtil.get("chargingNew2"));//平时充电时长
                                    customerChargingordertracks.setNormalChargingQuantity((double) (totalAn - (Integer) redisUtil.get("pnvTypeNew2")));//平时充电电量
                                    customerChargingordertracks.setNormalChargingPrice(peakTemplateVo.getChargingPrice());//平时电费
                                    customerChargingordertracks.setNormalServicePrice(peakTemplateVo.getServicePrice());//平时服务费

                                    assetsConnectorNew.setConnectStatus((int) connectedByte);
                                    assetsConnectorNew.setStatus((int) moduleChargingInfo.getStateMap().get(i));
                                    Double serviceTotal = customerChargingordertracks.getNormalServicePrice()
                                            + customerChargingordertracks.getValleysServicePrice()
                                            + customerChargingordertracks.getPeaksServicePrice();
                                    Double chargingPriceTotal = customerChargingordertracks.getNormalChargingPrice()
                                            + customerChargingordertracks.getValleysChargingPrice()
                                            + customerChargingordertracks.getPeaksChargingPrice();
                                    Double totalCharing = customerChargingordertracks.getPeaksChargingQuantity()
                                            +customerChargingordertracks.getNormalChargingQuantity()
                                            +customerChargingordertracks.getValleysChargingQuantity();

                                    customerChargingordertracks.setTotalChargingTime(totalDate);//总充电时长
                                    customerChargingordertracks.setTotalChargingQuantity(totalCharing);//总充电电量
                                    customerChargingordertracks.setTotalChargingPrice(chargingPriceTotal);//总充电费
                                    customerChargingordertracks.setTotalServicePrice(serviceTotal);//总服务费
                                    customerChargingordertracks.setTotalPrice(customerChargingordertracks.getTotalChargingPrice() + customerChargingordertracks.getTotalServicePrice());//总费用
                                    customerChargingordertracks.setSoc(Double.valueOf(socByte));//当前SOC
                                    customerChargingordertracks.setElectric(totalKw);//当前电表度数
                                    customerChargingordertracks.setRequireCurrent(current);//当前电流
                                    customerChargingordertracks.setRequireVoltage(voltage);//当前电压
                                    customerChargingordertracks.setLeftTime(leftTime); //预计剩余时间
                                    customerChargingordertracksMapper.insert(customerChargingordertracks);
                                    assetsConnectorMapper.updateById(assetsConnectorNew);
                                    QueryWrapper<CustomerChargingorder> queryWrapper= new QueryWrapper();
                                    queryWrapper.eq("id",chargingOrder.getId());
                                    chargingOrder.setTotalPrice(customerChargingordertracks.getTotalPrice());
                                    customerChargingorderMapper.update(chargingOrder,queryWrapper);

                                }else if (stateByte == 2){
                                    generateFinalOrder(chargingOrder.getId(),moduleChargingInfo);	//最终订单
                                    stopSendMq(moduleChargingInfo);
                                }
                            }
                        } else{		//谷

                            for (int i = 0; i < moduleChargingInfo.getStateMap().size(); i++) {
                                Integer totalAn = moduleChargingInfo.getAhMap().get(i);    //位置N本次累计充电Ah
                                Double totalKw = moduleChargingInfo.getKwhMap().get(i);    //位置N电表度数kwh
                                Integer totalDate = moduleChargingInfo.getTimeMap().get(i); //位置N本次累计充电时间
                                Integer minute = moduleChargingInfo.getRemainTimeMap().get(i);    //预估充满时间(分钟)  Map<充电枪位置, 分钟>
                                Byte socByte = moduleChargingInfo.getSocNowMap().get(i);	//充电枪位置N起始充电SOC   Map<充电枪位置, soc>
                                Byte connectedByte = moduleChargingInfo.getConnectedStateMap().get(i);	//充电枪位置N连接状态   Map<充电枪位置, 连接状态>  0未连接，1已连接
                                Byte stateByte = moduleChargingInfo.getStateMap().get(i);
                                Double current = moduleChargingInfo.getCurrentMap().get(i); //电流
                                Double voltage = moduleChargingInfo.getVoltageMap().get(i); //电压
                                Integer leftTime = moduleChargingInfo.getRemainTimeMap().get(i); //预计剩余时间
                                if (socByte==1) {
                                    if (redisUtil.get("pnvTypeNew3") == null) {
                                        redisUtil.set("pnvTypeNew3", totalAn);
                                        redisUtil.set("chargingNew3", totalDate);
                                    }
                                    assetsConnectorNew.setConnectStatus((int) connectedByte);
                                    assetsConnectorNew.setStatus((int) moduleChargingInfo.getStateMap().get(i));
                                    customerChargingordertracks.setValleysChargingTime(totalDate - (Integer) redisUtil.get("chargingNew3"));//谷时充电时长
                                    customerChargingordertracks.setValleysChargingQuantity((double) (totalAn - (Integer) redisUtil.get("pnvTypeNew3")));//谷时充电电量
                                    customerChargingordertracks.setValleysChargingPrice(peakTemplateVo.getChargingPrice());//谷时电费
                                    customerChargingordertracks.setValleysServicePrice(peakTemplateVo.getServicePrice());//谷时服务费

                                    Double serviceTotal = customerChargingordertracks.getNormalServicePrice()
                                            + customerChargingordertracks.getValleysServicePrice()
                                            + customerChargingordertracks.getPeaksServicePrice();
                                    Double chargingPriceTotal = customerChargingordertracks.getNormalChargingPrice()
                                            + customerChargingordertracks.getValleysChargingPrice()
                                            + customerChargingordertracks.getPeaksChargingPrice();
                                    Double totalCharing = customerChargingordertracks.getPeaksChargingQuantity()
                                            +customerChargingordertracks.getNormalChargingQuantity()
                                            +customerChargingordertracks.getValleysChargingQuantity();

                                    customerChargingordertracks.setTotalChargingTime(totalDate);//总充电时长
                                    customerChargingordertracks.setTotalChargingQuantity(totalCharing);//总充电电量
                                    customerChargingordertracks.setTotalChargingPrice(chargingPriceTotal);//总充电费
                                    customerChargingordertracks.setTotalServicePrice(serviceTotal);//总服务费
                                    customerChargingordertracks.setTotalPrice(customerChargingordertracks.getTotalChargingPrice() + customerChargingordertracks.getTotalServicePrice());//总费用
                                    customerChargingordertracks.setSoc(Double.valueOf(socByte));//当前SOC
                                    customerChargingordertracks.setElectric(totalKw);//当前电表度数
                                    customerChargingordertracks.setRequireCurrent(current);//当前电流
                                    customerChargingordertracks.setRequireVoltage(voltage);//当前电压
                                    customerChargingordertracks.setLeftTime(leftTime); //预计剩余时间
                                    customerChargingordertracksMapper.insert(customerChargingordertracks);
                                    assetsConnectorMapper.updateById(assetsConnectorNew);
                                    QueryWrapper<CustomerChargingorder> queryWrapper= new QueryWrapper();
                                    queryWrapper.eq("id",chargingOrder.getId());
                                    chargingOrder.setTotalPrice(customerChargingordertracks.getTotalPrice());
                                    customerChargingorderMapper.update(chargingOrder,queryWrapper);
                                }else if (stateByte==2){
                                    generateFinalOrder(chargingOrder.getId(),moduleChargingInfo);	//最终订单
                                    stopSendMq(moduleChargingInfo);
                                }
                            }
                        }
                    }
                }
            }
        } else {
            //余额不足，生成最终订单
            generateFinalOrder(customerChargingordertracks.getOrderId(),moduleChargingInfo);
            //停止mq
            stopSendMq(moduleChargingInfo);
        }
        return customerChargingordertracks;
    }

    public void generateFinalOrder(int chargingorder,ModuleChargingInfo chargingInfo) {
        QueryWrapper<CustomerChargingorder> orderWrapper = new QueryWrapper<>();
        orderWrapper.eq("order_no", chargingorder);
        CustomerChargingorder order = customerChargingorderMapper.selectOne(orderWrapper);
        if (order != null) {
            //如果此订单正在充电，才能结束充电
            order.setStopTime(new Date());
            //order.setChargingStatus(END_CHARGING.getValue());
            //将充电轨迹记录按照时间升序取最后一条，将电量，服务费等信息补充到订单信息中
            QueryWrapper<CustomerChargingordertracks> tracksWrapper = new QueryWrapper<>();
            tracksWrapper.eq("order_id", order.getId());
            tracksWrapper.orderByAsc("add_time");
            List<CustomerChargingordertracks> trackList = customerChargingordertracksMapper.selectList(tracksWrapper);
            CustomerChargingordertracks tracks = trackList.get(trackList.size() - 1);
            //将充电轨迹记录的一些数据封装到订单中
            order.setPeaksChargingTime(tracks.getPeaksChargingTime());//峰时充电时长
            order.setPeaksChargingQuantity(tracks.getPeaksChargingQuantity());//峰时充电电量
            order.setPeaksChargingPrice(tracks.getPeaksChargingPrice());//峰时电费
            order.setPeaksServicePrice(tracks.getPeaksServicePrice());//峰时服务费
            order.setNormalChargingTime(tracks.getNormalChargingTime());//平时充电时长
            order.setNormalChargingQuantity(tracks.getNormalChargingQuantity());//平时充电电量
            order.setNormalChargingPrice(tracks.getNormalChargingPrice());//平时电费
            order.setNormalServicePrice(tracks.getNormalServicePrice());//平时服务费
            order.setValleysChargingTime(tracks.getValleysChargingTime());//谷时充电时长
            order.setValleysChargingQuantity(tracks.getValleysChargingQuantity());//谷时电量
            order.setValleysChargingPrice(tracks.getValleysChargingPrice());//谷时电费
            order.setValleysServicePrice(tracks.getValleysServicePrice());//谷时服务费
            order.setTotalChargingTime(tracks.getTotalChargingTime());//总充电时长
            order.setTotalChargingQuantity(tracks.getTotalChargingQuantity());//总充电电量
            order.setTotalChargingPrice(tracks.getTotalChargingPrice());//总充电费
            order.setTotalServicePrice(tracks.getTotalServicePrice());//总服务费
            order.setTotalPrice(tracks.getTotalPrice());//总费用
            order.setSocStart((double)chargingInfo.getSocBeginMap().get(1));//起始SOC电量
            order.setSocEnd(trackList.get(0).getSoc());//结束SOC电量
            order.setElectricStart(trackList.get(0).getElectric());//起始电表度数
            order.setElectricEnd(tracks.getElectric());//结束电表度数
            //更新订单信息
            QueryWrapper<CustomerChargingorder> updateWrapper = new QueryWrapper<>();
            updateWrapper.eq("order_no", order.getOrderNo());
            customerChargingorderMapper.update(order, updateWrapper);
            //更新充电枪状态
            AssetsConnector connector = new AssetsConnector();
            connector.setId(order.getConnectorId());
            connector.setStatus(ConnectorStatusEnum.END_CHARGING.getValue());
            assetsConnectorMapper.updateById(connector);
            redisUtil.del("pnvTypeNew1");
            redisUtil.del("pnvTypeNew2");
            redisUtil.del("pnvTypeNew3");
            redisUtil.del("chargingNew1");
            redisUtil.del("chargingNew2");
            redisUtil.del("chargingNew3");
        }
    }


    public void stopSendMq(ModuleChargingInfo moduleChargingInfo){
        //下发停止mq->
        PileCtrl ctrl=new PileCtrl();
        //接口个数和连接枪位置编码与现在表的是不是对应的
        ctrl.setPileCode(moduleChargingInfo.getPileCode());//电桩编码
        ctrl.setProviderId(moduleChargingInfo.getProviderId());//所属桩
        ctrl.setParamType(PileCtrlParamType.PILE_START_STOP.getType());
        ctrl.setConnectorCount(moduleChargingInfo.getConnectorCnt());//接口个数--连接枪个数
        ctrl.setConnectorNo(moduleChargingInfo.getConnectorNo());//连接枪位置编码--枪口号(充电桩底层接口号)
        //pileCtrl.setMemberId(Server.getOperatorId());
        //pileCtrl.setBaseEquipmentCode(equipmentCode);
        //充电模块位置编号   Map<充电模块位置, 编号>
        Map<Byte, Byte> connectorNoMap = new HashMap<Byte, Byte>();
        //充电模块 控制参数值  Map<充电模块位置, 控制参数值>
        Map<Byte, Integer> valueMap = new HashMap<Byte, Integer>();

        for (byte i = 1; i <= moduleChargingInfo.getConnectorCnt(); ++i) {
            connectorNoMap.put(i, i);//编号

            int value = 0;
            if (i == moduleChargingInfo.getConnectorNo()) {
                //1:开启   2:关闭
                value = false ? 1 : 2;
            }
            valueMap.put(i, value);//启停充电
        }

        ctrl.setConnectorNoMap(connectorNoMap);
        ctrl.setValueMap(valueMap);
        amqpTemplate.convertAndSend(RabbitmqConstant.STOP_PILE_EXCHANGE, RabbitmqConstant.STOP_PILE_ROUTING_KEY,ctrl);
    }
*/


}
