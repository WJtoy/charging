package com.gdcdgj.charging.service.provider.localServiceImpl.login;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.gdcdgj.charging.api.constant.RedisConstant;
import com.gdcdgj.charging.api.entity.CustomerLoginrecord;
import com.gdcdgj.charging.api.entity.CustomerMember;
import com.gdcdgj.charging.api.enums.MemberSexEnum;
import com.gdcdgj.charging.api.enums.MemberSourceEnum;
import com.gdcdgj.charging.api.enums.MemberStatusEnum;
import com.gdcdgj.charging.api.localService.login.LoginService;
import com.gdcdgj.charging.api.util.IdGenerationTool;
import com.gdcdgj.charging.api.util.RedisUtil;
import com.gdcdgj.charging.api.vo.CommonVo;
import com.gdcdgj.charging.service.provider.mapper.CustomerLoginrecordMapper;
import com.gdcdgj.charging.service.provider.mapper.CustomerMemberMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * 登录、注册、退出
 *
 * @author Changliang Tao
 * @date 2020/3/27 16:49
 * @since JDK 1.8
 */
@Slf4j
@Service(version = "1.0.0")
public class LoginServiceImpl implements LoginService {

    @Autowired
    CustomerMemberMapper customerMemberMapper;

    @Autowired
    CustomerLoginrecordMapper customerLoginrecordMapper;

    @Autowired
    RedisUtil redisUtil;

    /**
     * 登录方法
     *
     * @return
     * @throws
     * @author Changliang Tao
     * @date 2020/3/27 16:50
     */
    @Override
    public CommonVo login(Map<String,String> map) {
        //前端传入的值
        String phone=map.get("phone");
        String code = map.get("code");
        // 根据手机号去redis查询,如果有，则返回
        String token = (String) redisUtil.get(RedisConstant.MEMBER_LOGIN_TOKEN + phone);
        if (token != null) {
            return new CommonVo(formatToken(token));
        }
        // 如果redis里面没有
        // 根据手机号去数据库查询该用户
        QueryWrapper<CustomerMember> phoneWrapper = new QueryWrapper<>();
        phoneWrapper.eq("phone",phone);
        Integer phoneRecords = customerMemberMapper.selectCount(phoneWrapper);
        log.info("查看手机号是否有被注册：" + phoneRecords);
        // 如果存在，则生成token，并保存到redis
        if (phoneRecords != 0) {
            // 生成token
            token = RedisConstant.TOKEN_PREFIX + IdGenerationTool.getRandomStringByLength(100);
            // 根据手机号码查询用户
            QueryWrapper<CustomerMember> memberWrapper=new QueryWrapper<>();
            memberWrapper.eq("phone",phone);
            CustomerMember member = customerMemberMapper.selectOne(memberWrapper);
            // 在数据库更新token、登录时间
            member.setToken(token).setLastLoginTime(new Date());
            customerMemberMapper.updateById(member);
            // 保存到redis
            redisUtil.set(RedisConstant.MEMBER_LOGIN_TOKEN + phone, token, RedisConstant.MEMBER_LOGIN_TOKEN_EXPIRE);
            redisUtil.set(token, member, RedisConstant.MEMBER_LOGIN_TOKEN_EXPIRE);
            // 保存登录记录
            CustomerLoginrecord loginRecord = new CustomerLoginrecord();
            loginRecord.setLoginTime(new Date()).setMemberId(member.getId());
            customerLoginrecordMapper.insert(loginRecord);

            // 返回token
            return new CommonVo(formatToken(token));
        } else {
            log.info("该用户不存在");
            CommonVo vo = this.register(map);
            if ("00".equals(vo.getstatus())){
                Map<String,String> loginMap=new HashMap();
                loginMap.put("phone",map.get("phone"));
                vo = this.login(loginMap);
            }
            return vo;
        }
    }

    private Map<String,String> formatToken(String token){
        Map<String,String> data=new HashMap<>();
        data.put("token",token);
        return data;
    }

    /**
     * 注册
     *
     * @return common vo
     * @throws
     * @author Changliang Tao
     * @date 2020/4/21 10:01
     */
    @Transactional
    public CommonVo register(Map<String,String> map) {
        // 目前保存的字段有 phone sex register_time status source password memo
        CustomerMember member=new CustomerMember();
        try {
            member.setRegisterTime(new Date())
                    .setCredit(0.00)
                    .setWallet(0.00)
                    .setSex(MemberSexEnum.UNKNOWN.getValue())
                    .setStatus(MemberStatusEnum.NORMAL.getValue())
                    .setSource(MemberSourceEnum.MINI_APP.getValue())
                    .setPassword(map.get("password"))
                    .setMemo("用户注册")
                    .setPhone(map.get("phone"))
                    .setRegisterAddress(map.get("register_address"));
            customerMemberMapper.insert(member);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new CommonVo("注册成功");
    }

}
