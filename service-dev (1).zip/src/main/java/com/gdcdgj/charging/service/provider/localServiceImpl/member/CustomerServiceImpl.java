package com.gdcdgj.charging.service.provider.localServiceImpl.member;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.gdcdgj.charging.api.entity.*;
import com.gdcdgj.charging.api.enums.ChargingOrderPayStatusEnum;
import com.gdcdgj.charging.api.vo.customer.CarnumberInfoVo;
import com.gdcdgj.charging.service.provider.mapper.*;
import org.apache.dubbo.config.annotation.Service;
import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.gdcdgj.charging.api.constant.RedisConstant;
import com.gdcdgj.charging.api.enums.PayMethodEnum;
import com.gdcdgj.charging.api.enums.PriceIsDefaultEunm;
import com.gdcdgj.charging.api.localService.member.CustomerService;
import com.gdcdgj.charging.api.util.RedisUtil;
import com.gdcdgj.charging.api.vo.CommonVo;
import com.gdcdgj.charging.api.vo.charging.ChargingStationAllInfoVo;
import com.gdcdgj.charging.api.vo.charging.ChargingStationNumberVo;
import com.gdcdgj.charging.api.vo.customer.CustomerInfoVo;
import com.gdcdgj.charging.api.vo.customer.MoneyRecordVo;
import com.gdcdgj.charging.service.provider.localServiceImpl.station.StationServiceImpl;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author JianMei Chen
 * @date 2020/05/08/8:45
 */
@Service
@Slf4j
public class CustomerServiceImpl implements CustomerService {

    @Autowired
    private CustomerCarnumberMapper customerCarnumberMapper;//会员车牌

    @Autowired
    private CustomerCouponsrecordMapper customerCouponsrecordMapper;//会员优惠券

    @Autowired
    private CustomerMemberMapper customerMemberMapper;//会员

    @Autowired
    private CustomerRechargerecordMapper customerRechargerecordMapper;//会员充值记录

    @Autowired
    private CustomerMemberFavourateStationsMapper customerMemberFavourateStationsMapper;//会员收藏站点关联

    @Autowired
    private AssetsStationsMapper assetsStationsMapper;//站点

    @Autowired
    private AssetsStationchargingpriceMapper assetsStationchargingpriceMapper;//价格绑定表

    @Autowired
    private ConfigurationChargingpriceMapper configurationChargingpriceMapper;//价格模板表

    @Autowired
    private ConfigurationChargingpricetimeperiodMapper configurationChargingpricetimeperiodMapper;//价格时段


    @Autowired
    private CustomerRefundrecordMapper customerRefundrecordMapper;//会员退款记录

    @Autowired
    private CustomerChargingorderMapper customerChargingorderMapper;//充电订单

    @Autowired
    private StationServiceImpl stationServiceImpl;

    @Autowired
    private RedisUtil redisUtil;

    @Override
    public CommonVo profile(String token) {
        log.info("会员相关信息");
        CustomerInfoVo vo=new CustomerInfoVo();
        //参数为空
        if (token==null)
            return new CommonVo("token为空",null);
        //参数不为空
        try {
            CustomerMember member = (CustomerMember) redisUtil.get(token);
            member = customerMemberMapper.selectById(member.getId());
            if (member!=null){
                vo.setPhone(member.getPhone());
                vo.setWallet(member.getWallet());
                vo.setCredit(member.getCredit());
                //1.根据会员编号查询会员车辆信息
                QueryWrapper<CustomerCarnumber> carNumberMapper=new QueryWrapper<>();
                carNumberMapper.eq("member_id",member.getId());
                carNumberMapper.eq("is_default",1);
                CustomerCarnumber carnumber = customerCarnumberMapper.selectOne(carNumberMapper);
                //车牌号
                if (carnumber!=null)
                    vo.setCar_number(carnumber.getNumber());
                //2.根据会员编号查询优惠券的数量
                QueryWrapper<CustomerCouponsrecord> couponWrapper=new QueryWrapper<>();
                couponWrapper.eq("member_id",member.getId());
                Integer count = customerCouponsrecordMapper.selectCount(couponWrapper);
                vo.setCoupon_count(count);
                redisUtil.set(token,member,RedisConstant.MEMBER_LOGIN_TOKEN_EXPIRE);
            }else{
                return new CommonVo("redis里没有该会员的记录",null);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new CommonVo(vo);
    }

    @Override
    @Transactional
    public String rechargeNotify(Map<String, String> map) {
        log.info("会员支付充值后通知回调!!!");
        try {
            CustomerRechargerecord recharge=new CustomerRechargerecord();
            recharge.setMoney(Double.parseDouble(map.get("payMoney")));//金额
            SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            recharge.setTradeTime(df.parse(map.get("payTime")));//支付时间
            if ("WX".equalsIgnoreCase(map.get("channelId"))){//支付类型
                recharge.setPayMethod(PayMethodEnum.WX.getValue());
            }
            recharge.setTradeNo(map.get("upOrderId"));//流水号
            recharge.setStatus(Integer.parseInt(map.get("state")));//支付状态
            recharge.setRemark(map.get("orderDesc"));//订单详情
            QueryWrapper<CustomerMember> phoenWrpper = new QueryWrapper<>();
            String attach = map.get("attach");//附带信息
            JSONObject jsonObject = JSONObject.parseObject(attach);
            String phone = jsonObject.getString("phone");
            phoenWrpper.eq("phone",phone);
            CustomerMember member = customerMemberMapper.selectOne(phoenWrpper);
            if (member!=null)
                recharge.setMemberId(member.getId());
            else
                return "没有会员信息";
            //添加会员充值记录
            customerRechargerecordMapper.insert(recharge);
            //修改会员钱包金额
            Double wallet = member.getWallet();
            member.setWallet(wallet+Double.parseDouble(map.get("payMoney")));
            customerMemberMapper.updateById(member);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        log.info("SUCCESS");
        return "SUCCESS";
    }

    @Override
    public CommonVo collectionStation(String token,Integer page,Integer pageSize) {
        log.info("显示会员收藏站点列表");
        List<ChargingStationAllInfoVo> list=new ArrayList<>();
        CustomerMember member = (CustomerMember) redisUtil.get(token);
        QueryWrapper<CustomerMemberFavourateStations> wrapper=new QueryWrapper<>();
        wrapper.eq("member_id",member.getId());
        Page<CustomerMemberFavourateStations> customerMemberFavourateStationsPage = customerMemberFavourateStationsMapper.selectPage(new Page<>(page, pageSize), wrapper);
        List<CustomerMemberFavourateStations> customerMemberFavourateStations = customerMemberFavourateStationsPage.getRecords();
        if (customerMemberFavourateStations==null||customerMemberFavourateStations.size()<=0)
            return new CommonVo("该会员没有收藏任何站点",null);
        List<Integer> ids=new ArrayList<>();
        for (CustomerMemberFavourateStations favourateStation : customerMemberFavourateStations) {
            ids.add(favourateStation.getStationsId());
        }
        log.info("站点编号集合："+ids);
        List<ChargingStationAllInfoVo> allInfoVos = assetsStationsMapper.selectStationByIds(ids);
        for (ChargingStationAllInfoVo vo : allInfoVos) {
            //1.通过站点编号在价格绑定表中查询看有几个模板编号,如果>1表示，该站点有活动模板，需看当前时间是否为活动时间
            QueryWrapper<AssetsStationchargingprice> priceMiddleWrapper=new QueryWrapper<>();
            priceMiddleWrapper.eq("station_id",vo.getId());
            Integer count = assetsStationchargingpriceMapper.selectCount(priceMiddleWrapper);
            if (count>1){//表示该站点有多个价格模板
                //2.根据价格绑定表的is_defalut字段和station_id字段来找出活动模板的活动时间
                QueryWrapper<AssetsStationchargingprice> actionWrapper=new QueryWrapper<>();
                actionWrapper.eq("station_id",vo.getId());
                actionWrapper.eq("is_default", PriceIsDefaultEunm.NO.getValue());
                actionWrapper.eq("is_enabled",1);
                List<AssetsStationchargingprice> priceMiddleTables = assetsStationchargingpriceMapper.selectList(actionWrapper);
                for (AssetsStationchargingprice chargingPrice : priceMiddleTables) {
                    if (stationServiceImpl.nowTimeIsRangeTime(chargingPrice.getStartTime(),chargingPrice.getEndTime(),"yyyy-MM-dd HH:mm:ss")){
                        //3.通过价格模板编号来查询价格模板信息
                        ConfigurationChargingprice priceModel = configurationChargingpriceMapper.selectById(chargingPrice.getPriceId());
                        //4.根据价格模板看是否统一服务费和统一电费来判断当前的服务费和电费
                        //根据模板编号来查询价格时段
                        QueryWrapper<ConfigurationChargingpricetimeperiod> timeWrapper=new QueryWrapper<>();
                        timeWrapper.eq("price_id",priceModel.getId());
                        List<ConfigurationChargingpricetimeperiod> priceTimePeriods = configurationChargingpricetimeperiodMapper.selectList(timeWrapper);
                        if (priceModel.getIsServiceFlatFee()&&priceModel.getIsFlatFee()){//服务费和电费都统一
                            vo.setPrice(priceModel.getServicePrice().add(priceModel.getChargingPrice()).doubleValue());
                        }else if (priceModel.getIsFlatFee()){//电费统一，服务费不统一
                            stationServiceImpl.chargingTyServiceNoTy(priceTimePeriods,vo,priceModel,true,1,null,null);
                        }else if (priceModel.getIsServiceFlatFee()){//服务费统一，电费不统一
                            stationServiceImpl.serviceTyChargingNoTy(priceTimePeriods,vo,priceModel,true,1,null,null);
                        }else {//都不统一
                            stationServiceImpl.noMulti(priceTimePeriods,vo,priceModel,true,1,null,null);
                        }
                    }else {//不在活动范围内，只显示原价
                        AssetsStationchargingprice assetsStationchargingprice = stationServiceImpl.queryDefaultPrice(vo.getId());
                        if (assetsStationchargingprice!=null)
                            stationServiceImpl.defaultPriceModual(assetsStationchargingprice,vo);
                        else
                            return new CommonVo("有个站点没有默认模板，请添加后再测试！",null);
                    }
                }
                //原价显示
                AssetsStationchargingprice assetsStationchargingprice = stationServiceImpl.queryDefaultPrice(vo.getId());
                if (assetsStationchargingprice!=null)
                    stationServiceImpl.defaultPriceModual(assetsStationchargingprice,vo);
                else
                    return new CommonVo("有个站点没有默认模板，请添加后再测试！",null);
            }else if (count==1){//表示只有一个价格模板
                AssetsStationchargingprice assetsStationchargingprice = stationServiceImpl.queryDefaultPrice(vo.getId());
                if (assetsStationchargingprice!=null)
                    stationServiceImpl.defaultPriceModual(assetsStationchargingprice,vo);
                else
                    return new CommonVo("有个站点没有默认模板，请添加后再测试！",null);
            }else {
                return new CommonVo("有站点没有绑定价格模板，请绑定！",null);
            }
            ChargingStationNumberVo freeFastAndSlowNum = assetsStationsMapper.getFreeFastAndSlowNum(vo.getId());
            if (freeFastAndSlowNum!=null){
                vo.setFree_slow_cntr_count(freeFastAndSlowNum.getFreeSlowNum());
                vo.setFree_fast_cntr_count(freeFastAndSlowNum.getFreeFastNum());
            }else {
                vo.setFree_slow_cntr_count(0);
                vo.setFree_fast_cntr_count(0);
            }
            ChargingStationNumberVo totalFastAndSlowNum = assetsStationsMapper.getTotalFastAndSlowNum(vo.getId());
            if (totalFastAndSlowNum!=null){
                vo.setFast_cntr_count(totalFastAndSlowNum.getTotalFastNum());
                vo.setSlow_cntr_count(totalFastAndSlowNum.getTotalSlowNum());
            }else {
                vo.setFast_cntr_count(0);
                vo.setSlow_cntr_count(0);
            }
            list.add(vo);
        }
        for (ChargingStationAllInfoVo allInfoVo : list) {
            Double originalPrice = allInfoVo.getOriginal_price();
            if (allInfoVo.getOriginal_price()!=null&&allInfoVo.getPrice()!=null&&allInfoVo.getPrice()>allInfoVo.getOriginal_price()){
                allInfoVo.setOriginal_price(allInfoVo.getPrice());
                allInfoVo.setPrice(originalPrice);
            }
        }
        Map<String,Object> map=new HashMap<>();
        map.put("stations",list);
        return new CommonVo(map);
    }

    @Override
    @Transactional
    public CommonVo collection(Integer stationId, Integer type,String token) {
        log.info("会员收藏/取消站点收藏");
        if(stationId==null || type==null)
            return new CommonVo("请求参数为空！！",null);
        CustomerMember member = (CustomerMember) redisUtil.get(token);
        AssetsStations station = assetsStationsMapper.selectById(stationId);
        if (station!=null){
            if (type==1){//表示收藏
                try {
                    CustomerMemberFavourateStations favourateStations=new CustomerMemberFavourateStations();
                    favourateStations.setMemberId(member.getId());
                    favourateStations.setStationsId(stationId);
                    customerMemberFavourateStationsMapper.insert(favourateStations);
                    return new CommonVo("会员收藏成功");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }else {//表示取消收藏
                QueryWrapper<CustomerMemberFavourateStations> wrapper=new QueryWrapper<>();
                wrapper.eq("member_id",member.getId());
                wrapper.eq("stations_id",stationId);
                CustomerMemberFavourateStations favourateStations = customerMemberFavourateStationsMapper.selectOne(wrapper);
                if (favourateStations!=null){
                    customerMemberFavourateStationsMapper.deleteById(favourateStations.getId());
                }
                return new CommonVo("会员取消收藏成功");
            }
        }
        return new CommonVo(null);
    }

    @Override
    public CommonVo moneyRecord(Integer type, String token,Integer page,Integer pageSize) {
        log.info("会员充值/退款记录查询,分页");
        SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        List<MoneyRecordVo> list=new ArrayList<>();
        if (type==null || token==null) {
            return new CommonVo("请求参数为空！！",null);
        }
        CustomerMember member = (CustomerMember) redisUtil.get(token);
        if (member==null) {
            return new CommonVo("请登录！！",null);
        }
        if (type==1){//1表示充值
            MoneyRecordVo vo=null;
            QueryWrapper<CustomerRechargerecord> wrapper=new QueryWrapper<>();
            wrapper.eq("member_id",member.getId());
            wrapper.orderByDesc("trade_time");
            Page<CustomerRechargerecord> customerRechargerecordPage = customerRechargerecordMapper.selectPage(new Page<>(page, pageSize), wrapper);
            List<CustomerRechargerecord> customerRechargerecords = customerRechargerecordPage.getRecords();
            if (customerRechargerecords==null || customerRechargerecords.size()<=0) {
                return new CommonVo("该会员没有充值记录",null);
            }
            for (CustomerRechargerecord customerRechargerecord : customerRechargerecords) {
                vo=new MoneyRecordVo();
                vo.setMoney(customerRechargerecord.getMoney());
                vo.setRemark(customerRechargerecord.getRemark());
                vo.setStatus(customerRechargerecord.getStatus());
                vo.setTrade_no(customerRechargerecord.getTradeNo());
                vo.setPay_method(customerRechargerecord.getPayMethod());
                vo.setTime(df.format(customerRechargerecord.getTradeTime()));
                list.add(vo);
            }
            log.info(new CommonVo(list).toString());
            return new CommonVo(list);
        }else if (type==2){//2表示退款
            MoneyRecordVo vo=null;
            QueryWrapper<CustomerRefundrecord> wrapper=new QueryWrapper<>();
            wrapper.eq("member_id",member.getId());
            wrapper.orderByDesc("trade_time");
            Page<CustomerRefundrecord> customerRefundrecordPage = customerRefundrecordMapper.selectPage(new Page<>(page, pageSize), wrapper);
            List<CustomerRefundrecord> customerRefundrecords = customerRefundrecordPage.getRecords();
            if (customerRefundrecords==null || customerRefundrecords.size()<=0)
                return new CommonVo("该会员没有退款记录",null);
            for (CustomerRefundrecord customerRefundrecord : customerRefundrecords) {
                vo=new MoneyRecordVo();
                vo.setMoney(customerRefundrecord.getMoney());
                vo.setRemark(customerRefundrecord.getRemark());
                vo.setStatus(customerRefundrecord.getStatus());
                vo.setTrade_no(customerRefundrecord.getTradeNo());
                vo.setPay_method(customerRefundrecord.getPayMethod());
                vo.setTime(df.format(customerRefundrecord.getTradeTime()));
                list.add(vo);
            }
            log.info(new CommonVo(list).toString());
            return new CommonVo(list);
        }
        return new CommonVo(list);
    }


    @Transactional
    public CommonVo addCarNumber(String token,String carNumber,Boolean is_default) {
        log.info("绑定车辆");
        CustomerMember member = (CustomerMember) redisUtil.get(token);
        if (member==null)
            return new CommonVo("会员不存在，请重新登录",null);
        CustomerCarnumber customerCarnumber= getDefaultCarNumberInfo(member.getId());
        if (customerCarnumber!=null&&is_default){
            customerCarnumber.setIsDefault(false);
            customerCarnumberMapper.updateById(customerCarnumber);
        }
        CustomerCarnumber carnumber=new CustomerCarnumber();
        carnumber.setMemberId(member.getId());
        carnumber.setNumber(carNumber);
        carnumber.setIsDefault(is_default);
        customerCarnumberMapper.insert(carnumber);
        return new CommonVo(null);
    }


    @Transactional
    public CommonVo alertCarnumberInfo(Integer id, Integer type,String token) {
        log.info("设置车牌号为默认/删除车牌号,1表示设置车牌号为默认，2表示删除车牌号");
        if (type==null ||id==null)
            return new CommonVo("请求参数为空",null);
        CustomerMember member = (CustomerMember) redisUtil.get(token);
        if (member==null)
            return new CommonVo("会员不存在，请重新登录",null);
        if (type==1){//设置车牌号为默认
            CustomerCarnumber defaultCarNumberInfo = getDefaultCarNumberInfo(member.getId());
            if (defaultCarNumberInfo!=null){
                defaultCarNumberInfo.setIsDefault(false);
                customerCarnumberMapper.updateById(defaultCarNumberInfo);
            }
            QueryWrapper<CustomerCarnumber> wrapper=new QueryWrapper<>();
            wrapper.eq("id",id);
            wrapper.eq("member_id",member.getId());
            CustomerCarnumber carnumber = customerCarnumberMapper.selectOne(wrapper);
            if (carnumber==null)
                return new CommonVo("该会员没有车辆id",null);
            carnumber.setIsDefault(true);
            customerCarnumberMapper.updateById(carnumber);
        }else {//删除车辆
            customerCarnumberMapper.deleteById(id);
        }
        return new CommonVo(null);
    }



    @Transactional
    public CommonVo editCarNumber(Integer id,String carNumber,Boolean is_default) {
        log.info("编辑车辆信息");
        CustomerCarnumber carnumber = customerCarnumberMapper.selectById(id);
        carnumber.setNumber(carNumber);
        if (is_default){
            CustomerCarnumber defaultCarNumberInfo = getDefaultCarNumberInfo(carnumber.getMemberId());
            if (defaultCarNumberInfo!=null){
                defaultCarNumberInfo.setIsDefault(false);
                customerCarnumberMapper.updateById(defaultCarNumberInfo);
            }
            carnumber.setIsDefault(is_default);
            customerCarnumberMapper.updateById(carnumber);
        }else {
            carnumber.setIsDefault(is_default);
            customerCarnumberMapper.updateById(carnumber);
        }
        return new CommonVo(null);
    }


    public CommonVo carNumberList(String token) {
        log.info("获取会员车辆所有信息");
        CustomerMember member = (CustomerMember) redisUtil.get(token);
        List<CarnumberInfoVo> list=new ArrayList<>();
        CarnumberInfoVo vo=null;
        if (member==null)
            return new CommonVo("会员不存在，请重新登录",null);
        QueryWrapper<CustomerCarnumber> wrapper=new QueryWrapper<>();
        wrapper.eq("member_id",member.getId());
        List<CustomerCarnumber> customerCarnumbers = customerCarnumberMapper.selectList(wrapper);
        if (customerCarnumbers.size()<=0)
            return new CommonVo("该会员没有任何车辆",null);
        for (CustomerCarnumber carnumber : customerCarnumbers) {
            vo=new CarnumberInfoVo();
            vo.setId(carnumber.getId());
            vo.setCarnumber(carnumber.getNumber());
            vo.setIs_defalult(carnumber.getIsDefault());
            list.add(vo);
        }
        return new CommonVo(list);

    }

    @Override
    @Transactional
    public CommonVo pay(String orderNo) {
        log.info("会员支付");
        try {
            QueryWrapper<CustomerChargingorder> wrapper=new QueryWrapper<>();
            wrapper.eq("order_no",orderNo);
            CustomerChargingorder order = customerChargingorderMapper.selectOne(wrapper);
            if (order==null)
                return new CommonVo("该订单不存在",null);
            CustomerMember member = customerMemberMapper.selectById(order.getMemberId());
            //修改会员的钱包金额
            if(order.getTotalPrice() == null){
                member.setWallet(member.getWallet()-0);
            }else {
                member.setWallet(member.getWallet()-order.getTotalPrice());
            }
            //修改会员的钱包余额
            customerMemberMapper.updateById(member);
            //修改订单支付状态
            order.setPaymentStatus(ChargingOrderPayStatusEnum.PAID.getValue());
            //修改订单支付时间
            order.setPayTime(new Date());
            order.setBillTime(new Date());
            customerChargingorderMapper.updateById(order);
        } catch (Exception e) {
            return new CommonVo("请查询数据库是否有多条同样的订单",null);
        }
        return new CommonVo("支付成功");
    }

    private CustomerCarnumber getDefaultCarNumberInfo(Integer id){
        QueryWrapper<CustomerCarnumber> wrapper=new QueryWrapper<>();
        wrapper.eq("is_default",true);
        wrapper.eq("member_id",id);
        CustomerCarnumber customerCarnumber = customerCarnumberMapper.selectOne(wrapper);
        return customerCarnumber;
    }
}