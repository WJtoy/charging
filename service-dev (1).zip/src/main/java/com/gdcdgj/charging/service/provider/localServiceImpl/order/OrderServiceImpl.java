package com.gdcdgj.charging.service.provider.localServiceImpl.order;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.gdcdgj.charging.api.constant.ResultCode;
import com.gdcdgj.charging.api.entity.*;
import com.gdcdgj.charging.api.enums.ChargingOrderPayStatusEnum;
import com.gdcdgj.charging.api.enums.ChargingOrderStatusEnum;
import com.gdcdgj.charging.api.localService.order.OrderService;
import com.gdcdgj.charging.api.util.RedisUtil;
import com.gdcdgj.charging.api.util.TimeUtils;
import com.gdcdgj.charging.api.vo.CommonVo;
import com.gdcdgj.charging.api.vo.order.OrderInfoVo;
import com.gdcdgj.charging.api.vo.order.OrderListInfoVo;
import com.gdcdgj.charging.api.vo.station.StationTagsVo;
import com.gdcdgj.charging.service.provider.mapper.*;
import com.google.common.collect.Ordering;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.dubbo.config.annotation.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import springfox.documentation.spi.service.contexts.Orderings;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

/**
 * @author JianMei Chen
 * @date 2020/05/09/12:00
 */
@Service
@Slf4j
public class OrderServiceImpl implements OrderService {

    @Autowired
    private CustomerChargingorderMapper customerChargingorderMapper;//订单

    @Autowired
    private CustomerChargingordertracksMapper customerChargingordertracksMapper;//充电轨迹

    @Autowired
    private AssetsConnectorMapper assetsConnectorMapper;//连接枪

    @Autowired
    private RedisUtil redisUtil;//redis

    @Autowired
    private AssetsStationsMapper assetsStationsMapper;//站点

    @Autowired
    private ConfigurationSystemdictMapper configurationSystemdictMapper;//数据字典

    SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    @Autowired
    private CustomerMemberMapper customerMemberMapper;

    @Override
    public CommonVo order(String orderNo) {
        log.info("查询订单实时状态");
        OrderInfoVo vo=new OrderInfoVo();
        //参数为空
        if (StringUtils.isBlank(orderNo))
            return new CommonVo("请求参数为空",null);
        //参数不为空
        try {
            //1.通过订单号查询订单信息,查询到订单的状态
            QueryWrapper<CustomerChargingorder> orderWrapper=new QueryWrapper<>();
            orderWrapper.eq("order_no",orderNo);
            CustomerChargingorder order = customerChargingorderMapper.selectOne(orderWrapper);
            if (order==null)
                return new CommonVo("该订单不存在！！",null);
            //通过订单表的枪编号获取枪信息
            AssetsConnector connector = assetsConnectorMapper.selectById(order.getConnectorId());
            if (connector==null)
                return new CommonVo("该订单没有枪编号，请检查！！",null);
            //如果订单状态为充电中，则在充电轨迹记录表中获取数据
            tyFengZhuang(vo,order);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new CommonVo(vo);
    }

    public void tyFengZhuang(OrderInfoVo vo,CustomerChargingorder order){
        vo.setOrder_no(order.getOrderNo());
        vo.setConnector_code(order.getConnectorCode());
        vo.setPayment_status(order.getPaymentStatus());
        vo.setCharging_status(order.getChargingStatus());
        if (order.getStartTime() != null)
            vo.setStart_time(sdf.format(order.getStartTime()));
        if (order.getLeftTime()!=null)
            vo.setLeft_time(order.getLeftTime());
        if (order.getVoltage()!=null)
            vo.setVoltage(order.getVoltage());
        if (order.getCurrent()!=null)
            vo.setCurrent(0.0);
        if (order.getTotalChargingTime()!=null)
            vo.setTotal_charging_time(order.getTotalChargingTime());
        if(order.getTotalChargingQuantity()!=null)
            vo.setTotal_charging_quantity(order.getTotalChargingQuantity());
        if (order.getTotalChargingPrice()!=null)
            vo.setTotal_charging_price(order.getTotalChargingPrice());
        if (order.getTotalServicePrice()!=null)
            vo.setTotal_service_price(order.getTotalServicePrice());
        if(order.getTotalPrice()!=null)
            vo.setTotal_price(order.getTotalPrice());
        if (order.getSocStart()!=null)
            vo.setSoc_start(order.getSocStart());
        if(order.getSocEnd()!=null)
            vo.setSoc_end(order.getSocEnd());
        if (order.getStopTime() != null)
            vo.setEnd_time(sdf.format(order.getStopTime()));
    }

    @Override
    public CommonVo orderList(Integer charging_status, Integer payment_status,String token) {
        log.info("订单列表");
        log.info("充电状态:"+charging_status+",支付状态："+payment_status);
        List<OrderListInfoVo> list=new ArrayList<>();//查询全部使用
        OrderListInfoVo vo=null;
        if (charging_status!=null&& payment_status!=null)
            return new CommonVo("支付状态和充电状态不能同时传入，只能选择一种状态！",null);
        try {
            //1.根据token在redis获取会员基本信息
            CustomerMember member = (CustomerMember) redisUtil.get(token);
            if (member==null)
                return new CommonVo("会员不存在，token过期，请重新登录",null);
            //充电状态不为空，前端表示为：充电中。需求：charging_status in (1 2 3 ) 都归到充电中的订单
            if (charging_status!=null){
                //现在是一个用户可以有多个正在充电中的订单,前端固定传入的是正在充电的值
                CommonVo commonVo = chargingOrder(member, vo, list);
                return commonVo;
            }
            //支付状态不为空
            if (payment_status!=null){
                if (payment_status==ChargingOrderPayStatusEnum.NO_PAY.getValue()){//未支付订单
                    //需求：充电金额大于零并且payment_status=1 并且 charging_status in ( 4 5 ) 订单属于 未支付订单
                    CommonVo commonVo = noPayOrder(member, vo, list);
                    return commonVo;
                }else {//已支付订单
                    CommonVo commonVo = paySuccessOrder(member, vo, list);
                    return commonVo;
                }
            }
            //查询该会员的所有订单
            QueryWrapper<CustomerChargingorder> allOrderWrapper=new QueryWrapper<>();
            allOrderWrapper.eq("member_id",member.getId());
            List<CustomerChargingorder> allOrders = customerChargingorderMapper.selectList(allOrderWrapper);
            if (allOrders!=null && allOrders.size()>0) {
                for (CustomerChargingorder order : allOrders) {
                    if (order.getChargingStatus()==ChargingOrderStatusEnum.CHARGING.getValue()||
                        order.getChargingStatus()==ChargingOrderStatusEnum.PREPARE_CHARGING.getValue()||
                        order.getChargingStatus()==ChargingOrderStatusEnum.ENDING.getValue()){//表示充电中
                        log.info("充电中的订单");
                        CommonVo commonVo = chargingOrder(member, vo, list);
                    }else if (order.getPaymentStatus()==ChargingOrderPayStatusEnum.NO_PAY.getValue()&&
                        order.getTotalPrice()>0 &&order.getChargingStatus()==ChargingOrderStatusEnum.END_CHARGING.getValue()){//未支付
                        log.info("支付1，充电4的订单");
                        CommonVo commonVo = noPayOrder(member, vo, list);
                    }else if (order.getPaymentStatus()==ChargingOrderPayStatusEnum.NO_PAY.getValue()&&
                            order.getTotalPrice()>0 &&order.getChargingStatus()==ChargingOrderStatusEnum.START_FAIL.getValue()){
                        log.info("支付为1，充电为5的订单");
                        CommonVo commonVo = noPayOrder(member,vo,list);
                    }else if (order.getPaymentStatus()==ChargingOrderPayStatusEnum.NO_PAY.getValue()&&
                            order.getTotalPrice()>0 &&order.getChargingStatus()==ChargingOrderStatusEnum.SYSTEM_FAULT.getValue()){
                        log.info("支付为1，充电为6的订单");
                        CommonVo commonVo = noPayOrder(member,vo,list);
                    } else if (order.getPaymentStatus()==ChargingOrderPayStatusEnum.PAID.getValue()&&
                        order.getChargingStatus()==ChargingOrderStatusEnum.END_CHARGING.getValue()){//这里是：充电结束且支付成功 还有个系统故障的问题
                        log.info("结束充电，且已支付");
                        otherOrder(order,vo,list);
                    }else if (order.getPaymentStatus()==ChargingOrderPayStatusEnum.NO_PAY.getValue()&&
                            order.getTotalPrice()<=0 &&order.getChargingStatus()==ChargingOrderStatusEnum.SYSTEM_FAULT.getValue()){
                        log.info("系统故障，总金额小于=0");
                        otherOrder(order,vo,list);
                    }
                }
                TimeUtils.listSort(list);
                return new CommonVo(list);
            }else {
                return new CommonVo("该会员没有任何订单",null);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new CommonVo(list);
    }

    public void otherOrder(CustomerChargingorder order,OrderListInfoVo vo,List<OrderListInfoVo> list){
        vo=new OrderListInfoVo();
        vo.setOrder_no(order.getOrderNo());
        //获取站点信息
        AssetsStations station = assetsStationsMapper.selectById(order.getStationId());
        if (station!=null)
            vo.setStation_name(station.getName());
        vo.setCharging_status(order.getChargingStatus());
        vo.setPayment_status(order.getPaymentStatus());
        if (order.getStartTime()!=null)
            vo.setStart_time(sdf.format(order.getStartTime()));
        if(order.getTotalChargingTime()!=null)
            vo.setTotal_charging_time(order.getTotalChargingTime());
        if (order.getTotalPrice()!=null)
            vo.setTotal_price(order.getTotalPrice());
        list.add(vo);
    }

    public CommonVo paySuccessOrder(CustomerMember member,OrderListInfoVo vo,List<OrderListInfoVo> list){
        //已支付订单，会有多个
        QueryWrapper<CustomerChargingorder> orderListWrapper=new QueryWrapper<>();
        orderListWrapper.eq("payment_status",ChargingOrderPayStatusEnum.PAID.getValue());
        orderListWrapper.eq("member_id",member.getId());
        orderListWrapper.eq("charging_status",ChargingOrderStatusEnum.END_CHARGING.getValue());
        orderListWrapper.orderByDesc("start_time");
        List<CustomerChargingorder> orders = customerChargingorderMapper.selectList(orderListWrapper);
        if (orders!=null&&orders.size()>0) {
            for (CustomerChargingorder order : orders) {
                otherOrder(order,vo,list);
            }
            return new CommonVo(list);
        }else {
            return new CommonVo("该会员没有已支付订单",null);
        }
    }

    public CommonVo noPayOrder(CustomerMember member,OrderListInfoVo vo,List<OrderListInfoVo> list){
        QueryWrapper<CustomerChargingorder> orderWrapper=new QueryWrapper<>();
        orderWrapper.eq("payment_status",ChargingOrderPayStatusEnum.NO_PAY.getValue());
        orderWrapper.eq("member_id",member.getId());
        orderWrapper.in("charging_status",ChargingOrderStatusEnum.END_CHARGING.getValue(),
                ChargingOrderStatusEnum.START_FAIL.getValue(),ChargingOrderStatusEnum.SYSTEM_FAULT.getValue());
        orderWrapper.gt("total_price",0);
        orderWrapper.orderByDesc("start_time");
        List<CustomerChargingorder> orderList = customerChargingorderMapper.selectList(orderWrapper);
        if (orderList.size() >0) {
            for (CustomerChargingorder order : orderList) {
                otherOrder(order,vo,list);
            }
            TimeUtils.listSort(list);
            return new CommonVo(list);
        }else {
            return new CommonVo("该会员没有未支付订单",null);
        }
    }

    public CommonVo chargingOrder(CustomerMember member,OrderListInfoVo vo,List<OrderListInfoVo> list){
        QueryWrapper<CustomerChargingorder> orderWrapper=new QueryWrapper<>();
        orderWrapper.in("charging_status",ChargingOrderStatusEnum.PREPARE_CHARGING.getValue(),
                ChargingOrderStatusEnum.CHARGING.getValue(),ChargingOrderStatusEnum.ENDING.getValue());
        orderWrapper.eq("member_id",member.getId());
        orderWrapper.orderByDesc("start_time");
        //查询充电中的订单
        List<CustomerChargingorder> orderList = customerChargingorderMapper.selectList(orderWrapper);
        if (orderList.size()>0){
            for (CustomerChargingorder order : orderList) {
                vo=new OrderListInfoVo();
                //查询站点信息
                AssetsStations station = assetsStationsMapper.selectById(order.getStationId());
                //查询充电轨迹记录信息
                QueryWrapper<CustomerChargingordertracks> trackWrapper=new QueryWrapper<>();
                trackWrapper.eq("order_id",order.getId());
                trackWrapper.orderByAsc("add_time");
                List<CustomerChargingordertracks> track = customerChargingordertracksMapper.selectList(trackWrapper);
                //封装
                vo.setOrder_no(order.getOrderNo());
                if (station!=null)
                    vo.setStation_name(station.getName());
                vo.setCharging_status(order.getChargingStatus());
                vo.setPayment_status(order.getPaymentStatus());
                if (order.getStartTime()!=null)
                    vo.setStart_time(sdf.format(order.getStartTime()));
                if (track!=null&&track.size()>0) {
                    vo.setTotal_charging_time(track.get(track.size()-1).getTotalChargingTime());
                    vo.setTotal_price(track.get(track.size()-1).getTotalPrice());
                }
                list.add(vo);
            }
        }else {
            return new CommonVo("该会员没有正在充电的订单",null);
        }
        TimeUtils.listSort(list);
        return new CommonVo(list);
    }

    @Override
    public CommonVo orderTags() {
        log.info("显示订单评价标签");
        List<StationTagsVo> list=null;
        QueryWrapper<ConfigurationSystemdict> wrapper=new QueryWrapper<>();
        wrapper.select("value");
        wrapper.eq("`key`","ORDER_EVALUATE_TAGS");
        ConfigurationSystemdict systemdict=null;
        try {
            systemdict = configurationSystemdictMapper.selectOne(wrapper);
            list = formatTagValue(systemdict.getValue());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new CommonVo(ResultCode.SUCCESS_CODE,"显示站点的所有标签",list);
    }

    public List<StationTagsVo> formatTagValue(String jsonString){
        List<StationTagsVo> list=new ArrayList<>();
        StationTagsVo vo=null;

        JSONArray objects = JSONArray.parseArray(jsonString);
        int j=0;
        Object[] result=new Object[100];
        for (Object object : objects) {
            //将object转换为字符串
            String s = JSONObject.toJSONString(object);
            //在将字符串转换为JsonArray
            JSONArray jsonArray = JSONArray.parseArray(s);
            Iterator<Object> iterator = jsonArray.iterator();
            while (iterator.hasNext()){
                result[j]=iterator.next();
                j++;
            }
        }
        for (int i=0;i<result.length;i++){
            if (result[i]!=null&&i%2==0){
                vo=new StationTagsVo();
                vo.setId((Integer) result[i]);
                vo.setName((String) result[i+1]);
                list.add(vo);
            }
        }
        return list;
    }

    //结算订单
    @Transactional
    public CommonVo settleOrder(String token,String orderNo) {
        CustomerMember member = (CustomerMember) redisUtil.get(token);
        // 根据会员id到数据库查询最新的会员信息
        member = customerMemberMapper.selectById(member.getId());
        if (member != null) {
            QueryWrapper<CustomerChargingorder> orderWrapper = new QueryWrapper<>();
            orderWrapper.eq("member_id", member.getId());
            orderWrapper.eq("order_no", orderNo);
            CustomerChargingorder customerChargingorders = customerChargingorderMapper.selectOne(orderWrapper);
            if (customerChargingorders != null) {
                if (member.getWallet() > customerChargingorders.getTotalPrice()) {
                    member.setWallet(member.getWallet() - customerChargingorders.getTotalPrice());
                    customerChargingorders.setPaymentStatus(2);
                    customerChargingorders.setPayTime(new Date());
                    customerChargingorderMapper.updateById(customerChargingorders);
                    customerMemberMapper.updateById(member);
                    return new CommonVo("支付扣费成功");
                }
                return new CommonVo("余额不足，支付扣费失败");
            }
            return new CommonVo("该订单不存在");
        }
        return new CommonVo("用户未登陆");
    }
}