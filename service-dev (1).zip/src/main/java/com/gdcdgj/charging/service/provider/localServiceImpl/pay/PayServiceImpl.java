package com.gdcdgj.charging.service.provider.localServiceImpl.pay;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.gdcdgj.charging.api.entity.CustomerChargingorder;
import com.gdcdgj.charging.api.entity.CustomerChargingorderpayment;
import com.gdcdgj.charging.api.entity.CustomerMember;
import com.gdcdgj.charging.api.entity.CustomerRechargerecord;
import com.gdcdgj.charging.api.enums.ChargingOrderPayStatusEnum;
import com.gdcdgj.charging.api.enums.PayMethodEnum;
import com.gdcdgj.charging.api.enums.PayStatusEnum;
import com.gdcdgj.charging.api.localService.pay.PayService;
import com.gdcdgj.charging.api.util.HttpClientUtil;
import com.gdcdgj.charging.api.util.IdGenerationTool;
import com.gdcdgj.charging.api.util.MD5Util;
import com.gdcdgj.charging.api.util.PropertyUtil;
import com.gdcdgj.charging.api.util.pay.wx.WXConfig;
import com.gdcdgj.charging.api.util.pay.wx.WXCore;
import com.gdcdgj.charging.api.vo.CommonVo;
import com.gdcdgj.charging.service.provider.mapper.CustomerChargingorderMapper;
import com.gdcdgj.charging.service.provider.mapper.CustomerChargingorderpaymentMapper;
import com.gdcdgj.charging.service.provider.mapper.CustomerMemberMapper;
import com.gdcdgj.charging.service.provider.mapper.CustomerRechargerecordMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.dubbo.config.annotation.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;

import java.util.*;

/**
 * @author JianMei Chen
 * @date 2020/04/28/14:59
 */
@Service
@Slf4j
public class PayServiceImpl implements PayService {

    @Autowired
    private CustomerMemberMapper customerMemberMapper;//会员信息

    @Autowired
    private CustomerRechargerecordMapper customerRechargerecordMapper;//会员充值记录

    @Autowired
    private CustomerChargingorderpaymentMapper customerChargingorderpaymentMapper;//订单支付记录

    @Autowired
    private CustomerChargingorderMapper customerChargingorderMapper;//消费订单

    @Override
    public CommonVo preloadCharge(Map<String,String> map) {
        log.info("会员充值");
        //参数为空
        if (map==null)
            return new CommonVo("请求参数为空！",null);
        //参数不为空
        //1.通过会员编号来查询会员信息
        CustomerMember member = customerMemberMapper.selectById(map.get("memberId"));
        if (member==null)
            return new CommonVo("会员不存在",null);
        double payMoney=0;
        try {
            payMoney = Double.parseDouble(map.get("money"));
            if (payMoney<=0)
                return new CommonVo("支付金额小于等于0",null);
        } catch (NumberFormatException e) {
            return new CommonVo("支付金额为非法数字",null);
        }
        //将数据添加到会员充值记录表中
        CustomerRechargerecord rechargerecord=new CustomerRechargerecord();
        rechargerecord.setMemberId(member.getId());
        rechargerecord.setPayMethod(Integer.parseInt(map.get("payMethod")));
        rechargerecord.setStatus(0);//表示未充值成功
        rechargerecord.setTradeNo(IdGenerationTool.getRandomStringByLength(20));
        rechargerecord.setTradeTime(new Date());
        rechargerecord.setMoney(payMoney);
        customerRechargerecordMapper.insert(rechargerecord);

        if (Integer.parseInt(map.get("payMethod"))==PayMethodEnum.WX.getValue()){
            //微信 为客户端提供 appId, apiKey, mchId, body, notifyURL, Out_trade_no
            String openid = map.get("openId");
            String notifyUrl = PropertyUtil.getString("wx.notify_url");
            String body = PropertyUtil.getString("wx.body");
            String ip = map.get("ip");
            String chargeId=IdGenerationTool.getRandomStringByLength(20);
            WXCore wxCore = new WXCore();
            CommonVo commonVo = wxCore.wxPay(openid, notifyUrl, chargeId, map.get("money"), ip, body, null);
            return commonVo;
        }
        return null;
    }

    @Override
    public CommonVo tgChargeResult(Map<String,String> map) {
        if (map==null)
            return new CommonVo("参数为空！",null);
        log.info("通莞金服回调接口");
        try {
            if (!"balanceOrder".equals(map.get("orderType"))) {
                log.info("orderType不为balanceOrder");
                return null;
            }
            if (map.get("state").equals("0")){
                QueryWrapper<CustomerRechargerecord> wrapper=new QueryWrapper<>();
                wrapper.eq("trade_no",map.get("lowOrderId"));
                CustomerRechargerecord rechargerecord = customerRechargerecordMapper.selectOne(wrapper);
                if (rechargerecord==null){
                    rechargerecord=new CustomerRechargerecord();
                    rechargerecord.setMemberId(Integer.valueOf(map.get("memberId")));
                    rechargerecord.setMoney(Double.parseDouble(map.get("payMoney"))*100);
                    rechargerecord.setTradeTime(new Date());
                    rechargerecord.setTradeNo(map.get("lowOrderId"));
                    rechargerecord.setStatus(PayStatusEnum.SUCCESS.getValue());
                    rechargerecord.setPayMethod(Integer.parseInt(map.get("payMethod")));
                    //插入会员充值记录
                    customerRechargerecordMapper.insert(rechargerecord);
                }
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return new CommonVo("");
    }

    @Override
    public CommonVo orderQuery(Map<String, String> map) {
        log.info("去通莞金服主动查询订单");
        String lowOrderId = map.get("lowOrderId");
        String sign = MD5Util.toMD5("account=158408085257712&lowOrderId=" + lowOrderId + "&key=a77977d0bb05071c16679d557e2ac5b9").toUpperCase();
        Map<String, Object> param = new HashMap<>();
        param.put("account", "158408085257712");
        param.put("lowOrderId", lowOrderId);
        param.put("sign", sign);
        Map<String, String> header = new HashMap<>();
        header.put("Content-Type", "application/json");
        String response = HttpClientUtil.sendPostJson("http://ipay.833006.net/tgPosp/services/payApi/orderQuery", header, param, "utf-8");
        Map<String, String> paramMap = handleRequestParam(response);
        try {
            Thread.sleep(1000);
            this.tgChargeResult(paramMap);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return new CommonVo("");
    }

    @Override
    public CommonVo payChargingOrderCallBack(Map<String, String> map) {
        log.info("充电微信支付回调");
        //微信支付
        if (map.get("type").equalsIgnoreCase("WX")){
            weixinPayResult(map);
        }
        //		if(null != order){// TODO 当运营商平台有新订单完成时，将订单信息推送至省平台
//			provincialChargingService.notifyCharingOrderInfo(order.getChargeSeq(), payChannel);
//		}
        return new CommonVo("充电订单支付回调");
    }

    private void weixinPayResult(Map<String,String> map){
        //在支付成功状态下，进行数据库操作
        if (map.get(WXConfig.RETURN_KEY_RETURN_CODE).equalsIgnoreCase("success")) {

            //订单支付信息添加
            CustomerChargingorderpayment orderPaymemt = new CustomerChargingorderpayment();
            orderPaymemt.setPayTime(new Date());
            orderPaymemt.setPayMethod(PayMethodEnum.WX.getValue());
            orderPaymemt.setPayAmount(Double.valueOf(map.get(WXConfig.RETURN_KEY_TOTAL_FEE)));
            orderPaymemt.setTradeNo(IdGenerationTool.getRandomStringByLength(30));
            orderPaymemt.setBusinessNo(map.get(WXConfig.RETURN_KEY_TRANSACTION_ID));
            orderPaymemt.setIsSuccess(true);
            QueryWrapper<CustomerChargingorder> orderWrapper=new QueryWrapper<>();
            orderWrapper.eq("order_no",map.get(WXConfig.RETURN_KEY_OUT_TRADE_NO));
            CustomerChargingorder order = customerChargingorderMapper.selectOne(orderWrapper);
            orderPaymemt.setOrderId(order.getId());
            customerChargingorderpaymentMapper.insert(orderPaymemt);

            //更新订单信息
            order.setPaymentStatus(ChargingOrderPayStatusEnum.PAID.getValue());
            order.setRealPayAmount(Double.valueOf(map.get(WXConfig.RETURN_KEY_TOTAL_FEE)));
            customerChargingorderMapper.updateById(order);
        }
    }

    public Map<String,String> handleRequestParam(String jsonText){
        if(null == jsonText  || StringUtils.isBlank(jsonText)){
            return null;
        }else {
            Map<String, String> map = parseJSON(jsonText);
            if(CollectionUtils.isEmpty(map)){
                return null;
            }
            return map;
        }
    }

    protected Map<String, String> parseJSON(String jsonText){
        Map<String, String> paramData  = new HashMap<String, String>();
        JSONObject jsonObject = JSONObject.parseObject(jsonText);
        Set<String> set = jsonObject.keySet();
        Iterator<String> iter = set.iterator();
        while(iter.hasNext()){
            String key = iter.next();
            String value = jsonObject.getString(key);
            paramData.put(key, value);
        }
        return paramData;
    }
}
