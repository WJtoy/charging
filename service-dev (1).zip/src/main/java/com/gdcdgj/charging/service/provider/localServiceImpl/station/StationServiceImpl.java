package com.gdcdgj.charging.service.provider.localServiceImpl.station;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.gdcdgj.charging.api.constant.ResultCode;
import com.gdcdgj.charging.api.entity.*;
import com.gdcdgj.charging.api.enums.ChargingOrderStatusEnum;
import com.gdcdgj.charging.api.enums.PriceIsDefaultEunm;
import com.gdcdgj.charging.api.localService.station.StationService;
import com.gdcdgj.charging.api.util.PropertyUtil;
import com.gdcdgj.charging.api.vo.CommonVo;
import com.gdcdgj.charging.api.vo.charging.ChargingStationAllInfoVo;
import com.gdcdgj.charging.api.vo.charging.ChargingStationNumberVo;
import com.gdcdgj.charging.api.vo.station.ConnectorInfoVo;
import com.gdcdgj.charging.api.vo.station.PriceTemplateVo;
import com.gdcdgj.charging.api.vo.station.StationDescVo;
import com.gdcdgj.charging.api.vo.station.StationTagsVo;
import com.gdcdgj.charging.service.provider.mapper.*;
import com.gdcdgj.charging.service.provider.service.AssetsStationchargingpriceService;
import com.gdcdgj.charging.service.provider.service.ConfigurationChargingpricetimeperiodService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.dubbo.config.annotation.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author JianMei Chen
 * @date 2020/05/06/13:56
 */
@Service
@Slf4j
public class StationServiceImpl implements StationService {

    @Value("${com.gdcdgj.charging.imgUrlPrefix}")
    private String imgUrlPrefix;

    @Autowired
    private AssetsStationsMapper assetsStationsMapper;//站点

    @Autowired
    private AssetsStationchargingpriceMapper assetsStationchargingpriceMapper;//价格绑定

    @Autowired
    private ConfigurationChargingpriceMapper configurationChargingpriceMapper;//价格模板

    @Autowired
    private ConfigurationChargingpricetimeperiodMapper configurationChargingpricetimeperiodMapper;//价格时段

    @Autowired
    private ConfigurationSystemdictMapper configurationSystemdictMapper;//标签

    @Autowired
    private AssetsStationbusinesshoursMapper assetsStationbusinesshoursMapper;//站点营业时间

    @Autowired
    private AssetsStationimagesMapper assetsStationimagesMapper;//站点图片

    @Autowired
    private EmployeeCompanyMapper employeeCompanyMapper;//运营商

    @Autowired
    private CustomerChargingorderMapper customerChargingorderMapper;//充电订单

    @Autowired
    private CustomerChargingordertracksMapper customerChargingordertracksMapper;//充电轨迹记录

    @Autowired
    private AssetsConnectorMapper assetsConnectorMapper;//充电枪

    //=====================================================

    @Autowired
    private AssetsStationchargingpriceService assetsStationchargingpriceService;

    @Autowired
    private ConfigurationChargingpricetimeperiodService configurationChargingpricetimeperiodService;

    SimpleDateFormat sdf=new SimpleDateFormat("HH:mm");

    SimpleDateFormat yyyyMMdd=new SimpleDateFormat("yyyy-MM-dd");

    SimpleDateFormat hhMMss=new SimpleDateFormat("HH:mm:ss");

    @Override
    public CommonVo findStationList(Integer page,Integer pagesize,Integer tags, Double latitude,Double longitude,Double distance,String search) {
        log.info("站点列表,获取目前价格或者原价格");
        //参数为空
        if (page==null || pagesize==null || latitude==null || longitude==null || distance==null){
            return new CommonVo("请求参数为空！",null);
        }
        List<ChargingStationAllInfoVo> list=new ArrayList<>();
        //参数不为空
        try {
            Map<String,Object> map=new HashMap<>();
            map.put("tags",tags);
            map.put("index",(page-1)*pagesize);
            map.put("size",pagesize);
            log.info("关键字="+search);
            if (StringUtils.isNotBlank(search)){
                map.put("keyword","%"+search+"%");
            }else {
                map.put("keyword",null);
            }
            List<ChargingStationAllInfoVo> allVos = assetsStationsMapper.findStationsByTags(map);
            Iterator<ChargingStationAllInfoVo> iterator = allVos.iterator();
            if (iterator.hasNext()){
                ChargingStationAllInfoVo vo = iterator.next();
                if (vo.getLatitude()!=null&&vo.getLongitude()!=null) {
                    Double stationLatitude = vo.getLatitude();//站点纬度
                    Double stationLongitude = vo.getLongitude();//站点经度
                    double a=Math.abs(stationLatitude-latitude);
                    double b=Math.abs(stationLongitude-longitude);
                    double sqrt = Math.sqrt((Math.pow(a, 2) + Math.pow(b, 2)));
                    if (sqrt>distance&&distance!=0){
                        log.info("大于distance距离...");
                        iterator.remove();
                    }
                }
            }
            for (ChargingStationAllInfoVo vo : allVos) {
                //1.通过站点编号在价格绑定表中查询看有几个模板编号,如果>1表示，该站点有活动模板，需看当前时间是否为活动时间
                QueryWrapper<AssetsStationchargingprice> priceMiddleWrapper=new QueryWrapper<>();
                priceMiddleWrapper.eq("station_id",vo.getId());
                Integer count = assetsStationchargingpriceMapper.selectCount(priceMiddleWrapper);
                if (count>1){//表示该站点有多个价格模板
                    //2.根据价格绑定表的is_defalut字段和station_id字段来找出活动模板的活动时间
                    QueryWrapper<AssetsStationchargingprice> actionWrapper=new QueryWrapper<>();
                    actionWrapper.eq("station_id",vo.getId());
                    actionWrapper.eq("is_default", PriceIsDefaultEunm.NO.getValue());
                    actionWrapper.eq("is_enabled",1);
                    List<AssetsStationchargingprice> priceMiddleTables = assetsStationchargingpriceMapper.selectList(actionWrapper);
                    for (AssetsStationchargingprice chargingPrice : priceMiddleTables) {
                        if (nowTimeIsRangeTime(chargingPrice.getStartTime(),chargingPrice.getEndTime(),"yyyy-MM-dd")){
                            //3.通过价格模板编号来查询价格模板信息
                            ConfigurationChargingprice priceModel = configurationChargingpriceMapper.selectById(chargingPrice.getPriceId());
                            //4.根据价格模板看是否统一服务费和统一电费来判断当前的服务费和电费
                            //根据模板编号来查询价格时段
                            QueryWrapper<ConfigurationChargingpricetimeperiod> timeWrapper=new QueryWrapper<>();
                            timeWrapper.eq("price_id",priceModel.getId());
                            List<ConfigurationChargingpricetimeperiod> priceTimePeriods = configurationChargingpricetimeperiodMapper.selectList(timeWrapper);
                            if (priceModel.getIsServiceFlatFee()&&priceModel.getIsFlatFee()){//服务费和电费都统一
                                vo.setPrice(roundMath(priceModel.getServicePrice().add(priceModel.getChargingPrice()).doubleValue()));
                            }else if (priceModel.getIsFlatFee()){//电费统一，服务费不统一
                                chargingTyServiceNoTy(priceTimePeriods,vo,priceModel,true,1,null,null);
                            }else if (priceModel.getIsServiceFlatFee()){//服务费统一，电费不统一
                                serviceTyChargingNoTy(priceTimePeriods,vo,priceModel,true,1,null,null);
                            }else {//都不统一
                                noMulti(priceTimePeriods,vo,priceModel,true,1,null,null);
                            }
                        }else {//不在活动范围内，只显示原价
                            AssetsStationchargingprice assetsStationchargingprice = queryDefaultPrice(vo.getId());
                            if (assetsStationchargingprice!=null)
                                defaultPriceModual(assetsStationchargingprice,vo);
                            else
                                return new CommonVo("有个站点没有默认模板，请添加后再测试！",null);
                        }
                    }
                    //原价显示
                    AssetsStationchargingprice assetsStationchargingprice = queryDefaultPrice(vo.getId());
                    if (assetsStationchargingprice!=null)
                        activeOriginalPrice(assetsStationchargingprice,vo);
                    else
                        return new CommonVo("有个站点没有默认模板，请添加后再测试！",null);
                }else if (count==1){//表示只有一个价格模板
                    AssetsStationchargingprice assetsStationchargingprice = queryDefaultPrice(vo.getId());
                    if (assetsStationchargingprice!=null)
                        defaultPriceModual(assetsStationchargingprice,vo);
                    else
                        return new CommonVo("有个站点没有默认模板，请添加后再测试！",null);
                }else {
                    return new CommonVo("有站点没有绑定价格模板，请绑定！",null);
                }
                vo.setDistance(distance);
                ChargingStationNumberVo freeFastAndSlowNum = assetsStationsMapper.getFreeFastAndSlowNum(vo.getId());
                if (freeFastAndSlowNum!=null){
                    vo.setFree_slow_cntr_count(freeFastAndSlowNum.getFreeSlowNum());
                    vo.setFree_fast_cntr_count(freeFastAndSlowNum.getFreeFastNum());
                }else {
                    vo.setFree_slow_cntr_count(0);
                    vo.setFree_fast_cntr_count(0);
                }
                ChargingStationNumberVo totalFastAndSlowNum = assetsStationsMapper.getTotalFastAndSlowNum(vo.getId());
                if (totalFastAndSlowNum!=null){
                    vo.setFast_cntr_count(totalFastAndSlowNum.getTotalFastNum());
                    vo.setSlow_cntr_count(totalFastAndSlowNum.getTotalSlowNum());
                }else {
                    vo.setFast_cntr_count(0);
                    vo.setSlow_cntr_count(0);
                }
                list.add(vo);
            }
            for (ChargingStationAllInfoVo allInfoVo : list) {
                Double originalPrice = allInfoVo.getOriginal_price();
                if (allInfoVo.getOriginal_price()!=null&&allInfoVo.getPrice()!=null&&allInfoVo.getPrice()>allInfoVo.getOriginal_price()){
                    allInfoVo.setOriginal_price(allInfoVo.getPrice());
                    allInfoVo.setPrice(originalPrice);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        Map<String,Object> map=new HashMap<>();
        map.put("stations",list);
        return new CommonVo(map);
    }

    private Double roundMath(Double d){
        double round = (Math.round(d*100)/100.0);
        return round;
    }

    @Override
    public CommonVo findStationTags() {
        log.info("显示站点的所有标签");
        List<StationTagsVo> list=null;
        QueryWrapper<ConfigurationSystemdict> wrapper=new QueryWrapper<>();
        wrapper.select("value");
        wrapper.eq("`key`","STATION_LABEL");
        ConfigurationSystemdict systemdict=null;
        try {
            systemdict = configurationSystemdictMapper.selectOne(wrapper);
            list = formatTagValue(systemdict.getValue());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new CommonVo(ResultCode.SUCCESS_CODE,"显示站点的所有标签",list);
    }

    @Override
    public CommonVo stationDesc(Integer stationId) {
        log.info("显示站点详细信息");
        StationDescVo vo=new StationDescVo();
        //参数为空
        if (stationId==null){
            return new CommonVo("请求参数为空了！",null);
        }
        //参数不为空
        try {
            //1.根据站点编号在站点表中获取信息
            AssetsStations station = assetsStationsMapper.selectById(stationId);
            if (station!=null){
               //2.根据站点编号获取站点营业时间
                QueryWrapper<AssetsStationbusinesshours> businesHourWrapper=new QueryWrapper<>();
                businesHourWrapper.eq("station_id",station.getId());
                AssetsStationbusinesshours stationBusinessHours = assetsStationbusinesshoursMapper.selectOne(businesHourWrapper);
                if (stationBusinessHours==null){
                    vo.setWeekday("");
                    vo.setStart_time("");
                    vo.setEnd_time("");
                }else {
                    vo.setWeekday(stationBusinessHours.getWeekday());
                    vo.setStart_time(sdf.format(stationBusinessHours.getStartTime()));
                    vo.setEnd_time(sdf.format(stationBusinessHours.getEndTime()));
                }
                //3.根据站点编号获取站点图片信息
                QueryWrapper<AssetsStationimages> imagesWrapper=new QueryWrapper<>();
                imagesWrapper.eq("station_id",station.getId());
                List<AssetsStationimages> stationImages = assetsStationimagesMapper.selectList(imagesWrapper);
                List<String> imageUrls = new ArrayList<>();
                if (stationImages.size()>0) {
                    for (AssetsStationimages image : stationImages) {
                        log.info("打印图片url前缀："+imgUrlPrefix);
                        imageUrls.add(imgUrlPrefix +image.getImage());
                    }
                }else {
                    System.out.println("该站点没有图片");
                }
                //4.根据站点编号获取快充桩状态描述
                List<ConnectorInfoVo> fastInfo = null;
                List<ConnectorInfoVo> slowInfo = null;
                try {
                    fastInfo = assetsStationsMapper.findFastInfo(station.getId());
                    modifySoc(fastInfo);
                    //5.根据站点编号获取慢充桩状态描述
                    slowInfo = assetsStationsMapper.findSlowInfo(station.getId());
                    modifySoc(slowInfo);
                } catch (Exception e) {
                    return new CommonVo("一个枪只能有一个正在充电的订单，请检查，发现有一个枪有多个正在充电的订单",null);
                }
                //6.根据站点编号获取运营商信息
                EmployeeCompany employeeCompany = employeeCompanyMapper.selectById(station.getCompanyId());
                if (employeeCompany==null)
                    vo.setCompany("");
                else
                    vo.setCompany(employeeCompany.getName());
                //7.根据站点编号获取所有价格模板
                CommonVo commonVo = queryChargingPriceByStationId(station.getId());
                if ("99".equalsIgnoreCase(commonVo.getstatus()))
                    return new CommonVo(commonVo.getMsg(),null);
                //8.封装
                vo.setName(station.getName());
                vo.setAddress(station.getAddress());
                vo.setExt_address(station.getExtAddress());
                vo.setLatitude(station.getLatitude());
                vo.setLongitude(station.getLongitude());
                vo.setImages(imageUrls);
                if (commonVo.getdata()!=null&&"00".equalsIgnoreCase(commonVo.getstatus()))
                    vo.setPrice_period((List<PriceTemplateVo>) commonVo.getdata());
                QueryWrapper<ConfigurationSystemdict> wrapper=new QueryWrapper<>();
                wrapper.select("value");
                wrapper.eq("`key`","STATION_LABEL");
                ConfigurationSystemdict systemdict = configurationSystemdictMapper.selectOne(wrapper);
                List<StationTagsVo> tagsVos = formatTagValue(systemdict.getValue());
                vo.setTags(formartTags(station.getPropertyLabel(), tagsVos));
                vo.setFast_cntrs(fastInfo);
                vo.setSlow_cntrs(slowInfo);
                vo.setPark_fee_type(station.getParkFeeType());
                vo.setPark_fee_desc(station.getParkFeeDesc());
                vo.setPhone(station.getServicePhone());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new CommonVo(ResultCode.SUCCESS_CODE,"查询站点详情",vo);
    }

    @Override
    public CommonVo queryStationByCode(String code) {
        log.info("根据枪编码获取站点编号");
        QueryWrapper<AssetsConnector> connectorWrapper=new QueryWrapper<>();
        connectorWrapper.eq("code",code);
        AssetsConnector connector = assetsConnectorMapper.selectOne(connectorWrapper);
        if (connector==null)
            return new CommonVo("枪编码错误",null);
        Map<String,Object> map=new HashMap<>();
        map.put("station_id",connector.getStationId());
        return new CommonVo(map);
    }

    @Override
    public CommonVo evaluateTags() {
        log.info("获取站点评价标签");
        List<StationTagsVo> list=null;
        QueryWrapper<ConfigurationSystemdict> wrapper=new QueryWrapper<>();
        wrapper.select("value");
        wrapper.eq("`key`","STATION_EVALUATE_TAGS");
        ConfigurationSystemdict systemdict=null;
        try {
            systemdict = configurationSystemdictMapper.selectOne(wrapper);
            list = formatTagValue(systemdict.getValue());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new CommonVo(ResultCode.SUCCESS_CODE,"显示站点的所有标签",list);
    }

    private void modifySoc(List<ConnectorInfoVo> list){
        try {
            for (ConnectorInfoVo connectorInfoVo : list) {
                //根据枪编号和订单状态来获取订单信息（订单号），一个枪只能有一个正在充电中的订单
                QueryWrapper<CustomerChargingorder> orderWrapper=new QueryWrapper<>();
                orderWrapper.eq("connector_id",connectorInfoVo.getId());
                orderWrapper.eq("charging_status", ChargingOrderStatusEnum.CHARGING.getValue());
                CustomerChargingorder order = customerChargingorderMapper.selectOne(orderWrapper);
                if (order!=null){
                    //通过订单号在充电轨迹记录表中获取soc
                    QueryWrapper<CustomerChargingordertracks> trackWrapper=new QueryWrapper<>();
                    trackWrapper.eq("order_id",order.getId());
                    trackWrapper.orderByAsc("add_time");
                    List<CustomerChargingordertracks> orderTracks = customerChargingordertracksMapper.selectList(trackWrapper);
                    if (orderTracks.size()>0)
                        connectorInfoVo.setSoc(orderTracks.get(orderTracks.size()-1).getSoc());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 格式化标签值
     * @Author JianMei Chen
     * @Date  2020/5/6
     * @return
     **/
    public List<StationTagsVo> formatTagValue(String jsonString){
        List<StationTagsVo> list=new ArrayList<>();
        StationTagsVo vo=null;

        JSONArray objects = JSONArray.parseArray(jsonString);
        int j=0;
        Object[] result=new Object[100];
        for (Object object : objects) {
            //将object转换为字符串
            String s = JSONObject.toJSONString(object);
            //在将字符串转换为JsonArray
            JSONArray jsonArray = JSONArray.parseArray(s);
            Iterator<Object> iterator = jsonArray.iterator();
            while (iterator.hasNext()){
                result[j]=iterator.next();
                j++;
            }
        }
        for (int i=0;i<result.length;i++){
            if (result[i]!=null&&i%2==0){
                vo=new StationTagsVo();
                vo.setId((Integer) result[i]);
                vo.setName((String) result[i+1]);
                list.add(vo);
            }
        }
        return list;
    }

    public String formartTags(Integer tags, List<StationTagsVo> tagsVos){
        List<String> list=new ArrayList<>();
        for (StationTagsVo tagsVo : tagsVos) {
            int data=tagsVo.getId()&tags;
            if (data==tagsVo.getId()){
                list.add(tagsVo.getId()+"");
            }
        }
        String listStr = list.toString();
        return listStr.substring(1,listStr.length()-1);
    }

    //===================================================================
    /**
     * 判断当前时间是否在指定时间内
     * @Author: JianMei Chen
     * @Date: 2020/4/23
     */
    public boolean nowTimeIsRangeTime(Date start,Date end,String format){
        SimpleDateFormat df=new SimpleDateFormat(format);
        try {
            //当前时间
            Calendar nowTime=Calendar.getInstance();
            nowTime.setTime(df.parse(df.format(new Date())));
            //开始时间
            Calendar startTime=Calendar.getInstance();
            startTime.setTime(df.parse(df.format(start)));
            //结束时间
            Calendar endTime = Calendar.getInstance();
            endTime.setTime(df.parse(df.format(end)));
            if (df.format(new Date()).equalsIgnoreCase(df.format(start))){
                return true;
            }
            //表示在指定时间范围内
            if (nowTime.after(startTime)&&nowTime.before(endTime)){
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     *  格式化营业时间
     * @Author: JianMei Chen
     * @Date: 2020/4/23
     */
    public String getBusinessHours(List<AssetsStationbusinesshours> list){
        Map<Integer,Object> map=new HashMap<>();
        AssetsStationbusinesshours hours=null;
        for (int i=0;i<list.size();i++){
            hours=list.get(i);
            String str=hours.getWeekday()+","+hours.getStartTime()+"-"+hours.getEndTime();
            map.put(i++,str);
        }
        return JSONObject.toJSONString(map);
    }


    /**
     * 服务费和电费都统一
     * @Author: JianMei Chen
     * @Date: 2020/4/24
     */
    public void allTy(PriceTemplateVo vo,ConfigurationChargingprice price){
        vo.setCharging_price(price.getChargingPrice().doubleValue());
        vo.setService_price(price.getServicePrice().doubleValue());
        vo.setPnv_type(0);
    }

    /**
     * 服务费统一，电费不统一
     * @Author: JianMei Chen
     * @Date: 2020/4/24
     */
    public void serviceTyChargingNoTy(List<ConfigurationChargingpricetimeperiod> timePeriods,ChargingStationAllInfoVo allInfoVo,
                                      ConfigurationChargingprice priceModel,boolean isActivity,Integer model,
                                      ConfigurationChargingpricetimeperiod timePeriod2,PriceTemplateVo vo){
        if (model==1){
            if (isActivity){//表示活动
                for (ConfigurationChargingpricetimeperiod timePeriod : timePeriods) {
                    if (nowTimeIsRangeTime(timePeriod.getStart(),timePeriod.getEnd(),"HH:mm:ss")){
                        //根据所属峰平谷来判断充电费用
                        if ("peaks".equals(timePeriod.getPnvType())){
                            allInfoVo.setPrice(roundMath(priceModel.getServicePrice().add(priceModel.getPeaksChargingPrice()).doubleValue()));
                        }else if("normal".equals(timePeriod.getPnvType())){
                            allInfoVo.setPrice(roundMath(priceModel.getServicePrice().add(priceModel.getNormalChargingPrice()).doubleValue()));
                        }else if ("valleys".equals(timePeriod.getPnvType())){
                            allInfoVo.setPrice(roundMath(priceModel.getServicePrice().add(priceModel.getValleysChargingPrice()).doubleValue()));
                        }
                        break;
                    }
                }
            }else {
                //表示默认，也是原价格
                for (ConfigurationChargingpricetimeperiod timePeriod : timePeriods) {
                    if (nowTimeIsRangeTime(timePeriod.getStart(),timePeriod.getEnd(),"HH:mm:ss")){
                        //根据所属峰平谷来判断充电费用
                        if ("peaks".equals(timePeriod.getPnvType())){
                            allInfoVo.setOriginal_price(roundMath(priceModel.getServicePrice().add(priceModel.getPeaksChargingPrice()).doubleValue()));
                            allInfoVo.setPrice(roundMath(priceModel.getServicePrice().add(priceModel.getPeaksChargingPrice()).doubleValue()));
                        }else if("normal".equals(timePeriod.getPnvType())){
                            allInfoVo.setOriginal_price(roundMath(priceModel.getServicePrice().add(priceModel.getNormalChargingPrice()).doubleValue()));
                            allInfoVo.setPrice(roundMath(priceModel.getServicePrice().add(priceModel.getNormalChargingPrice()).doubleValue()));
                        }else if ("valleys".equals(timePeriod.getPnvType())){
                            allInfoVo.setOriginal_price(roundMath(priceModel.getServicePrice().add(priceModel.getValleysChargingPrice()).doubleValue()));
                            allInfoVo.setPrice(roundMath(priceModel.getServicePrice().add(priceModel.getValleysChargingPrice()).doubleValue()));
                        }
                        break;
                    }
                }
            }
        }else if (model==2){
            vo.setService_price(priceModel.getServicePrice().doubleValue());
            if ("peaks".equalsIgnoreCase(timePeriod2.getPnvType())){
                vo.setCharging_price(priceModel.getPeaksChargingPrice().doubleValue());
                vo.setPnv_type(1);
            }else if ("normal".equalsIgnoreCase(timePeriod2.getPnvType())){
                vo.setCharging_price(priceModel.getNormalChargingPrice().doubleValue());
                vo.setPnv_type(2);
            }else if ("valleys".equalsIgnoreCase(timePeriod2.getPnvType())){
                vo.setCharging_price(priceModel.getValleysChargingPrice().doubleValue());
                vo.setPnv_type(3);
            }
        }else if (model==3){
            for (ConfigurationChargingpricetimeperiod timePeriod : timePeriods) {
                if (nowTimeIsRangeTime(timePeriod.getStart(),timePeriod.getEnd(),"HH:mm:ss")){
                    //根据所属峰平谷来判断充电费用
                    if ("peaks".equals(timePeriod.getPnvType())){
                        allInfoVo.setOriginal_price(roundMath(priceModel.getServicePrice().add(priceModel.getPeaksChargingPrice()).doubleValue()));
                    }else if("normal".equals(timePeriod.getPnvType())){
                        allInfoVo.setOriginal_price(roundMath(priceModel.getServicePrice().add(priceModel.getNormalChargingPrice()).doubleValue()));
                    }else if ("valleys".equals(timePeriod.getPnvType())){
                        allInfoVo.setOriginal_price(roundMath(priceModel.getServicePrice().add(priceModel.getValleysChargingPrice()).doubleValue()));
                    }
                    break;
                }
            }
        }
    }

    /**
     * 电费统一，服务费不统一
     * @Author: JianMei Chen
     * @Date: 2020/4/24
     */
    public void chargingTyServiceNoTy(List<ConfigurationChargingpricetimeperiod> timePeriods, ChargingStationAllInfoVo allInfoVo,
                                      ConfigurationChargingprice price, boolean isActive,Integer model,
                                      ConfigurationChargingpricetimeperiod timePeriod2,PriceTemplateVo vo){
        if (model==1){
            if (isActive){//是活动
                for (ConfigurationChargingpricetimeperiod timePeriod : timePeriods) {
                    //表示当前时间在指定时间段内
                    if (nowTimeIsRangeTime(timePeriod.getStart(),timePeriod.getEnd(),"HH:mm:ss")){
                        //根据所属峰平谷来判断价格
                        if ("peaks".equals(timePeriod.getPnvType())){
                            allInfoVo.setPrice(roundMath(price.getChargingPrice().add(price.getPeaksServicePrice()).doubleValue()));
                        }else if ("normal".equals(timePeriod.getPnvType())){
                            allInfoVo.setPrice(roundMath(price.getChargingPrice().add(price.getNormalServicePrice()).doubleValue()));
                        }else if ("valleys".equals(timePeriod.getPnvType())){
                            allInfoVo.setPrice(roundMath(price.getChargingPrice().add(price.getValleysServicePrice()).doubleValue()));
                        }
                        break;
                    }
                }
            }else {//默认价格，也是原价格
                for (ConfigurationChargingpricetimeperiod timePeriod : timePeriods) {
                    if (nowTimeIsRangeTime(timePeriod.getStart(),timePeriod.getEnd(),"HH:mm:ss")){
                        if ("peaks".equals(timePeriod.getPnvType())){
                            allInfoVo.setOriginal_price(roundMath(price.getChargingPrice().add(price.getPeaksServicePrice()).doubleValue()));
                            allInfoVo.setPrice(roundMath(price.getChargingPrice().add(price.getPeaksServicePrice()).doubleValue()));
                        }else if ("normal".equals(timePeriod.getPnvType())){
                            allInfoVo.setOriginal_price(roundMath(price.getChargingPrice().add(price.getNormalServicePrice()).doubleValue()));
                            allInfoVo.setPrice(roundMath(price.getChargingPrice().add(price.getNormalServicePrice()).doubleValue()));
                        }else if ("valleys".equals(timePeriod.getPnvType())){
                            allInfoVo.setOriginal_price(roundMath(price.getChargingPrice().add(price.getValleysServicePrice()).doubleValue()));
                            allInfoVo.setPrice(roundMath(price.getChargingPrice().add(price.getValleysServicePrice()).doubleValue()));
                        }
                        break;
                    }
                }
            }
        }else if (model==2){
            vo.setCharging_price(price.getChargingPrice().doubleValue());
            if ("peaks".equalsIgnoreCase(timePeriod2.getPnvType())){
                vo.setService_price(price.getPeaksServicePrice().doubleValue());
                vo.setPnv_type(1);
            }else if ("normal".equalsIgnoreCase(timePeriod2.getPnvType())){
                vo.setService_price(price.getNormalServicePrice().doubleValue());
                vo.setPnv_type(2);
            }else if ("valleys".equalsIgnoreCase(timePeriod2.getPnvType())){
                vo.setService_price(price.getValleysServicePrice().doubleValue());
                vo.setPnv_type(3);
            }
        }else if (model==3){
            for (ConfigurationChargingpricetimeperiod timePeriod : timePeriods) {
                //表示当前时间在指定时间段内
                if (nowTimeIsRangeTime(timePeriod.getStart(),timePeriod.getEnd(),"HH:mm:ss")){
                    //根据所属峰平谷来判断价格
                    if ("peaks".equals(timePeriod.getPnvType())){
                        allInfoVo.setOriginal_price(roundMath(price.getChargingPrice().add(price.getPeaksServicePrice()).doubleValue()));
                    }else if ("normal".equals(timePeriod.getPnvType())){
                        allInfoVo.setOriginal_price(roundMath(price.getChargingPrice().add(price.getNormalServicePrice()).doubleValue()));
                    }else if ("valleys".equals(timePeriod.getPnvType())){
                        allInfoVo.setOriginal_price(roundMath(price.getChargingPrice().add(price.getValleysServicePrice()).doubleValue()));
                    }
                    break;
                }
            }
        }
    }

    /**
     * 服务费和电费都不统一，根据当前时间来判断是否峰平谷时间来决定服务费和电费的费用
     * @Author: JianMei Chen
     * @Date: 2020/4/24
     */
    public void noMulti(List<ConfigurationChargingpricetimeperiod> timePeriods,ChargingStationAllInfoVo allInfoVo,
                        ConfigurationChargingprice priceModel,boolean isActivity,Integer model,
                        ConfigurationChargingpricetimeperiod timePeriod2,PriceTemplateVo vo){
        if (model==1){
            if (isActivity){//活动
                for (ConfigurationChargingpricetimeperiod timePeriod : timePeriods) {
                    if (nowTimeIsRangeTime(timePeriod.getStart(), timePeriod.getEnd(), "HH:mm:ss")){
                        if ("peaks".equals(timePeriod.getPnvType())){//峰值
                            allInfoVo.setPrice(roundMath(priceModel.getPeaksChargingPrice().add(priceModel.getPeaksServicePrice()).doubleValue()));
                        }else if ("normal".equals(timePeriod.getPnvType())){//平时
                            allInfoVo.setPrice(roundMath(priceModel.getNormalChargingPrice().add(priceModel.getNormalServicePrice()).doubleValue()));
                        }else if ("valleys".equals(timePeriod.getPnvType())){//谷时
                            allInfoVo.setPrice(roundMath(priceModel.getValleysChargingPrice().add(priceModel.getValleysServicePrice()).doubleValue()));
                        }
                        break;
                    }
                }
            }else {//默认价格，也是原价格
                for (ConfigurationChargingpricetimeperiod timePeriod : timePeriods) {
                    if (nowTimeIsRangeTime(timePeriod.getStart(), timePeriod.getEnd(), "HH:mm:ss")){
                        if ("peaks".equals(timePeriod.getPnvType())){//峰值
                            allInfoVo.setOriginal_price(roundMath(priceModel.getPeaksChargingPrice().add(priceModel.getPeaksServicePrice()).doubleValue()));
                            allInfoVo.setPrice(roundMath(priceModel.getPeaksChargingPrice().add(priceModel.getPeaksServicePrice()).doubleValue()));
                        }else if ("normal".equals(timePeriod.getPnvType())){//平时
                            allInfoVo.setOriginal_price(roundMath(priceModel.getNormalChargingPrice().add(priceModel.getNormalServicePrice()).doubleValue()));
                            allInfoVo.setPrice(roundMath(priceModel.getNormalChargingPrice().add(priceModel.getNormalServicePrice()).doubleValue()));
                        }else if ("valleys".equals(timePeriod.getPnvType())){//谷时
                            allInfoVo.setOriginal_price(roundMath(priceModel.getValleysChargingPrice().add(priceModel.getValleysServicePrice()).doubleValue()));
                            allInfoVo.setPrice(roundMath(priceModel.getValleysChargingPrice().add(priceModel.getValleysServicePrice()).doubleValue()));
                        }
                        break;
                    }
                }
            }
        }else if (model==2){
            if ("peaks".equalsIgnoreCase(timePeriod2.getPnvType())){
                vo.setCharging_price(priceModel.getPeaksChargingPrice().doubleValue());
                vo.setService_price(priceModel.getPeaksServicePrice().doubleValue());
                vo.setPnv_type(1);
            }else if ("normal".equalsIgnoreCase(timePeriod2.getPnvType())){
                vo.setCharging_price(priceModel.getNormalChargingPrice().doubleValue());
                vo.setService_price(priceModel.getNormalServicePrice().doubleValue());
                vo.setPnv_type(2);
            }else if ("valleys".equalsIgnoreCase(timePeriod2.getPnvType())){
                vo.setCharging_price(priceModel.getValleysChargingPrice().doubleValue());
                vo.setService_price(priceModel.getValleysServicePrice().doubleValue());
                vo.setPnv_type(3);
            }
        }else if (model==3){
            for (ConfigurationChargingpricetimeperiod timePeriod : timePeriods) {
                if (nowTimeIsRangeTime(timePeriod.getStart(), timePeriod.getEnd(), "HH:mm:ss")){
                    if ("peaks".equals(timePeriod.getPnvType())){//峰值
                        allInfoVo.setOriginal_price(roundMath(priceModel.getPeaksChargingPrice().add(priceModel.getPeaksServicePrice()).doubleValue()));
                    }else if ("normal".equals(timePeriod.getPnvType())){//平时
                        allInfoVo.setOriginal_price(roundMath(priceModel.getNormalChargingPrice().add(priceModel.getNormalServicePrice()).doubleValue()));
                    }else if ("valleys".equals(timePeriod.getPnvType())){//谷时
                        allInfoVo.setOriginal_price(roundMath(priceModel.getValleysChargingPrice().add(priceModel.getValleysServicePrice()).doubleValue()));
                    }
                    break;
                }
            }
        }
    }


    public AssetsStationchargingprice queryDefaultPrice(Integer stationId){
        //不在活动范围内，使用默认模板来计算服务费和电费.一个站点只有一个默认模板
        QueryWrapper<AssetsStationchargingprice> defaultWrapper=new QueryWrapper<>();
        defaultWrapper.eq("station_id",stationId);
        defaultWrapper.eq("is_default", PriceIsDefaultEunm.DEFAULT.getValue());//表示默认
        defaultWrapper.eq("is_enabled",1);
        AssetsStationchargingprice priceMiddleTable = assetsStationchargingpriceMapper.selectOne(defaultWrapper);
        return priceMiddleTable;
    }


    public void defaultPriceModual(AssetsStationchargingprice priceMiddleTable,ChargingStationAllInfoVo allInfoVo){
        ConfigurationChargingprice priceModual = configurationChargingpriceMapper.selectById(priceMiddleTable.getPriceId());
        QueryWrapper<ConfigurationChargingpricetimeperiod> timeWrapper=new QueryWrapper<>();
        timeWrapper.eq("price_id",priceModual.getId());
        List<ConfigurationChargingpricetimeperiod> priceTimePeriodList = configurationChargingpricetimeperiodMapper.selectList(timeWrapper);
        if (priceModual.getIsServiceFlatFee()&&priceModual.getIsFlatFee()){
            allInfoVo.setOriginal_price(roundMath(priceModual.getChargingPrice().add(priceModual.getServicePrice()).doubleValue()));
            allInfoVo.setPrice(roundMath(priceModual.getChargingPrice().add(priceModual.getServicePrice()).doubleValue()));
        }else if (priceModual.getIsFlatFee()){//表示电费统一，服务费不统一
            chargingTyServiceNoTy(priceTimePeriodList,allInfoVo,priceModual,false,1,null,null);
        }else if (priceModual.getIsServiceFlatFee()){//表示服务费统一，电费不统一
            serviceTyChargingNoTy(priceTimePeriodList,allInfoVo,priceModual,false,1,null,null);
        }else {//表示服务费和电费都不统一
            noMulti(priceTimePeriodList,allInfoVo,priceModual,false,1,null,null);
        }
    }
    public void activeOriginalPrice(AssetsStationchargingprice priceMiddleTable,ChargingStationAllInfoVo allInfoVo){
        ConfigurationChargingprice priceModual = configurationChargingpriceMapper.selectById(priceMiddleTable.getPriceId());
        QueryWrapper<ConfigurationChargingpricetimeperiod> timeWrapper=new QueryWrapper<>();
        timeWrapper.eq("price_id",priceModual.getId());
        List<ConfigurationChargingpricetimeperiod> priceTimePeriodList = configurationChargingpricetimeperiodMapper.selectList(timeWrapper);
        if (priceModual.getIsServiceFlatFee()&&priceModual.getIsFlatFee()){
            allInfoVo.setOriginal_price(roundMath(priceModual.getChargingPrice().add(priceModual.getServicePrice()).doubleValue()));
        }else if (priceModual.getIsFlatFee()){//表示电费统一，服务费不统一
            chargingTyServiceNoTy(priceTimePeriodList,allInfoVo,priceModual,false,3,null,null);
        }else if (priceModual.getIsServiceFlatFee()){//表示服务费统一，电费不统一
            serviceTyChargingNoTy(priceTimePeriodList,allInfoVo,priceModual,false,3,null,null);
        }else {//表示服务费和电费都不统一
            noMulti(priceTimePeriodList,allInfoVo,priceModual,false,3,null,null);
        }
    }


    public CommonVo queryChargingPriceByStationId(Integer stationId) {
        Integer hours=0;
        List<PriceTemplateVo> list=new ArrayList<>();
        PriceTemplateVo vo=null;
        log.info("通过站点Id来查询该站点的所有价格模板");
        if (stationId==null) {
            return new CommonVo("请求参数为空！",null);
        }
        try {
            //1.根据站点编号在价格绑定表判断有几个模板
            QueryWrapper<AssetsStationchargingprice> wrapper=new QueryWrapper<>();
            wrapper.eq("station_id",stationId);
            Integer count = assetsStationchargingpriceMapper.selectCount(wrapper);
            //表示该站点有两个价格模板
            if (count>1) {
                //2.找到“活动”的模板指定时间，判断当前时间是否在活动时间内，如果在的话，使用该模板的编号
                List<AssetsStationchargingprice> priceMiddleList = assetsStationchargingpriceService.findActivityByStationId(stationId);
                if (priceMiddleList.size()>0){
                    for (AssetsStationchargingprice priceMiddleTable : priceMiddleList) {
                        if (nowTimeIsRangeTime(priceMiddleTable.getStartTime(),priceMiddleTable.getEndTime(),"yyyy-MM-dd")){
                            log.info("当前时间在活动范围内");
                            List<ConfigurationChargingpricetimeperiod> timePeriods = configurationChargingpricetimeperiodService.findAllByPriceIdOrderByAsc(priceMiddleTable.getPriceId());
                            if (timePeriods.size()<=0){//表示没有价格时段数据，则为统一服务费和电费
                                Integer integer = tyPrice(vo, priceMiddleTable, list);
                                CommonVo surplus = surplus(priceMiddleTable, list, stationId, vo, integer);
                                return surplus;
                            }
                            hours = currency(timePeriods, list, priceMiddleTable, vo);
                            CommonVo commonVo = surplus(priceMiddleTable, list, stationId,vo,hours);
                            return commonVo;
                        }else {
                            System.out.println("有活动模板，但是不在活动范围内，所有使用默认模板");
                            //1.通过站点编号以及状态获取默认模板的信息
                            CommonVo commonVo = defaultStationDesc(priceMiddleTable, list, stationId,vo,hours);
                            return commonVo;
                        }
                    }
                }else {
                    return new CommonVo("该站点有多个模板，但是却没有活动模板，请核对数据库的数据！",null);
                }
            }else if(count==1){
                //只有一个默认模板
                log.info("该站点只有一个模板，是默认模板");
                AssetsStationchargingprice defaultMiddleTable = assetsStationchargingpriceService.findDefaultByStationId(stationId);
                List<ConfigurationChargingpricetimeperiod> timePeriods = configurationChargingpricetimeperiodService.findAllByPriceIdOrderByAsc(defaultMiddleTable.getPriceId());
                if (timePeriods.size()>0){
                    hours = currency(timePeriods, list, defaultMiddleTable, vo);
                    ConfigurationChargingprice price = configurationChargingpriceMapper.selectById(defaultMiddleTable.getPriceId());
                    onePrice(vo,timePeriods,price,list,hours);
                    return new CommonVo(list);
                }else {
                    //表示只有默认模板。只有到默认模板来根据
                    Integer integer = tyPrice(vo, defaultMiddleTable, list);
                    log.info("只要默认模板，添加>>>>>>>>>>>>>>>>>>>>>>+"+integer);
                    vo=new PriceTemplateVo();
                    vo.setPnv_type(0);
                    ConfigurationChargingprice price = configurationChargingpriceMapper.selectById(defaultMiddleTable.getPriceId());
                    vo.setService_price(price.getServicePrice().doubleValue());
                    vo.setCharging_price(price.getChargingPrice().doubleValue());
                    vo.setPeriod("00:00-"+(integer<=9?"0"+integer:integer)+":00");
                    list.add(vo);
                }
            }else {
                return new CommonVo("该站点没有设置模板，请去设置！！",null);
            }
        } catch (Exception e) {
            log.info("查询失败");
            e.printStackTrace();
        }
        return new CommonVo(list);
    }

    private Integer tyPrice(PriceTemplateVo vo,AssetsStationchargingprice priceMiddleTable,List<PriceTemplateVo> list){
        vo=new PriceTemplateVo();
        Date nowDate = new Date();
        Integer hours=nowDate.getHours();
        String hoursStr="";
        if (hours<=9)
            hoursStr="0"+hours+":00";
        else
            hoursStr=hours+":00";
        vo.setPeriod(hoursStr+"-24:00");
        vo.setPnv_type(0);
        ConfigurationChargingprice price = configurationChargingpriceMapper.selectById(priceMiddleTable.getPriceId());
        vo.setService_price(price.getServicePrice().doubleValue());
        vo.setCharging_price(price.getChargingPrice().doubleValue());
        list.add(vo);
        return hours;
    }

    private void onePrice(PriceTemplateVo vo,List<ConfigurationChargingpricetimeperiod> timePeriodList,
                          ConfigurationChargingprice price,List<PriceTemplateVo> list,Integer hours){
        log.info("相减时间2："+hours);
        int hour= 24-hours;
        String hoursStr="";
        if (hour<10){
            hoursStr="0"+hour+":00:00";
        }else {
            hoursStr=hour+":00:00";
        }
        log.info("相差小时："+hoursStr);
        for (ConfigurationChargingpricetimeperiod timePeriod : timePeriodList) {
            PriceTemplateVo priceTemplateVo = pnvTy(vo, timePeriod, price, list);
            try {
                list.add(priceTemplateVo);
                if (hoursStr.equalsIgnoreCase(hhMMss.format(timePeriod.getEnd()))){
                    log.info("加上hours时间到时间段的结束时间，退出"+hhMMss.format(timePeriod.getEnd()));
                    break;
                }
                if (tomorrowIsActivity(timePeriod.getStart(),timePeriod.getEnd(),hhMMss.parse(hoursStr),"HH:mm:ss")){
                    log.info("开始时间："+sdf.format(timePeriod.getStart())+"结束时间："+sdf.format(timePeriod.getEnd()));
                    log.info("表示加上hours时间在某个时间范围内，取加上时间段后退出>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
                    hoursStr = hoursStr.substring(0, hoursStr.lastIndexOf(":"));
                    priceTemplateVo.setPeriod(sdf.format(timePeriod.getStart())+"-"+hoursStr);
                    //list.add(priceTemplateVo);
                    break;
                }
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
    }

    private PriceTemplateVo pnvTy(PriceTemplateVo vo,ConfigurationChargingpricetimeperiod timePeriod,
                       ConfigurationChargingprice price,List<PriceTemplateVo> list){
        vo=new PriceTemplateVo();
        formartPeriod(timePeriod,vo);
        if (price.getIsServiceFlatFee()&&price.getIsFlatFee()){//服务费和电费都统一
            allTy(vo,price);
        }else if (price.getIsFlatFee()){//电费统一，服务费不统一
            chargingTyServiceNoTy(null,null,price,false,2,timePeriod,vo);
        }else if (price.getIsServiceFlatFee()){//服务费统一，电费不统一
            serviceTyChargingNoTy(null,null,price,false,2,timePeriod,vo);
        }else{//电费和服务费不统一
            noMulti(null,null,price,false,2,timePeriod,vo);
        }
//        list.add(vo);
        return vo;
    }

    public CommonVo defaultStationDesc(AssetsStationchargingprice priceMiddleTable,List<PriceTemplateVo> list,Integer stationId,PriceTemplateVo vo
    ,Integer hours){
        try {
            AssetsStationchargingprice middleTable = assetsStationchargingpriceService.findDefaultByStationId(stationId);
            if (middleTable==null)
                return new CommonVo("该站点没有默认模板，请添加！",null);
            //判断当前时间在哪个时间段。
            List<ConfigurationChargingpricetimeperiod> timePeriodList= configurationChargingpricetimeperiodService.findAllByPriceIdOrderByAsc(middleTable.getPriceId());
            if (timePeriodList.size()<=0){
                Integer integer = tyPrice(vo, middleTable, list);
                CommonVo surplus = surplus(priceMiddleTable, list, stationId, vo, integer);
                return surplus;
            }
            hours = currency(timePeriodList, list, middleTable, vo);
            //判断第二天是否在活动范围内
            CommonVo commonVo = surplus(priceMiddleTable, list, stationId, vo,hours);
            return commonVo;
        } catch (Exception e) {
            e.printStackTrace();
//            return new CommonVo("该站点有多个默认模板，一个站点只能有一个默认模板，请检查！",null);
        }
        return new CommonVo(null);
    }


    public void formartPeriod(ConfigurationChargingpricetimeperiod timePeriod,PriceTemplateVo vo){
        if ("00:00".equalsIgnoreCase(sdf.format(timePeriod.getEnd())) || "23:59".equalsIgnoreCase(sdf.format(timePeriod.getEnd()))){
            vo.setPeriod(sdf.format(timePeriod.getStart())+"-"+"24:00");
        }else {
            vo.setPeriod(sdf.format(timePeriod.getStart())+"-"+sdf.format(timePeriod.getEnd()));
        }
    }

    public CommonVo surplus(AssetsStationchargingprice priceMiddleTable,List<PriceTemplateVo> list,Integer stationId,PriceTemplateVo vo,Integer hours){
        Calendar instance = Calendar.getInstance();
        instance.setTime(new Date());
        instance.add(Calendar.DAY_OF_MONTH,1);
        Date tomorrow = instance.getTime();
        if (hours>0&&hours!=24&&tomorrowIsActivity(priceMiddleTable.getStartTime(),priceMiddleTable.getEndTime(),tomorrow,"yyyy-MM-dd")){
            log.info("明天还在活动范围内,且当前时间不在一天的00:00时间段，获取活动模板");
            ConfigurationChargingprice price = configurationChargingpriceMapper.selectById(priceMiddleTable.getPriceId());
            List<ConfigurationChargingpricetimeperiod> timePeriodList = configurationChargingpricetimeperiodService.findAllByPriceIdOrderByAsc(price.getId());
            if (timePeriodList.size()<=0){
                sxTyPrice(vo,price,list,hours);
                return new CommonVo(list);
            }
            onePrice(vo,timePeriodList,price,list,hours);
        }else if (hours>0&&hours!=24&&!tomorrowIsActivity(priceMiddleTable.getStartTime(),priceMiddleTable.getEndTime(),tomorrow,"yyyy-MM-dd")){
            log.info("明天不在活动范围内，且当前时间不在当天的00:00时间段，  使用默认模板来判断接下来时间段的价格模板");
            try {
                AssetsStationchargingprice middleTable = assetsStationchargingpriceService.findDefaultByStationId(stationId);
                if (middleTable==null)
                    return new CommonVo("该站点没有默认模板，请修正！",null);
                ConfigurationChargingprice price = configurationChargingpriceMapper.selectById(middleTable.getPriceId());
                List<ConfigurationChargingpricetimeperiod> timePeriodList = configurationChargingpricetimeperiodService.findAllByPriceIdOrderByAsc(price.getId());
                if (timePeriodList.size()<=0){
                    sxTyPrice(vo,price,list,hours);
                    return new CommonVo(list);
                }
                onePrice(vo,timePeriodList,price,list,hours);
            } catch (Exception e) {
                return new CommonVo("请检查该站点是否有多个默认模板，一个站点只能有一个默认模板！请修正!",null);
            }
        }
        return new CommonVo(list);
    }

    private void sxTyPrice(PriceTemplateVo vo, ConfigurationChargingprice price, List<PriceTemplateVo> list, Integer hours){
        vo=new PriceTemplateVo();
        vo.setPnv_type(0);
        String hoursStr="";
        if(hours<10){
            hoursStr="0"+hours+":00";
            vo.setPeriod("00:00-"+hoursStr);
        }else {
            vo.setPeriod("00:00"+hours+":00");
        }
        vo.setCharging_price(price.getChargingPrice().doubleValue());
        vo.setService_price(price.getServicePrice().doubleValue());
        list.add(vo);
    }


    public Integer currency(List<ConfigurationChargingpricetimeperiod> timePeriods,List<PriceTemplateVo> list,
                         AssetsStationchargingprice priceMiddleTable,PriceTemplateVo vo){
        int hour=0;
        try {
            for (int i=0;i<timePeriods.size();i++) {
                ConfigurationChargingpricetimeperiod timePeriod = timePeriods.get(i);
                if (hhMMss.format(timePeriod.getEnd()).equalsIgnoreCase("00:00:00")){
                    log.info("结束时间是：00:00:00");
                    timePeriod.setEnd(hhMMss.parse("23:59:59"));
                }
                if (nowTimeIsRangeTime(timePeriod.getStart(),timePeriod.getEnd(),"HH:mm")){
                    //将该时间段的开始时间与今天的24点对比，看还差几个小时
                    Date start = hhMMss.parse(hhMMss.format(timePeriod.getStart()));
                    Date end = hhMMss.parse("24:00:00");
                    hour= (int) Math.ceil((end.getTime()-(start.getTime()))/((float)(60*60*1000)));//相差小时
                    log.info("相减时间1："+hour);
                    List<Integer> indexList=new ArrayList<>();
                    for (int j=i;j<timePeriods.size();j++){
                        indexList.add(j);
                    }
                    //获取价格模板信息
                    ConfigurationChargingprice price = configurationChargingpriceMapper.selectById(priceMiddleTable.getPriceId());
                    for (Integer index : indexList) {
                        ConfigurationChargingpricetimeperiod chargingpricetimeperiod = timePeriods.get(index);
                        PriceTemplateVo priceTemplateVo = pnvTy(vo, chargingpricetimeperiod, price, list);
                        list.add(priceTemplateVo);
                    }
                    break;
                }
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return hour;
    }

    private boolean tomorrowIsActivity(Date start,Date end,Date tomorrow,String format){
        SimpleDateFormat df=new SimpleDateFormat(format);
        try {
            //当前时间
            Calendar nowTime=Calendar.getInstance();
            nowTime.setTime(df.parse(df.format(tomorrow)));
            //开始时间
            Calendar startTime=Calendar.getInstance();
            startTime.setTime(df.parse(df.format(start)));
            //结束时间
            Calendar endTime = Calendar.getInstance();
            endTime.setTime(df.parse(df.format(end)));
            if (df.format(tomorrow).equalsIgnoreCase(df.format(start))){
                return true;
            }
            //表示在指定时间范围内
            if (nowTime.after(startTime)&&nowTime.before(endTime)){
                return true;
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return false;
    }

}