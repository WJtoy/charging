package com.gdcdgj.charging.service.provider.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gdcdgj.charging.api.entity.AssetsChargingpile;

import java.util.Map;

/**
 * <p>
 * 充电桩 Mapper 接口
 * </p>
 *
 * @author tcl
 * @since 2020-04-20
 */
public interface AssetsChargingpileMapper extends BaseMapper<AssetsChargingpile> {

}
