package com.gdcdgj.charging.service.provider.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gdcdgj.charging.api.entity.AssetsConnector;

/**
 * <p>
 * 充电枪 Mapper 接口
 * </p>
 *
 * @author tcl
 * @since 2020-04-20
 */
public interface AssetsConnectorMapper extends BaseMapper<AssetsConnector> {

}
