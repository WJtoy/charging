package com.gdcdgj.charging.service.provider.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gdcdgj.charging.api.entity.AssetsStationbusinesshours;

/**
 * <p>
 * 站点营业时间 Mapper 接口
 * </p>
 *
 * @author tcl
 * @since 2020-04-20
 */
public interface AssetsStationbusinesshoursMapper extends BaseMapper<AssetsStationbusinesshours> {

}
