package com.gdcdgj.charging.service.provider.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gdcdgj.charging.api.entity.AssetsStations;
import com.gdcdgj.charging.api.vo.charging.ChargingStationAllInfoVo;
import com.gdcdgj.charging.api.vo.charging.ChargingStationInfoVo;
import com.gdcdgj.charging.api.vo.charging.ChargingStationNumberVo;
import com.gdcdgj.charging.api.vo.station.ConnectorInfoVo;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 充电站 Mapper 接口
 * </p>
 *
 * @author tcl
 * @since 2020-04-20
 */
public interface AssetsStationsMapper extends BaseMapper<AssetsStations> {

    /**
    * @Description: 通过cityCode获取充电站点的信息
    * @Param: cityCode 区划代码
    * @return: 
    * @Author: JianMei Chen
    * @Date: 2020/4/22
    */
    List<ChargingStationInfoVo> getStationList(String cityCode);

    /**
    * @Description:  通过站点编号来查询快充，慢充枪的总数量
    * @param: stationId
    * @return:
    * @Author: JianMei Chen
    * @Date: 2020/4/23
    */
    ChargingStationNumberVo getTotalFastAndSlowNum(Integer stationId);

    /**
    * @Description:  通过站点编号来查询（空闲状态下）快充，慢充枪的空闲数量
    * @param: stationId
    * @return:
    * @Author: JianMei Chen
    * @Date: 2020/4/23
    */
    ChargingStationNumberVo getFreeFastAndSlowNum(Integer stationId);

    //=================================================

    /**
     * 根据标签查询站点
     * @Author JianMei Chen
     * @Date  2020/5/7
     * @return
     **/
    List<ChargingStationAllInfoVo> findStationsByTags(Map<String,Object> map);


    /**
     * 根据站点编号查询快充桩相关信息
     * @Author JianMei Chen
     * @Date  2020/5/7
     * @return
     **/
    List<ConnectorInfoVo> findFastInfo(Integer stationId);


    /**
     * 根据站点编号查询慢充桩相关信息
     * @Author JianMei Chen
     * @Date  2020/5/7
     * @return
     **/
    List<ConnectorInfoVo> findSlowInfo(Integer stationId);


    /**
     *  查询id集合下的站点相关信息
     * @Author JianMei Chen
     * @Date  2020/5/20
     * @return
     **/
    List<ChargingStationAllInfoVo> selectStationByIds(@Param("ids") List<Integer> ids);
}
