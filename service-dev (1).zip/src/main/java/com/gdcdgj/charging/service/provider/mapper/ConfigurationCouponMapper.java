package com.gdcdgj.charging.service.provider.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gdcdgj.charging.api.entity.ConfigurationCoupon;

/**
 * <p>
 * 优惠券模板 Mapper 接口
 * </p>
 *
 * @author tcl
 * @since 2020-04-20
 */
public interface ConfigurationCouponMapper extends BaseMapper<ConfigurationCoupon> {

}
