package com.gdcdgj.charging.service.provider.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gdcdgj.charging.api.entity.ConfigurationEquipmentsoftware;

/**
 * <p>
 * 软件版本库 Mapper 接口
 * </p>
 *
 * @author tcl
 * @since 2020-04-20
 */
public interface ConfigurationEquipmentsoftwareMapper extends BaseMapper<ConfigurationEquipmentsoftware> {

}
