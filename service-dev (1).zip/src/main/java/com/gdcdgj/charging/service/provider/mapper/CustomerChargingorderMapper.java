package com.gdcdgj.charging.service.provider.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gdcdgj.charging.api.entity.CustomerChargingorder;
import com.gdcdgj.charging.api.vo.charging.ChargingOrderInfoVo;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 会员账户充值记录 Mapper 接口
 * </p>
 *
 * @author tcl
 * @since 2020-04-20
 */
public interface CustomerChargingorderMapper extends BaseMapper<CustomerChargingorder> {

    /**
     * @Description: 分页查询订单信息, 包含充电桩名称，充电桩地址，充电枪接口类型
     * @Param: map
     * @return:
     * @Author: JianMei Chen
     * @Date: 2020/4/22
     */
    List<ChargingOrderInfoVo> queryChargingOrderList(Map<String, Object> map);

    /**
     * 查询该会员是否有正在充电、结束充电、未付费的订单
     *
     * @param
     * @return
     * @throws
     * @author Changliang Tao
     * @date 2020/4/23 10:37
     */

    Integer getOrderCountByMemberIdAndStatusList(Map<String, Object> paramMap);
}
