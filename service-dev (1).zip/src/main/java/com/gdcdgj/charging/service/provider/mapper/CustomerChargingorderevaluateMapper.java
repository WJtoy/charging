package com.gdcdgj.charging.service.provider.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gdcdgj.charging.api.entity.CustomerChargingorderevaluate;

/**
 * <p>
 * 订单评价表 Mapper 接口
 * </p>
 *
 * @author tcl
 * @since 2020-04-30
 */
public interface CustomerChargingorderevaluateMapper extends BaseMapper<CustomerChargingorderevaluate> {

}
