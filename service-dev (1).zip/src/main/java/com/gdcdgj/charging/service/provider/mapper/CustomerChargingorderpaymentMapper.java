package com.gdcdgj.charging.service.provider.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gdcdgj.charging.api.entity.CustomerChargingorderpayment;

/**
 * <p>
 * 会员充电订单支付记录 Mapper 接口
 * </p>
 *
 * @author tcl
 * @since 2020-04-20
 */
public interface CustomerChargingorderpaymentMapper extends BaseMapper<CustomerChargingorderpayment> {

}
