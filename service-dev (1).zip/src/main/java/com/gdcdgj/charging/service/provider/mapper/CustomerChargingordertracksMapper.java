package com.gdcdgj.charging.service.provider.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gdcdgj.charging.api.entity.CustomerChargingordertracks;
import com.gdcdgj.charging.api.vo.order.QuantityInfoVo;

import java.util.Map;

/**
 * <p>
 * 充电订单过程轨迹跟踪 Mapper 接口
 * </p>
 *
 * @author tcl
 * @since 2020-04-20
 */
public interface CustomerChargingordertracksMapper extends BaseMapper<CustomerChargingordertracks> {

    QuantityInfoVo findQuantity(Map<String,Object> map);
}
