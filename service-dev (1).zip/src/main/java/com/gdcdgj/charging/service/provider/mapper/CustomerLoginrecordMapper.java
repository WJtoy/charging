package com.gdcdgj.charging.service.provider.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gdcdgj.charging.api.entity.CustomerLoginrecord;

/**
 * <p>
 * 会员登陆记录 Mapper 接口
 * </p>
 *
 * @author tcl
 * @since 2020-04-20
 */
public interface CustomerLoginrecordMapper extends BaseMapper<CustomerLoginrecord> {

}
