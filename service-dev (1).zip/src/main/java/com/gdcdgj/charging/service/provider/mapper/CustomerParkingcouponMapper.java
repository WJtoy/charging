package com.gdcdgj.charging.service.provider.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gdcdgj.charging.api.entity.CustomerParkingcoupon;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author tcl
 * @since 2020-04-22
 */
public interface CustomerParkingcouponMapper extends BaseMapper<CustomerParkingcoupon> {

}
