package com.gdcdgj.charging.service.provider.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gdcdgj.charging.api.entity.CustomerRefundrecord;

/**
 * <p>
 * 会员账户充值记录 Mapper 接口
 * </p>
 *
 * @author tcl
 * @since 2020-04-20
 */
public interface CustomerRefundrecordMapper extends BaseMapper<CustomerRefundrecord> {

}
