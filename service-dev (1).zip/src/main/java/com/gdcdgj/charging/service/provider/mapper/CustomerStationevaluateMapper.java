package com.gdcdgj.charging.service.provider.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gdcdgj.charging.api.entity.CustomerStationevaluate;

/**
 * <p>
 * 站点评价表 Mapper 接口
 * </p>
 *
 * @author tcl
 * @since 2020-04-30
 */
public interface CustomerStationevaluateMapper extends BaseMapper<CustomerStationevaluate> {

}
