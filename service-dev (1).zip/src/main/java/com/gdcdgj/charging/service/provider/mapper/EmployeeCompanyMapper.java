package com.gdcdgj.charging.service.provider.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gdcdgj.charging.api.entity.EmployeeCompany;

/**
 * <p>
 * 运营商 Mapper 接口
 * </p>
 *
 * @author tcl
 * @since 2020-04-20
 */
public interface EmployeeCompanyMapper extends BaseMapper<EmployeeCompany> {

}
