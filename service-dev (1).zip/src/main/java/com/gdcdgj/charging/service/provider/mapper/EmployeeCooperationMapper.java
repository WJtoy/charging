package com.gdcdgj.charging.service.provider.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gdcdgj.charging.api.entity.EmployeeCooperation;

/**
 * <p>
 * 合作渠道商 Mapper 接口
 * </p>
 *
 * @author tcl
 * @since 2020-04-20
 */
public interface EmployeeCooperationMapper extends BaseMapper<EmployeeCooperation> {

}
