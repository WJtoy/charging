package com.gdcdgj.charging.service.provider.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gdcdgj.charging.api.entity.EmployeePermissions;

/**
 * <p>
 * 权限 Mapper 接口
 * </p>
 *
 * @author tcl
 * @since 2020-04-20
 */
public interface EmployeePermissionsMapper extends BaseMapper<EmployeePermissions> {

}
