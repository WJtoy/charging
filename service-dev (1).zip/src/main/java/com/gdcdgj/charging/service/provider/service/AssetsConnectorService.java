package com.gdcdgj.charging.service.provider.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gdcdgj.charging.api.entity.AssetsConnector;

/**
 * <p>
 * 充电枪 服务类
 * </p>
 *
 * @author tcl
 * @since 2020-04-20
 */
public interface AssetsConnectorService extends IService<AssetsConnector> {

    AssetsConnector getConnectorByCode(String code);

    /**
     * 根据充电枪id, 将充电枪状态从空闲改为准备充电
     *
     * @param
     * @return
     * @throws
     * @author Changliang Tao
     * @date 2020/4/24 8:29
     */

    Integer updateConnectorStatusFromFreeToPrepareCharging(AssetsConnector connector);
}
