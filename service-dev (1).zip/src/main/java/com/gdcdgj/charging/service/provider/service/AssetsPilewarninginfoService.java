package com.gdcdgj.charging.service.provider.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gdcdgj.charging.api.entity.AssetsPilewarninginfo;

/**
 * <p>
 * 电桩告警记录信息 服务类
 * </p>
 *
 * @author tcl
 * @since 2020-04-20
 */
public interface AssetsPilewarninginfoService extends IService<AssetsPilewarninginfo> {

}
