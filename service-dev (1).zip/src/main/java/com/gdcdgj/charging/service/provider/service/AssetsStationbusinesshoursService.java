package com.gdcdgj.charging.service.provider.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gdcdgj.charging.api.entity.AssetsStationbusinesshours;

/**
 * <p>
 * 站点营业时间 服务类
 * </p>
 *
 * @author tcl
 * @since 2020-04-20
 */
public interface AssetsStationbusinesshoursService extends IService<AssetsStationbusinesshours> {

}
