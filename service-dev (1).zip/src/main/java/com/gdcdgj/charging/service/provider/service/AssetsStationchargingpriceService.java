package com.gdcdgj.charging.service.provider.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gdcdgj.charging.api.entity.AssetsStationchargingprice;

import java.util.List;

/**
 * <p>
 * 站点使用价格关系 服务类
 * </p>
 *
 * @author tcl
 * @since 2020-04-20
 */
public interface AssetsStationchargingpriceService extends IService<AssetsStationchargingprice> {


    /**
     *  获取活动模板绑定信息
     * @Author JianMei Chen
     * @Date  2020/5/18
     * @return
     **/
    List<AssetsStationchargingprice> findActivityByStationId(Integer stationId);


    /**
     *  获取默认模板绑定信息
     * @Author JianMei Chen
     * @Date  2020/5/18
     * @return
     **/
    AssetsStationchargingprice findDefaultByStationId(Integer stationId);

}
