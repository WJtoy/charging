package com.gdcdgj.charging.service.provider.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gdcdgj.charging.api.entity.AssetsStations;

/**
 * <p>
 * 充电站 服务类
 * </p>
 *
 * @author tcl
 * @since 2020-04-20
 */
public interface AssetsStationsService extends IService<AssetsStations> {

}
