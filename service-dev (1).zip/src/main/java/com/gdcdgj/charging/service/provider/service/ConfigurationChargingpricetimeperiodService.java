package com.gdcdgj.charging.service.provider.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gdcdgj.charging.api.entity.ConfigurationChargingpricetimeperiod;

import java.util.List;

/**
 * <p>
 * 价格模板时间段 服务类
 * </p>
 *
 * @author tcl
 * @since 2020-04-20
 */
public interface ConfigurationChargingpricetimeperiodService extends IService<ConfigurationChargingpricetimeperiod> {

    List<ConfigurationChargingpricetimeperiod> findAllByPriceIdOrderByAsc(Integer priceId);
}