package com.gdcdgj.charging.service.provider.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gdcdgj.charging.api.entity.ConfigurationCoupon;

/**
 * <p>
 * 优惠券模板 服务类
 * </p>
 *
 * @author tcl
 * @since 2020-04-20
 */
public interface ConfigurationCouponService extends IService<ConfigurationCoupon> {

}
