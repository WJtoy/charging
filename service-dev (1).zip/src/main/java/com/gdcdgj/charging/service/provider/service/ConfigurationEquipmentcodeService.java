package com.gdcdgj.charging.service.provider.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gdcdgj.charging.api.entity.ConfigurationEquipmentcode;

/**
 * <p>
 * 充电桩告警消息配置 服务类
 * </p>
 *
 * @author tcl
 * @since 2020-04-20
 */
public interface ConfigurationEquipmentcodeService extends IService<ConfigurationEquipmentcode> {

}
