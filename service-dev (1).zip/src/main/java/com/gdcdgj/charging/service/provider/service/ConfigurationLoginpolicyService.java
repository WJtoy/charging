package com.gdcdgj.charging.service.provider.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gdcdgj.charging.api.entity.ConfigurationLoginpolicy;

/**
 * <p>
 * 登陆策略 服务类
 * </p>
 *
 * @author tcl
 * @since 2020-04-20
 */
public interface ConfigurationLoginpolicyService extends IService<ConfigurationLoginpolicy> {

}
