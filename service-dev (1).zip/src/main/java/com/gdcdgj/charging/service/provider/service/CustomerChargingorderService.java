package com.gdcdgj.charging.service.provider.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gdcdgj.charging.api.entity.CustomerChargingorder;

import java.util.Map;

/**
 * <p>
 * 会员账户充值记录 服务类
 * </p>
 *
 * @author tcl
 * @since 2020-04-20
 */
public interface CustomerChargingorderService extends IService<CustomerChargingorder> {
    /**
     * 根据会员id和状态列表 查找订单数
     *
     * @param
     * @return
     * @throws
     * @author Changliang Tao
     * @date 2020/4/22 16:45
     */

    Integer getOrderCountByMemberIdAndStatusList(Map<String, Object> paramMap);

    /**
     * 根据会员id将订单状态为prepare charging 改为start fail
     *
     * @param
     * @return
     * @throws
     * @author Changliang Tao
     * @date 2020/4/22 16:46
     */

    int updatePrepareChargingToStartFail(CustomerChargingorder chargingorder);

    /**
     * 根据会员id查找订单状态为prepare charging
     *
     * @param
     * @return
     * @throws
     * @author Changliang Tao
     * @date 2020/4/22 16:48
     */

    CustomerChargingorder getPrepareChargingOrder(Integer id);

}
