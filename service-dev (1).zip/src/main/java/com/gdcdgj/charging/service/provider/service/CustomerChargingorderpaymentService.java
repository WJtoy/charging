package com.gdcdgj.charging.service.provider.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gdcdgj.charging.api.entity.CustomerChargingorderpayment;

/**
 * <p>
 * 会员充电订单支付记录 服务类
 * </p>
 *
 * @author tcl
 * @since 2020-04-20
 */
public interface CustomerChargingorderpaymentService extends IService<CustomerChargingorderpayment> {

}
