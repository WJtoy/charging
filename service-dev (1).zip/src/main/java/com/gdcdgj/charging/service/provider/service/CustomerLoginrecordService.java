package com.gdcdgj.charging.service.provider.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gdcdgj.charging.api.entity.CustomerLoginrecord;

/**
 * <p>
 * 会员登陆记录 服务类
 * </p>
 *
 * @author tcl
 * @since 2020-04-20
 */
public interface CustomerLoginrecordService extends IService<CustomerLoginrecord> {

}
