package com.gdcdgj.charging.service.provider.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gdcdgj.charging.api.entity.CustomerRefundrecord;

/**
 * <p>
 * 会员账户充值记录 服务类
 * </p>
 *
 * @author tcl
 * @since 2020-04-20
 */
public interface CustomerRefundrecordService extends IService<CustomerRefundrecord> {

}
