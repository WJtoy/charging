package com.gdcdgj.charging.service.provider.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gdcdgj.charging.api.entity.DjangoMigrations;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author tcl
 * @since 2020-04-20
 */
public interface DjangoMigrationsService extends IService<DjangoMigrations> {

}
