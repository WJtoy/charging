package com.gdcdgj.charging.service.provider.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gdcdgj.charging.api.entity.EmployeeCompany;

/**
 * <p>
 * 运营商 服务类
 * </p>
 *
 * @author tcl
 * @since 2020-04-20
 */
public interface EmployeeCompanyService extends IService<EmployeeCompany> {

}
