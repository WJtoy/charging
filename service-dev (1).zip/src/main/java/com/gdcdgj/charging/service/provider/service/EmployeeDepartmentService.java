package com.gdcdgj.charging.service.provider.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gdcdgj.charging.api.entity.EmployeeDepartment;

/**
 * <p>
 * 部门 服务类
 * </p>
 *
 * @author tcl
 * @since 2020-04-20
 */
public interface EmployeeDepartmentService extends IService<EmployeeDepartment> {

}
