package com.gdcdgj.charging.service.provider.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gdcdgj.charging.api.entity.EmployeePermissions;

/**
 * <p>
 * 权限 服务类
 * </p>
 *
 * @author tcl
 * @since 2020-04-20
 */
public interface EmployeePermissionsService extends IService<EmployeePermissions> {

}
