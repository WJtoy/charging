package com.gdcdgj.charging.service.provider.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gdcdgj.charging.api.entity.EmployeeUser;

/**
 * <p>
 * 用户 服务类
 * </p>
 *
 * @author tcl
 * @since 2020-04-20
 */
public interface EmployeeUserService extends IService<EmployeeUser> {

}
