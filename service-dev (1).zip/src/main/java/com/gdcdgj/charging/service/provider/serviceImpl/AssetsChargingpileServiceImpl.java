package com.gdcdgj.charging.service.provider.serviceImpl;


import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gdcdgj.charging.api.entity.AssetsChargingpile;
import com.gdcdgj.charging.service.provider.mapper.AssetsChargingpileMapper;
import com.gdcdgj.charging.service.provider.service.AssetsChargingpileService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 充电桩 服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-04-22
 */
@Service
public class AssetsChargingpileServiceImpl extends ServiceImpl<AssetsChargingpileMapper, AssetsChargingpile> implements AssetsChargingpileService {
}
