package com.gdcdgj.charging.service.provider.serviceImpl;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gdcdgj.charging.api.entity.AssetsConnector;
import com.gdcdgj.charging.api.enums.ConnectorStatusEnum;
import com.gdcdgj.charging.service.provider.mapper.AssetsConnectorMapper;
import com.gdcdgj.charging.service.provider.service.AssetsConnectorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 充电枪 服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-04-20
 */
@Service
public class AssetsConnectorServiceImpl extends ServiceImpl<AssetsConnectorMapper, AssetsConnector> implements AssetsConnectorService {
    @Autowired
    AssetsConnectorMapper connectorMapper;

    @Override
    public AssetsConnector getConnectorByCode(String code) {
        QueryWrapper<AssetsConnector> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("code", code);
        return connectorMapper.selectOne(queryWrapper);
    }

    /**
     * 根据充电枪id, 将充电枪状态从空闲改为准备充电
     *
     * @param connector
     * @return
     * @throws
     * @author Changliang Tao
     * @date 2020/4/24 8:29
     */
    @Override
    public Integer updateConnectorStatusFromFreeToPrepareCharging(AssetsConnector connector) {
        UpdateWrapper<AssetsConnector> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("id", connector.getId())
                .eq("status", ConnectorStatusEnum.FREE.getValue());
        return connectorMapper.update(connector, updateWrapper);
    }

}
