package com.gdcdgj.charging.service.provider.serviceImpl;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gdcdgj.charging.api.entity.AssetsStationchargingprice;
import com.gdcdgj.charging.api.enums.PriceIsDefaultEunm;
import com.gdcdgj.charging.service.provider.mapper.AssetsStationchargingpriceMapper;
import com.gdcdgj.charging.service.provider.service.AssetsStationchargingpriceService;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 站点使用价格关系 服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-05-14
 */
@Service
public class AssetsStationchargingpriceServiceImpl extends ServiceImpl<AssetsStationchargingpriceMapper, AssetsStationchargingprice> implements AssetsStationchargingpriceService {


    /**
     *  获取活动模板绑定信息
     * @Author JianMei Chen
     * @Date  2020/5/18
     * @return
     **/
    @Override
    public List<AssetsStationchargingprice> findActivityByStationId(Integer stationId) {
        QueryWrapper<AssetsStationchargingprice> wrapper=new QueryWrapper<>();
        wrapper.eq("is_enabled", 1);
        wrapper.eq("is_default", PriceIsDefaultEunm.NO.getValue());
        wrapper.eq("station_id", stationId);
        List<AssetsStationchargingprice> list = this.list(wrapper);
        return list;
    }

    @Override
    public AssetsStationchargingprice findDefaultByStationId(Integer stationId) {
        QueryWrapper<AssetsStationchargingprice> defaultWrapper=new QueryWrapper<>();
        defaultWrapper.eq("station_id",stationId);
        defaultWrapper.eq("is_default",PriceIsDefaultEunm.DEFAULT.getValue());
        AssetsStationchargingprice one = this.getOne(defaultWrapper);
        return one;
    }
}
