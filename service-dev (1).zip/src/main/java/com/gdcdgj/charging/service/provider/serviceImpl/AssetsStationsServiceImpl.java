package com.gdcdgj.charging.service.provider.serviceImpl;


import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gdcdgj.charging.api.entity.AssetsStations;
import com.gdcdgj.charging.service.provider.mapper.AssetsStationsMapper;
import com.gdcdgj.charging.service.provider.service.AssetsStationsService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 充电站 服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-04-22
 */
@Service
public class AssetsStationsServiceImpl extends ServiceImpl<AssetsStationsMapper, AssetsStations> implements AssetsStationsService {

}
