package com.gdcdgj.charging.service.provider.serviceImpl;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gdcdgj.charging.api.entity.ConfigurationChargingpricetimeperiod;
import com.gdcdgj.charging.service.provider.mapper.ConfigurationChargingpricetimeperiodMapper;
import com.gdcdgj.charging.service.provider.service.ConfigurationChargingpricetimeperiodService;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 价格模板时间段 服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-05-14
 */
@Service
public class ConfigurationChargingpricetimeperiodServiceImpl extends ServiceImpl<ConfigurationChargingpricetimeperiodMapper, ConfigurationChargingpricetimeperiod> implements ConfigurationChargingpricetimeperiodService {

    @Override
    public List<ConfigurationChargingpricetimeperiod> findAllByPriceIdOrderByAsc(Integer priceId) {
        QueryWrapper<ConfigurationChargingpricetimeperiod> wrapper=new QueryWrapper<>();
        wrapper.eq("price_id",priceId);
        wrapper.orderByAsc("start");
        List<ConfigurationChargingpricetimeperiod> list = this.list(wrapper);
        return list;
    }
}
