package com.gdcdgj.charging.service.provider.serviceImpl;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gdcdgj.charging.api.entity.CustomerChargingorder;
import com.gdcdgj.charging.api.enums.ChargingOrderStatusEnum;
import com.gdcdgj.charging.service.provider.mapper.CustomerChargingorderMapper;
import com.gdcdgj.charging.service.provider.service.CustomerChargingorderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * <p>
 * 会员账户充值记录 服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-04-22
 */
@Service
public class CustomerChargingorderServiceImpl extends ServiceImpl<CustomerChargingorderMapper, CustomerChargingorder> implements CustomerChargingorderService {
    @Autowired
    CustomerChargingorderMapper chargingorderMapper;

    /**
     * 查询该会员是否有正在充电、结束充电、未付费的订单
     *
     * @param
     * @return
     * @throws
     * @author Changliang Tao
     * @date 2020/4/23 10:36
     */

    @Override
    public Integer getOrderCountByMemberIdAndStatusList(Map<String, Object> paramMap) {
        return chargingorderMapper.getOrderCountByMemberIdAndStatusList(paramMap);
    }

    /**
     * 根据订单id将订单状态为prepare charging 改为start fail
     *
     * @param
     * @return
     * @throws
     * @author Changliang Tao
     * @date 2020/4/22 16:46
     */
    @Override
    public int updatePrepareChargingToStartFail(CustomerChargingorder chargingorder) {
        UpdateWrapper<CustomerChargingorder> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("id", chargingorder.getId())
                .eq("charging_status", ChargingOrderStatusEnum.PREPARE_CHARGING.getValue());
        return chargingorderMapper.update(chargingorder, updateWrapper);
    }

    /**
     * 根据会员id查找订单状态为prepare charging
     *
     * @param id@return
     * @throws
     * @author Changliang Tao
     * @date 2020/4/22 16:48
     */
    @Override
    public CustomerChargingorder getPrepareChargingOrder(Integer id) {
        QueryWrapper<CustomerChargingorder> chargingorderQueryWrapper = new QueryWrapper<>();
        chargingorderQueryWrapper.eq("member_id", id).eq("charging_status", ChargingOrderStatusEnum.PREPARE_CHARGING.getValue());
        return chargingorderMapper.selectOne(chargingorderQueryWrapper);
    }
}
