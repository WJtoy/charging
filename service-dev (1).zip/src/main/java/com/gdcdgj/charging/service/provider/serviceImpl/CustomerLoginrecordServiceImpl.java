package com.gdcdgj.charging.service.provider.serviceImpl;


import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gdcdgj.charging.api.entity.CustomerLoginrecord;
import com.gdcdgj.charging.service.provider.mapper.CustomerLoginrecordMapper;
import com.gdcdgj.charging.service.provider.service.CustomerLoginrecordService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 会员登陆记录 服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-04-20
 */
@Service
public class CustomerLoginrecordServiceImpl extends ServiceImpl<CustomerLoginrecordMapper, CustomerLoginrecord> implements CustomerLoginrecordService {

}
