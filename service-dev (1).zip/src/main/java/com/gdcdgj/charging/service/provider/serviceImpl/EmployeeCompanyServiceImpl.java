package com.gdcdgj.charging.service.provider.serviceImpl;


import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gdcdgj.charging.api.entity.EmployeeCompany;
import com.gdcdgj.charging.service.provider.mapper.EmployeeCompanyMapper;
import com.gdcdgj.charging.service.provider.service.EmployeeCompanyService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 运营商 服务实现类
 * </p>
 *
 * @author tcl
 * @since 2020-04-23
 */
@Service
public class EmployeeCompanyServiceImpl extends ServiceImpl<EmployeeCompanyMapper, EmployeeCompany> implements EmployeeCompanyService {

}
