package com.gdcdgj.charging.service.provider.util;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * @author JianMei Chen
 * @date 2020/06/05/11:30
 */
@ConfigurationProperties(prefix = "com.gdcdgj.charging")
@Data
public class CustomProperties {

    private String imgUrlPrefix;
}
