package com.gdcdgj.charging.service.provider.util;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.gdcdgj.charging.api.entity.AssetsConnector;
import com.gdcdgj.charging.api.entity.CustomerChargingorder;
import com.gdcdgj.charging.api.entity.CustomerMember;
import com.gdcdgj.charging.api.localService.charging.ChargingService;
import com.gdcdgj.charging.api.localService.order.OrderService;
import com.gdcdgj.charging.api.util.RedisUtil;
import com.gdcdgj.charging.api.vo.CommonVo;
import com.gdcdgj.charging.service.provider.mapper.AssetsConnectorMapper;
import com.gdcdgj.charging.service.provider.mapper.CustomerChargingorderMapper;
import com.gdcdgj.charging.service.provider.mapper.CustomerMemberMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Map;

import static com.gdcdgj.charging.api.enums.ChargingOrderStatusEnum.CHARGING;

@Service
public class MainTest {

    @Resource
    RedisUtil redisUtil;
    @Resource
    CustomerChargingorderMapper customerChargingorderMapper;
    @Resource
    AssetsConnectorMapper assetsConnectorMapper;
    @Resource
    ChargingService chargingService;
    @Resource
    CustomerMemberMapper customerMemberMapper;
    @Resource
    OrderService orderService;

    public void mainStopChargingEndIng(CommonVo commonVoNew1){
        Map mapTokenNew = JSONObject.parseObject(JSONObject.toJSONString(commonVoNew1.getdata()), Map.class);
        CustomerMember customerMember = (CustomerMember) redisUtil.get(mapTokenNew.get("token").toString());
        QueryWrapper<CustomerChargingorder> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("member_id",customerMember.getId());
        queryWrapper.eq("charging_status" ,CHARGING.getValue());
        CustomerChargingorder customerChargingorder = customerChargingorderMapper.selectOne(queryWrapper);
        if(customerChargingorder != null) {
            QueryWrapper<AssetsConnector> assetsConnectorQueryWrapper = new QueryWrapper<>();
            assetsConnectorQueryWrapper.eq("id", customerChargingorder.getConnectorId());
            AssetsConnector assetsConnector = assetsConnectorMapper.selectOne(assetsConnectorQueryWrapper);
            chargingService.stop(mapTokenNew.get("token").toString(), assetsConnector.getCode(), 0);
        }
    }

    public void mainSetOrder(CommonVo commonVo){
        Map mapToken = JSONObject.parseObject(JSONObject.toJSONString(commonVo.getdata()), Map.class);

        CustomerMember member = (CustomerMember) redisUtil.get(mapToken.get("token").toString());
        // 根据会员id到数据库查询最新的会员信息
        member = customerMemberMapper.selectById(member.getId());
        QueryWrapper<CustomerChargingorder> orderWrapper = new QueryWrapper<>();
        orderWrapper.eq("member_id", member.getId());
        orderWrapper.eq("payment_status", 1);
        orderWrapper.eq("charging_status", 4);

        CustomerChargingorder customerChargingorders = customerChargingorderMapper.selectOne(orderWrapper);

        orderService.settleOrder(mapToken.get("token").toString(),customerChargingorders.getOrderNo());
    }




}
