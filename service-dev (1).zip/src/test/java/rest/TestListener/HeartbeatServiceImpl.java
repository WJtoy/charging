package rest.TestListener;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.gdcdgj.charging.api.entity.AssetsConnector;
import com.gdcdgj.charging.api.vo.srv2gw.HeartBeat;
import com.gdcdgj.charging.service.provider.mapper.AssetsConnectorMapper;
import com.gdcdgj.charging.service.provider.service.AssetsChargingpileService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.Set;


@Slf4j
@Service
public class HeartbeatServiceImpl {


    @Autowired
    AssetsChargingpileService chargingpileService;
    @Autowired
    AssetsConnectorMapper assetsConnectorMapper;

    public void handler(HeartBeat heartbeat) {
        //监听心跳数据 更改各枪状态
        if (heartbeat.getConnectorState() != null) {
            Map<Integer, Integer> connectorState = heartbeat.getConnectorState();
            Set<Integer> keys = connectorState.keySet();
            for (Integer key : keys) {
                QueryWrapper<AssetsConnector> assetsConnectors = new QueryWrapper<>();
                assetsConnectors.eq("code", heartbeat.getCode(heartbeat.getPileCode(), key));
                assetsConnectors.eq("serial_no", key);
                //根据桩编码和枪口号获取当前枪信息
                AssetsConnector assetsConnector = assetsConnectorMapper.selectOne(assetsConnectors);
                if (assetsConnector != null) {
                    assetsConnector.setConnectStatus(connectorState.get(key));
                    QueryWrapper<AssetsConnector> assetsUpdate = new QueryWrapper<>();
                    assetsUpdate.eq("id", assetsConnector.getId());
                    //根据心跳应答来的状态修改枪的connectorState
                    assetsConnectorMapper.update(assetsConnector, assetsUpdate);
                }
                log.info("根据心跳应答来的状态修改枪的connectorState处理完成！");
            }
        }
    }
}
