package rest.cd;

import com.gdcdgj.charging.api.entity.CustomerChargingorder;
import com.gdcdgj.charging.service.provider.ServiceApplication;
import com.gdcdgj.charging.service.provider.mapper.CustomerChargingorderMapper;
import lombok.extern.slf4j.Slf4j;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author JianMei Chen
 * @date 2020/06/05/16:57
 */
@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = ServiceApplication.class)
public class TimeTest {

    @Resource
    private CustomerChargingorderMapper customerChargingorderMapper;


    @Test
    public void test(){
        CustomerChargingorder customerChargingorderNews = new CustomerChargingorder();
        customerChargingorderNews.setId(547);
        customerChargingorderNews.setChargingStatus(5);
        customerChargingorderNews.setStopMethod(5);
        customerChargingorderNews.setBillTime(new Date());
        customerChargingorderNews.setStopTime(new Date());
        customerChargingorderMapper.updateById(customerChargingorderNews);
        CustomerChargingorder customerChargingorder = customerChargingorderMapper.selectById(547);
    }
}
