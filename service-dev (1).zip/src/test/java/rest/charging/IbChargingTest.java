package rest.charging;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.gdcdgj.charging.api.entity.AssetsConnector;
import com.gdcdgj.charging.api.entity.CustomerChargingorder;
import com.gdcdgj.charging.api.entity.CustomerMember;
import com.gdcdgj.charging.api.localService.charging.ChargingService;
import com.gdcdgj.charging.api.localService.login.LoginService;
import com.gdcdgj.charging.api.localService.order.OrderService;
import com.gdcdgj.charging.api.util.DateTimeUtil;
import com.gdcdgj.charging.api.util.RedisUtil;
import com.gdcdgj.charging.api.vo.CommonVo;
import com.gdcdgj.charging.api.vo.srv2gw.ModuleChargingInfo;
import com.gdcdgj.charging.api.vo.srv2gw.PileCtrl;
import com.gdcdgj.charging.api.vo.srv2gw.PileStartedRst;
import com.gdcdgj.charging.api.vo.srv2gw.StateInfo;
import com.gdcdgj.charging.service.provider.listener.*;
import com.gdcdgj.charging.service.provider.localServiceImpl.member.CustomerServiceImpl;
import com.gdcdgj.charging.service.provider.mapper.AssetsConnectorMapper;
import com.gdcdgj.charging.service.provider.mapper.CustomerChargingorderMapper;
import com.gdcdgj.charging.service.provider.mapper.CustomerChargingordertracksMapper;
import com.gdcdgj.charging.service.provider.mapper.CustomerMemberMapper;
import com.gdcdgj.charging.service.provider.util.MainTest;
import com.gdcdgj.charging.service.provider.util.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.util.*;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class IbChargingTest {

    @Resource
    LoginService loginService;

    @Resource
    StateInfoListener stateInfoListener;

    @Resource
    CustomerChargingordertracksMapper customerChargingordertracksMapper;

    @Resource
    CustomerChargingorderMapper customerChargingorderMapper;

    @Resource
    AssetsConnectorMapper assetsConnectorMapper;

    @Resource
    RedisUtil redisUtil;

    @Resource
    StartedListener startedListener;

    @Resource
    MoubleInfoListener moubleInfoListener;

    @Resource
    ChargingService chargingService;

    @Resource
    StopChargingListener stopChargingListener;

    @Resource
    OrderService orderService;

    @Resource
    CustomerMemberMapper customerMemberMapper;
    @Resource
    MainTest mainTest;

    @Resource
    CustomerServiceImpl customerServiceImpl;

    @Resource
    ChargeRecordInfoListener chargeRecordInfoListener;

    /**
     * 注册
     */

    /*private static String phone = StringUtils.getTel();
    private static String phoneNew = StringUtils.getTel();*/

      private static String phone = "13751302397";
      private static String phoneNew = "15300084688";
    @Test
    public void Aregister(){
        Map map = new HashMap();
        map.put("password",phone);
        map.put("register_address","441900");
        map.put("phone",phone);
        QueryWrapper<CustomerMember> customerMemberQueryWrapper = new QueryWrapper<CustomerMember>();
        customerMemberQueryWrapper.eq("phone" , phone);
        CustomerMember customerMember = customerMemberMapper.selectOne(customerMemberQueryWrapper);
        if (customerMember == null) {
            loginService.register(map);
        }

    }


    /**
     * 登陆
     */
    @Test
    public void Blogin(){
        Map map2 = new HashMap();
        map2.put("phone",phone);
        loginService.login(map2);
    }

    /**
     * /充值
     */
    @Test
    public void CrechargeNotify(){

        Map map = new HashMap();
        map.put("payMoney","10");
        map.put("payTime","2020-05-26 18:16:15");
        map.put("channelId","WX");
        map.put("upOrderId", UUID.randomUUID().toString());
        map.put("state","1");
        map.put("orderDesc","测试");
        map.put("attach","{'phone':"+phone+"}");
        customerServiceImpl.rechargeNotify(map);
    }

    /**
     * 状态包
     */
    @Test
    public void DstateInfo() {

        Map map = new HashMap();
        ModuleChargingInfo moduleChargingInfo = new ModuleChargingInfo();
        moduleChargingInfo.setProviderId(2);
        map.put((byte)1,(byte)0);
        map.put((byte)2,(byte)0);
        moduleChargingInfo.setStateMap(map);    //Map<枪的位置，状态>
        moduleChargingInfo.setPileCode("ib_tjyy2");
        map.clear();
        map.put((byte)1,(byte)0);
        map.put((byte)2,(byte)0);

        moduleChargingInfo.setConnectedStateMap(map);   //枪的连接状态 Map<枪的位置，连接状态>
        moubleInfoListener.assetsConnectorStatus(moduleChargingInfo);
        map.clear();
        StateInfo stateInfo = new StateInfo();
        AssetsConnector assetsConnector = null;
        QueryWrapper assetsWrapper = null;
        Iterator i = moduleChargingInfo.getStateMap().keySet().iterator();
        while (i.hasNext()) {
            String sno = i.next().toString();
            String code = moduleChargingInfo.getCode(moduleChargingInfo.getPileCode(),Integer.valueOf(sno));
            assetsWrapper = new QueryWrapper<>();
            assetsWrapper.eq("code", code);
            assetsWrapper.eq("serial_no", stateInfo.getConnectorNo());
            assetsConnector = assetsConnectorMapper.selectOne(assetsWrapper);
        }
    }

    /**
     *  启动
     */
    @Test
    public void EstartCharging () throws Exception{

        Map map = new HashMap();
        Map mapNew = new HashMap();
        ModuleChargingInfo moduleChargingInfo = new ModuleChargingInfo();
        moduleChargingInfo.setProviderId(2);
        mapNew.put((byte)1,(byte)0);
        mapNew.put((byte)2,(byte)0);
        moduleChargingInfo.setStateMap(mapNew);    //Map<枪的位置，状态>
        moduleChargingInfo.setPileCode("ib_tjyy2");

        map.put((byte)1,(byte)1);
        map.put((byte)2,(byte)1);
        moduleChargingInfo.setConnectedStateMap(map);   //枪的连接状态 Map<枪的位置，连接状态>

        moubleInfoListener.assetsConnectorStatus(moduleChargingInfo);
        Map map2 = new HashMap();
        map2.put("phone",phone);
        CommonVo commonVo = loginService.login(map2);

        Map mapToken = JSONObject.parseObject(JSONObject.toJSONString(commonVo.getdata()), Map.class);

        CommonVo commonVo1 = chargingService.start(mapToken.get("token").toString(),"ib_tjyy2_1", DateTimeUtil.getFormatDateTimeString(new Date()),0);

        log.info(commonVo1.getdata()+"c"+commonVo1.getstatus()+"1111"+commonVo1.getMsg());
        if (commonVo1.getdata()!=null) {
            QueryWrapper<CustomerChargingorder> orderWrapper = new QueryWrapper<>();
            orderWrapper.eq("order_no", commonVo1.getdata().toString());
            CustomerChargingorder customerChargingorder = customerChargingorderMapper.selectOne(orderWrapper);
        }
    }


    /***
     * 充电中
     */
    @Test
    public void Fcharging(){
        QueryWrapper<CustomerChargingorder> orderWrapperNew = new QueryWrapper<>();
        orderWrapperNew.eq("pile_provider_id",2);   //1科旺 2是宜步
        orderWrapperNew.eq("member_phone",phone);
        orderWrapperNew.orderByDesc("id");
        List<CustomerChargingorder> customerChargingorderNewList = customerChargingorderMapper.selectList(orderWrapperNew);
        PileStartedRst pileStartedRst = new PileStartedRst();
        CustomerChargingorder cco = customerChargingorderNewList.get(0);
        pileStartedRst.setMemberId(cco.getMemberId());
        pileStartedRst.setProviderId(2);
        String cnnrCode = cco.getConnectorCode();
        pileStartedRst.setPileCode(cnnrCode.substring(0,cnnrCode.length()-2));
        pileStartedRst.setConnectorNo(Byte.valueOf(cnnrCode.substring(cnnrCode.length()-1)));
        pileStartedRst.setResult(1);
        startedListener.onHandlerMessage(pileStartedRst);
        QueryWrapper<CustomerChargingorder> orderWrapperNews = new QueryWrapper<>();
        orderWrapperNews.eq("order_no",customerChargingorderNewList.get(0).getOrderNo());
        CustomerChargingorder customerChargingorderNews = customerChargingorderMapper.selectOne(orderWrapperNews);
        assert (customerChargingorderNews.getChargingStatus()==2);

    }
    /***
     * 轨迹充电中
     */
    @Test
    public void GonCharging(){
        QueryWrapper<CustomerChargingorder> orderWrapperNewS = new QueryWrapper<>();
        orderWrapperNewS.eq("pile_provider_id",2);   //1科旺 2是宜步
        orderWrapperNewS.orderByDesc("id");
        List<CustomerChargingorder> customerChargingorderList = customerChargingorderMapper.selectList(orderWrapperNewS);
        QueryWrapper<CustomerChargingorder> orderWrapperNewes = new QueryWrapper<>();
        orderWrapperNewes.eq("order_no",customerChargingorderList.get(0).getOrderNo());
        CustomerChargingorder customerChargingorderNew = customerChargingorderMapper.selectOne(orderWrapperNewes);
        String cnnrCodess = customerChargingorderNew.getConnectorCode();
        redisUtil.set(customerChargingorderNew.getConnectorCode().substring(0,cnnrCodess.length()-2)
                +"_"+customerChargingorderNew.getConnectorCode().substring(cnnrCodess.length()-1),customerChargingorderNew.getMemberId());

        ModuleChargingInfo moduleChargingInfo = new ModuleChargingInfo();
        moduleChargingInfo.setProviderId(2);        //2是宜步
        Map map1 = new HashMap();
        map1.put((byte)1,(byte)1);
        map1.put((byte)2,(byte)1);
        moduleChargingInfo.setStateMap(map1);    //Map<枪的位置，状态>
        moduleChargingInfo.setPileCode(customerChargingorderNew.getConnectorCode().substring(0,cnnrCodess.length()-2));

        Map map2 = new HashMap();
        map2.put((byte)1,(byte)1);
        map2.put((byte)2,(byte)1);
        moduleChargingInfo.setConnectedStateMap(map2);   //枪的连接状态 Map<枪的位置，连接状态>

        // moubleInfoListener.assetsConnectorStatus(moduleChargingInfo);
        Map map3 = new HashMap();
        map3.put((byte)1,(byte)11);
        map3.put((byte)2,(byte)22);
        moduleChargingInfo.setSocBeginMap(map3);    //充电枪位置N起始充电SOC   Map<充电枪位置, soc>
        Map map4 = new HashMap();
        map4.put((byte)1,11);
        map4.put((byte)2,22);
        moduleChargingInfo.setAhMap(map4);  	//位置N本次累计充电Ah  Map<充电枪位置, Ah>
        Map map5 = new HashMap();
        map5.put((byte)1,20d);
        map5.put((byte)2,10d);
        moduleChargingInfo.setTimeMap(map5);    //位置N本次累计充电时间  Map<充电枪位置, 时间> *60
        Map map6 = new HashMap();
        map6.put((byte)1,2200.0);
        map6.put((byte)2,3800.0);
        moduleChargingInfo.setVoltageMap(map6); //位置N电压V  Map<充电枪位置, V> *0.1
        Map map7 = new HashMap();
        map7.put((byte)1,554526.0);
        map7.put((byte)2,336250.0);
        moduleChargingInfo.setKwhMap(map7); //位置N电表度数kwh  Map<充电枪位置, kwh> *0.01
        Map map8 = new HashMap();
        map8.put((byte)1,4200.0);
        map8.put((byte)2,3500.0);

        moduleChargingInfo.setKwhTotalMap(map8);    //位置N本次累计充电kwh  Map<充电枪位置, kwh>10 *0.01

        Map map9 = new HashMap();
        map9.put((byte)1,150.0);
        map9.put((byte)2,100.0);
        moduleChargingInfo.setCurrentMap(map9);     //位置N电流A  Map<充电枪位置, A>  0.1
        Map map10 = new HashMap();
        map10.put((byte)1,(byte)70);
        map10.put((byte)2,(byte)80);
        moduleChargingInfo.setSocNowMap(map10); //充电枪位置N当前SOC   Map<充电枪位置, soc>
        Map map11 = new HashMap();
        map11.put((byte)1,5d);
        map11.put((byte)2,10d);
        moduleChargingInfo.setRemainTimeMap(map11); //预估充满时间(分钟)  Map<充电枪位置, 分钟> * 60
        moubleInfoListener.onHandlerMessage(moduleChargingInfo);
    }
    /**
     *   充电中 -> 充电结束中
     */
    @Test
    public void HstopChargingEndIng(){
        Map mapNew1 = new HashMap();
        mapNew1.put("phone",phone);
        CommonVo commonVoNew1 = loginService.login(mapNew1);
        mainTest.mainStopChargingEndIng(commonVoNew1);
    }

    /***
     * 充电结束
     */
    @Test
    public void IendCharging(){
            PileCtrl pileCtrlNew = new PileCtrl();
            pileCtrlNew.setResultCode(1);                  //宜步
            pileCtrlNew.setPileCode("ib_tjyy2");
            pileCtrlNew.setProviderId(2);
            pileCtrlNew.setConnectorNo((byte)1);
            pileCtrlNew.setVinCar("654321");
            stopChargingListener.onHandlerMessage(pileCtrlNew);
        }


    /***
     * 扣费  充电结束 -> 已支付
     */
    @Test
    public void JsetOrder(){
        Map map2 = new HashMap();
        map2.put("phone",phone);
        CommonVo commonVo = loginService.login(map2);
        mainTest.mainSetOrder( commonVo);
    }

}
