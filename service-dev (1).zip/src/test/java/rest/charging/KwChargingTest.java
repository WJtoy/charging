package rest.charging;


import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.gdcdgj.charging.api.entity.AssetsConnector;
import com.gdcdgj.charging.api.entity.CustomerChargingorder;
import com.gdcdgj.charging.api.entity.CustomerMember;
import com.gdcdgj.charging.api.localService.charging.ChargingService;
import com.gdcdgj.charging.api.localService.login.LoginService;
import com.gdcdgj.charging.api.localService.order.OrderService;
import com.gdcdgj.charging.api.util.DateTimeUtil;
import com.gdcdgj.charging.api.util.RedisUtil;
import com.gdcdgj.charging.api.vo.CommonVo;
import com.gdcdgj.charging.api.vo.srv2gw.ModuleChargingInfo;
import com.gdcdgj.charging.api.vo.srv2gw.PileCtrl;
import com.gdcdgj.charging.api.vo.srv2gw.PileStartedRst;
import com.gdcdgj.charging.api.vo.srv2gw.StateInfo;
import com.gdcdgj.charging.service.provider.listener.*;
import com.gdcdgj.charging.service.provider.localServiceImpl.member.CustomerServiceImpl;
import com.gdcdgj.charging.service.provider.mapper.AssetsConnectorMapper;
import com.gdcdgj.charging.service.provider.mapper.CustomerChargingorderMapper;
import com.gdcdgj.charging.service.provider.mapper.CustomerChargingordertracksMapper;
import com.gdcdgj.charging.service.provider.mapper.CustomerMemberMapper;
import com.gdcdgj.charging.service.provider.util.MainTest;
import com.gdcdgj.charging.service.provider.util.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.util.*;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class KwChargingTest {

    @Resource
    LoginService loginService;

    @Resource
    StateInfoListener stateInfoListener;

    @Resource
    CustomerChargingordertracksMapper customerChargingordertracksMapper;

    @Resource
    CustomerChargingorderMapper customerChargingorderMapper;

    @Resource
    AssetsConnectorMapper assetsConnectorMapper;

    @Resource
    RedisUtil redisUtil;

    @Resource
    StartedListener startedListener;

    @Resource
    MoubleInfoListener moubleInfoListener;

    @Resource
    ChargingService chargingService;

    @Resource
    StopChargingListener stopChargingListener;

    @Resource
    OrderService orderService;

    @Resource
    CustomerMemberMapper customerMemberMapper;
    @Resource
    MainTest mainTest;

    @Resource
    CustomerServiceImpl customerServiceImpl;

    @Resource
    ChargeRecordInfoListener chargeRecordInfoListener;

    private static String phone = "13751302397";
    private static String phoneNew = "13700005555";

    @Test
    public void Aregister(){
        Map mapNew = new HashMap();
        mapNew.put("password",phoneNew);
        mapNew.put("register_address","441900");
        mapNew.put("phone",phoneNew);
        QueryWrapper<CustomerMember> customerMemberQueryWrapperNew = new QueryWrapper<CustomerMember>();
        customerMemberQueryWrapperNew.eq("phone" , phoneNew);
        CustomerMember customerMemberNew = customerMemberMapper.selectOne(customerMemberQueryWrapperNew);
        if (customerMemberNew == null) {
            loginService.register(mapNew);
        }
    }
    /**
     * 登陆
     */
    @Test
    public void Blogin(){
        Map map2 = new HashMap();
        map2.put("phone",phoneNew);
        loginService.login(map2);
    }

    /**
     * /充值
     */
    @Test
    public void CrechargeNotify(){

        Map map = new HashMap();
        map.put("payMoney","10");
        map.put("payTime","2020-05-26 18:16:15");
        map.put("channelId","WX");
        map.put("upOrderId", UUID.randomUUID().toString());
        map.put("state","1");
        map.put("orderDesc","测试");
        map.put("attach","{'phone':"+phoneNew+"}");
        customerServiceImpl.rechargeNotify(map);
    }

    /**
     * 状态包
     */
    @Test
    public void DstateInfo() {

        StateInfo stateInfo = new StateInfo();
        stateInfo.setProviderId(1); //1科旺
        stateInfo.setPileCode("44192019122601002");
        stateInfo.setWorkState((byte) 0);    //工作状态
        stateInfo.setCarConnectState((byte) 2);  //连接状态
        stateInfo.setConnectorNo((byte) 2);  //枪口号
        stateInfoListener.onHandlerMessage(stateInfo);
        String code = stateInfo.getCode(stateInfo.getPileCode(), (int) stateInfo.getConnectorNo());
        QueryWrapper<AssetsConnector> assetsWrapper = new QueryWrapper<>();
        assetsWrapper.eq("code", code);
        assetsWrapper.eq("serial_no", stateInfo.getConnectorNo());
        AssetsConnector assetsConnector = assetsConnectorMapper.selectOne(assetsWrapper);
        assert (assetsConnector.getStatus() == 0);
        assert (assetsConnector.getConnectStatus() == 1);
    }

    /***
     * 发起充电
     */
    @Test
    public void EstartCharging() throws Exception{

        Map mapNew1 = new HashMap();
        mapNew1.put("phone",phoneNew);
        CommonVo commonVoNew1 = loginService.login(mapNew1);
        Map mapTokenNew = JSONObject.parseObject(JSONObject.toJSONString(commonVoNew1.getdata()), Map.class);
        CommonVo commonVoNew2 = chargingService
                .start(mapTokenNew.get("token").toString(),"cdgj_A", DateTimeUtil.getFormatDateTimeString(new Date()),0);

        log.info(commonVoNew2.getdata()+"1123"+commonVoNew2.getMsg()+"--->");
        QueryWrapper<CustomerChargingorder> orderWrapperNew = new QueryWrapper<>();
        orderWrapperNew.eq("order_no",commonVoNew2.getdata().toString().split("=")[1].replace("}","") );
        CustomerChargingorder customerChargingorderNew = customerChargingorderMapper.selectOne(orderWrapperNew);
        assert (commonVoNew2.getdata() != null);
        assert (customerChargingorderNew.getChargingStatus() == 1);
        assert (customerChargingorderNew.getPaymentStatus() == 1);
    }

    /***
     *  响应充电中
     */
    @Test
    public void onCharging(){
        QueryWrapper<CustomerChargingorder> orderWrapperNewS = new QueryWrapper<>();
        orderWrapperNewS.eq("pile_provider_id",1);   //1科旺 2是宜步
        orderWrapperNewS.eq("member_phone",phoneNew);
        orderWrapperNewS.orderByDesc("id");
        List<CustomerChargingorder> customerChargingorderNewListS = customerChargingorderMapper.selectList(orderWrapperNewS);
        PileStartedRst pileStartedRstNew = new PileStartedRst();
        CustomerChargingorder ccos = customerChargingorderNewListS.get(0);
        pileStartedRstNew.setMemberId(ccos.getMemberId());
        String cnnrCodes=ccos.getConnectorCode();
        pileStartedRstNew.setPileCode(cnnrCodes.substring(0,cnnrCodes.length()-2));
        pileStartedRstNew.setConnectorNo(Byte.valueOf(cnnrCodes.substring(cnnrCodes.length()-1)));
        pileStartedRstNew.setResult(1);
        pileStartedRstNew.setProviderId(1);
        startedListener.onHandlerMessage(pileStartedRstNew);
        QueryWrapper<CustomerChargingorder> orderWrapper = new QueryWrapper<>();
        orderWrapper.eq("order_no",customerChargingorderNewListS.get(0).getOrderNo());
        CustomerChargingorder customerChargingorder = customerChargingorderMapper.selectOne(orderWrapper);
        assert (customerChargingorder.getChargingStatus()==2);
    }

    /**
     * 轨迹充电中
     */
    @Test
    public void GonCharging(){
        QueryWrapper<CustomerChargingorder> orderWrapper = new QueryWrapper<>();
        orderWrapper.eq("pile_provider_id",1);   //1科旺 2是宜步
        orderWrapper.orderByDesc("id");
        List<CustomerChargingorder> customerChargingorderNewList = customerChargingorderMapper.selectList(orderWrapper);
        QueryWrapper<CustomerChargingorder> orderWrapperNew = new QueryWrapper<>();
        orderWrapperNew.eq("order_no",customerChargingorderNewList.get(0).getOrderNo());
        CustomerChargingorder customerChargingorder = customerChargingorderMapper.selectOne(orderWrapperNew);
        StateInfo stateInfo = new StateInfo();
        String cnnrCodes = customerChargingorder.getConnectorCode();
        redisUtil.set(customerChargingorder.getConnectorCode().substring(0,cnnrCodes.length()-2)
                +"0"+customerChargingorder.getConnectorCode().substring(cnnrCodes.length()-1),customerChargingorder.getMemberId());
        stateInfo.setPileCode(cnnrCodes.substring(0,cnnrCodes.length()-2));
        stateInfo.setProviderId(1);
        stateInfo.setWorkState((byte) 2);
        stateInfo.setChargeTime(1000);//充电时长 秒
        stateInfo.setChargePowerCount(10.0); //累计充电电量 * 0.01
        stateInfo.setCurrentSOC((byte) 97); //电池电量
        stateInfo.setCurrentQuliety(366.0);//电表读数*0.01
        stateInfo.setDCChargeElectric(10.6);//电流
        stateInfo.setDCChargePressure(380.0);//电压
        stateInfo.setResidueChargeTime(6); //剩余充电时间 分钟 *60
        stateInfo.setChargePower(1.1); //当前充电功率  *0.1
        stateInfo.setConnectorNo((byte) 2);
        stateInfo.setConnectorCount((byte) 2);
        stateInfoListener.setNewCustomerChargingordertracks(stateInfo);

    }

    /**
     *   充电中 -> 充电结束中
     */
    @Test
    public void HstopChargingEndIng(){
        Map mapNew1 = new HashMap();
        mapNew1.put("phone",phoneNew);
        CommonVo commonVoNew1 = loginService.login(mapNew1);
        mainTest.mainStopChargingEndIng(commonVoNew1);
    }

    /**
     * 桩响应指令  充电结束中 -> 充电结束
     */
    @Test
    public void IstopChargingEnd(){
        PileCtrl pileCtrl = new PileCtrl();
        pileCtrl.setResultCode(1);                  //科旺
        pileCtrl.setPileCode("44192019122601002");
        pileCtrl.setProviderId(1);
        pileCtrl.setConnectorNo((byte)2);
        pileCtrl.setVinCar("123456");
        stopChargingListener.onHandlerMessage(pileCtrl);
    }


    /***
     * 扣费  充电结束 -> 已支付
     */
    @Test
    public void JsetOrder(){
        Map mapNew = new HashMap();
        mapNew.put("phone",phoneNew);
        CommonVo commonVoNew = loginService.login(mapNew);
        mainTest.mainSetOrder(commonVoNew);
    }


}
