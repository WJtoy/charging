package rest.charging;


import com.gdcdgj.charging.api.util.RedisUtil;
import com.gdcdgj.charging.api.vo.srv2gw.ChargeRecordInfo;
import com.gdcdgj.charging.api.vo.srv2gw.ModuleChargingInfo;
import com.gdcdgj.charging.service.provider.listener.ChargeRecordInfoListener;
import com.gdcdgj.charging.service.provider.listener.MoubleInfoListener;
import lombok.extern.slf4j.Slf4j;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class PartTest {

        @Resource
        ChargeRecordInfoListener chargeRecordInfoListener;

        @Resource
        MoubleInfoListener moubleInfoListener;

        @Autowired
        RedisUtil redisUtil;

    /**
     *  最终充电记录
     */
    @Test
    public void  finalCharging(){
        ChargeRecordInfo chargeRecordInfo = new ChargeRecordInfo();
        chargeRecordInfo.setPileCode("ib_tjyy2");   //桩
        chargeRecordInfo.setConnectorNo(1);     //枪口
        chargeRecordInfo.setProviderId(2);  //设备商
        chargeRecordInfo.setKwh(12);    //充电量
        chargeRecordInfo.setChargeTimeLen(11);    //充电时长
        chargeRecordInfo.setStartSOC(78);
        chargeRecordInfo.setStopSOC(90);
        chargeRecordInfo.setCarVIN("000000000");   //vin码
        String code = chargeRecordInfo.getCode(chargeRecordInfo.getPileCode(), (int) chargeRecordInfo.getConnectorNo());
        redisUtil.set(code,31);     //用户id
        chargeRecordInfoListener.onHandlerMessage(chargeRecordInfo);
    }

    @Test
    public void test(){
        ModuleChargingInfo moduleChargingInfo = new ModuleChargingInfo();
        moduleChargingInfo.setProviderId(2);        //2是宜步
        Map map1 = new HashMap();
        map1.put((byte)1,(byte)0);
        moduleChargingInfo.setStateMap(map1);    //Map<枪的位置，状态>
        Map map2 = new HashMap();
        map2.put((byte)1,(byte)0);
        moduleChargingInfo.setConnectedStateMap(map2);   //枪的连接状态 Map<枪的位置，连接状态>
        Map map3 = new HashMap();
        map3.put((byte)1,(byte)11);
        moduleChargingInfo.setSocBeginMap(map3);    //充电枪位置N起始充电SOC   Map<充电枪位置, soc>
        Map map4 = new HashMap();
        map4.put((byte)1,11);
        moduleChargingInfo.setAhMap(map4);  	//位置N本次累计充电Ah  Map<充电枪位置, Ah>
        Map map5 = new HashMap();
        map5.put((byte)1,20d);
        moduleChargingInfo.setTimeMap(map5);    //位置N本次累计充电时间  Map<充电枪位置, 时间> *60
        Map map6 = new HashMap();
        map6.put((byte)1,2200.0);
        moduleChargingInfo.setVoltageMap(map6); //位置N电压V  Map<充电枪位置, V> *0.1
        Map map7 = new HashMap();
        map7.put((byte)1,554526.0);
        moduleChargingInfo.setKwhMap(map7); //位置N电表度数kwh  Map<充电枪位置, kwh> *0.01
        Map map8 = new HashMap();
        map8.put((byte)1,4200.0);
        moduleChargingInfo.setKwhTotalMap(map8);    //位置N本次累计充电kwh  Map<充电枪位置, kwh>10 *0.01
        Map map9 = new HashMap();
        map9.put((byte)1,150.0);
        moduleChargingInfo.setCurrentMap(map9);     //位置N电流A  Map<充电枪位置, A>  0.1
        Map map10 = new HashMap();
        map10.put((byte)1,(byte)70);
        moduleChargingInfo.setSocNowMap(map10); //充电枪位置N当前SOC   Map<充电枪位置, soc>
        Map map11 = new HashMap();
        map11.put((byte)1,5d);
        moduleChargingInfo.setRemainTimeMap(map11); //预估充满时间(分钟)  Map<充电枪位置, 分钟> * 60
        moduleChargingInfo.setPileCode("ib_tjyy2");
        moduleChargingInfo.setConnectorNo(1);
        String code = moduleChargingInfo.getCode(moduleChargingInfo.getPileCode(),moduleChargingInfo.getConnectorNo());
        redisUtil.set(code,31);
        moubleInfoListener.onHandlerMessage(moduleChargingInfo);
    }

}
