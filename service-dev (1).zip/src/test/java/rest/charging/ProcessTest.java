package rest.charging;

import com.gdcdgj.charging.api.localService.login.LoginService;
import com.gdcdgj.charging.api.vo.CommonVo;
import com.gdcdgj.charging.service.provider.ServiceApplication;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.Reference;
import org.apache.dubbo.config.spring.context.annotation.DubboComponentScan;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.Map;

/**
 * @author JianMei Chen
 * @date 2020/05/29/14:06
 */
@SpringBootTest(classes = ProcessTest.class)
@EnableAutoConfiguration
@RunWith(SpringRunner.class)
@Slf4j
@DubboComponentScan("com.gdcdgj.charging.service.provider.serviceImpl")
public class ProcessTest {

    @Reference
    private LoginService loginService;

    @Test
    public void login(){
        Map<String,String> map=new HashMap<>();
        map.put("phone","13489890909");
        map.put("code","");
//        CommonVo vo = loginService.login(map);
        System.err.println("登录");
    }
}
