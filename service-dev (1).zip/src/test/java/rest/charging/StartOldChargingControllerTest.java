package rest.charging;


import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.gdcdgj.charging.api.entity.AssetsConnector;
import com.gdcdgj.charging.api.entity.CustomerChargingorder;
import com.gdcdgj.charging.api.entity.CustomerMember;
import com.gdcdgj.charging.api.localService.charging.ChargingService;
import com.gdcdgj.charging.api.localService.login.LoginService;
import com.gdcdgj.charging.api.localService.order.OrderService;
import com.gdcdgj.charging.api.util.DateTimeUtil;
import com.gdcdgj.charging.api.util.RedisUtil;
import com.gdcdgj.charging.api.vo.CommonVo;
import com.gdcdgj.charging.api.vo.srv2gw.*;
import com.gdcdgj.charging.service.provider.listener.*;
import com.gdcdgj.charging.service.provider.localServiceImpl.member.CustomerServiceImpl;
import com.gdcdgj.charging.service.provider.mapper.AssetsConnectorMapper;
import com.gdcdgj.charging.service.provider.mapper.CustomerChargingorderMapper;
import com.gdcdgj.charging.service.provider.mapper.CustomerChargingordertracksMapper;
import com.gdcdgj.charging.service.provider.mapper.CustomerMemberMapper;
import com.gdcdgj.charging.service.provider.util.MainTest;
import com.gdcdgj.charging.service.provider.util.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.util.*;


/**
 * 扫码充电测试
 *
 * @author Changliang Tao
 * @date 2020/4/24 9:03
 * @since JDK 1.8
 */

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest
@SpringBootApplication(scanBasePackages = "com.gdcdgj.charging.service.provider")
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class StartOldChargingControllerTest {


    @Resource
    LoginService loginService;

    @Resource
    StateInfoListener stateInfoListener;

    @Resource
    CustomerChargingordertracksMapper customerChargingordertracksMapper;

    @Resource
    CustomerChargingorderMapper customerChargingorderMapper;

    @Resource
    AssetsConnectorMapper assetsConnectorMapper;

    @Resource
    RedisUtil redisUtil;

    @Resource
    StartedListener startedListener;

    @Resource
    MoubleInfoListener moubleInfoListener;

    @Resource
    ChargingService chargingService;

    @Resource
    StopChargingListener stopChargingListener;

    @Resource
    OrderService orderService;

    @Resource
    CustomerMemberMapper customerMemberMapper;
    @Resource
    MainTest mainTest;

    @Resource
    CustomerServiceImpl customerServiceImpl;

    @Resource
    ChargeRecordInfoListener chargeRecordInfoListener;


    /*//测试心跳
    @Test
    public void heartbeat() throws Exception{
        HeartBeat heartBeat = new HeartBeat();
        Map map = new HashMap();
        map.put(1,1);
        heartBeat.setConnectorState(map);
        heartBeat.setPileCode("ib_tjyy1");
        heartbeatServiceImpl.handler(heartBeat);
    }

    //测试签到
    @Test
    public void signIn() throws Exception{
        SignIn signIn = new SignIn();
        signIn.setStartStopSingal((byte)1);
        //signIn.setPileCode("ib_tjyy2");
        signIn.setPileCode("44192019122601002");
        signInService.handlerSignIn(signIn);
        signIn.setPileCode("ib_tjyy2");
        //signIn.setPileCode("44192019122601002");
        signInService.handlerSignIn(signIn);

    }
    @Test
    public void unSignIn() throws Exception{
        SignIn signIn = new SignIn();
        signIn.setStartStopSingal((byte)0);
        //signIn.setPileCode("ib_tjyy2");
        signIn.setPileCode("44192019122601002");
        signInService.handlerSignIn(signIn);
        signIn.setPileCode("ib_tjyy2");
        //signIn.setPileCode("44192019122601002");
        signInService.handlerSignIn(signIn);

    }*/

    /**
     * 注册
     */

    private static String phone = StringUtils.getTel();
    private static String phoneNew = StringUtils.getTel();

  /*  private static String phone = "15606781877";
    private static String phoneNew = "15300084688";*/
    @Test
    public void Aregister(){
        Map map = new HashMap();
        map.put("password",phone);
        map.put("register_address","441900");
        map.put("phone",phone);
        QueryWrapper<CustomerMember> customerMemberQueryWrapper = new QueryWrapper<CustomerMember>();
        customerMemberQueryWrapper.eq("phone" , phone);
        CustomerMember customerMember = customerMemberMapper.selectOne(customerMemberQueryWrapper);
        if (customerMember == null) {
            loginService.register(map);
        }

        Map mapNew = new HashMap();
        mapNew.put("password",phoneNew);
        mapNew.put("register_address","441900");
        mapNew.put("phone",phoneNew);
        QueryWrapper<CustomerMember> customerMemberQueryWrapperNew = new QueryWrapper<CustomerMember>();
        customerMemberQueryWrapperNew.eq("phone" , phoneNew);
        CustomerMember customerMemberNew = customerMemberMapper.selectOne(customerMemberQueryWrapperNew);
        if (customerMemberNew == null) {
            loginService.register(mapNew);
        }
    }


    /**
     * 登陆
     */
    @Test
    public void Blogin(){
        Map map2 = new HashMap();
        map2.put("phone",phone);
        loginService.login(map2);
        Map mapNew = new HashMap();
        mapNew.put("phone",phoneNew);
        loginService.login(mapNew);
    }

    /**
     * /充值
     */
   @Test
   public void CrechargeNotify(){

       Map map = new HashMap();
       map.put("payMoney","10");
       map.put("payTime","2020-05-26 18:16:15");
       map.put("channelId","WX");
       map.put("upOrderId", UUID.randomUUID().toString());
       map.put("state","1");
       map.put("orderDesc","测试");
       map.put("attach","{'phone':"+phone+"}");
       customerServiceImpl.rechargeNotify(map);

       Map mapNew = new HashMap();
       mapNew.put("payMoney","10");
       mapNew.put("payTime","2020-05-26 18:16:15");
       mapNew.put("channelId","WX");
       mapNew.put("upOrderId", UUID.randomUUID().toString());
       mapNew.put("state","1");
       mapNew.put("orderDesc","测试");
       mapNew.put("attach","{'phone':"+phoneNew+"}");
       customerServiceImpl.rechargeNotify(mapNew);


   }


    @Test
    public void DstateInfo(){
            StateInfo stateInfo = new StateInfo();
            stateInfo.setProviderId(1); //1科旺
            stateInfo.setPileCode("44192019122601002");
            stateInfo.setWorkState((byte)0);    //工作状态
            stateInfo.setCarConnectState((byte)2);  //连接状态
            stateInfo.setConnectorNo((byte)2);  //枪口号
            stateInfoListener.onHandlerMessage(stateInfo);

            String code = stateInfo.getCode(stateInfo.getPileCode(),(int) stateInfo.getConnectorNo());
            QueryWrapper<AssetsConnector> assetsWrapper = new QueryWrapper<>();
            assetsWrapper.eq("code", code);
            assetsWrapper.eq("serial_no", stateInfo.getConnectorNo());
            AssetsConnector assetsConnector = assetsConnectorMapper.selectOne(assetsWrapper);
            assert(assetsConnector.getStatus()==0);
            assert(assetsConnector.getConnectStatus()==1);

            StateInfo stateInfo1 = new StateInfo();
            stateInfo1.setProviderId(1); //1科旺
            stateInfo1.setPileCode("44192019122601002");
            stateInfo1.setWorkState((byte)1);    //工作状态
            stateInfo1.setCarConnectState((byte)2);  //连接状态
            stateInfo1.setConnectorNo((byte)2);  //枪口号
            stateInfoListener.onHandlerMessage(stateInfo1);
            String code1 = stateInfo1.getCode(stateInfo1.getPileCode(),(int) stateInfo1.getConnectorNo());
            QueryWrapper<AssetsConnector> assetsWrapper1 = new QueryWrapper<>();
            assetsWrapper1.eq("code", code1);
            assetsWrapper1.eq("serial_no", stateInfo1.getConnectorNo());
            AssetsConnector assetsConnector1 = assetsConnectorMapper.selectOne(assetsWrapper);
            assert(assetsConnector1.getStatus()==0);
            assert(assetsConnector1.getConnectStatus()==1);

        StateInfo stateInfo2 = new StateInfo();
        stateInfo2.setProviderId(1); //1科旺
        stateInfo2.setPileCode("44192019122601002");
        stateInfo2.setWorkState((byte)4);    //工作状态
        stateInfo2.setCarConnectState((byte)2);  //连接状态
        stateInfo2.setConnectorNo((byte)2);  //枪口号
        stateInfoListener.onHandlerMessage(stateInfo2);
        String code2 = stateInfo2.getCode(stateInfo2.getPileCode(),(int) stateInfo2.getConnectorNo());
        QueryWrapper<AssetsConnector> assetsWrapper2 = new QueryWrapper<>();
        assetsWrapper2.eq("code", code);
        assetsWrapper2.eq("serial_no", stateInfo2.getConnectorNo());
        AssetsConnector assetsConnector2 = assetsConnectorMapper.selectOne(assetsWrapper2);
        assert(assetsConnector2.getStatus()==0);
        assert(assetsConnector2.getConnectStatus()==1);


        StateInfo stateInfo3 = new StateInfo();
        stateInfo3.setProviderId(1); //1科旺
        stateInfo3.setPileCode("44192019122601002");
        stateInfo3.setWorkState((byte)5);    //工作状态
        stateInfo3.setCarConnectState((byte)2);  //连接状态
        stateInfo3.setConnectorNo((byte)2);  //枪口号
        stateInfoListener.onHandlerMessage(stateInfo3);

        String code3 = stateInfo3.getCode(stateInfo3.getPileCode(),(int) stateInfo3.getConnectorNo());
        QueryWrapper<AssetsConnector> assetsWrapper3 = new QueryWrapper<>();
        assetsWrapper3.eq("code", code3);
        assetsWrapper3.eq("serial_no", stateInfo3.getConnectorNo());
        AssetsConnector assetsConnector3 = assetsConnectorMapper.selectOne(assetsWrapper);
        assert(assetsConnector3.getStatus()==0);
        assert(assetsConnector3.getConnectStatus()==1);


        StateInfo stateInfo4 = new StateInfo();
        stateInfo4.setProviderId(1); //1科旺
        stateInfo4.setPileCode("44192019122601002");
        stateInfo4.setWorkState((byte)0);    //工作状态
        stateInfo4.setCarConnectState((byte)0);  //连接状态
        stateInfo4.setConnectorNo((byte)2);  //枪口号
        stateInfoListener.onHandlerMessage(stateInfo4);

        String code4 = stateInfo4.getCode(stateInfo4.getPileCode(),(int) stateInfo4.getConnectorNo());
        QueryWrapper<AssetsConnector> assetsWrapper4 = new QueryWrapper<>();
        assetsWrapper4.eq("code", code4);
        assetsWrapper4.eq("serial_no", stateInfo.getConnectorNo());
        AssetsConnector assetsConnector4 = assetsConnectorMapper.selectOne(assetsWrapper);
        assert(assetsConnector4.getStatus()==0);
        assert(assetsConnector4.getConnectStatus()==0);



        StateInfo stateInfo5 = new StateInfo();
        stateInfo5.setProviderId(1); //1科旺
        stateInfo5.setPileCode("44192019122601002");
        stateInfo5.setWorkState((byte)1);    //工作状态
        stateInfo5.setCarConnectState((byte)0);  //连接状态
        stateInfo5.setConnectorNo((byte)2);  //枪口号
        stateInfoListener.onHandlerMessage(stateInfo5);
        String code5 = stateInfo5.getCode(stateInfo5.getPileCode(),(int) stateInfo5.getConnectorNo());
        QueryWrapper<AssetsConnector> assetsWrapper5 = new QueryWrapper<>();
        assetsWrapper5.eq("code", code5);
        assetsWrapper5.eq("serial_no", stateInfo5.getConnectorNo());
        AssetsConnector assetsConnector5 = assetsConnectorMapper.selectOne(assetsWrapper5);
        assert(assetsConnector5.getStatus()==0);
        assert(assetsConnector5.getConnectStatus()==0);



        StateInfo stateInfo6 = new StateInfo();
        stateInfo6.setProviderId(1); //1科旺
        stateInfo6.setPileCode("44192019122601002");
        stateInfo6.setWorkState((byte)4);    //工作状态
        stateInfo6.setCarConnectState((byte)0);  //连接状态
        stateInfo6.setConnectorNo((byte)2);  //枪口号
        stateInfoListener.onHandlerMessage(stateInfo6);
        String code6 = stateInfo6.getCode(stateInfo6.getPileCode(),(int) stateInfo6.getConnectorNo());
        QueryWrapper<AssetsConnector> assetsWrapper6 = new QueryWrapper<>();
        assetsWrapper6.eq("code", code6);
        assetsWrapper6.eq("serial_no", stateInfo6.getConnectorNo());
        AssetsConnector assetsConnector6 = assetsConnectorMapper.selectOne(assetsWrapper6);
        assert(assetsConnector6.getStatus()==0);
        assert(assetsConnector6.getConnectStatus()==0);


        StateInfo stateInfo7 = new StateInfo();
        stateInfo7.setProviderId(1); //1科旺
        stateInfo7.setPileCode("44192019122601002");
        stateInfo7.setWorkState((byte)5);    //工作状态
        stateInfo7.setCarConnectState((byte)0);  //连接状态
        stateInfo7.setConnectorNo((byte)2);  //枪口号
        stateInfoListener.onHandlerMessage(stateInfo7);
        String code7 = stateInfo7.getCode(stateInfo7.getPileCode(),(int) stateInfo7.getConnectorNo());
        QueryWrapper<AssetsConnector> assetsWrapper7 = new QueryWrapper<>();
        assetsWrapper7.eq("code", code7);
        assetsWrapper7.eq("serial_no", stateInfo7.getConnectorNo());
        AssetsConnector assetsConnector7 = assetsConnectorMapper.selectOne(assetsWrapper7);
        assert(assetsConnector7.getStatus()==0);
        assert(assetsConnector7.getConnectStatus()==0);



        StateInfo stateInfo8 = new StateInfo();
        stateInfo8.setProviderId(1); //1科旺
        stateInfo8.setPileCode("44192019122601002");
        stateInfo8.setWorkState((byte)2);    //工作状态
        stateInfo8.setCarConnectState((byte)2);  //连接状态
        stateInfo8.setConnectorNo((byte)2);  //枪口号
        stateInfoListener.onHandlerMessage(stateInfo8);
        String code8 = stateInfo8.getCode(stateInfo8.getPileCode(),(int) stateInfo8.getConnectorNo());
        QueryWrapper<AssetsConnector> assetsWrapper8 = new QueryWrapper<>();
        assetsWrapper8.eq("code", code8);
        assetsWrapper8.eq("serial_no", stateInfo8.getConnectorNo());
        AssetsConnector assetsConnector8 = assetsConnectorMapper.selectOne(assetsWrapper);
        assert(assetsConnector8.getStatus()==1);
        assert(assetsConnector8.getConnectStatus()==1);




        StateInfo stateInfo9 = new StateInfo();
        stateInfo9.setProviderId(1); //1科旺
        stateInfo9.setPileCode("44192019122601002");
        stateInfo9.setWorkState((byte)3);    //工作状态
        stateInfo9.setCarConnectState((byte)0);  //连接状态
        stateInfo9.setConnectorNo((byte)2);  //枪口号
        stateInfoListener.onHandlerMessage(stateInfo9);

        String code9 = stateInfo9.getCode(stateInfo9.getPileCode(),(int) stateInfo9.getConnectorNo());
        QueryWrapper<AssetsConnector> assetsWrapper9 = new QueryWrapper<>();
        assetsWrapper9.eq("code", code9);
        assetsWrapper9.eq("serial_no", stateInfo9.getConnectorNo());
        AssetsConnector assetsConnector9 = assetsConnectorMapper.selectOne(assetsWrapper9);
        assert(assetsConnector9.getStatus()==2);
        assert(assetsConnector9.getConnectStatus()==0);



        StateInfo stateInfo10 = new StateInfo();
        stateInfo10.setProviderId(1); //1科旺
        stateInfo10.setPileCode("44192019122601002");
        stateInfo10.setWorkState((byte)3);    //工作状态
        stateInfo10.setCarConnectState((byte)2);  //连接状态
        stateInfo10.setConnectorNo((byte)2);  //枪口号
        stateInfoListener.onHandlerMessage(stateInfo10);
        String code10 = stateInfo10.getCode(stateInfo10.getPileCode(),(int) stateInfo10.getConnectorNo());
        QueryWrapper<AssetsConnector> assetsWrapper10 = new QueryWrapper<>();
        assetsWrapper10.eq("code", code10);
        assetsWrapper10.eq("serial_no", stateInfo10.getConnectorNo());
        AssetsConnector assetsConnector10 = assetsConnectorMapper.selectOne(assetsWrapper);
        assert(assetsConnector10.getStatus()==2);
        assert(assetsConnector10.getConnectStatus()==1);


        StateInfo stateInfo11 = new StateInfo();
        stateInfo11.setProviderId(1); //1科旺
        stateInfo11.setPileCode("44192019122601002");
        stateInfo11.setWorkState((byte)6);    //工作状态
        stateInfo11.setCarConnectState((byte)0);  //连接状态
        stateInfo11.setConnectorNo((byte)2);  //枪口号
        stateInfoListener.onHandlerMessage(stateInfo11);

        String code11 = stateInfo11.getCode(stateInfo11.getPileCode(),(int) stateInfo11.getConnectorNo());
        QueryWrapper<AssetsConnector> assetsWrapper11 = new QueryWrapper<>();
        assetsWrapper11.eq("code", code11);
        assetsWrapper11.eq("serial_no", stateInfo11.getConnectorNo());
        AssetsConnector assetsConnector11 = assetsConnectorMapper.selectOne(assetsWrapper11);
        assert(assetsConnector11.getStatus()==3);
        assert(assetsConnector11.getConnectStatus()==0);





        StateInfo stateInfo12 = new StateInfo();
        stateInfo12.setProviderId(1); //1科旺
        stateInfo12.setPileCode("44192019122601002");
        stateInfo12.setWorkState((byte)6);    //工作状态
        stateInfo12.setCarConnectState((byte)2);  //连接状态
        stateInfo12.setConnectorNo((byte)2);  //枪口号
        stateInfoListener.onHandlerMessage(stateInfo12);

        String code12 = stateInfo12.getCode(stateInfo12.getPileCode(),(int) stateInfo12.getConnectorNo());
        QueryWrapper<AssetsConnector> assetsWrapper12 = new QueryWrapper<>();
        assetsWrapper12.eq("code", code12);
        assetsWrapper12.eq("serial_no", stateInfo.getConnectorNo());
        AssetsConnector assetsConnector12 = assetsConnectorMapper.selectOne(assetsWrapper12);
        assert(assetsConnector12.getStatus()==3);
        assert(assetsConnector12.getConnectStatus()==1);


            String codes =null;
            Map map = new HashMap();
            ModuleChargingInfo moduleChargingInfo = new ModuleChargingInfo();
            moduleChargingInfo.setProviderId(2);
            map.put((byte)1,(byte)0);
            map.put((byte)2,(byte)0);
            moduleChargingInfo.setStateMap(map);    //Map<枪的位置，状态>
            moduleChargingInfo.setPileCode("ib_tjyy2");
            map.clear();
            map.put((byte)1,(byte)0);
            map.put((byte)2,(byte)0);

            moduleChargingInfo.setConnectedStateMap(map);   //枪的连接状态 Map<枪的位置，连接状态>
            moubleInfoListener.assetsConnectorStatus(moduleChargingInfo);
            map.clear();
            for (int i=1; i <= moduleChargingInfo.getStateMap().size(); i++) {
                codes = moduleChargingInfo.getCode(moduleChargingInfo.getPileCode(), i);
                assetsWrapper = new QueryWrapper<>();
                assetsWrapper.eq("code", codes);
                assetsWrapper.eq("serial_no", stateInfo.getConnectorNo());
                assetsConnector = assetsConnectorMapper.selectOne(assetsWrapper);
                assert (assetsConnector.getStatus() == 0);
                assert (assetsConnector.getConnectStatus() == 0);
            }


        moduleChargingInfo.setProviderId(2);
        map.put((byte)1,(byte)0);
        map.put((byte)2,(byte)0);
        moduleChargingInfo.setStateMap(map);    //Map<枪的位置，状态>
        moduleChargingInfo.setPileCode("ib_tjyy2");
        map.clear();
        map.put((byte)1,(byte)1);
        map.put((byte)2,(byte)1);

        moduleChargingInfo.setConnectedStateMap(map);   //枪的连接状态 Map<枪的位置，连接状态>
        moubleInfoListener.assetsConnectorStatus(moduleChargingInfo);
        map.clear();
        for (int i=1; i <= moduleChargingInfo.getStateMap().size(); i++) {
            codes = moduleChargingInfo.getCode(moduleChargingInfo.getPileCode(), i);
            assetsWrapper = new QueryWrapper<>();
            assetsWrapper.eq("code", codes);
            assetsWrapper.eq("serial_no", stateInfo.getConnectorNo());
            assetsConnector = assetsConnectorMapper.selectOne(assetsWrapper);
            assert (assetsConnector.getStatus() == 0);
            assert (assetsConnector.getConnectStatus() == 1);
        }


        moduleChargingInfo.setProviderId(2);
        map.put((byte)1,(byte)1);
        map.put((byte)2,(byte)1);
        moduleChargingInfo.setStateMap(map);    //Map<枪的位置，状态>
        moduleChargingInfo.setPileCode("ib_tjyy2");
        map.clear();
        map.put((byte)1,(byte)1);
        map.put((byte)2,(byte)1);

        moduleChargingInfo.setConnectedStateMap(map);   //枪的连接状态 Map<枪的位置，连接状态>
        moubleInfoListener.assetsConnectorStatus(moduleChargingInfo);
        map.clear();
        for (int i=1; i <= moduleChargingInfo.getStateMap().size(); i++) {
            codes = moduleChargingInfo.getCode(moduleChargingInfo.getPileCode(), i);
            assetsWrapper = new QueryWrapper<>();
            assetsWrapper.eq("code", codes);
            assetsWrapper.eq("serial_no", stateInfo.getConnectorNo());
            assetsConnector = assetsConnectorMapper.selectOne(assetsWrapper);
            assert (assetsConnector.getStatus() == 1);
            assert (assetsConnector.getConnectStatus() == 1);
        }


        moduleChargingInfo.setProviderId(2);
        map.put((byte)1,(byte)2);
        map.put((byte)2,(byte)2);
        moduleChargingInfo.setStateMap(map);    //Map<枪的位置，状态>
        moduleChargingInfo.setPileCode("ib_tjyy2");
        map.clear();
        map.put((byte)1,(byte)0);
        map.put((byte)2,(byte)0);

        moduleChargingInfo.setConnectedStateMap(map);   //枪的连接状态 Map<枪的位置，连接状态>
        moubleInfoListener.assetsConnectorStatus(moduleChargingInfo);
        map.clear();
        for (int i=1; i <= moduleChargingInfo.getStateMap().size(); i++) {
            codes = moduleChargingInfo.getCode(moduleChargingInfo.getPileCode(), i);
            assetsWrapper = new QueryWrapper<>();
            assetsWrapper.eq("code", codes);
            assetsWrapper.eq("serial_no", stateInfo.getConnectorNo());
            assetsConnector = assetsConnectorMapper.selectOne(assetsWrapper);
            assert (assetsConnector.getStatus() == 2);
            assert (assetsConnector.getConnectStatus() == 0);
        }

        moduleChargingInfo.setProviderId(2);
        map.put((byte)1,(byte)2);
        map.put((byte)2,(byte)2);
        moduleChargingInfo.setStateMap(map);    //Map<枪的位置，状态>
        moduleChargingInfo.setPileCode("ib_tjyy2");
        map.clear();
        map.put((byte)1,(byte)1);
        map.put((byte)2,(byte)1);

        moduleChargingInfo.setConnectedStateMap(map);   //枪的连接状态 Map<枪的位置，连接状态>
        moubleInfoListener.assetsConnectorStatus(moduleChargingInfo);
        map.clear();
        for (int i=1; i <= moduleChargingInfo.getStateMap().size(); i++) {
            codes = moduleChargingInfo.getCode(moduleChargingInfo.getPileCode(), i);
            assetsWrapper = new QueryWrapper<>();
            assetsWrapper.eq("code", codes);
            assetsWrapper.eq("serial_no", stateInfo.getConnectorNo());
            assetsConnector = assetsConnectorMapper.selectOne(assetsWrapper);
            assert (assetsConnector.getStatus() == 2);
            assert (assetsConnector.getConnectStatus() == 1);
        }


        moduleChargingInfo.setProviderId(2);
        map.put((byte)1,(byte)3);
        map.put((byte)2,(byte)3);
        moduleChargingInfo.setStateMap(map);    //Map<枪的位置，状态>
        moduleChargingInfo.setPileCode("ib_tjyy2");
        map.clear();
        map.put((byte)1,(byte)0);
        map.put((byte)2,(byte)0);

        moduleChargingInfo.setConnectedStateMap(map);   //枪的连接状态 Map<枪的位置，连接状态>
        moubleInfoListener.assetsConnectorStatus(moduleChargingInfo);
        map.clear();
        for (int i=1; i <= moduleChargingInfo.getStateMap().size(); i++) {
            codes = moduleChargingInfo.getCode(moduleChargingInfo.getPileCode(), i);
            assetsWrapper = new QueryWrapper<>();
            assetsWrapper.eq("code", codes);
            assetsWrapper.eq("serial_no", stateInfo.getConnectorNo());
            assetsConnector = assetsConnectorMapper.selectOne(assetsWrapper);
            assert (assetsConnector.getStatus() == 3);
            assert (assetsConnector.getConnectStatus() == 0);
        }


        moduleChargingInfo.setProviderId(2);
        map.put((byte)1,(byte)3);
        map.put((byte)2,(byte)3);
        moduleChargingInfo.setStateMap(map);    //Map<枪的位置，状态>
        moduleChargingInfo.setPileCode("ib_tjyy2");
        map.clear();
        map.put((byte)1,(byte)1);
        map.put((byte)2,(byte)1);

        moduleChargingInfo.setConnectedStateMap(map);   //枪的连接状态 Map<枪的位置，连接状态>
        moubleInfoListener.assetsConnectorStatus(moduleChargingInfo);
        map.clear();
        for (int i=1; i <= moduleChargingInfo.getStateMap().size(); i++) {
            codes = moduleChargingInfo.getCode(moduleChargingInfo.getPileCode(), i);
            assetsWrapper = new QueryWrapper<>();
            assetsWrapper.eq("code", codes);
            assetsWrapper.eq("serial_no", stateInfo.getConnectorNo());
            assetsConnector = assetsConnectorMapper.selectOne(assetsWrapper);
            assert (assetsConnector.getStatus() == 3);
            assert (assetsConnector.getConnectStatus() == 1);
        }

    }

    /**
     * 发起充电 -->准备充电
     * @throws Exception
     */
    @Test
    public void EonStartCharging() throws Exception{

        String codes =null;
        Map map = new HashMap();
        Map mapNew = new HashMap();
        ModuleChargingInfo moduleChargingInfo = new ModuleChargingInfo();
        moduleChargingInfo.setProviderId(2);
        mapNew.put((byte)1,(byte)0);
        mapNew.put((byte)2,(byte)0);
        moduleChargingInfo.setStateMap(mapNew);    //Map<枪的位置，状态>
        moduleChargingInfo.setPileCode("ib_tjyy1");

        map.put((byte)1,(byte)1);
        map.put((byte)2,(byte)1);
        moduleChargingInfo.setConnectedStateMap(map);   //枪的连接状态 Map<枪的位置，连接状态>

        moubleInfoListener.assetsConnectorStatus(moduleChargingInfo);
       /* map.clear();
        mapNew.clear();
        for (int i=1; i <= moduleChargingInfo.getStateMap().size(); i++) {
            codes = moduleChargingInfo.getCode(moduleChargingInfo.getPileCode(), i);

            QueryWrapper<AssetsConnector> assetsWrapper = new QueryWrapper<>();
            assetsWrapper.eq("code", codes);
            //assetsWrapper.eq("serial_no", stateInfo.getConnectorNo());
            AssetsConnector assetsConnector = assetsConnectorMapper.selectOne(assetsWrapper);
            assert (assetsConnector.getStatus() == 0);
            assert (assetsConnector.getConnectStatus() == 1);
        }*/
        Map map2 = new HashMap();
        map2.put("phone","15500946642");
        CommonVo commonVo = loginService.login(map2);

        Map mapToken = JSONObject.parseObject(JSONObject.toJSONString(commonVo.getdata()), Map.class);

        CommonVo commonVo1 = chargingService.start(mapToken.get("token").toString(),"ib_tjyy2_1",DateTimeUtil.getFormatDateTimeString(new Date()),0);

        log.info(commonVo1.getdata()+"c"+commonVo1.getstatus()+"1111"+commonVo1.getMsg());

        QueryWrapper<CustomerChargingorder> orderWrapper = new QueryWrapper<>();
        orderWrapper.eq("order_no", commonVo1.getdata().toString());
        CustomerChargingorder customerChargingorder = customerChargingorderMapper.selectOne(orderWrapper);

        assert (commonVo1.getdata() != null);
        assert (customerChargingorder.getChargingStatus() == 1);
        assert (customerChargingorder.getPaymentStatus() == 1);






        StateInfo stateInfo = new StateInfo();
        stateInfo.setProviderId(1); //1科旺
        stateInfo.setPileCode("44192019122601002");
        stateInfo.setWorkState((byte)0);    //工作状态
        stateInfo.setCarConnectState((byte)2);  //连接状态
        stateInfo.setConnectorNo((byte)2);  //枪口号
        stateInfoListener.onHandlerMessage(stateInfo);

        Map mapNew1 = new HashMap();
        mapNew1.put("phone",phoneNew);
        CommonVo commonVoNew1 = loginService.login(mapNew1);

        Map mapTokenNew = JSONObject.parseObject(JSONObject.toJSONString(commonVoNew1.getdata()), Map.class);

        CommonVo commonVoNew2 = chargingService.start(mapTokenNew.get("token").toString(),"4419201912260100202",DateTimeUtil.getFormatDateTimeString(new Date()),0);
        log.info(commonVoNew2.getdata()+"1123"+commonVoNew2.getMsg());
        QueryWrapper<CustomerChargingorder> orderWrapperNew = new QueryWrapper<>();
        orderWrapperNew.eq("order_no", commonVoNew2.getdata().toString());
        CustomerChargingorder customerChargingorderNew = customerChargingorderMapper.selectOne(orderWrapperNew);
        assert (commonVoNew2.getdata() != null);
        assert (customerChargingorderNew.getChargingStatus() == 1);
        assert (customerChargingorderNew.getPaymentStatus() == 1);
    }





    /**
     * 桩响应充电中
     */
    @Test
    public void FreturnStartCharging(){
        QueryWrapper<CustomerChargingorder> orderWrapperNew = new QueryWrapper<>();
        orderWrapperNew.eq("pile_provider_id",2);   //1科旺 2是宜步
        orderWrapperNew.eq("member_phone",phone);
        orderWrapperNew.orderByDesc("id");
        List<CustomerChargingorder> customerChargingorderNewList = customerChargingorderMapper.selectList(orderWrapperNew);
        PileStartedRst pileStartedRst = new PileStartedRst();
        CustomerChargingorder cco = customerChargingorderNewList.get(0);
        pileStartedRst.setMemberId(cco.getMemberId());
        pileStartedRst.setProviderId(1);
        String cnnrCode = cco.getConnectorCode();
        pileStartedRst.setPileCode(cnnrCode.substring(0,cnnrCode.length()-2));
        pileStartedRst.setConnectorNo(Byte.valueOf(cnnrCode.substring(cnnrCode.length()-1)));
        pileStartedRst.setResult(1);
        startedListener.onHandlerMessage(pileStartedRst);
        QueryWrapper<CustomerChargingorder> orderWrapperNews = new QueryWrapper<>();
        orderWrapperNews.eq("order_no",customerChargingorderNewList.get(0).getOrderNo());
        CustomerChargingorder customerChargingorderNews = customerChargingorderMapper.selectOne(orderWrapperNews);
        assert (customerChargingorderNews.getChargingStatus()==2);


        QueryWrapper<CustomerChargingorder> orderWrapperNewS = new QueryWrapper<>();
        orderWrapperNewS.eq("pile_provider_id",1);   //1科旺 2是宜步
        orderWrapperNewS.eq("member_phone",phoneNew);
        orderWrapperNewS.orderByDesc("id");
        List<CustomerChargingorder> customerChargingorderNewListS = customerChargingorderMapper.selectList(orderWrapperNewS);
        PileStartedRst pileStartedRstNew = new PileStartedRst();
        CustomerChargingorder ccos = customerChargingorderNewListS.get(0);
        pileStartedRstNew.setMemberId(ccos.getMemberId());
        String cnnrCodes=ccos.getConnectorCode();
        pileStartedRstNew.setPileCode(cnnrCodes.substring(0,cnnrCodes.length()-2));
        pileStartedRstNew.setConnectorNo(Byte.valueOf(cnnrCodes.substring(cnnrCodes.length()-1)));
        pileStartedRstNew.setResult(1);
        pileStartedRstNew.setProviderId(2);
        startedListener.onHandlerMessage(pileStartedRstNew);
        QueryWrapper<CustomerChargingorder> orderWrapper = new QueryWrapper<>();
        orderWrapper.eq("order_no",customerChargingorderNewListS.get(0).getOrderNo());
        CustomerChargingorder customerChargingorder = customerChargingorderMapper.selectOne(orderWrapper);
        assert (customerChargingorder.getChargingStatus()==2);

    }



    /**
     * 桩循环响应充电指令 -> 充电中以及轨迹
     */
    @Test
    public void GonChargingIng(){
        /*  QueryWrapper<CustomerChargingorder> orderWrapper = new QueryWrapper<>();
        orderWrapper.eq("pile_provider_id",1);   //1科旺 2是宜步
        orderWrapper.orderByDesc("id");
        List<CustomerChargingorder> customerChargingorderNewList = customerChargingorderMapper.selectList(orderWrapper);
        QueryWrapper<CustomerChargingorder> orderWrapperNew = new QueryWrapper<>();
        orderWrapperNew.eq("order_no",customerChargingorderNewList.get(0).getOrderNo());
        CustomerChargingorder customerChargingorder = customerChargingorderMapper.selectOne(orderWrapperNew);


        StateInfo stateInfo = new StateInfo();
        String cnnrCodes = customerChargingorder.getConnectorCode();

        redisUtil.set(customerChargingorder.getConnectorCode().substring(0,cnnrCodes.length()-2)
                +"0"+customerChargingorder.getConnectorCode().substring(cnnrCodes.length()-1),customerChargingorder.getMemberId());
        stateInfo.setPileCode(cnnrCodes.substring(0,cnnrCodes.length()-2));
        stateInfo.setProviderId(1);
        stateInfo.setWorkState((byte) 2);
        stateInfo.setChargeTime(1000);//充电时长 秒
        stateInfo.setChargePowerCount(10.0); //累计充电电量 * 0.01
        stateInfo.setCurrentSOC((byte) 97); //电池电量
        stateInfo.setCurrentQuliety(366.0);//电表读数*0.01
        stateInfo.setDCChargeElectric(10.6);//电流
        stateInfo.setDCChargePressure(380.0);//电压
        stateInfo.setResidueChargeTime(6); //剩余充电时间 分钟 *60
        stateInfo.setChargePower(1.1); //当前充电功率  *0.1
        stateInfo.setConnectorNo((byte) 2);
        stateInfo.setConnectorCount((byte) 2);
        stateInfoListener.setNewCustomerChargingordertracks(stateInfo);*/





        QueryWrapper<CustomerChargingorder> orderWrapperNewS = new QueryWrapper<>();
        orderWrapperNewS.eq("pile_provider_id",2);   //1科旺 2是宜步
        orderWrapperNewS.orderByDesc("id");
        List<CustomerChargingorder> customerChargingorderList = customerChargingorderMapper.selectList(orderWrapperNewS);
        QueryWrapper<CustomerChargingorder> orderWrapperNewes = new QueryWrapper<>();
        orderWrapperNewes.eq("order_no",customerChargingorderList.get(0).getOrderNo());
        CustomerChargingorder customerChargingorderNew = customerChargingorderMapper.selectOne(orderWrapperNewes);
        String cnnrCodess = customerChargingorderNew.getConnectorCode();
        redisUtil.set(customerChargingorderNew.getConnectorCode().substring(0,cnnrCodess.length()-2)
                +"_"+customerChargingorderNew.getConnectorCode().substring(cnnrCodess.length()-1),customerChargingorderNew.getMemberId());

        ModuleChargingInfo moduleChargingInfo = new ModuleChargingInfo();
        moduleChargingInfo.setProviderId(2);        //2是宜步
        Map map1 = new HashMap();
        map1.put((byte)1,(byte)0);
        map1.put((byte)2,(byte)0);
        moduleChargingInfo.setStateMap(map1);    //Map<枪的位置，状态>
        moduleChargingInfo.setPileCode(customerChargingorderNew.getConnectorCode().substring(0,cnnrCodess.length()-2));

        Map map2 = new HashMap();
        map2.put((byte)1,(byte)1);
        map2.put((byte)2,(byte)1);
        moduleChargingInfo.setConnectedStateMap(map2);   //枪的连接状态 Map<枪的位置，连接状态>

       // moubleInfoListener.assetsConnectorStatus(moduleChargingInfo);
        Map map3 = new HashMap();
        map3.put((byte)1,(byte)11);
        map3.put((byte)2,(byte)22);
        moduleChargingInfo.setSocBeginMap(map3);    //充电枪位置N起始充电SOC   Map<充电枪位置, soc>
        Map map4 = new HashMap();
        map4.put((byte)1,11);
        map4.put((byte)2,22);
        moduleChargingInfo.setAhMap(map4);  	//位置N本次累计充电Ah  Map<充电枪位置, Ah>
        Map map5 = new HashMap();
        map5.put((byte)1,20);
        map5.put((byte)2,10);
        moduleChargingInfo.setTimeMap(map5);    //位置N本次累计充电时间  Map<充电枪位置, 时间> *60
        Map map6 = new HashMap();
        map6.put((byte)1,2200.0);
        map6.put((byte)2,3800.0);
        moduleChargingInfo.setVoltageMap(map6); //位置N电压V  Map<充电枪位置, V> *0.1
        Map map7 = new HashMap();
        map7.put((byte)1,554526.0);
        map7.put((byte)2,336250.0);
        moduleChargingInfo.setKwhMap(map7); //位置N电表度数kwh  Map<充电枪位置, kwh> *0.01
        Map map8 = new HashMap();
        map8.put((byte)1,4200.0);
        map8.put((byte)2,3500.0);

        moduleChargingInfo.setKwhTotalMap(map8);    //位置N本次累计充电kwh  Map<充电枪位置, kwh>10 *0.01

        Map map9 = new HashMap();
        map9.put((byte)1,150.0);
        map9.put((byte)2,100.0);
        moduleChargingInfo.setCurrentMap(map9);     //位置N电流A  Map<充电枪位置, A>  0.1
        Map map10 = new HashMap();
        map10.put((byte)1,(byte)70);
        map10.put((byte)2,(byte)80);
        moduleChargingInfo.setSocNowMap(map10); //充电枪位置N当前SOC   Map<充电枪位置, soc>
        Map map11 = new HashMap();
        map11.put((byte)1,5);
        map11.put((byte)2,10);
        moduleChargingInfo.setRemainTimeMap(map11); //预估充满时间(分钟)  Map<充电枪位置, 分钟> * 60
        moubleInfoListener.onHandlerMessage(moduleChargingInfo);

    }

    /**
     *   充电中 -> 充电结束中
     */
    @Test
    public void HstopChargingEndIng(){
        Map mapNew1 = new HashMap();
        mapNew1.put("phone",phone);
        CommonVo commonVoNew1 = loginService.login(mapNew1);
        mainTest.mainStopChargingEndIng(commonVoNew1);

        Map mapNew = new HashMap();
        mapNew.put("phone",phoneNew);
        CommonVo commonVoNew = loginService.login(mapNew);
        mainTest.mainStopChargingEndIng(commonVoNew);

    }


    /**
     * 桩响应指令  充电结束中 -> 充电结束
     */
    @Test
    public void IstopChargingEnd(){
        PileCtrl pileCtrl = new PileCtrl();
        pileCtrl.setResultCode(1);                  //科旺
        pileCtrl.setPileCode("44192019122601002");
        pileCtrl.setProviderId(1);
        pileCtrl.setConnectorNo((byte)2);
        pileCtrl.setVinCar("123456");
        stopChargingListener.onHandlerMessage(pileCtrl);

        PileCtrl pileCtrlNew = new PileCtrl();
        pileCtrlNew.setResultCode(1);                  //宜步
        pileCtrlNew.setPileCode("ib_tjyy2");
        pileCtrlNew.setProviderId(2);
        pileCtrlNew.setConnectorNo((byte)1);
        pileCtrl.setVinCar("654321");
        stopChargingListener.onHandlerMessage(pileCtrlNew);
    }


    /***
     * 扣费  充电结束 -> 已支付
     */
    @Test
    public void JsetOrder(){
        Map map2 = new HashMap();
        map2.put("phone",phone);
        CommonVo commonVo = loginService.login(map2);
        mainTest.mainSetOrder( commonVo);
        Map mapNew = new HashMap();
        mapNew.put("phone",phoneNew);
        CommonVo commonVoNew = loginService.login(mapNew);
        mainTest.mainSetOrder(commonVoNew);


    }


/**
 * 急停
 */
    @Test
    public void emergencyStop(){
        ChargeRecordInfo chargeRecordInfo = new ChargeRecordInfo();
        chargeRecordInfo.setChargeStopCause(1);     //1和5都是急停普捉
        chargeRecordInfo.setPileCode("ib_tjyy1");
        chargeRecordInfo.setConnectorNo(2);
        chargeRecordInfo.setProviderId(2);
        chargeRecordInfo.setStopSOC(0);
        chargeRecordInfo.setStartSOC(0);
        chargeRecordInfo.setBeforeAmmeterNum(1.0);
        chargeRecordInfo.setAfterAmmeterNum(2.0);
        //chargeRecordInfo.setChargeStopCause(12);

        String code = chargeRecordInfo.getCode(chargeRecordInfo.getPileCode(),(int) chargeRecordInfo.getConnectorNo());
        //redisUtil.set(code,10);
        chargeRecordInfoListener.onHandlerMessage(chargeRecordInfo);
    }


    //余额不足自动停止充电
    @Test
    public void testWallet(){

        QueryWrapper<CustomerChargingorder> orderWrapperNewS = new QueryWrapper<>();
        orderWrapperNewS.eq("pile_provider_id",2);   //1科旺 2是宜步
        orderWrapperNewS.orderByDesc("id");
        List<CustomerChargingorder> customerChargingorderList = customerChargingorderMapper.selectList(orderWrapperNewS);
        QueryWrapper<CustomerChargingorder> orderWrapperNewes = new QueryWrapper<>();
        orderWrapperNewes.eq("order_no",customerChargingorderList.get(0).getOrderNo());
        CustomerChargingorder customerChargingorderNew = customerChargingorderMapper.selectOne(orderWrapperNewes);
        String cnnrCodess = customerChargingorderNew.getConnectorCode();
        redisUtil.set(customerChargingorderNew.getConnectorCode().substring(0,cnnrCodess.length()-2)
                +"_"+customerChargingorderNew.getConnectorCode().substring(cnnrCodess.length()-1),customerChargingorderNew.getMemberId());

        ModuleChargingInfo moduleChargingInfo = new ModuleChargingInfo();
        moduleChargingInfo.setProviderId(2);        //2是宜步
        Map map1 = new HashMap();
        map1.put((byte)1,(byte)1);
        map1.put((byte)2,(byte)1);
        moduleChargingInfo.setStateMap(map1);    //Map<枪的位置，状态>
        moduleChargingInfo.setPileCode(customerChargingorderNew.getConnectorCode().substring(0,cnnrCodess.length()-2));

        Map map2 = new HashMap();
        map2.put((byte)1,(byte)1);
        map2.put((byte)2,(byte)1);
        moduleChargingInfo.setConnectedStateMap(map2);   //枪的连接状态 Map<枪的位置，连接状态>

        // moubleInfoListener.assetsConnectorStatus(moduleChargingInfo);
        Map map3 = new HashMap();
        map3.put((byte)1,(byte)11);
        map3.put((byte)2,(byte)22);
        moduleChargingInfo.setSocBeginMap(map3);    //充电枪位置N起始充电SOC   Map<充电枪位置, soc>
        Map map4 = new HashMap();
        map4.put((byte)1,11);
        map4.put((byte)2,22);
        moduleChargingInfo.setAhMap(map4);  	//位置N本次累计充电Ah  Map<充电枪位置, Ah>
        Map map5 = new HashMap();
        map5.put((byte)1,20);
        map5.put((byte)2,10);
        moduleChargingInfo.setTimeMap(map5);    //位置N本次累计充电时间  Map<充电枪位置, 时间> *60
        Map map6 = new HashMap();
        map6.put((byte)1,2200.0);
        map6.put((byte)2,3800.0);
        moduleChargingInfo.setVoltageMap(map6); //位置N电压V  Map<充电枪位置, V> *0.1
        Map map7 = new HashMap();
        map7.put((byte)1,554526.0);
        map7.put((byte)2,336250.0);
        moduleChargingInfo.setKwhMap(map7); //位置N电表度数kwh  Map<充电枪位置, kwh> *0.01
        Map map8 = new HashMap();
        map8.put((byte)1,4200.0);
        map8.put((byte)2,3500.0);

        moduleChargingInfo.setKwhTotalMap(map8);    //位置N本次累计充电kwh  Map<充电枪位置, kwh>10 *0.01

        Map map9 = new HashMap();
        map9.put((byte)1,150.0);
        map9.put((byte)2,100.0);
        moduleChargingInfo.setCurrentMap(map9);     //位置N电流A  Map<充电枪位置, A>  0.1
        Map map10 = new HashMap();
        map10.put((byte)1,(byte)70);
        map10.put((byte)2,(byte)80);
        moduleChargingInfo.setSocNowMap(map10); //充电枪位置N当前SOC   Map<充电枪位置, soc>
        Map map11 = new HashMap();
        map11.put((byte)1,5);
        map11.put((byte)2,10);
        moduleChargingInfo.setRemainTimeMap(map11); //预估充满时间(分钟)  Map<充电枪位置, 分钟> * 60
        moubleInfoListener.onHandlerMessage(moduleChargingInfo);

    }

    /**
     * 	//充电机故障编码  4字节	每位表示一个故障
     * 	private long faultCode;
     *
     * 	private byte connectorCnt;//充电枪数量
     * 	//充电枪位置N充电类型  1=直流；2=交流  Map<充电枪位置, 类型>
     * 	private Map<Byte, Byte> typeMap;
     *
     * 	//位置N状态 0：充电位待机 1：充电中 2：充电结束 3：充电位故障
     * 	//Map<充电枪位置, 状态>
     * 	private Map<Byte, Byte> stateMap;
     *
     * 	//位置N本次累计充电kwh  Map<充电枪位置, kwh>10
     * 	private Map<Byte, Double> kwhTotalMap;
     *
     * 	//位置N本次累计充电Ah  Map<充电枪位置, Ah>
     * 	private Map<Byte, Integer> ahMap;
     *
     * 	//位置N本次累计充电时间  Map<充电枪位置, 时间>
     * 	private Map<Byte, Integer> timeMap;
     *
     * 	//充电枪位置N起始充电SOC   Map<充电枪位置, soc>
     * 	private Map<Byte, Byte> socBeginMap;
     *
     * 	//充电枪位置N当前SOC   Map<充电枪位置, soc>
     * 	private Map<Byte, Byte> socNowMap;
     *
     * 	//位置N电表度数kwh  Map<充电枪位置, kwh>
     * 	private Map<Byte, Double> kwhMap;
     *
     * 	//位置N电压V  Map<充电枪位置, V>
     * 	private Map<Byte, Double> voltageMap;
     *
     * 	//位置N电流A  Map<充电枪位置, A>
     * 	private Map<Byte, Double> currentMap;
     *
     * 	//预估充满时间(分钟)  Map<充电枪位置, 分钟>
     * 	private Map<Byte, Integer> remainTimeMap;
     *
     * 	//充电枪位置N连接状态   Map<充电枪位置, 连接状态>  0未连接，1已连接
     * 	private Map<Byte, Byte> connectedStateMap;
     */

}
