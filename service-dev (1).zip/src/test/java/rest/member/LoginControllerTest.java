package rest.member;

import com.gdcdgj.charging.api.localService.login.LoginService;
import javafx.application.Application;
import org.apache.ibatis.annotations.Param;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import javax.annotation.Resource;

import java.util.HashMap;
import java.util.Map;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * 测试登录、注册、退出
 *
 * @author Changliang Tao
 * @date 2020/4/24 10:34
 * @since JDK 1.8
 */
@SpringBootTest(classes = Application.class)
@AutoConfigureMockMvc
class LoginControllerTest {
    @Autowired
    MockMvc mockMvc;
    @Resource
    private LoginService loginService;

    @Test
    void login() throws Exception {
        MockHttpServletRequestBuilder requestBuilder = post("/login/13903904434");
        mockMvc.perform(requestBuilder)
                .andExpect(status().isOk())
                .andDo(print());

    }

    @Test
    void chargingNew() throws Exception {


    }





    @Test
    void register() throws Exception {
        MockHttpServletRequestBuilder requestBuilder = post("/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{ \"phone\": \"15776639962\"}".getBytes());
        mockMvc.perform(requestBuilder)
                .andExpect(status().isOk())
                .andDo(print());
    }

    @Test
    void logout() {
    }
}
